# dtm-lausitzring-2012-r2

Event: DTM Lausitzring | Circuit: Lausitzring | Date: 2012-05-06
Scheduled: ? | Official duration: 1:09:45.795 | Laps (winner): 52

## Qualifying (archive order)
Q1 #7 [DTMV8] 1:18.777 BMW Team Schnitzer | Bruno Spengler
Q2 #16 [DTMV8] 1:18.815 BMW Team RBM | Augusto Farfus
Q3 #11 [DTMV8] 1:18.820 HWA Team | Gary Paffett
Q4 #9 [DTMV8] 1:19.206 Phoenix Racing | Mike Rockenfeller
Q5 #21 [DTMV8] 1:18.374 Team Rosberg | Edoardo Mortara
Q6 #5 [DTMV8] 1:18.461 Mercedes AMG | Jamie Green
Q7 #1 [DTMV8] 1:18.490 BMW Team RMG | Martin Tomczyk
Q8 #3 [DTMV8] 1:18.569 Abt Sportsline | Mattias Ekström
Q9 #10 [DTMV8] 1:18.667 Phoenix Racing | Miguel Molina
Q10 #18 [DTMV8] 1:18.686 Audi Sport Team Abt | Adrien Tambay
Q11 #22 [DTMV8] 1:18.749 Team Rosberg | Filipe Albuquerque
Q12 #4 [DTMV8] 1:18.758 Abt Sportsline | Timo Scheider
Q13 #15 [DTMV8] 1:18.771 BMW Team RBM | Andy Priaulx
Q14 #2 [DTMV8] 1:18.817 BMW Team RMG | Joey Hand
Q15 #20 [DTMV8] 1:18.840 Mücke Motorsport | Robert Wickens
Q16 #12 [DTMV8] 1:18.862 HWA Team | Christian Vietoris
Q17 #6 [DTMV8] 1:19.506 Mercedes AMG | Ralf Schumacher
Q18 #23 [DTMV8] 1:19.557 Persson Motorsport | Roberto Merhi
Q19 #24 [DTMV8] 1:19.584 Persson Motorsport | Susie Wolff
Q20 #19 [DTMV8] 1:19.672 Mücke Motorsport | David Coulthard
Q21 #8 [DTMV8] 1:19.737 BMW Team Schnitzer | Dirk Werner
Q22 #17 [DTMV8] 1:20.415 Audi Sport Team Abt | Rahel Frey

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #7 Bruno Spengler 1:18.777 BMW Team Schnitzer
DTMV8: #7 Bruno Spengler 1:18.777 BMW Team Schnitzer

## Fastest laps (archive)
Overall: #5 Jamie Green 1:19.025 lap 29
DTMV8: #5 Jamie Green 1:19.025 lap 29

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #7 BMW Team Schnitzer | BMW M3 DTM | Classified 52L gap — | Bruno Spengler
 2 g3 #11 HWA Team | Mercedes AMG C-Coupé | Classified 52L gap 1.019 | Gary Paffett
 3 g2 #16 BMW Team RBM | BMW M3 DTM | Classified 52L gap 7.069 | Augusto Farfus
 4 g6 #5 Mercedes AMG | Mercedes AMG C-Coupé | Classified 52L gap 7.676 | Jamie Green
 5 g8 #3 Abt Sportsline | Audi A5 DTM | Classified 52L gap 21.362 | Mattias Ekström
 6 g12 #4 Abt Sportsline | Audi A5 DTM | Classified 52L gap 22.607 | Timo Scheider
 7 g7 #1 BMW Team RMG | BMW M3 DTM | Classified 52L gap 25.446 | Martin Tomczyk
 8 g5 #21 Team Rosberg | Audi A5 DTM | Classified 52L gap 32.202 | Edoardo Mortara
 9 g11 #22 Team Rosberg | Audi A5 DTM | Classified 52L gap 32.658 | Filipe Albuquerque
 10 g16 #6 Mercedes AMG | Mercedes AMG C-Coupé | Classified 52L gap 35.513 | Ralf Schumacher
 11 g18 #12 HWA Team | Mercedes AMG C-Coupé | Classified 52L gap 45.699 | Christian Vietoris
 12 g20 #19 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 52L gap 46.355 | David Coulthard
 13 g4 #9 Phoenix Racing | Audi A5 DTM | Classified 52L gap 47.667 | Mike Rockenfeller
 14 g14 #2 BMW Team RMG | BMW M3 DTM | Classified 52L gap 48.034 | Joey Hand
 15 g9 #10 Phoenix Racing | Audi A5 DTM | Classified 52L gap 48.836 | Miguel Molina
 16 g17 #23 Persson Motorsport | Mercedes AMG C-Coupé | Classified 52L gap 56.454 | Roberto Merhi
 17 g13 #15 BMW Team RBM | BMW M3 DTM | Classified 52L gap 58.984 | Andy Priaulx
 18 g10 #18 Audi Sport Team Abt | Audi A5 DTM | Classified 52L gap 1:04.646 | Adrien Tambay
 19 g21 #8 BMW Team Schnitzer | BMW M3 DTM | Classified 52L gap 1:05.201 | Dirk Werner
 20 g22 #17 Audi Sport Team Abt | Audi A5 DTM | Classified 52L gap 1:08.570 | Rahel Frey
 21 g19 #24 Persson Motorsport | Mercedes AMG C-Coupé | Classified 51L gap 1 LAP | Susie Wolff
 22 g15 #20 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 47L gap 5 LAPS | Robert Wickens
