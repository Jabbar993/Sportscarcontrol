# dtm-circuitricardotormo-2012-r9

Event: DTM Circuit Ricardo Tormo | Circuit: Ricardo Tormo | Date: 2012-09-30
Scheduled: ? | Official duration: 1:08:22.522 | Laps (winner): 46

## Qualifying (archive order)
Q1 #16 [DTMV8] 1:26.446 BMW Team RBM | Augusto Farfus
Q2 #21 [DTMV8] 1:26.756 Team Rosberg | Edoardo Mortara
Q3 #22 [DTMV8] 1:26.894 Team Rosberg | Filipe Albuquerque
Q4 #18 [DTMV8] 1:26.981 Audi Sport Team Abt | Adrien Tambay
Q5 #9 [DTMV8] 1:26.789 Phoenix Racing | Mike Rockenfeller
Q6 #15 [DTMV8] 1:26.824 BMW Team RBM | Andy Priaulx
Q7 #4 [DTMV8] 1:26.849 Abt Sportsline | Timo Scheider
Q8 #3 [DTMV8] 1:26.936 Abt Sportsline | Mattias Ekström
Q9 #8 [DTMV8] 1:27.039 BMW Team Schnitzer | Dirk Werner
Q10 #10 [DTMV8] 1:27.040 Phoenix Racing | Miguel Molina
Q11 #1 [DTMV8] 1:26.813 BMW Team RMG | Martin Tomczyk
Q12 #7 [DTMV8] 1:26.818 BMW Team Schnitzer | Bruno Spengler
Q13 #2 [DTMV8] 1:26.977 BMW Team RMG | Joey Hand
Q14 #20 [DTMV8] 1:27.128 Mücke Motorsport | Robert Wickens
Q15 #17 [DTMV8] 1:27.260 Audi Sport Team Abt | Rahel Frey
Q16 #11 [DTMV8] 1:27.288 HWA Team | Gary Paffett
Q17 #23 [DTMV8] 1:27.377 Persson Motorsport | Roberto Merhi
Q18 #5 [DTMV8] 1:27.380 Mercedes AMG | Jamie Green
Q19 #12 [DTMV8] 1:27.454 HWA Team | Christian Vietoris
Q20 #24 [DTMV8] 1:27.533 Persson Motorsport | Susie Wolff
Q21 #19 [DTMV8] 1:28.012 Mücke Motorsport | David Coulthard
Q22 #6 [DTMV8] 1:28.090 Mercedes AMG | Ralf Schumacher

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #16 Augusto Farfus 1:26.446 BMW Team RBM
DTMV8: #16 Augusto Farfus 1:26.446 BMW Team RBM

## Fastest laps (archive)
Overall: #7 Bruno Spengler 1:27.116 lap 32
DTMV8: #7 Bruno Spengler 1:27.116 lap 32

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #16 BMW Team RBM | BMW M3 DTM | Classified 46L gap — | Augusto Farfus
 2 g4 #18 Audi Sport Team Abt | Audi A5 DTM | Classified 46L gap 8.406 | Adrien Tambay
 3 g8 #3 Abt Sportsline | Audi A5 DTM | Classified 46L gap 8.967 | Mattias Ekström
 4 g3 #22 Team Rosberg | Audi A5 DTM | Classified 46L gap 23.067 | Filipe Albuquerque
 5 g5 #9 Phoenix Racing | Audi A5 DTM | Classified 46L gap 28.066 | Mike Rockenfeller
 6 g12 #7 BMW Team Schnitzer | BMW M3 DTM | Classified 46L gap 39.831 | Bruno Spengler
 7 g15 #17 Audi Sport Team Abt | Audi A5 DTM | Classified 46L gap 48.318 | Rahel Frey
 8 g6 #15 BMW Team RBM | BMW M3 DTM | Classified 46L gap 49.562 | Andy Priaulx
 9 g9 #8 BMW Team Schnitzer | BMW M3 DTM | Classified 46L gap 58.327 | Dirk Werner
 10 g18 #5 Mercedes AMG | Mercedes AMG C-Coupé | Classified 46L gap 1:10.596 | Jamie Green
 11 g21 #19 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 46L gap 1:12.228 | David Coulthard
 12 g19 #12 HWA Team | Mercedes AMG C-Coupé | Classified 46L gap 1:20.388 | Christian Vietoris
 13 g20 #24 Persson Motorsport | Mercedes AMG C-Coupé | Classified 45L gap 1 LAP | Susie Wolff
 14 g22 #6 Mercedes AMG | Mercedes AMG C-Coupé | Classified 45L gap 1 LAP | Ralf Schumacher
 15 g13 #2 BMW Team RMG | BMW M3 DTM | Classified 42L gap 4 LAPS | Joey Hand
 16 g2 #21 Team Rosberg | Audi A5 DTM | Classified 38L gap 8 LAPS | Edoardo Mortara
 17 g7 #4 Abt Sportsline | Audi A5 DTM | RET 29L gap RET | Timo Scheider
 18 g16 #11 HWA Team | Mercedes AMG C-Coupé | RET 27L gap RET | Gary Paffett
 19 g10 #10 Phoenix Racing | Audi A5 DTM | RET 25L gap RET | Miguel Molina
 20 g14 #20 Mücke Motorsport | Mercedes AMG C-Coupé | RET 3L gap RET | Robert Wickens
 21 g17 #23 Persson Motorsport | Mercedes AMG C-Coupé | RET 1L gap RET | Roberto Merhi
 22 g11 #1 BMW Team RMG | BMW M3 DTM | RET 0L gap RET | Martin Tomczyk
