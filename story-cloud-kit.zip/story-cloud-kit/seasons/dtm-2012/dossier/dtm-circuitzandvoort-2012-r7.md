# dtm-circuitzandvoort-2012-r7

Event: DTM Circuit Zandvoort | Circuit: Zandvoort | Date: 2012-08-26
Scheduled: ? | Official duration: 1:16:17.679 | Laps (winner): 43

## Qualifying (archive order)
Q1 #4 [DTMV8] 1:32.365 Abt Sportsline | Timo Scheider
Q2 #9 [DTMV8] 1:32.615 Phoenix Racing | Mike Rockenfeller
Q3 #22 [DTMV8] 1:32.936 Team Rosberg | Filipe Albuquerque
Q4 #21 [DTMV8] 1:33.094 Team Rosberg | Edoardo Mortara
Q5 #3 [DTMV8] 1:31.605 Abt Sportsline | Mattias Ekström
Q6 #5 [DTMV8] 1:31.643 Mercedes AMG | Jamie Green
Q7 #8 [DTMV8] 1:31.767 BMW Team Schnitzer | Dirk Werner
Q8 #11 [DTMV8] 1:31.820 HWA Team | Gary Paffett
Q9 #12 [DTMV8] 1:31.973 HWA Team | Christian Vietoris
Q10 #18 [DTMV8] 1:32.127 Audi Sport Team Abt | Adrien Tambay
Q11 #1 [DTMV8] 1:31.992 BMW Team RMG | Martin Tomczyk
Q12 #20 [DTMV8] 1:31.997 Mücke Motorsport | Robert Wickens
Q13 #10 [DTMV8] 1:32.092 Phoenix Racing | Miguel Molina
Q14 #23 [DTMV8] 1:32.241 Persson Motorsport | Roberto Merhi
Q15 #6 [DTMV8] 1:32.295 Mercedes AMG | Ralf Schumacher
Q16 #15 [DTMV8] 1:32.445 BMW Team RBM | Andy Priaulx
Q17 #2 [DTMV8] 1:33.052 BMW Team RMG | Joey Hand
Q18 #7 [DTMV8] 1:33.156 BMW Team Schnitzer | Bruno Spengler
Q19 #24 [DTMV8] 1:33.161 Persson Motorsport | Susie Wolff
Q20 #16 [DTMV8] 1:33.285 BMW Team RBM | Augusto Farfus
Q21 #17 [DTMV8] 1:33.327 Audi Sport Team Abt | Rahel Frey
Q22 #19 [DTMV8] 1:33.409 Mücke Motorsport | David Coulthard

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #4 Timo Scheider 1:32.365 Abt Sportsline
DTMV8: #4 Timo Scheider 1:32.365 Abt Sportsline

## Fastest laps (archive)
Overall: #11 Gary Paffett 1:34.054 lap 13
DTMV8: #11 Gary Paffett 1:34.054 lap 13

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g4 #21 Team Rosberg | Audi A5 DTM | Classified 43L gap — | Edoardo Mortara
 2 g2 #9 Phoenix Racing | Audi A5 DTM | Classified 43L gap 1.513 | Mike Rockenfeller
 3 g5 #3 Abt Sportsline | Audi A5 DTM | Classified 43L gap 8.417 | Mattias Ekström
 4 g6 #5 Mercedes AMG | Mercedes AMG C-Coupé | Classified 43L gap 13.283 | Jamie Green
 5 g10 #18 Audi Sport Team Abt | Audi A5 DTM | Classified 43L gap 21.313 | Adrien Tambay
 6 g18 #7 BMW Team Schnitzer | BMW M3 DTM | Classified 43L gap 26.397 | Bruno Spengler
 7 g8 #11 HWA Team | Mercedes AMG C-Coupé | Classified 43L gap 33.791 | Gary Paffett
 8 g7 #8 BMW Team Schnitzer | BMW M3 DTM | Classified 43L gap 33.923 | Dirk Werner
 9 g20 #16 BMW Team RBM | BMW M3 DTM | Classified 43L gap 34.706 | Augusto Farfus
 10 g15 #6 Mercedes AMG | Mercedes AMG C-Coupé | Classified 43L gap 36.380 | Ralf Schumacher
 11 g14 #23 Persson Motorsport | Mercedes AMG C-Coupé | Classified 43L gap 36.771 | Roberto Merhi
 12 g19 #24 Persson Motorsport | Mercedes AMG C-Coupé | Classified 43L gap 43.135 | Susie Wolff
 13 g16 #15 BMW Team RBM | BMW M3 DTM | Classified 43L gap 53.127 | Andy Priaulx
 14 g17 #2 BMW Team RMG | BMW M3 DTM | Classified 42L gap 1 LAP | Joey Hand
 15 g3 #22 Team Rosberg | Audi A5 DTM | Classified 34L gap 9 LAPS | Filipe Albuquerque
 16 g11 #1 BMW Team RMG | BMW M3 DTM | RET 28L gap RET | Martin Tomczyk
 17 g22 #19 Mücke Motorsport | Mercedes AMG C-Coupé | RET 22L gap RET | David Coulthard
 18 g1 #4 Abt Sportsline | Audi A5 DTM | RET 6L gap RET | Timo Scheider
 19 g9 #12 HWA Team | Mercedes AMG C-Coupé | RET 1L gap RET | Christian Vietoris
 20 g12 #20 Mücke Motorsport | Mercedes AMG C-Coupé | RET 0L gap RET | Robert Wickens
 21 g13 #10 Phoenix Racing | Audi A5 DTM | RET 0L gap RET | Miguel Molina
 22 g21 #17 Audi Sport Team Abt | Audi A5 DTM | RET 0L gap RET | Rahel Frey
