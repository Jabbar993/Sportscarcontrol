# dtm-norisring-2012-r5

Event: DTM Norisring | Circuit: Norisring | Date: 2012-07-01
Scheduled: ? | Official duration: 1:15:00.005 | Laps (winner): 78

## Qualifying (archive order)
Q1 #11 [DTMV8] 49.139 HWA Team | Gary Paffett
Q2 #5 [DTMV8] 49.171 Mercedes AMG | Jamie Green
Q3 #16 [DTMV8] 49.255 BMW Team RBM | Augusto Farfus
Q4 #3 [DTMV8] 49.369 Abt Sportsline | Mattias Ekström
Q5 #6 [DTMV8] 49.023 Mercedes AMG | Ralf Schumacher
Q6 #1 [DTMV8] 49.049 BMW Team RMG | Martin Tomczyk
Q7 #7 [DTMV8] 49.100 BMW Team Schnitzer | Bruno Spengler
Q8 #12 [DTMV8] 49.156 HWA Team | Christian Vietoris
Q9 #15 [DTMV8] 49.186 BMW Team RBM | Andy Priaulx
Q10 #21 [DTMV8] 49.195 Team Rosberg | Edoardo Mortara
Q11 #9 [DTMV8] 49.029 Phoenix Racing | Mike Rockenfeller
Q12 #18 [DTMV8] 49.038 Audi Sport Team Abt | Adrien Tambay
Q13 #22 [DTMV8] 49.091 Team Rosberg | Filipe Albuquerque
Q14 #19 [DTMV8] 49.130 Mücke Motorsport | David Coulthard
Q15 #2 [DTMV8] 49.135 BMW Team RMG | Joey Hand
Q16 #8 [DTMV8] 49.297 BMW Team Schnitzer | Dirk Werner
Q17 #20 [DTMV8] 49.248 Mücke Motorsport | Robert Wickens
Q18 #23 [DTMV8] 49.348 Persson Motorsport | Roberto Merhi
Q19 #24 [DTMV8] 49.378 Persson Motorsport | Susie Wolff
Q20 #10 [DTMV8] 49.466 Phoenix Racing | Miguel Molina
Q21 #4 [DTMV8] 49.525 Abt Sportsline | Timo Scheider
Q22 #17 [DTMV8] 49.539 Audi Sport Team Abt | Rahel Frey

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #11 Gary Paffett 49.139 HWA Team
DTMV8: #11 Gary Paffett 49.139 HWA Team

## Fastest laps (archive)
Overall: #5 Jamie Green 54.451 lap 72
DTMV8: #5 Jamie Green 54.451 lap 72

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g2 #5 Mercedes AMG | Mercedes AMG C-Coupé | Classified 78L gap — | Jamie Green
 2 g6 #1 BMW Team RMG | BMW M3 DTM | Classified 78L gap 0.687 | Martin Tomczyk
 3 g7 #7 BMW Team Schnitzer | BMW M3 DTM | Classified 78L gap 2.335 | Bruno Spengler
 4 g1 #11 HWA Team | Mercedes AMG C-Coupé | Classified 78L gap 14.666 | Gary Paffett
 5 g14 #19 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 78L gap 36.861 | David Coulthard
 6 g11 #9 Phoenix Racing | Audi A5 DTM | Classified 78L gap 37.062 | Mike Rockenfeller
 7 g9 #15 BMW Team RBM | BMW M3 DTM | Classified 78L gap 44.529 | Andy Priaulx
 8 g8 #12 HWA Team | Mercedes AMG C-Coupé | Classified 78L gap 46.236 | Christian Vietoris
 9 g17 #20 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 78L gap 49.254 | Robert Wickens
 10 g16 #8 BMW Team Schnitzer | BMW M3 DTM | Classified 78L gap 49.301 | Dirk Werner
 11 g13 #22 Team Rosberg | Audi A5 DTM | Classified 77L gap 1 LAP | Filipe Albuquerque
 12 g20 #10 Phoenix Racing | Audi A5 DTM | Classified 77L gap 1 LAP | Miguel Molina
 13 g18 #23 Persson Motorsport | Mercedes AMG C-Coupé | Classified 77L gap 1 LAP | Roberto Merhi
 14 g15 #2 BMW Team RMG | BMW M3 DTM | Classified 77L gap 1 LAP | Joey Hand
 15 g12 #18 Audi Sport Team Abt | Audi A5 DTM | Classified 76L gap 2 LAPS | Adrien Tambay
 16 g21 #4 Abt Sportsline | Audi A5 DTM | Classified 76L gap 2 LAPS | Timo Scheider
 17 g22 #17 Audi Sport Team Abt | Audi A5 DTM | Classified 75L gap 3 LAPS | Rahel Frey
 18 g5 #6 Mercedes AMG | Mercedes AMG C-Coupé | RET 45L gap RET | Ralf Schumacher
 19 g10 #21 Team Rosberg | Audi A5 DTM | RET 41L gap RET | Edoardo Mortara
 20 g19 #24 Persson Motorsport | Mercedes AMG C-Coupé | RET 20L gap RET | Susie Wolff
 21 g3 #16 BMW Team RBM | BMW M3 DTM | RET 15L gap RET | Augusto Farfus
 22 g4 #3 Abt Sportsline | Audi A5 DTM | RET 1L gap RET | Mattias Ekström
