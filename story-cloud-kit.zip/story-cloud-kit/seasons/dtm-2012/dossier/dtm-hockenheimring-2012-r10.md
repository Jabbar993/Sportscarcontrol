# dtm-hockenheimring-2012-r10

Event: DTM Hockenheimring | Circuit: Hockenheimring | Date: 2012-10-21
Scheduled: ? | Official duration: 1:07:59.069 | Laps (winner): 42

## Qualifying (archive order)
Q1 #16 [DTMV8] 1:34.140 BMW Team RBM | Augusto Farfus
Q2 #11 [DTMV8] 1:34.261 HWA Team | Gary Paffett
Q3 #7 [DTMV8] 1:34.268 BMW Team Schnitzer | Bruno Spengler
Q4 #3 [DTMV8] 1:34.627 Abt Sportsline | Mattias Ekström
Q5 #2 [DTMV8] 1:34.031 BMW Team RMG | Joey Hand
Q6 #1 [DTMV8] 1:34.050 BMW Team RMG | Martin Tomczyk
Q7 #8 [DTMV8] 1:34.079 BMW Team Schnitzer | Dirk Werner
Q8 #4 [DTMV8] 1:34.133 Abt Sportsline | Timo Scheider
Q9 #21 [DTMV8] 1:34.159 Team Rosberg | Edoardo Mortara
Q10 #5 [DTMV8] 1:34.251 Mercedes AMG | Jamie Green
Q11 #22 [DTMV8] 1:34.288 Team Rosberg | Filipe Albuquerque
Q12 #9 [DTMV8] 1:34.304 Phoenix Racing | Mike Rockenfeller
Q13 #12 [DTMV8] 1:34.358 HWA Team | Christian Vietoris
Q14 #15 [DTMV8] 1:34.375 BMW Team RBM | Andy Priaulx
Q15 #18 [DTMV8] 1:34.477 Audi Sport Team Abt | Adrien Tambay
Q16 #17 [DTMV8] 1:34.720 Audi Sport Team Abt | Rahel Frey
Q17 #6 [DTMV8] 1:34.722 Mercedes AMG | Ralf Schumacher
Q18 #20 [DTMV8] 1:34.723 Mücke Motorsport | Robert Wickens
Q19 #23 [DTMV8] 1:35.032 Persson Motorsport | Roberto Merhi
Q20 #10 [DTMV8] 1:35.080 Phoenix Racing | Miguel Molina
Q21 #19 [DTMV8] 1:35.275 Mücke Motorsport | David Coulthard
Q22 #24 [DTMV8] 1:35.325 Persson Motorsport | Susie Wolff

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #16 Augusto Farfus 1:34.140 BMW Team RBM
DTMV8: #16 Augusto Farfus 1:34.140 BMW Team RBM

## Fastest laps (archive)
Overall: #11 Gary Paffett 1:35.402 lap 29
DTMV8: #11 Gary Paffett 1:35.402 lap 29

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g3 #7 BMW Team Schnitzer | BMW M3 DTM | Classified 42L gap — | Bruno Spengler
 2 g2 #11 HWA Team | Mercedes AMG C-Coupé | Classified 42L gap 2.214 | Gary Paffett
 3 g1 #16 BMW Team RBM | BMW M3 DTM | Classified 42L gap 11.954 | Augusto Farfus
 4 g9 #5 Mercedes AMG | Mercedes AMG C-Coupé | Classified 42L gap 23.479 | Jamie Green
 5 g7 #8 BMW Team Schnitzer | BMW M3 DTM | Classified 42L gap 25.384 | Dirk Werner
 6 g8 #21 Team Rosberg | Audi A5 DTM | Classified 42L gap 41.701 | Edoardo Mortara
 7 g13 #15 BMW Team RBM | BMW M3 DTM | Classified 42L gap 42.265 | Andy Priaulx
 8 g5 #2 BMW Team RMG | BMW M3 DTM | Classified 42L gap 42.843 | Joey Hand
 9 g16 #6 Mercedes AMG | Mercedes AMG C-Coupé | Classified 42L gap 43.878 | Ralf Schumacher
 10 g12 #12 HWA Team | Mercedes AMG C-Coupé | Classified 42L gap 45.138 | Christian Vietoris
 11 g10 #22 Team Rosberg | Audi A5 DTM | Classified 42L gap 58.232 | Filipe Albuquerque
 12 g22 #4 Abt Sportsline | Audi A5 DTM | Classified 42L gap 1:14.020 | Timo Scheider
 13 g21 #24 Persson Motorsport | Mercedes AMG C-Coupé | Classified 42L gap 1:35.931 | Susie Wolff
 14 g6 #1 BMW Team RMG | BMW M3 DTM | Classified 41L gap 1 LAP | Martin Tomczyk
 15 g18 #23 Persson Motorsport | Mercedes AMG C-Coupé | Classified 41L gap 1 LAP | Roberto Merhi
 16 g15 #17 Audi Sport Team Abt | Audi A5 DTM | Classified 41L gap 1 LAP | Rahel Frey
 17 g19 #10 Phoenix Racing | Audi A5 DTM | RET 25L gap RET | Miguel Molina
 18 g20 #19 Mücke Motorsport | Mercedes AMG C-Coupé | RET 23L gap RET | David Coulthard
 19 g17 #20 Mücke Motorsport | Mercedes AMG C-Coupé | RET 20L gap RET | Robert Wickens
 20 g4 #3 Abt Sportsline | Audi A5 DTM | RET 11L gap RET | Mattias Ekström
 21 g11 #9 Phoenix Racing | Audi A5 DTM | RET 2L gap RET | Mike Rockenfeller
 22 g14 #18 Audi Sport Team Abt | Audi A5 DTM | RET 1L gap RET | Adrien Tambay
