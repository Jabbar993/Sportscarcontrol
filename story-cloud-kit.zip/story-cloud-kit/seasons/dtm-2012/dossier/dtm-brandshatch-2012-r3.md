# dtm-brandshatch-2012-r3

Event: DTM Brands Hatch | Circuit: Brands Hatch | Date: 2012-05-20
Scheduled: ? | Official duration: 1:10:01.585 | Laps (winner): 97

## Qualifying (archive order)
Q1 #11 [DTMV8] 41.266 HWA Team | Gary Paffett
Q2 #12 [DTMV8] 41.410 HWA Team | Christian Vietoris
Q3 #7 [DTMV8] 41.462 BMW Team Schnitzer | Bruno Spengler
Q4 #9 [DTMV8] 41.484 Phoenix Racing | Mike Rockenfeller
Q5 #1 [DTMV8] 41.101 BMW Team RMG | Martin Tomczyk
Q6 #22 [DTMV8] 41.142 Team Rosberg | Filipe Albuquerque
Q7 #18 [DTMV8] 41.156 Audi Sport Team Abt | Adrien Tambay
Q8 #3 [DTMV8] 41.163 Abt Sportsline | Mattias Ekström
Q9 #16 [DTMV8] 41.172 BMW Team RBM | Augusto Farfus
Q10 #5 [DTMV8] 41.284 Mercedes AMG | Jamie Green
Q11 #21 [DTMV8] 41.381 Team Rosberg | Edoardo Mortara
Q12 #10 [DTMV8] 41.392 Phoenix Racing | Miguel Molina
Q13 #2 [DTMV8] 41.399 BMW Team RMG | Joey Hand
Q14 #15 [DTMV8] 41.403 BMW Team RBM | Andy Priaulx
Q15 #4 [DTMV8] 41.479 Abt Sportsline | Timo Scheider
Q16 #23 [DTMV8] 41.524 Persson Motorsport | Roberto Merhi
Q17 #20 [DTMV8] 41.584 Mücke Motorsport | Robert Wickens
Q18 #6 [DTMV8] 41.587 Mercedes AMG | Ralf Schumacher
Q19 #8 [DTMV8] 41.655 BMW Team Schnitzer | Dirk Werner
Q20 #19 [DTMV8] 41.657 Mücke Motorsport | David Coulthard
Q21 #24 [DTMV8] 41.677 Persson Motorsport | Susie Wolff
Q22 #17 [DTMV8] 41.956 Audi Sport Team Abt | Rahel Frey

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #11 Gary Paffett 41.266 HWA Team
DTMV8: #11 Gary Paffett 41.266 HWA Team

## Fastest laps (archive)
Overall: #1 Martin Tomczyk 42.138 lap 57
DTMV8: #1 Martin Tomczyk 42.138 lap 57

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #11 HWA Team | Mercedes AMG C-Coupé | Classified 97L gap — | Gary Paffett
 2 g3 #7 BMW Team Schnitzer | BMW M3 DTM | Classified 97L gap 5.065 | Bruno Spengler
 3 g4 #9 Phoenix Racing | Audi A5 DTM | Classified 97L gap 5.579 | Mike Rockenfeller
 4 g5 #1 BMW Team RMG | BMW M3 DTM | Classified 97L gap 5.997 | Martin Tomczyk
 5 g8 #3 Abt Sportsline | Audi A5 DTM | Classified 97L gap 22.416 | Mattias Ekström
 6 g2 #12 HWA Team | Mercedes AMG C-Coupé | Classified 97L gap 23.195 | Christian Vietoris
 7 g12 #10 Phoenix Racing | Audi A5 DTM | Classified 97L gap 23.689 | Miguel Molina
 8 g10 #5 Mercedes AMG | Mercedes AMG C-Coupé | Classified 97L gap 24.284 | Jamie Green
 9 g11 #21 Team Rosberg | Audi A5 DTM | Classified 97L gap 25.779 | Edoardo Mortara
 10 g6 #22 Team Rosberg | Audi A5 DTM | Classified 97L gap 29.582 | Filipe Albuquerque
 11 g9 #16 BMW Team RBM | BMW M3 DTM | Classified 97L gap 30.302 | Augusto Farfus
 12 g7 #18 Audi Sport Team Abt | Audi A5 DTM | Classified 97L gap 33.015 | Adrien Tambay
 13 g13 #2 BMW Team RMG | BMW M3 DTM | Classified 97L gap 35.977 | Joey Hand
 14 g17 #20 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 97L gap 36.340 | Robert Wickens
 15 g20 #19 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 96L gap 1 LAP | David Coulthard
 16 g19 #8 BMW Team Schnitzer | BMW M3 DTM | Classified 96L gap 1 LAP | Dirk Werner
 17 g16 #23 Persson Motorsport | Mercedes AMG C-Coupé | Classified 96L gap 1 LAP | Roberto Merhi
 18 g21 #17 Audi Sport Team Abt | Audi A5 DTM | Classified 96L gap 1 LAP | Rahel Frey
 19 g18 #6 Mercedes AMG | Mercedes AMG C-Coupé | Classified 96L gap 1 LAP | Ralf Schumacher
 20 g22 #24 Persson Motorsport | Mercedes AMG C-Coupé | Classified 81L gap 16 LAPS | Susie Wolff
 21 g15 #4 Abt Sportsline | Audi A5 DTM | RET 55L gap RET | Timo Scheider
 22 g14 #15 BMW Team RBM | BMW M3 DTM | RET 12L gap RET | Andy Priaulx
