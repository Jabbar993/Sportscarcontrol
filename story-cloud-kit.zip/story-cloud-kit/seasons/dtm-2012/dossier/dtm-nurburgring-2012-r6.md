# dtm-nurburgring-2012-r6

Event: DTM Nürburgring | Circuit: Nürburgring | Date: 2012-08-19
Scheduled: ? | Official duration: 1:11:12.847 | Laps (winner): 49

## Qualifying (archive order)
Q1 #7 [DTMV8] 1:24.284 BMW Team Schnitzer | Bruno Spengler
Q2 #21 [DTMV8] 1:24.505 Team Rosberg | Edoardo Mortara
Q3 #22 [DTMV8] 1:24.555 Team Rosberg | Filipe Albuquerque
Q4 #9 [DTMV8] 1:24.727 Phoenix Racing | Mike Rockenfeller
Q5 #1 [DTMV8] 1:24.241 BMW Team RMG | Martin Tomczyk
Q6 #16 [DTMV8] 1:24.288 BMW Team RBM | Augusto Farfus
Q7 #5 [DTMV8] 1:24.312 Mercedes AMG | Jamie Green
Q8 #8 [DTMV8] 1:24.422 BMW Team Schnitzer | Dirk Werner
Q9 #20 [DTMV8] 1:24.423 Mücke Motorsport | Robert Wickens
Q10 #4 [DTMV8] 1:24.748 Abt Sportsline | Timo Scheider
Q11 #11 [DTMV8] 1:24.486 HWA Team | Gary Paffett
Q12 #3 [DTMV8] 1:24.507 Abt Sportsline | Mattias Ekström
Q13 #10 [DTMV8] 1:24.539 Phoenix Racing | Miguel Molina
Q14 #2 [DTMV8] 1:24.664 BMW Team RMG | Joey Hand
Q15 #6 [DTMV8] 1:24.705 Mercedes AMG | Ralf Schumacher
Q16 #18 [DTMV8] 1:24.747 Audi Sport Team Abt | Adrien Tambay
Q17 #17 [DTMV8] 1:24.890 Audi Sport Team Abt | Rahel Frey
Q18 #12 [DTMV8] 1:24.944 HWA Team | Christian Vietoris
Q19 #15 [DTMV8] 1:24.974 BMW Team RBM | Andy Priaulx
Q20 #23 [DTMV8] 1:25.114 Persson Motorsport | Roberto Merhi
Q21 #24 [DTMV8] 1:25.275 Persson Motorsport | Susie Wolff
Q22 #19 [DTMV8] 1:25.297 Mücke Motorsport | David Coulthard

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #7 Bruno Spengler 1:24.284 BMW Team Schnitzer
DTMV8: #7 Bruno Spengler 1:24.284 BMW Team Schnitzer

## Fastest laps (archive)
Overall: #7 Bruno Spengler 1:25.185 lap 31
DTMV8: #7 Bruno Spengler 1:25.185 lap 31

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #7 BMW Team Schnitzer | BMW M3 DTM | Classified 49L gap — | Bruno Spengler
 2 g2 #21 Team Rosberg | Audi A5 DTM | Classified 49L gap 6.703 | Edoardo Mortara
 3 g5 #1 BMW Team RMG | BMW M3 DTM | Classified 49L gap 10.802 | Martin Tomczyk
 4 g7 #5 Mercedes AMG | Mercedes AMG C-Coupé | Classified 49L gap 22.019 | Jamie Green
 5 g4 #9 Phoenix Racing | Audi A5 DTM | Classified 49L gap 23.054 | Mike Rockenfeller
 6 g11 #11 HWA Team | Mercedes AMG C-Coupé | Classified 49L gap 23.765 | Gary Paffett
 7 g9 #20 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 49L gap 25.041 | Robert Wickens
 8 g3 #22 Team Rosberg | Audi A5 DTM | Classified 49L gap 29.601 | Filipe Albuquerque
 9 g10 #4 Abt Sportsline | Audi A5 DTM | Classified 49L gap 30.422 | Timo Scheider
 10 g6 #16 BMW Team RBM | BMW M3 DTM | Classified 49L gap 33.686 | Augusto Farfus
 11 g12 #3 Abt Sportsline | Audi A5 DTM | Classified 49L gap 35.436 | Mattias Ekström
 12 g8 #8 BMW Team Schnitzer | BMW M3 DTM | Classified 49L gap 40.828 | Dirk Werner
 13 g15 #6 Mercedes AMG | Mercedes AMG C-Coupé | Classified 49L gap 42.526 | Ralf Schumacher
 14 g17 #17 Audi Sport Team Abt | Audi A5 DTM | Classified 49L gap 43.105 | Rahel Frey
 15 g13 #10 Phoenix Racing | Audi A5 DTM | Classified 49L gap 46.558 | Miguel Molina
 16 g18 #12 HWA Team | Mercedes AMG C-Coupé | Classified 49L gap 53.240 | Christian Vietoris
 17 g21 #24 Persson Motorsport | Mercedes AMG C-Coupé | Classified 49L gap 1:09.036 | Susie Wolff
 18 g14 #2 BMW Team RMG | BMW M3 DTM | Classified 49L gap 1:12.214 | Joey Hand
 19 g19 #15 BMW Team RBM | BMW M3 DTM | Classified 49L gap 1:25.739 | Andy Priaulx
 20 g22 #19 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 48L gap 1 LAP | David Coulthard
 21 g16 #18 Audi Sport Team Abt | Audi A5 DTM | RET 14L gap RET | Adrien Tambay
 22 g20 #23 Persson Motorsport | Mercedes AMG C-Coupé | RET 9L gap RET | Roberto Merhi
