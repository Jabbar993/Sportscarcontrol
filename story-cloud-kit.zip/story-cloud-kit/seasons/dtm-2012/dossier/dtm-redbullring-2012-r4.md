# dtm-redbullring-2012-r4

Event: DTM Red Bull Ring | Circuit: Red Bull Ring | Date: 2012-06-03
Scheduled: ? | Official duration: 1:12:30.277 | Laps (winner): 47

## Qualifying (archive order)
Q1 #21 [DTMV8] 1:26.171 Team Rosberg | Edoardo Mortara
Q2 #11 [DTMV8] 1:26.292 HWA Team | Gary Paffett
Q3 #3 [DTMV8] 1:26.319 Abt Sportsline | Mattias Ekström
Q4 #1 [DTMV8] 1:26.408 BMW Team RMG | Martin Tomczyk
Q5 #2 [DTMV8] 1:25.927 BMW Team RMG | Joey Hand
Q6 #7 [DTMV8] 1:25.963 BMW Team Schnitzer | Bruno Spengler
Q7 #5 [DTMV8] 1:26.022 Mercedes AMG | Jamie Green
Q8 #22 [DTMV8] 1:26.294 Team Rosberg | Filipe Albuquerque
Q9 #8 [DTMV8] 1:26.309 BMW Team Schnitzer | Dirk Werner
Q10 #6 [DTMV8] 1:26.340 Mercedes AMG | Ralf Schumacher
Q11 #16 [DTMV8] 1:26.068 BMW Team RBM | Augusto Farfus
Q12 #10 [DTMV8] 1:26.251 Phoenix Racing | Miguel Molina
Q13 #9 [DTMV8] 1:26.274 Phoenix Racing | Mike Rockenfeller
Q14 #12 [DTMV8] 1:26.320 HWA Team | Christian Vietoris
Q15 #18 [DTMV8] 1:26.449 Audi Sport Team Abt | Adrien Tambay
Q16 #4 [DTMV8] 1:26.519 Abt Sportsline | Timo Scheider
Q17 #23 [DTMV8] 1:26.605 Persson Motorsport | Roberto Merhi
Q18 #15 [DTMV8] 1:26.620 BMW Team RBM | Andy Priaulx
Q19 #20 [DTMV8] 1:26.725 Mücke Motorsport | Robert Wickens
Q20 #24 [DTMV8] 1:26.914 Persson Motorsport | Susie Wolff
Q21 #17 [DTMV8] 1:27.057 Audi Sport Team Abt | Rahel Frey
Q22 #19 [DTMV8] 1:27.117 Mücke Motorsport | David Coulthard

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #21 Edoardo Mortara 1:26.171 Team Rosberg
DTMV8: #21 Edoardo Mortara 1:26.171 Team Rosberg

## Fastest laps (archive)
Overall: #4 Timo Scheider 1:27.027 lap 26
DTMV8: #4 Timo Scheider 1:27.027 lap 26

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #21 Team Rosberg | Audi A5 DTM | Classified 47L gap — | Edoardo Mortara
 2 g4 #1 BMW Team RMG | BMW M3 DTM | Classified 47L gap 1.068 | Martin Tomczyk
 3 g2 #11 HWA Team | Mercedes AMG C-Coupé | Classified 47L gap 2.142 | Gary Paffett
 4 g3 #3 Abt Sportsline | Audi A5 DTM | Classified 47L gap 2.769 | Mattias Ekström
 5 g7 #5 Mercedes AMG | Mercedes AMG C-Coupé | Classified 47L gap 5.406 | Jamie Green
 6 g16 #4 Abt Sportsline | Audi A5 DTM | Classified 47L gap 35.351 | Timo Scheider
 7 g13 #9 Phoenix Racing | Audi A5 DTM | Classified 47L gap 37.260 | Mike Rockenfeller
 8 g8 #22 Team Rosberg | Audi A5 DTM | Classified 47L gap 38.062 | Filipe Albuquerque
 9 g5 #2 BMW Team RMG | BMW M3 DTM | Classified 47L gap 39.419 | Joey Hand
 10 g11 #16 BMW Team RBM | BMW M3 DTM | Classified 47L gap 39.904 | Augusto Farfus
 11 g10 #6 Mercedes AMG | Mercedes AMG C-Coupé | Classified 47L gap 43.567 | Ralf Schumacher
 12 g17 #23 Persson Motorsport | Mercedes AMG C-Coupé | Classified 47L gap 50.339 | Roberto Merhi
 13 g19 #20 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 47L gap 1:05.670 | Robert Wickens
 14 g20 #24 Persson Motorsport | Mercedes AMG C-Coupé | Classified 47L gap 1:06.161 | Susie Wolff
 15 g21 #17 Audi Sport Team Abt | Audi A5 DTM | Classified 47L gap 1:06.988 | Rahel Frey
 16 g6 #7 BMW Team Schnitzer | BMW M3 DTM | RET 33L gap RET | Bruno Spengler
 17 g22 #19 Mücke Motorsport | Mercedes AMG C-Coupé | RET 22L gap RET | David Coulthard
 18 g12 #10 Phoenix Racing | Audi A5 DTM | RET 17L gap RET | Miguel Molina
 19 g9 #8 BMW Team Schnitzer | BMW M3 DTM | RET 1L gap RET | Dirk Werner
 20 g18 #15 BMW Team RBM | BMW M3 DTM | RET 1L gap RET | Andy Priaulx
 21 g14 #12 HWA Team | Mercedes AMG C-Coupé | RET 0L gap RET | Christian Vietoris
 22 g15 #18 Audi Sport Team Abt | Audi A5 DTM | RET 0L gap RET | Adrien Tambay
