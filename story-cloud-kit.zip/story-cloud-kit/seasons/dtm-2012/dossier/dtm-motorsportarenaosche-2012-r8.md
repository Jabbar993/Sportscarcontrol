# dtm-motorsportarenaosche-2012-r8

Event: DTM Motorsport Arena Oschersleben | Circuit: Oschersleben | Date: 2012-09-16
Scheduled: ? | Official duration: 1:12:09.607 | Laps (winner): 51

## Qualifying (archive order)
Q1 #7 [DTMV8] 1:20.916 BMW Team Schnitzer | Bruno Spengler
Q2 #11 [DTMV8] 1:21.002 HWA Team | Gary Paffett
Q3 #5 [DTMV8] 1:21.226 Mercedes AMG | Jamie Green
Q4 #8 [DTMV8] 1:21.911 BMW Team Schnitzer | Dirk Werner
Q5 #3 [DTMV8] 1:20.927 Abt Sportsline | Mattias Ekström
Q6 #1 [DTMV8] 1:20.999 BMW Team RMG | Martin Tomczyk
Q7 #21 [DTMV8] 1:21.048 Team Rosberg | Edoardo Mortara
Q8 #9 [DTMV8] 1:21.059 Phoenix Racing | Mike Rockenfeller
Q9 #10 [DTMV8] 1:21.155 Phoenix Racing | Miguel Molina
Q10 #16 [DTMV8] 1:21.949 BMW Team RBM | Augusto Farfus
Q11 #6 [DTMV8] 1:21.157 Mercedes AMG | Ralf Schumacher
Q12 #15 [DTMV8] 1:21.173 BMW Team RBM | Andy Priaulx
Q13 #20 [DTMV8] 1:21.176 Mücke Motorsport | Robert Wickens
Q14 #22 [DTMV8] 1:21.280 Team Rosberg | Filipe Albuquerque
Q15 #4 [DTMV8] 1:21.286 Abt Sportsline | Timo Scheider
Q16 #12 [DTMV8] 1:21.583 HWA Team | Christian Vietoris
Q17 #18 [DTMV8] 1:21.654 Audi Sport Team Abt | Adrien Tambay
Q18 #17 [DTMV8] 1:21.875 Audi Sport Team Abt | Rahel Frey
Q19 #23 [DTMV8] 1:22.026 Persson Motorsport | Roberto Merhi
Q20 #2 [DTMV8] 1:22.035 BMW Team RMG | Joey Hand
Q21 #19 [DTMV8] 1:22.169 Mücke Motorsport | David Coulthard
Q22 #24 [DTMV8] 1:22.422 Persson Motorsport | Susie Wolff

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #7 Bruno Spengler 1:20.916 BMW Team Schnitzer
DTMV8: #7 Bruno Spengler 1:20.916 BMW Team Schnitzer

## Fastest laps (archive)
Overall: #23 Roberto Merhi 1:22.752 lap 40
DTMV8: #23 Roberto Merhi 1:22.752 lap 40

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #7 BMW Team Schnitzer | BMW M3 DTM | Classified 51L gap — | Bruno Spengler
 2 g2 #11 HWA Team | Mercedes AMG C-Coupé | Classified 51L gap 0.629 | Gary Paffett
 3 g3 #5 Mercedes AMG | Mercedes AMG C-Coupé | Classified 51L gap 15.512 | Jamie Green
 4 g4 #8 BMW Team Schnitzer | BMW M3 DTM | Classified 51L gap 22.311 | Dirk Werner
 5 g9 #16 BMW Team RBM | BMW M3 DTM | Classified 51L gap 24.423 | Augusto Farfus
 6 g7 #9 Phoenix Racing | Audi A5 DTM | Classified 51L gap 26.940 | Mike Rockenfeller
 7 g13 #20 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 51L gap 33.737 | Robert Wickens
 8 g5 #3 Abt Sportsline | Audi A5 DTM | Classified 51L gap 34.631 | Mattias Ekström
 9 g14 #22 Team Rosberg | Audi A5 DTM | Classified 51L gap 42.943 | Filipe Albuquerque
 10 g15 #4 Abt Sportsline | Audi A5 DTM | Classified 51L gap 44.852 | Timo Scheider
 11 g20 #2 BMW Team RMG | BMW M3 DTM | Classified 51L gap 46.140 | Joey Hand
 12 g16 #12 HWA Team | Mercedes AMG C-Coupé | Classified 51L gap 55.296 | Christian Vietoris
 13 g10 #6 Mercedes AMG | Mercedes AMG C-Coupé | Classified 51L gap 1:14.587 | Ralf Schumacher
 14 g19 #23 Persson Motorsport | Mercedes AMG C-Coupé | Classified 51L gap 1:15.545 | Roberto Merhi
 15 g8 #10 Phoenix Racing | Audi A5 DTM | Classified 50L gap 1 LAP | Miguel Molina
 16 g17 #18 Audi Sport Team Abt | Audi A5 DTM | Classified 47L gap 4 LAPS | Adrien Tambay
 17 g12 #15 BMW Team RBM | BMW M3 DTM | Classified 39L gap 12 LAPS | Andy Priaulx
 18 g11 #1 BMW Team RMG | BMW M3 DTM | RET 20L gap RET | Martin Tomczyk
 19 g22 #24 Persson Motorsport | Mercedes AMG C-Coupé | RET 12L gap RET | Susie Wolff
 20 g6 #21 Team Rosberg | Audi A5 DTM | RET 6L gap RET | Edoardo Mortara
 21 g18 #17 Audi Sport Team Abt | Audi A5 DTM | RET 6L gap RET | Rahel Frey
 22 g21 #19 Mücke Motorsport | Mercedes AMG C-Coupé | RET 1L gap RET | David Coulthard
