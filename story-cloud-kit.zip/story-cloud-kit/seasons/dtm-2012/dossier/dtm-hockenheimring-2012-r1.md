# dtm-hockenheimring-2012-r1

Event: DTM Hockenheimring | Circuit: Hockenheimring | Date: 2012-04-29
Scheduled: ? | Official duration: 1:04:37.615 | Laps (winner): 40

## Qualifying (archive order)
Q1 #3 [DTMV8] 1:34.680 Abt Sportsline | Mattias Ekström
Q2 #5 [DTMV8] 1:34.895 Mercedes AMG | Jamie Green
Q3 #8 [DTMV8] 1:36.276 BMW Team Schnitzer | Dirk Werner
Q4 #21 [DTMV8]  Team Rosberg | Edoardo Mortara
Q5 #9 [DTMV8] 1:34.264 Phoenix Racing | Mike Rockenfeller
Q6 #11 [DTMV8] 1:34.287 HWA Team | Gary Paffett
Q7 #15 [DTMV8] 1:34.299 BMW Team RBM | Andy Priaulx
Q8 #4 [DTMV8] 1:34.389 Abt Sportsline | Timo Scheider
Q9 #7 [DTMV8] 1:34.512 BMW Team Schnitzer | Bruno Spengler
Q10 #1 [DTMV8] 1:34.819 BMW Team RMG | Martin Tomczyk
Q11 #6 [DTMV8] 1:34.390 Mercedes AMG | Ralf Schumacher
Q12 #18 [DTMV8] 1:34.509 Audi Sport Team Abt | Adrien Tambay
Q13 #20 [DTMV8] 1:34.538 Mücke Motorsport | Robert Wickens
Q14 #22 [DTMV8] 1:34.555 Team Rosberg | Filipe Albuquerque
Q15 #12 [DTMV8] 1:34.783 HWA Team | Christian Vietoris
Q16 #2 [DTMV8] 1:35.140 BMW Team RMG | Joey Hand
Q17 #10 [DTMV8] 1:34.926 Phoenix Racing | Miguel Molina
Q18 #19 [DTMV8] 1:34.932 Mücke Motorsport | David Coulthard
Q19 #16 [DTMV8] 1:35.104 BMW Team RBM | Augusto Farfus
Q20 #23 [DTMV8] 1:35.167 Persson Motorsport | Roberto Merhi
Q21 #24 [DTMV8] 1:35.776 Persson Motorsport | Susie Wolff
Q22 #17 [DTMV8] 1:36.012 Audi Sport Team Abt | Rahel Frey

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #3 Mattias Ekström 1:34.680 Abt Sportsline
DTMV8: #3 Mattias Ekström 1:34.680 Abt Sportsline

## Fastest laps (archive)
Overall: #5 Jamie Green 1:34.901 lap 31
DTMV8: #5 Jamie Green 1:34.901 lap 31

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g6 #11 HWA Team | Mercedes AMG C-Coupé | Classified 40L gap — | Gary Paffett
 2 g2 #5 Mercedes AMG | Mercedes AMG C-Coupé | Classified 40L gap 4.709 | Jamie Green
 3 g1 #3 Abt Sportsline | Audi A5 DTM | Classified 40L gap 19.434 | Mattias Ekström
 4 g15 #12 HWA Team | Mercedes AMG C-Coupé | Classified 40L gap 25.774 | Christian Vietoris
 5 g5 #9 Phoenix Racing | Audi A5 DTM | Classified 40L gap 27.834 | Mike Rockenfeller
 6 g7 #15 BMW Team RBM | BMW M3 DTM | Classified 40L gap 28.435 | Andy Priaulx
 7 g11 #6 Mercedes AMG | Mercedes AMG C-Coupé | Classified 40L gap 39.948 | Ralf Schumacher
 8 g18 #19 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 40L gap 43.306 | David Coulthard
 9 g17 #10 Phoenix Racing | Audi A5 DTM | Classified 40L gap 46.079 | Miguel Molina
 10 g14 #22 Team Rosberg | Audi A5 DTM | Classified 40L gap 46.614 | Filipe Albuquerque
 11 g4 #21 Team Rosberg | Audi A5 DTM | Classified 40L gap 47.253 | Edoardo Mortara
 12 g21 #24 Persson Motorsport | Mercedes AMG C-Coupé | Classified 40L gap 51.971 | Susie Wolff
 13 g16 #2 BMW Team RMG | BMW M3 DTM | Classified 40L gap 1:08.628 | Joey Hand
 14 g13 #20 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 40L gap 1:09.027 | Robert Wickens
 15 g19 #16 BMW Team RBM | BMW M3 DTM | Classified 40L gap 1:09.556 | Augusto Farfus
 16 g22 #17 Audi Sport Team Abt | Audi A5 DTM | Classified 40L gap 1:16.123 | Rahel Frey
 17 g3 #8 BMW Team Schnitzer | BMW M3 DTM | Classified 39L gap 1 LAP | Dirk Werner
 18 g20 #23 Persson Motorsport | Mercedes AMG C-Coupé | Classified 38L gap 2 LAPS | Roberto Merhi
 19 g8 #4 Abt Sportsline | Audi A5 DTM | RET 13L gap RET | Timo Scheider
 20 g10 #1 BMW Team RMG | BMW M3 DTM | RET 4L gap RET | Martin Tomczyk
 21 g9 #7 BMW Team Schnitzer | BMW M3 DTM | RET 3L gap RET | Bruno Spengler
 22 g12 #18 Audi Sport Team Abt | Audi A5 DTM | RET 3L gap RET | Adrien Tambay
