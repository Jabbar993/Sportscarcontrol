# dtm-nurburgring-2014-r7

Event: DTM Nürburgring | Circuit: Nürburgring | Date: 2014-08-17
Scheduled: ? | Official duration: 1:09:42.802 | Laps (winner): 49

## Qualifying (archive order)
Q1 #23 [DTMV8] 1:22.780 BMW Team RMG | Marco Wittmann
Q2 #15 [DTMV8] 1:22.925 Audi Sport Team Abt | Edoardo Mortara
Q3 #1 [DTMV8] 1:22.951 Audi Sport Team Phoenix | Mike Rockenfeller
Q4 #21 [DTMV8] 1:22.996 Audi Sport Team Rosberg | Jamie Green
Q5 #2 [DTMV8] 1:23.048 Audi Sport Team Phoenix | Timo Scheider
Q6 #8 [DTMV8] 1:23.163 Audi Sport Team Abt Sportsline | Miguel Molina
Q7 #19 [DTMV8] 1:23.221 Mücke Motorsport | Daniel Juncadella
Q8 #6 [DTMV8] 1:23.354 HWA Team | Paul di Resta
Q9 #5 [DTMV8] 1:23.338 HWA Team | Christian Vietoris
Q10 #22 [DTMV8] 1:23.405 Audi Sport Team Rosberg | Nico Müller
Q11 #16 [DTMV8] 1:23.421 Audi Sport Team Abt | Adrien Tambay
Q12 #24 [DTMV8] 1:23.495 BMW Team RMG | Maxime Martin
Q13 #12 [DTMV8] 1:23.565 HWA Team | Robert Wickens
Q14 #3 [DTMV8] 1:23.592 BMW Team RBM | Augusto Farfus
Q15 #25 [DTMV8] 1:23.593 HWA Team | Pascal Wehrlein
Q16 #17 [DTMV8] 1:23.691 BMW Team MTEK | Timo Glock
Q17 #9 [DTMV8] 1:23.770 BMW Team Schnitzer | Bruno Spengler
Q18 #10 [DTMV8] 1:23.841 BMW Team Schnitzer | Martin Tomczyk
Q19 #18 [DTMV8] 1:27.479 BMW Team MTEK | António Félix da Costa
Q20 #4 [DTMV8] 1:27.568 BMW Team RBM | Joey Hand
Q21 #20 [DTMV8] 1:27.714 Mücke Motorsport | Vitaly Petrov
Q22 #7 [DTMV8] 1:28.504 Audi Sport Team Abt Sportsline | Mattias Ekström
Q23 #11 [DTMV8] 1:29.612 HWA Team | Gary Paffett

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #23 Marco Wittmann 1:22.780 BMW Team RMG
DTMV8: #23 Marco Wittmann 1:22.780 BMW Team RMG

## Fastest laps (archive)
Overall: #23 Marco Wittmann 1:23.175 lap 2
DTMV8: #23 Marco Wittmann 1:23.175 lap 2

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #23 BMW Team RMG | BMW M4 DTM | Classified 49L gap — | Marco Wittmann
 2 g3 #1 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 49L gap 1.286 | Mike Rockenfeller
 3 g2 #15 Audi Sport Team Abt | Audi RS 5 DTM | Classified 49L gap 12.019 | Edoardo Mortara
 4 g8 #6 HWA Team | Mercedes AMG C-Coupé | Classified 49L gap 12.815 | Paul di Resta
 5 g7 #19 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 49L gap 13.717 | Daniel Juncadella
 6 g9 #5 HWA Team | Mercedes AMG C-Coupé | Classified 49L gap 24.918 | Christian Vietoris
 7 g12 #24 BMW Team RMG | BMW M4 DTM | Classified 49L gap 28.921 | Maxime Martin
 8 g17 #10 BMW Team Schnitzer | BMW M4 DTM | Classified 49L gap 38.521 | Martin Tomczyk
 9 g13 #12 HWA Team | Mercedes AMG C-Coupé | Classified 49L gap 43.197 | Robert Wickens
 10 g18 #25 HWA Team | Mercedes AMG C-Coupé | Classified 49L gap 45.377 | Pascal Wehrlein
 11 g11 #16 Audi Sport Team Abt | Audi RS 5 DTM | Classified 49L gap 48.071 | Adrien Tambay
 12 g16 #9 BMW Team Schnitzer | BMW M4 DTM | Classified 49L gap 49.834 | Bruno Spengler
 13 g19 #18 BMW Team MTEK | BMW M4 DTM | Classified 49L gap 50.150 | António Félix da Costa
 14 g4 #21 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 49L gap 52.771 | Jamie Green
 15 g23 #11 HWA Team | Mercedes AMG C-Coupé | Classified 49L gap 57.056 | Gary Paffett
 16 g15 #17 BMW Team MTEK | BMW M4 DTM | Classified 49L gap 58.557 | Timo Glock
 17 g20 #4 BMW Team RBM | BMW M4 DTM | Classified 49L gap 1:20.955 | Joey Hand
 18 g21 #20 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 48L gap 1 LAP | Vitaly Petrov
 19 g14 #3 BMW Team RBM | BMW M4 DTM | RET 35L gap RET | Augusto Farfus
 20 g10 #22 Audi Sport Team Rosberg | Audi RS 5 DTM | RET 10L gap RET | Nico Müller
 21 g5 #2 Audi Sport Team Phoenix | Audi RS 5 DTM | RET 8L gap RET | Timo Scheider
 22 g6 #8 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | RET 4L gap RET | Miguel Molina
 23 g22 #7 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | RET 3L gap RET | Mattias Ekström
