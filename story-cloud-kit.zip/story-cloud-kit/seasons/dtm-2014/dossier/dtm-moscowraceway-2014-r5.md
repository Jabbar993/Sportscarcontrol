# dtm-moscowraceway-2014-r5

Event: DTM Moscow Raceway | Circuit: Moscow Raceway | Date: 2014-07-13
Scheduled: ? | Official duration: 1:15:09.422 | Laps (winner): 46

## Qualifying (archive order)
Q1 #24 [DTMV8] 1:28.619 BMW Team RMG | Maxime Martin
Q2 #9 [DTMV8] 1:28.638 BMW Team Schnitzer | Bruno Spengler
Q3 #22 [DTMV8] 1:28.714 Audi Sport Team Rosberg | Nico Müller
Q4 #1 [DTMV8] 1:28.714 Audi Sport Team Phoenix | Mike Rockenfeller
Q5 #16 [DTMV8] 1:28.754 Audi Sport Team Abt | Adrien Tambay
Q6 #3 [DTMV8] 1:28.760 BMW Team RBM | Augusto Farfus
Q7 #23 [DTMV8] 1:28.844 BMW Team RMG | Marco Wittmann
Q8 #8 [DTMV8] 1:28.925 Audi Sport Team Abt Sportsline | Miguel Molina
Q9 #21 [DTMV8] 1:28.805 Audi Sport Team Rosberg | Jamie Green
Q10 #17 [DTMV8] 1:28.855 BMW Team MTEK | Timo Glock
Q11 #7 [DTMV8] 1:28.932 Audi Sport Team Abt Sportsline | Mattias Ekström
Q12 #15 [DTMV8] 1:28.980 Audi Sport Team Abt | Edoardo Mortara
Q13 #18 [DTMV8] 1:29.058 BMW Team MTEK | António Félix da Costa
Q14 #12 [DTMV8] 1:29.148 HWA Team | Robert Wickens
Q15 #19 [DTMV8] 1:29.231 Mücke Motorsport | Daniel Juncadella
Q16 #4 [DTMV8] 1:29.270 BMW Team RBM | Joey Hand
Q17 #2 [DTMV8] 1:29.425 Audi Sport Team Phoenix | Timo Scheider
Q18 #6 [DTMV8] 1:29.509 HWA Team | Paul di Resta
Q19 #10 [DTMV8] 1:29.749 BMW Team Schnitzer | Martin Tomczyk
Q20 #25 [DTMV8] 1:29.836 HWA Team | Pascal Wehrlein
Q21 #11 [DTMV8] 1:29.925 HWA Team | Gary Paffett
Q22 #5 [DTMV8] 1:30.031 HWA Team | Christian Vietoris
Q23 #20 [DTMV8] 1:30.443 Mücke Motorsport | Vitaly Petrov

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #24 Maxime Martin 1:28.619 BMW Team RMG
DTMV8: #24 Maxime Martin 1:28.619 BMW Team RMG

## Fastest laps (archive)
Overall: #8 Miguel Molina 1:28.305 lap 37
DTMV8: #8 Miguel Molina 1:28.305 lap 37

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #24 BMW Team RMG | BMW M4 DTM | Classified 46L gap — | Maxime Martin
 2 g2 #9 BMW Team Schnitzer | BMW M4 DTM | Classified 46L gap 4.259 | Bruno Spengler
 3 g11 #7 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 46L gap 9.454 | Mattias Ekström
 4 g7 #23 BMW Team RMG | BMW M4 DTM | Classified 46L gap 9.591 | Marco Wittmann
 5 g3 #22 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 46L gap 10.740 | Nico Müller
 6 g10 #17 BMW Team MTEK | BMW M4 DTM | Classified 46L gap 15.632 | Timo Glock
 7 g21 #5 HWA Team | Mercedes AMG C-Coupé | Classified 46L gap 16.553 | Christian Vietoris
 8 g19 #25 HWA Team | Mercedes AMG C-Coupé | Classified 46L gap 19.300 | Pascal Wehrlein
 9 g12 #15 Audi Sport Team Abt | Audi RS 5 DTM | Classified 46L gap 20.987 | Edoardo Mortara
 10 g6 #3 BMW Team RBM | BMW M4 DTM | Classified 46L gap 21.110 | Augusto Farfus
 11 g13 #18 BMW Team MTEK | BMW M4 DTM | Classified 46L gap 21.636 | António Félix da Costa
 12 g8 #8 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 46L gap 21.668 | Miguel Molina
 13 g22 #10 BMW Team Schnitzer | BMW M4 DTM | Classified 46L gap 27.181 | Martin Tomczyk
 14 g14 #12 HWA Team | Mercedes AMG C-Coupé | Classified 46L gap 28.109 | Robert Wickens
 15 g15 #19 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 46L gap 28.625 | Daniel Juncadella
 16 g20 #11 HWA Team | Mercedes AMG C-Coupé | Classified 46L gap 29.039 | Gary Paffett
 17 g16 #4 BMW Team RBM | BMW M4 DTM | Classified 46L gap 29.759 | Joey Hand
 18 g23 #20 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 46L gap 39.933 | Vitaly Petrov
 19 g4 #1 Audi Sport Team Phoenix | Audi RS 5 DTM | RET 27L gap RET | Mike Rockenfeller
 20 g5 #16 Audi Sport Team Abt | Audi RS 5 DTM | RET 27L gap RET | Adrien Tambay
 21 g17 #2 Audi Sport Team Phoenix | Audi RS 5 DTM | RET 22L gap RET | Timo Scheider
 22 g18 #6 HWA Team | Mercedes AMG C-Coupé | RET 8L gap RET | Paul di Resta
 23 g9 #21 Audi Sport Team Rosberg | Audi RS 5 DTM | RET 6L gap RET | Jamie Green
