# dtm-hockenheimring-2014-r10

Event: DTM Hockenheimring | Circuit: Hockenheimring | Date: 2014-10-19
Scheduled: ? | Official duration: 1:08:37.604 | Laps (winner): 42

## Qualifying (archive order)
Q1 #8 [DTMV8] 1:33.316 Audi Sport Team Abt Sportsline | Miguel Molina
Q2 #7 [DTMV8] 1:33.332 Audi Sport Team Abt Sportsline | Mattias Ekström
Q3 #15 [DTMV8] 1:33.406 Audi Sport Team Abt | Edoardo Mortara
Q4 #3 [DTMV8] 1:33.460 BMW Team RBM | Augusto Farfus
Q5 #21 [DTMV8] 1:33.480 Audi Sport Team Rosberg | Jamie Green
Q6 #25 [DTMV8] 1:33.483 HWA Team | Pascal Wehrlein
Q7 #1 [DTMV8] 1:33.588 Audi Sport Team Phoenix | Mike Rockenfeller
Q8 #2 [DTMV8] 1:33.650 Audi Sport Team Phoenix | Timo Scheider
Q9 #18 [DTMV8] 1:33.381 BMW Team MTEK | António Félix da Costa
Q10 #6 [DTMV8] 1:33.468 HWA Team | Paul di Resta
Q11 #16 [DTMV8] 1:33.498 Audi Sport Team Abt | Adrien Tambay
Q12 #12 [DTMV8] 1:33.525 HWA Team | Robert Wickens
Q13 #23 [DTMV8] 1:33.642 BMW Team RMG | Marco Wittmann
Q14 #9 [DTMV8] 1:33.643 BMW Team Schnitzer | Bruno Spengler
Q15 #24 [DTMV8] 1:33.664 BMW Team RMG | Maxime Martin
Q16 #11 [DTMV8] 1:33.708 HWA Team | Gary Paffett
Q17 #19 [DTMV8] 1:33.721 Mücke Motorsport | Daniel Juncadella
Q18 #22 [DTMV8] 1:33.864 Audi Sport Team Rosberg | Nico Müller
Q19 #17 [DTMV8] 1:33.775 BMW Team MTEK | Timo Glock
Q20 #10 [DTMV8] 1:33.827 BMW Team Schnitzer | Martin Tomczyk
Q21 #4 [DTMV8] 1:33.939 BMW Team RBM | Joey Hand
Q22 #5 [DTMV8] 1:34.066 HWA Team | Christian Vietoris
Q23 #20 [DTMV8] 1:34.443 Mücke Motorsport | Vitaly Petrov

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #8 Miguel Molina 1:33.316 Audi Sport Team Abt Sportsline
DTMV8: #8 Miguel Molina 1:33.316 Audi Sport Team Abt Sportsline

## Fastest laps (archive)
Overall: #23 Marco Wittmann 1:33.643 lap 23
DTMV8: #23 Marco Wittmann 1:33.643 lap 23

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g2 #7 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 42L gap — | Mattias Ekström
 2 g7 #1 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 42L gap 2.402 | Mike Rockenfeller
 3 g5 #21 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 42L gap 3.914 | Jamie Green
 4 g10 #6 HWA Team | Mercedes AMG C-Coupé | Classified 42L gap 4.163 | Paul di Resta
 5 g13 #23 BMW Team RMG | BMW M4 DTM | Classified 42L gap 4.962 | Marco Wittmann
 6 g8 #2 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 42L gap 6.540 | Timo Scheider
 7 g20 #10 BMW Team Schnitzer | BMW M4 DTM | Classified 42L gap 7.526 | Martin Tomczyk
 8 g1 #8 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 42L gap 11.104 | Miguel Molina
 9 g9 #18 BMW Team MTEK | BMW M4 DTM | Classified 42L gap 12.198 | António Félix da Costa
 10 g16 #11 HWA Team | Mercedes AMG C-Coupé | Classified 42L gap 14.781 | Gary Paffett
 11 g19 #17 BMW Team MTEK | BMW M4 DTM | Classified 42L gap 15.179 | Timo Glock
 12 g14 #9 BMW Team Schnitzer | BMW M4 DTM | Classified 42L gap 15.838 | Bruno Spengler
 13 g18 #22 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 42L gap 15.973 | Nico Müller
 14 g22 #5 HWA Team | Mercedes AMG C-Coupé | Classified 42L gap 17.497 | Christian Vietoris
 15 g21 #4 BMW Team RBM | BMW M4 DTM | Classified 42L gap 17.769 | Joey Hand
 16 g4 #3 BMW Team RBM | BMW M4 DTM | Classified 42L gap 23.024 | Augusto Farfus
 17 g12 #12 HWA Team | Mercedes AMG C-Coupé | Classified 42L gap 40.344 | Robert Wickens
 18 g23 #20 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 41L gap 1 LAP | Vitaly Petrov
 19 g11 #16 Audi Sport Team Abt | Audi RS 5 DTM | Classified 41L gap 1 LAP | Adrien Tambay
 20 g6 #25 HWA Team | Mercedes AMG C-Coupé | Classified 40L gap 2 LAPS | Pascal Wehrlein
 21 g17 #19 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 36L gap 6 LAPS | Daniel Juncadella
 22 g3 #15 Audi Sport Team Abt | Audi RS 5 DTM | Classified 31L gap 11 LAPS | Edoardo Mortara
 23 g15 #24 BMW Team RMG | BMW M4 DTM | RET 27L gap RET | Maxime Martin
