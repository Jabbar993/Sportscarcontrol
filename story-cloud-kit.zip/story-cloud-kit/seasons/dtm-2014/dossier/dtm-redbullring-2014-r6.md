# dtm-redbullring-2014-r6

Event: DTM Red Bull Ring | Circuit: Red Bull Ring | Date: 2014-08-03
Scheduled: ? | Official duration: 1:08:23.185 | Laps (winner): 47

## Qualifying (archive order)
Q1 #12 [DTMV8] 1:25.175 HWA Team | Robert Wickens
Q2 #17 [DTMV8] 1:25.181 BMW Team MTEK | Timo Glock
Q3 #23 [DTMV8] 1:25.228 BMW Team RMG | Marco Wittmann
Q4 #3 [DTMV8] 1:25.237 BMW Team RBM | Augusto Farfus
Q5 #25 [DTMV8] 1:25.246 HWA Team | Pascal Wehrlein
Q6 #21 [DTMV8] 1:25.266 Audi Sport Team Rosberg | Jamie Green
Q7 #5 [DTMV8] 1:25.362 HWA Team | Christian Vietoris
Q8 #24 [DTMV8] 1:25.424 BMW Team RMG | Maxime Martin
Q9 #4 [DTMV8] 1:25.259 BMW Team RBM | Joey Hand
Q10 #9 [DTMV8] 1:25.309 BMW Team Schnitzer | Bruno Spengler
Q11 #10 [DTMV8] 1:25.323 BMW Team Schnitzer | Martin Tomczyk
Q12 #19 [DTMV8] 1:25.335 Mücke Motorsport | Daniel Juncadella
Q13 #18 [DTMV8] 1:25.343 BMW Team MTEK | António Félix da Costa
Q14 #1 [DTMV8] 1:25.385 Audi Sport Team Phoenix | Mike Rockenfeller
Q15 #2 [DTMV8] 1:25.400 Audi Sport Team Phoenix | Timo Scheider
Q16 #7 [DTMV8] 1:25.423 Audi Sport Team Abt Sportsline | Mattias Ekström
Q17 #8 [DTMV8] 1:25.708 Audi Sport Team Abt Sportsline | Miguel Molina
Q18 #22 [DTMV8] 1:25.526 Audi Sport Team Rosberg | Nico Müller
Q19 #11 [DTMV8] 1:25.577 HWA Team | Gary Paffett
Q20 #16 [DTMV8] 1:25.599 Audi Sport Team Abt | Adrien Tambay
Q21 #15 [DTMV8] 1:25.666 Audi Sport Team Abt | Edoardo Mortara
Q22 #20 [DTMV8] 1:25.856 Mücke Motorsport | Vitaly Petrov
Q23 #6 [DTMV8] 1:25.932 HWA Team | Paul di Resta

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #12 Robert Wickens 1:25.175 HWA Team
DTMV8: #12 Robert Wickens 1:25.175 HWA Team

## Fastest laps (archive)
Overall: #1 Mike Rockenfeller 1:25.266 lap 45
DTMV8: #1 Mike Rockenfeller 1:25.266 lap 45

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g3 #23 BMW Team RMG | BMW M4 DTM | Classified 47L gap — | Marco Wittmann
 2 g4 #3 BMW Team RBM | BMW M4 DTM | Classified 47L gap 3.298 | Augusto Farfus
 3 g2 #17 BMW Team MTEK | BMW M4 DTM | Classified 47L gap 5.391 | Timo Glock
 4 g11 #10 BMW Team Schnitzer | BMW M4 DTM | Classified 47L gap 6.237 | Martin Tomczyk
 5 g14 #2 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 47L gap 6.666 | Timo Scheider
 6 g20 #16 Audi Sport Team Abt | Audi RS 5 DTM | Classified 47L gap 12.213 | Adrien Tambay
 7 g15 #7 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 47L gap 14.046 | Mattias Ekström
 8 g6 #21 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 47L gap 14.456 | Jamie Green
 9 g7 #5 HWA Team | Mercedes AMG C-Coupé | Classified 47L gap 15.224 | Christian Vietoris
 10 g10 #9 BMW Team Schnitzer | BMW M4 DTM | Classified 47L gap 15.782 | Bruno Spengler
 11 g16 #8 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 47L gap 16.192 | Miguel Molina
 12 g9 #4 BMW Team RBM | BMW M4 DTM | Classified 47L gap 16.214 | Joey Hand
 13 g17 #1 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 47L gap 17.717 | Mike Rockenfeller
 14 g8 #24 BMW Team RMG | BMW M4 DTM | Classified 47L gap 30.235 | Maxime Martin
 15 g12 #19 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 47L gap 34.836 | Daniel Juncadella
 16 g21 #15 Audi Sport Team Abt | Audi RS 5 DTM | Classified 47L gap 35.420 | Edoardo Mortara
 17 g19 #11 HWA Team | Mercedes AMG C-Coupé | Classified 47L gap 40.852 | Gary Paffett
 18 g23 #6 HWA Team | Mercedes AMG C-Coupé | Classified 47L gap 44.107 | Paul di Resta
 19 g18 #22 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 47L gap 45.827 | Nico Müller
 20 g22 #20 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 47L gap 45.971 | Vitaly Petrov
 21 g1 #12 HWA Team | Mercedes AMG C-Coupé | DSQ 34L gap DSQ | Robert Wickens
 22 g5 #25 HWA Team | Mercedes AMG C-Coupé | RET 26L gap RET | Pascal Wehrlein
 23 g13 #18 BMW Team MTEK | BMW M4 DTM | RET 10L gap RET | António Félix da Costa
