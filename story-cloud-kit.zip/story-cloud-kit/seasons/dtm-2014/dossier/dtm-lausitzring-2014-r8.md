# dtm-lausitzring-2014-r8

Event: DTM Lausitzring | Circuit: Lausitzring | Date: 2014-09-14
Scheduled: ? | Official duration: 1:15:47.314 | Laps (winner): 52

## Qualifying (archive order)
Q1 #25 [DTMV8] 1:17.547 HWA Team | Pascal Wehrlein
Q2 #7 [DTMV8] 1:17.604 Audi Sport Team Abt Sportsline | Mattias Ekström
Q3 #21 [DTMV8] 1:17.715 Audi Sport Team Rosberg | Jamie Green
Q4 #2 [DTMV8] 1:17.761 Audi Sport Team Phoenix | Timo Scheider
Q5 #19 [DTMV8] 1:17.779 Mücke Motorsport | Daniel Juncadella
Q6 #8 [DTMV8] 1:17.786 Audi Sport Team Abt Sportsline | Miguel Molina
Q7 #23 [DTMV8] 1:18.143 BMW Team RMG | Marco Wittmann
Q8 #11 [DTMV8] 1:18.291 HWA Team | Gary Paffett
Q9 #17 [DTMV8] 1:18.141 BMW Team MTEK | Timo Glock
Q10 #1 [DTMV8] 1:18.150 Audi Sport Team Phoenix | Mike Rockenfeller
Q11 #5 [DTMV8] 1:18.202 HWA Team | Christian Vietoris
Q12 #12 [DTMV8] 1:18.250 HWA Team | Robert Wickens
Q13 #15 [DTMV8] 1:18.299 Audi Sport Team Abt | Edoardo Mortara
Q14 #20 [DTMV8] 1:18.314 Mücke Motorsport | Vitaly Petrov
Q15 #3 [DTMV8] 1:18.343 BMW Team RBM | Augusto Farfus
Q16 #24 [DTMV8] 1:18.375 BMW Team RMG | Maxime Martin
Q17 #9 [DTMV8] 1:18.416 BMW Team Schnitzer | Bruno Spengler
Q18 #16 [DTMV8] 1:18.467 Audi Sport Team Abt | Adrien Tambay
Q19 #18 [DTMV8] 1:18.491 BMW Team MTEK | António Félix da Costa
Q20 #22 [DTMV8] 1:18.591 Audi Sport Team Rosberg | Nico Müller
Q21 #10 [DTMV8] 1:18.629 BMW Team Schnitzer | Martin Tomczyk
Q22 #6 [DTMV8] 1:18.699 HWA Team | Paul di Resta
Q23 #4 [DTMV8]  BMW Team RBM | Joey Hand

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #25 Pascal Wehrlein 1:17.547 HWA Team
DTMV8: #25 Pascal Wehrlein 1:17.547 HWA Team

## Fastest laps (archive)
Overall: #2 Timo Scheider 1:19.782 lap 42
DTMV8: #2 Timo Scheider 1:19.782 lap 42

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #25 HWA Team | Mercedes AMG C-Coupé | Classified 52L gap — | Pascal Wehrlein
 2 g11 #5 HWA Team | Mercedes AMG C-Coupé | Classified 52L gap 15.418 | Christian Vietoris
 3 g4 #2 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 52L gap 15.681 | Timo Scheider
 4 g5 #19 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 52L gap 18.024 | Daniel Juncadella
 5 g12 #12 HWA Team | Mercedes AMG C-Coupé | Classified 52L gap 32.677 | Robert Wickens
 6 g7 #23 BMW Team RMG | BMW M4 DTM | Classified 52L gap 48.435 | Marco Wittmann
 7 g20 #3 BMW Team RBM | BMW M4 DTM | Classified 52L gap 1:02.380 | Augusto Farfus
 8 g23 #10 BMW Team Schnitzer | BMW M4 DTM | Classified 52L gap 1:07.705 | Martin Tomczyk
 9 g6 #8 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 52L gap 1:08.719 | Miguel Molina
 10 g10 #1 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 52L gap 1:13.480 | Mike Rockenfeller
 11 g22 #4 BMW Team RBM | BMW M4 DTM | Classified 52L gap 1:14.734 | Joey Hand
 12 g14 #20 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 52L gap 1:19.199 | Vitaly Petrov
 13 g8 #11 HWA Team | Mercedes AMG C-Coupé | Classified 51L gap 1 LAP | Gary Paffett
 14 g15 #24 BMW Team RMG | BMW M4 DTM | Classified 51L gap 1 LAP | Maxime Martin
 15 g16 #9 BMW Team Schnitzer | BMW M4 DTM | Classified 50L gap 2 LAPS | Bruno Spengler
 16 g13 #15 Audi Sport Team Abt | Audi RS 5 DTM | Classified 50L gap 2 LAPS | Edoardo Mortara
 17 g3 #21 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 48L gap 4 LAPS | Jamie Green
 18 g17 #16 Audi Sport Team Abt | Audi RS 5 DTM | Classified 41L gap 11 LAPS | Adrien Tambay
 19 g21 #6 HWA Team | Mercedes AMG C-Coupé | RET 38L gap RET | Paul di Resta
 20 g2 #7 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | RET 26L gap RET | Mattias Ekström
 21 g9 #17 BMW Team MTEK | BMW M4 DTM | RET 19L gap RET | Timo Glock
 22 g19 #22 Audi Sport Team Rosberg | Audi RS 5 DTM | RET 14L gap RET | Nico Müller
 23 g18 #18 BMW Team MTEK | BMW M4 DTM | RET 6L gap RET | António Félix da Costa
