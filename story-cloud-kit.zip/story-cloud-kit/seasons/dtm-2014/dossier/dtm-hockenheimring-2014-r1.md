# dtm-hockenheimring-2014-r1

Event: DTM Hockenheimring | Circuit: Hockenheimring | Date: 2014-05-04
Scheduled: ? | Official duration: 1:06:40.548 | Laps (winner): 42

## Qualifying (archive order)
Q1 #16 [DTMV8] 1:32.272 Audi Sport Team Abt | Adrien Tambay
Q2 #23 [DTMV8] 1:32.419 BMW Team RMG | Marco Wittmann
Q3 #9 [DTMV8] 1:32.600 BMW Team Schnitzer | Bruno Spengler
Q4 #18 [DTMV8] 1:32.608 BMW Team MTEK | António Félix da Costa
Q5 #7 [DTMV8] 1:32.624 Audi Sport Team Abt Sportsline | Mattias Ekström
Q6 #15 [DTMV8] 1:32.898 Audi Sport Team Abt | Edoardo Mortara
Q7 #10 [DTMV8] 1:33.113 BMW Team Schnitzer | Martin Tomczyk
Q8 #8 [DTMV8]  Audi Sport Team Abt Sportsline | Miguel Molina
Q9 #17 [DTMV8] 1:32.603 BMW Team MTEK | Timo Glock
Q10 #2 [DTMV8] 1:32.706 Audi Sport Team Phoenix | Timo Scheider
Q11 #1 [DTMV8] 1:32.717 Audi Sport Team Phoenix | Mike Rockenfeller
Q12 #3 [DTMV8] 1:32.739 BMW Team RBM | Augusto Farfus
Q13 #22 [DTMV8] 1:32.756 Audi Sport Team Rosberg | Nico Müller
Q14 #24 [DTMV8] 1:32.792 BMW Team RMG | Maxime Martin
Q15 #11 [DTMV8] 1:32.834 HWA Team | Gary Paffett
Q16 #25 [DTMV8] 1:32.840 HWA Team | Pascal Wehrlein
Q17 #4 [DTMV8] 1:32.885 BMW Team RBM | Joey Hand
Q18 #21 [DTMV8] 1:32.986 Audi Sport Team Rosberg | Jamie Green
Q19 #6 [DTMV8] 1:33.639 HWA Team | Paul di Resta
Q20 #19 [DTMV8] 1:33.746 Mücke Motorsport | Daniel Juncadella
Q21 #12 [DTMV8] 1:33.875 HWA Team | Robert Wickens
Q22 #5 [DTMV8] 1:34.242 HWA Team | Christian Vietoris
Q23 #20 [DTMV8] 1:34.367 Mücke Motorsport | Vitaly Petrov

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #16 Adrien Tambay 1:32.272 Audi Sport Team Abt
DTMV8: #16 Adrien Tambay 1:32.272 Audi Sport Team Abt

## Fastest laps (archive)
Overall: #10 Martin Tomczyk 1:32.532 lap 25
DTMV8: #10 Martin Tomczyk 1:32.532 lap 25

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g2 #23 BMW Team RMG | BMW M4 DTM | Classified 42L gap — | Marco Wittmann
 2 g5 #7 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 42L gap 12.869 | Mattias Ekström
 3 g1 #16 Audi Sport Team Abt | Audi RS 5 DTM | Classified 42L gap 14.879 | Adrien Tambay
 4 g10 #1 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 42L gap 17.593 | Mike Rockenfeller
 5 g8 #17 BMW Team MTEK | BMW M4 DTM | Classified 42L gap 21.780 | Timo Glock
 6 g3 #9 BMW Team Schnitzer | BMW M4 DTM | Classified 42L gap 23.513 | Bruno Spengler
 7 g7 #10 BMW Team Schnitzer | BMW M4 DTM | Classified 42L gap 24.082 | Martin Tomczyk
 8 g11 #3 BMW Team RBM | BMW M4 DTM | Classified 42L gap 24.913 | Augusto Farfus
 9 g9 #2 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 42L gap 26.138 | Timo Scheider
 10 g16 #4 BMW Team RBM | BMW M4 DTM | Classified 42L gap 34.759 | Joey Hand
 11 g15 #25 HWA Team | Mercedes AMG C-Coupé | Classified 42L gap 53.857 | Pascal Wehrlein
 12 g14 #11 HWA Team | Mercedes AMG C-Coupé | Classified 42L gap 57.264 | Gary Paffett
 13 g23 #8 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 42L gap 59.161 | Miguel Molina
 14 g18 #6 HWA Team | Mercedes AMG C-Coupé | Classified 42L gap 1:00.858 | Paul di Resta
 15 g21 #5 HWA Team | Mercedes AMG C-Coupé | Classified 42L gap 1:02.062 | Christian Vietoris
 16 g12 #22 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 42L gap 1:02.479 | Nico Müller
 17 g22 #20 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 42L gap 1:06.591 | Vitaly Petrov
 18 g20 #12 HWA Team | Mercedes AMG C-Coupé | Classified 42L gap 1:11.152 | Robert Wickens
 19 g19 #19 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 41L gap 1 LAP | Daniel Juncadella
 20 g13 #24 BMW Team RMG | BMW M4 DTM | Classified 41L gap 1 LAP | Maxime Martin
 21 g4 #18 BMW Team MTEK | BMW M4 DTM | Classified 38L gap 4 LAPS | António Félix da Costa
 22 g6 #15 Audi Sport Team Abt | Audi RS 5 DTM | Classified 31L gap 11 LAPS | Edoardo Mortara
 23 g17 #21 Audi Sport Team Rosberg | Audi RS 5 DTM | RET 2L gap RET | Jamie Green
