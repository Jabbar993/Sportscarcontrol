# dtm-norisring-2014-r4

Event: DTM Norisring | Circuit: Norisring | Date: 2014-06-29
Scheduled: ? | Official duration: 1:15:21.118 | Laps (winner): 82

## Qualifying (archive order)
Q1 #12 [DTMV8] 47.883 HWA Team | Robert Wickens
Q2 #6 [DTMV8] 47.976 HWA Team | Paul di Resta
Q3 #21 [DTMV8] 47.995 Audi Sport Team Rosberg | Jamie Green
Q4 #25 [DTMV8] 48.008 HWA Team | Pascal Wehrlein
Q5 #11 [DTMV8] 48.033 HWA Team | Gary Paffett
Q6 #5 [DTMV8] 48.033 HWA Team | Christian Vietoris
Q7 #7 [DTMV8] 48.079 Audi Sport Team Abt Sportsline | Mattias Ekström
Q8 #23 [DTMV8] 48.210 BMW Team RMG | Marco Wittmann
Q9 #16 [DTMV8] 48.223 Audi Sport Team Abt | Adrien Tambay
Q10 #22 [DTMV8] 48.235 Audi Sport Team Rosberg | Nico Müller
Q11 #24 [DTMV8] 48.267 BMW Team RMG | Maxime Martin
Q12 #1 [DTMV8] 48.292 Audi Sport Team Phoenix | Mike Rockenfeller
Q13 #17 [DTMV8] 48.316 BMW Team MTEK | Timo Glock
Q14 #4 [DTMV8] 48.320 BMW Team RBM | Joey Hand
Q15 #3 [DTMV8] 48.329 BMW Team RBM | Augusto Farfus
Q16 #9 [DTMV8] 48.329 BMW Team Schnitzer | Bruno Spengler
Q17 #19 [DTMV8] 48.375 Mücke Motorsport | Daniel Juncadella
Q18 #8 [DTMV8] 48.434 Audi Sport Team Abt Sportsline | Miguel Molina
Q19 #10 [DTMV8] 48.417 BMW Team Schnitzer | Martin Tomczyk
Q20 #15 [DTMV8] 48.439 Audi Sport Team Abt | Edoardo Mortara
Q21 #2 [DTMV8] 48.480 Audi Sport Team Phoenix | Timo Scheider
Q22 #18 [DTMV8] 48.488 BMW Team MTEK | António Félix da Costa
Q23 #20 [DTMV8] 48.544 Mücke Motorsport | Vitaly Petrov

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #12 Robert Wickens 47.883 HWA Team
DTMV8: #12 Robert Wickens 47.883 HWA Team

## Fastest laps (archive)
Overall: #7 Mattias Ekström 48.610 lap 79
DTMV8: #7 Mattias Ekström 48.610 lap 79

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #12 HWA Team | Mercedes AMG C-Coupé | Classified 82L gap — | Robert Wickens
 2 g3 #21 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 82L gap 23.906 | Jamie Green
 3 g12 #7 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 82L gap 25.922 | Mattias Ekström
 4 g20 #15 Audi Sport Team Abt | Audi RS 5 DTM | Classified 82L gap 32.875 | Edoardo Mortara
 5 g4 #25 HWA Team | Mercedes AMG C-Coupé | Classified 82L gap 44.788 | Pascal Wehrlein
 6 g7 #23 BMW Team RMG | BMW M4 DTM | Classified 82L gap 46.050 | Marco Wittmann
 7 g14 #4 BMW Team RBM | BMW M4 DTM | Classified 82L gap 47.991 | Joey Hand
 8 g11 #1 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 82L gap 48.803 | Mike Rockenfeller
 9 g8 #16 Audi Sport Team Abt | Audi RS 5 DTM | Classified 82L gap 1:14.661 | Adrien Tambay
 10 g21 #2 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 81L gap 1 LAP | Timo Scheider
 11 g16 #9 BMW Team Schnitzer | BMW M4 DTM | Classified 81L gap 1 LAP | Bruno Spengler
 12 g5 #11 HWA Team | Mercedes AMG C-Coupé | Classified 81L gap 1 LAP | Gary Paffett
 13 g17 #19 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 81L gap 1 LAP | Daniel Juncadella
 14 g15 #3 BMW Team RBM | BMW M4 DTM | Classified 81L gap 1 LAP | Augusto Farfus
 15 g2 #6 HWA Team | Mercedes AMG C-Coupé | Classified 81L gap 1 LAP | Paul di Resta
 16 g13 #17 BMW Team MTEK | BMW M4 DTM | Classified 80L gap 2 LAPS | Timo Glock
 17 g10 #24 BMW Team RMG | BMW M4 DTM | Classified 80L gap 2 LAPS | Maxime Martin
 18 g9 #22 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 80L gap 2 LAPS | Nico Müller
 19 g23 #20 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 80L gap 2 LAPS | Vitaly Petrov
 20 g22 #18 BMW Team MTEK | BMW M4 DTM | Classified 80L gap 2 LAPS | António Félix da Costa
 21 g6 #5 HWA Team | Mercedes AMG C-Coupé | Classified 73L gap 9 LAPS | Christian Vietoris
 22 g18 #8 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 71L gap 11 LAPS | Miguel Molina
 23 g19 #10 BMW Team Schnitzer | BMW M4 DTM | RET 58L gap RET | Martin Tomczyk
