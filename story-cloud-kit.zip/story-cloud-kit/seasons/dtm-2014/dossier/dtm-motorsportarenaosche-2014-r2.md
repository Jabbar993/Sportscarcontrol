# dtm-motorsportarenaosche-2014-r2

Event: DTM Motorsport Arena Oschersleben | Circuit: Oschersleben | Date: 2014-05-18
Scheduled: ? | Official duration: 1:15:28.785 | Laps (winner): 44

## Qualifying (archive order)
Q1 #23 [DTMV8] 1:20.516 BMW Team RMG | Marco Wittmann
Q2 #16 [DTMV8] 1:20.519 Audi Sport Team Abt | Adrien Tambay
Q3 #18 [DTMV8] 1:20.582 BMW Team MTEK | António Félix da Costa
Q4 #2 [DTMV8] 1:20.668 Audi Sport Team Phoenix | Timo Scheider
Q5 #1 [DTMV8] 1:20.676 Audi Sport Team Phoenix | Mike Rockenfeller
Q6 #9 [DTMV8] 1:20.703 BMW Team Schnitzer | Bruno Spengler
Q7 #15 [DTMV8] 1:21.113 Audi Sport Team Abt | Edoardo Mortara
Q8 #8 [DTMV8]  Audi Sport Team Abt Sportsline | Miguel Molina
Q9 #3 [DTMV8] 1:20.663 BMW Team RBM | Augusto Farfus
Q10 #25 [DTMV8] 1:20.668 HWA Team | Pascal Wehrlein
Q11 #21 [DTMV8] 1:20.767 Audi Sport Team Rosberg | Jamie Green
Q12 #7 [DTMV8] 1:20.788 Audi Sport Team Abt Sportsline | Mattias Ekström
Q13 #10 [DTMV8] 1:20.801 BMW Team Schnitzer | Martin Tomczyk
Q14 #24 [DTMV8] 1:20.904 BMW Team RMG | Maxime Martin
Q15 #22 [DTMV8] 1:20.957 Audi Sport Team Rosberg | Nico Müller
Q16 #4 [DTMV8] 1:20.973 BMW Team RBM | Joey Hand
Q17 #5 [DTMV8] 1:21.082 HWA Team | Christian Vietoris
Q18 #11 [DTMV8] 1:21.322 HWA Team | Gary Paffett
Q19 #17 [DTMV8] 1:21.439 BMW Team MTEK | Timo Glock
Q20 #12 [DTMV8] 1:21.595 HWA Team | Robert Wickens
Q21 #6 [DTMV8] 1:21.795 HWA Team | Paul di Resta
Q22 #19 [DTMV8] 1:21.915 Mücke Motorsport | Daniel Juncadella
Q23 #20 [DTMV8] 1:22.132 Mücke Motorsport | Vitaly Petrov

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #23 Marco Wittmann 1:20.516 BMW Team RMG
DTMV8: #23 Marco Wittmann 1:20.516 BMW Team RMG

## Fastest laps (archive)
Overall: #8 Miguel Molina 1:23.597 lap 5
DTMV8: #8 Miguel Molina 1:23.597 lap 5

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g16 #5 HWA Team | Mercedes AMG C-Coupé | Classified 44L gap — | Christian Vietoris
 2 g5 #1 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 44L gap 0.674 | Mike Rockenfeller
 3 g7 #15 Audi Sport Team Abt | Audi RS 5 DTM | Classified 44L gap 7.769 | Edoardo Mortara
 4 g20 #6 HWA Team | Mercedes AMG C-Coupé | Classified 44L gap 8.906 | Paul di Resta
 5 g8 #3 BMW Team RBM | BMW M4 DTM | Classified 44L gap 9.326 | Augusto Farfus
 6 g23 #8 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 44L gap 13.051 | Miguel Molina
 7 g4 #2 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 44L gap 20.503 | Timo Scheider
 8 g17 #11 HWA Team | Mercedes AMG C-Coupé | Classified 44L gap 20.597 | Gary Paffett
 9 g12 #10 BMW Team Schnitzer | BMW M4 DTM | Classified 44L gap 23.079 | Martin Tomczyk
 10 g2 #16 Audi Sport Team Abt | Audi RS 5 DTM | Classified 44L gap 24.340 | Adrien Tambay
 11 g3 #18 BMW Team MTEK | BMW M4 DTM | Classified 44L gap 24.620 | António Félix da Costa
 12 g6 #9 BMW Team Schnitzer | BMW M4 DTM | Classified 44L gap 26.892 | Bruno Spengler
 13 g11 #7 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 44L gap 27.201 | Mattias Ekström
 14 g13 #24 BMW Team RMG | BMW M4 DTM | Classified 44L gap 31.032 | Maxime Martin
 15 g15 #4 BMW Team RBM | BMW M4 DTM | Classified 44L gap 39.802 | Joey Hand
 16 g14 #22 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 44L gap 44.324 | Nico Müller
 17 g22 #20 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 44L gap 55.493 | Vitaly Petrov
 18 g10 #21 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 43L gap 1 LAP | Jamie Green
 19 g1 #23 BMW Team RMG | BMW M4 DTM | Classified 43L gap 1 LAP | Marco Wittmann
 20 g9 #25 HWA Team | Mercedes AMG C-Coupé | RET 26L gap RET | Pascal Wehrlein
 21 g21 #19 Mücke Motorsport | Mercedes AMG C-Coupé | RET 22L gap RET | Daniel Juncadella
 22 g18 #17 BMW Team MTEK | BMW M4 DTM | RET 13L gap RET | Timo Glock
 23 g19 #12 HWA Team | Mercedes AMG C-Coupé | RET 9L gap RET | Robert Wickens
