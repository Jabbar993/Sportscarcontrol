# dtm-hungaroring-2014-r3

Event: DTM Hungaroring | Circuit: Hungaroring | Date: 2014-06-01
Scheduled: ? | Official duration: 1:08:35.291 | Laps (winner): 41

## Qualifying (archive order)
Q1 #23 [DTMV8] 1:36.518 BMW Team RMG | Marco Wittmann
Q2 #17 [DTMV8] 1:36.731 BMW Team MTEK | Timo Glock
Q3 #8 [DTMV8] 1:36.757 Audi Sport Team Abt Sportsline | Miguel Molina
Q4 #24 [DTMV8] 1:36.777 BMW Team RMG | Maxime Martin
Q5 #18 [DTMV8] 1:36.896 BMW Team MTEK | António Félix da Costa
Q6 #3 [DTMV8] 1:37.061 BMW Team RBM | Augusto Farfus
Q7 #16 [DTMV8] 1:37.134 Audi Sport Team Abt | Adrien Tambay
Q8 #22 [DTMV8] 1:37.174 Audi Sport Team Rosberg | Nico Müller
Q9 #9 [DTMV8] 1:37.257 BMW Team Schnitzer | Bruno Spengler
Q10 #21 [DTMV8] 1:37.259 Audi Sport Team Rosberg | Jamie Green
Q11 #7 [DTMV8] 1:37.301 Audi Sport Team Abt Sportsline | Mattias Ekström
Q12 #15 [DTMV8] 1:37.352 Audi Sport Team Abt | Edoardo Mortara
Q13 #1 [DTMV8] 1:37.611 Audi Sport Team Phoenix | Mike Rockenfeller
Q14 #4 [DTMV8] 1:37.644 BMW Team RBM | Joey Hand
Q15 #2 [DTMV8] 1:37.766 Audi Sport Team Phoenix | Timo Scheider
Q16 #25 [DTMV8] 1:37.846 HWA Team | Pascal Wehrlein
Q17 #12 [DTMV8] 1:37.857 HWA Team | Robert Wickens
Q18 #10 [DTMV8] 1:37.945 BMW Team Schnitzer | Martin Tomczyk
Q19 #6 [DTMV8] 1:38.133 HWA Team | Paul di Resta
Q20 #19 [DTMV8] 1:38.216 Mücke Motorsport | Daniel Juncadella
Q21 #11 [DTMV8] 1:38.384 HWA Team | Gary Paffett
Q22 #20 [DTMV8] 1:38.960 Mücke Motorsport | Vitaly Petrov
Q23 #5 [DTMV8] 1:39.022 HWA Team | Christian Vietoris

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #23 Marco Wittmann 1:36.518 BMW Team RMG
DTMV8: #23 Marco Wittmann 1:36.518 BMW Team RMG

## Fastest laps (archive)
Overall: #22 Nico Müller 1:37.556 lap 26
DTMV8: #22 Nico Müller 1:37.556 lap 26

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #23 BMW Team RMG | BMW M4 DTM | Classified 41L gap — | Marco Wittmann
 2 g3 #8 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 41L gap 6.615 | Miguel Molina
 3 g9 #9 BMW Team Schnitzer | BMW M4 DTM | Classified 41L gap 21.842 | Bruno Spengler
 4 g12 #15 Audi Sport Team Abt | Audi RS 5 DTM | Classified 41L gap 29.960 | Edoardo Mortara
 5 g7 #16 Audi Sport Team Abt | Audi RS 5 DTM | Classified 41L gap 30.112 | Adrien Tambay
 6 g4 #24 BMW Team RMG | BMW M4 DTM | Classified 41L gap 30.357 | Maxime Martin
 7 g10 #21 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 41L gap 34.403 | Jamie Green
 8 g5 #18 BMW Team MTEK | BMW M4 DTM | Classified 41L gap 34.560 | António Félix da Costa
 9 g11 #7 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 41L gap 34.826 | Mattias Ekström
 10 g13 #1 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 41L gap 36.017 | Mike Rockenfeller
 11 g17 #12 HWA Team | Mercedes AMG C-Coupé | Classified 41L gap 38.732 | Robert Wickens
 12 g8 #22 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 41L gap 41.105 | Nico Müller
 13 g18 #10 BMW Team Schnitzer | BMW M4 DTM | Classified 41L gap 1:00.014 | Martin Tomczyk
 14 g16 #25 HWA Team | Mercedes AMG C-Coupé | Classified 41L gap 1:00.170 | Pascal Wehrlein
 15 g14 #4 BMW Team RBM | BMW M4 DTM | Classified 41L gap 1:04.407 | Joey Hand
 16 g20 #19 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 41L gap 1:04.809 | Daniel Juncadella
 17 g22 #20 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 41L gap 1:19.739 | Vitaly Petrov
 18 g19 #6 HWA Team | Mercedes AMG C-Coupé | Classified 41L gap 1:25.635 | Paul di Resta
 19 g2 #17 BMW Team MTEK | BMW M4 DTM | Classified 41L gap 1:28.687 | Timo Glock
 20 g23 #5 HWA Team | Mercedes AMG C-Coupé | Classified 36L gap 5 LAPS | Christian Vietoris
 21 g6 #3 BMW Team RBM | BMW M4 DTM | Classified 31L gap 10 LAPS | Augusto Farfus
 22 g15 #2 Audi Sport Team Phoenix | Audi RS 5 DTM | RET 10L gap RET | Timo Scheider
 23 g21 #11 HWA Team | Mercedes AMG C-Coupé | RET 1L gap RET | Gary Paffett
