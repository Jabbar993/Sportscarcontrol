# dtm-circuitzandvoort-2014-r9

Event: DTM Circuit Zandvoort | Circuit: Zandvoort | Date: 2014-09-28
Scheduled: ? | Official duration: 1:16:35.761 | Laps (winner): 43

## Qualifying (archive order)
Q1 #1 [DTMV8] 1:30.713 Audi Sport Team Phoenix | Mike Rockenfeller
Q2 #23 [DTMV8] 1:30.739 BMW Team RMG | Marco Wittmann
Q3 #15 [DTMV8] 1:30.757 Audi Sport Team Abt | Edoardo Mortara
Q4 #7 [DTMV8] 1:30.869 Audi Sport Team Abt Sportsline | Mattias Ekström
Q5 #21 [DTMV8] 1:30.957 Audi Sport Team Rosberg | Jamie Green
Q6 #22 [DTMV8] 1:30.968 Audi Sport Team Rosberg | Nico Müller
Q7 #25 [DTMV8] 1:31.063 HWA Team | Pascal Wehrlein
Q8 #10 [DTMV8] 1:31.904 BMW Team Schnitzer | Martin Tomczyk
Q9 #4 [DTMV8] 1:30.892 BMW Team RBM | Joey Hand
Q10 #8 [DTMV8] 1:30.908 Audi Sport Team Abt Sportsline | Miguel Molina
Q11 #11 [DTMV8] 1:30.965 HWA Team | Gary Paffett
Q12 #16 [DTMV8] 1:30.997 Audi Sport Team Abt | Adrien Tambay
Q13 #6 [DTMV8] 1:31.005 HWA Team | Paul di Resta
Q14 #17 [DTMV8] 1:31.027 BMW Team MTEK | Timo Glock
Q15 #9 [DTMV8] 1:31.102 BMW Team Schnitzer | Bruno Spengler
Q16 #2 [DTMV8] 1:31.118 Audi Sport Team Phoenix | Timo Scheider
Q17 #24 [DTMV8] 1:31.425 BMW Team RMG | Maxime Martin
Q18 #5 [DTMV8] 1:31.504 HWA Team | Christian Vietoris
Q19 #18 [DTMV8] 1:31.611 BMW Team MTEK | António Félix da Costa
Q20 #3 [DTMV8] 1:31.668 BMW Team RBM | Augusto Farfus
Q21 #12 [DTMV8] 1:31.673 HWA Team | Robert Wickens
Q22 #19 [DTMV8] 1:31.784 Mücke Motorsport | Daniel Juncadella
Q23 #20 [DTMV8] 1:33.002 Mücke Motorsport | Vitaly Petrov

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #1 Mike Rockenfeller 1:30.713 Audi Sport Team Phoenix
DTMV8: #1 Mike Rockenfeller 1:30.713 Audi Sport Team Phoenix

## Fastest laps (archive)
Overall: #23 Marco Wittmann 1:32.411 lap 2
DTMV8: #23 Marco Wittmann 1:32.411 lap 2

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g8 #7 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 43L gap — | Mattias Ekström
 2 g2 #23 BMW Team RMG | BMW M4 DTM | Classified 43L gap 7.414 | Marco Wittmann
 3 g6 #10 BMW Team Schnitzer | BMW M4 DTM | Classified 43L gap 11.144 | Martin Tomczyk
 4 g23 #15 Audi Sport Team Abt | Audi RS 5 DTM | Classified 43L gap 12.234 | Edoardo Mortara
 5 g17 #5 HWA Team | Mercedes AMG C-Coupé | Classified 43L gap 12.730 | Christian Vietoris
 6 g16 #24 BMW Team RMG | BMW M4 DTM | Classified 43L gap 14.260 | Maxime Martin
 7 g5 #25 HWA Team | Mercedes AMG C-Coupé | Classified 43L gap 15.128 | Pascal Wehrlein
 8 g20 #12 HWA Team | Mercedes AMG C-Coupé | Classified 43L gap 16.182 | Robert Wickens
 9 g15 #2 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 43L gap 16.792 | Timo Scheider
 10 g7 #4 BMW Team RBM | BMW M4 DTM | Classified 43L gap 20.736 | Joey Hand
 11 g22 #20 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 43L gap 21.518 | Vitaly Petrov
 12 g13 #17 BMW Team MTEK | BMW M4 DTM | Classified 43L gap 23.799 | Timo Glock
 13 g18 #18 BMW Team MTEK | BMW M4 DTM | Classified 43L gap 24.233 | António Félix da Costa
 14 g3 #21 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 43L gap 25.008 | Jamie Green
 15 g1 #1 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 43L gap 36.746 | Mike Rockenfeller
 16 g14 #9 BMW Team Schnitzer | BMW M4 DTM | Classified 43L gap 45.591 | Bruno Spengler
 17 g21 #19 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 43L gap 45.729 | Daniel Juncadella
 18 g9 #8 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 42L gap 1 LAP | Miguel Molina
 19 g10 #11 HWA Team | Mercedes AMG C-Coupé | Classified 34L gap 9 LAPS | Gary Paffett
 20 g4 #22 Audi Sport Team Rosberg | Audi RS 5 DTM | RET 25L gap RET | Nico Müller
 21 g19 #3 BMW Team RBM | BMW M4 DTM | RET 17L gap RET | Augusto Farfus
 22 g12 #6 HWA Team | Mercedes AMG C-Coupé | RET 16L gap RET | Paul di Resta
 23 g11 #16 Audi Sport Team Abt | Audi RS 5 DTM | RET 4L gap RET | Adrien Tambay
