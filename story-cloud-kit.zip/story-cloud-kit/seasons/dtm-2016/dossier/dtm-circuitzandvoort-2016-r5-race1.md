# dtm-circuitzandvoort-2016-r5-race1

Event: DTM Circuit Zandvoort Race 1 | Circuit: Zandvoort | Date: 2016-07-16
Scheduled: 00:40:00 | Official duration: 00:41:55.441 | Laps (winner): 25

## Qualifying (archive order)
Q1 #6 [DTMV8] 1:30.727 Mercedes-AMG Team HWA I | Robert Wickens
Q2 #11 [DTMV8] 1:30.843 BMW Team RMG | Marco Wittmann
Q3 #8 [DTMV8] 1:30.857 Mercedes-AMG Team Mücke | Christian Vietoris
Q4 #2 [DTMV8] 1:30.947 Mercedes-AMG Team ART | Gary Paffett
Q5 #53 [DTMV8] 1:30.953 Audi Sport Team Rosberg | Jamie Green
Q6 #48 [DTMV8] 1:31.099 Audi Sport Team Abt Sportsline | Edoardo Mortara
Q7 #34 [DTMV8] 1:31.144 Mercedes-AMG Team ART | Esteban Ocon
Q8 #13 [DTMV8] 1:31.149 BMW Team Schnitzer | António Félix da Costa
Q9 #5 [DTMV8] 1:31.164 Audi Sport Team Abt Sportsline | Mattias Ekström
Q10 #16 [DTMV8] 1:31.173 BMW Team RMG | Timo Glock
Q11 #27 [DTMV8] 1:31.217 Audi Sport Team Rosberg | Adrien Tambay
Q12 #36 [DTMV8] 1:31.281 BMW Team RBM | Maxime Martin
Q13 #12 [DTMV8] 1:31.327 Mercedes-AMG Team HWA I | Daniel Juncadella
Q14 #99 [DTMV8] 1:31.341 Audi Sport Team Phoenix | Mike Rockenfeller
Q15 #84 [DTMV8] 1:31.389 Mercedes-AMG Team HWA II | Maximilian Götz
Q16 #100 [DTMV8] 1:31.395 BMW Team Schnitzer | Martin Tomczyk
Q17 #7 [DTMV8] 1:31.626 BMW Team MTEK | Bruno Spengler
Q18 #17 [DTMV8] 1:31.665 Audi Sport Team Abt | Miguel Molina
Q19 #10 [DTMV8] 1:31.672 Audi Sport Team Phoenix | Timo Scheider
Q20 #3 [DTMV8] 1:31.725 Mercedes-AMG Team HWA II | Paul di Resta
Q21 #22 [DTMV8] 1:31.741 Mercedes-AMG Team Mücke | Lucas Auer
Q22 #31 [DTMV8] 1:31.822 BMW Team RBM | Tom Blomqvist
Q23 #51 [DTMV8] 1:31.872 Audi Sport Team Abt | Nico Müller
Q24 #18 [DTMV8] 1:31.911 BMW Team MTEK | Augusto Farfus

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #6 Robert Wickens 1:30.727 Mercedes-AMG Team HWA I
DTMV8: #6 Robert Wickens 1:30.727 Mercedes-AMG Team HWA I

## Fastest laps (archive)
Overall: #6 Robert Wickens 1:32.841 lap 8
DTMV8: #6 Robert Wickens 1:32.841 lap 8

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #6 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 25L gap — | Robert Wickens
 2 g2 #11 BMW Team RMG | BMW M4 DTM | Classified 25L gap 7.217 | Marco Wittmann
 3 g3 #8 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 25L gap 8.987 | Christian Vietoris
 4 g4 #2 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 25L gap 10.657 | Gary Paffett
 5 g5 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 25L gap 12.626 | Jamie Green
 6 g8 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 25L gap 18.178 | António Félix da Costa
 7 g9 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 25L gap 18.877 | Mattias Ekström
 8 g13 #12 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 25L gap 19.166 | Daniel Juncadella
 9 g7 #34 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 25L gap 19.838 | Esteban Ocon
 10 g12 #36 BMW Team RBM | BMW M4 DTM | Classified 25L gap 23.592 | Maxime Martin
 11 g18 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 25L gap 23.886 | Timo Scheider
 12 g20 #22 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 25L gap 28.082 | Lucas Auer
 13 g16 #7 BMW Team MTEK | BMW M4 DTM | Classified 25L gap 30.052 | Bruno Spengler
 14 g17 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 25L gap 30.424 | Mike Rockenfeller
 15 g19 #3 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 25L gap 30.898 | Paul di Resta
 16 g21 #31 BMW Team RBM | BMW M4 DTM | Classified 25L gap 31.416 | Tom Blomqvist
 17 g6 #48 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 25L gap 31.575 | Edoardo Mortara
 18 g23 #17 Audi Sport Team Abt | Audi RS 5 DTM | Classified 25L gap 32.288 | Miguel Molina
 19 g15 #100 BMW Team Schnitzer | BMW M4 DTM | Classified 25L gap 39.134 | Martin Tomczyk
 20 g22 #51 Audi Sport Team Abt | Audi RS 5 DTM | Classified 25L gap 39.549 | Nico Müller
 21 g10 #16 BMW Team RMG | BMW M4 DTM | Classified 25L gap 45.004 | Timo Glock
 22 g24 #18 BMW Team MTEK | BMW M4 DTM | RET 8L gap RET | Augusto Farfus
 23 g11 #27 Audi Sport Team Rosberg | Audi RS 5 DTM | RET 0L gap RET | Adrien Tambay
 24 g14 #84 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | RET 0L gap RET | Maximilian Götz
