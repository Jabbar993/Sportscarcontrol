# dtm-hockenheimring-2016-r9-race1

Event: DTM Hockenheimring Race 1 | Circuit: Hockenheimring | Date: 2016-10-15
Scheduled: 00:40:00 | Official duration: 00:43:02.346 | Laps (winner): 27

## Qualifying (archive order)
Q1 #13 [DTMV8] 1:32.344 BMW Team Schnitzer | António Félix da Costa
Q2 #17 [DTMV8] 1:32.444 Audi Sport Team Abt | Miguel Molina
Q3 #31 [DTMV8] 1:32.508 BMW Team RBM | Tom Blomqvist
Q4 #11 [DTMV8] 1:32.512 BMW Team RMG | Marco Wittmann
Q5 #36 [DTMV8] 1:32.574 BMW Team RBM | Maxime Martin
Q6 #99 [DTMV8] 1:32.620 Audi Sport Team Abt Sportsline | Mike Rockenfeller
Q7 #18 [DTMV8] 1:32.631 BMW Team MTEK | Augusto Farfus
Q8 #48 [DTMV8] 1:32.662 Audi Sport Team Abt Sportsline | Edoardo Mortara
Q9 #16 [DTMV8] 1:32.700 BMW Team RMG | Timo Glock
Q10 #51 [DTMV8] 1:32.704 Audi Sport Team Abt | Nico Müller
Q11 #72 [DTMV8] 1:32.726 Audi Sport Team Phoenix | René Rast
Q12 #3 [DTMV8] 1:32.794 Mercedes-AMG Team HWA II | Paul di Resta
Q13 #2 [DTMV8] 1:32.884 Mercedes-AMG Team ART | Gary Paffett
Q14 #53 [DTMV8] 1:32.908 Audi Sport Team Rosberg | Jamie Green
Q15 #10 [DTMV8] 1:32.918 Audi Sport Team Phoenix | Timo Scheider
Q16 #84 [DTMV8] 1:32.922 Mercedes-AMG Team HWA II | Maximilian Götz
Q17 #8 [DTMV8] 1:32.956 Mercedes-AMG Team Mücke | Christian Vietoris
Q18 #88 [DTMV8] 1:33.018 Mercedes-AMG Team ART | Felix Rosenqvist
Q19 #100 [DTMV8] 1:33.149 BMW Team Schnitzer | Martin Tomczyk
Q20 #7 [DTMV8] 1:33.168 BMW Team MTEK | Bruno Spengler
Q21 #6 [DTMV8] 1:33.238 Mercedes-AMG Team HWA I | Robert Wickens
Q22 #22 [DTMV8] 1:33.254 Mercedes-AMG Team Mücke | Lucas Auer
Q23 #27 [DTMV8] 1:33.285 Audi Sport Team Rosberg | Adrien Tambay
Q24 #12 [DTMV8] 1:33.362 Mercedes-AMG Team HWA I | Daniel Juncadella

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #13 António Félix da Costa 1:32.344 BMW Team Schnitzer
DTMV8: #13 António Félix da Costa 1:32.344 BMW Team Schnitzer

## Fastest laps (archive)
Overall: #13 António Félix da Costa 1:34.500 lap 5
DTMV8: #13 António Félix da Costa 1:34.500 lap 5

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g2 #17 Audi Sport Team Abt | Audi RS 5 DTM | Classified 27L gap — | Miguel Molina
 2 g4 #11 BMW Team RMG | BMW M4 DTM | Classified 27L gap 1.661 | Marco Wittmann
 3 g8 #48 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 27L gap 2.805 | Edoardo Mortara
 4 g1 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 27L gap 4.870 | António Félix da Costa
 5 g6 #99 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 27L gap 6.064 | Mike Rockenfeller
 6 g11 #72 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 27L gap 7.992 | René Rast
 7 g9 #16 BMW Team RMG | BMW M4 DTM | Classified 27L gap 11.858 | Timo Glock
 8 g14 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 27L gap 15.970 | Jamie Green
 9 g3 #31 BMW Team RBM | BMW M4 DTM | Classified 27L gap 17.188 | Tom Blomqvist
 10 g12 #3 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 27L gap 19.048 | Paul di Resta
 11 g7 #18 BMW Team MTEK | BMW M4 DTM | Classified 27L gap 21.208 | Augusto Farfus
 12 g21 #27 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 27L gap 21.928 | Adrien Tambay
 13 g5 #36 BMW Team RBM | BMW M4 DTM | Classified 27L gap 22.471 | Maxime Martin
 14 g19 #7 BMW Team MTEK | BMW M4 DTM | Classified 27L gap 23.233 | Bruno Spengler
 15 g10 #51 Audi Sport Team Abt | Audi RS 5 DTM | Classified 27L gap 23.808 | Nico Müller
 16 g15 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 27L gap 24.288 | Timo Scheider
 17 g16 #84 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 27L gap 24.712 | Maximilian Götz
 18 g24 #22 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 27L gap 24.967 | Lucas Auer
 19 g13 #2 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 27L gap 30.584 | Gary Paffett
 20 g23 #100 BMW Team Schnitzer | BMW M4 DTM | Classified 27L gap 35.904 | Martin Tomczyk
 21 g22 #12 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 27L gap 37.372 | Daniel Juncadella
 22 g17 #8 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 27L gap 43.593 | Christian Vietoris
 23 g20 #6 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | RET 25L gap RET | Robert Wickens
 24 g18 #88 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | RET 9L gap RET | Felix Rosenqvist
