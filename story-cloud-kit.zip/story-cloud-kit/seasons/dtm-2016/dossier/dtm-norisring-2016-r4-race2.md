# dtm-norisring-2016-r4-race2

Event: DTM Norisring Race 2 | Circuit: Norisring | Date: 2016-06-26
Scheduled: 01:00:00 | Official duration: 1:01:03.139 | Laps (winner): 72

## Qualifying (archive order)
Q1 #5 [DTMV8] 47.804 Audi Sport Team Abt Sportsline | Mattias Ekström
Q2 #31 [DTMV8] 47.820 BMW Team RBM | Tom Blomqvist
Q3 #3 [DTMV8] 47.877 Mercedes-AMG Team HWA II | Paul di Resta
Q4 #51 [DTMV8] 47.889 Audi Sport Team Abt | Nico Müller
Q5 #22 [DTMV8] 47.891 Mercedes-AMG Team Mücke | Lucas Auer
Q6 #36 [DTMV8] 47.895 BMW Team RBM | Maxime Martin
Q7 #6 [DTMV8] 47.902 Mercedes-AMG Team HWA I | Robert Wickens
Q8 #27 [DTMV8] 47.947 Audi Sport Team Rosberg | Adrien Tambay
Q9 #48 [DTMV8] 47.953 Audi Sport Team Abt Sportsline | Edoardo Mortara
Q10 #11 [DTMV8] 47.967 BMW Team RMG | Marco Wittmann
Q11 #13 [DTMV8] 47.996 BMW Team Schnitzer | António Félix da Costa
Q12 #84 [DTMV8] 48.029 Mercedes-AMG Team HWA II | Maximilian Götz
Q13 #10 [DTMV8] 48.032 Audi Sport Team Phoenix | Timo Scheider
Q14 #7 [DTMV8] 48.044 BMW Team MTEK | Bruno Spengler
Q15 #8 [DTMV8] 48.046 Mercedes-AMG Team Mücke | Christian Vietoris
Q16 #53 [DTMV8] 48.050 Audi Sport Team Rosberg | Jamie Green
Q17 #99 [DTMV8] 48.083 Audi Sport Team Phoenix | Mike Rockenfeller
Q18 #2 [DTMV8] 48.089 Mercedes-AMG Team ART | Gary Paffett
Q19 #34 [DTMV8] 48.101 Mercedes-AMG Team ART | Esteban Ocon
Q20 #12 [DTMV8] 48.110 Mercedes-AMG Team HWA I | Daniel Juncadella
Q21 #16 [DTMV8] 48.119 BMW Team RMG | Timo Glock
Q22 #18 [DTMV8] 48.129 BMW Team MTEK | Augusto Farfus
Q23 #17 [DTMV8] 48.139 Audi Sport Team Abt | Miguel Molina
Q24 #100 [DTMV8] 48.249 BMW Team Schnitzer | Martin Tomczyk

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #5 Mattias Ekström 47.804 Audi Sport Team Abt Sportsline
DTMV8: #5 Mattias Ekström 47.804 Audi Sport Team Abt Sportsline

## Fastest laps (archive)
Overall: #31 Tom Blomqvist 48.328 lap 54
DTMV8: #31 Tom Blomqvist 48.328 lap 54

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g3 #51 Audi Sport Team Abt | Audi RS 5 DTM | Classified 72L gap — | Nico Müller
 2 g1 #31 BMW Team RBM | BMW M4 DTM | Classified 72L gap 0.670 | Tom Blomqvist
 3 g6 #36 BMW Team RBM | BMW M4 DTM | Classified 72L gap 1.543 | Maxime Martin
 4 g2 #3 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 72L gap 4.701 | Paul di Resta
 5 g5 #22 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 72L gap 4.950 | Lucas Auer
 6 g10 #11 BMW Team RMG | BMW M4 DTM | Classified 72L gap 5.197 | Marco Wittmann
 7 g14 #7 BMW Team MTEK | BMW M4 DTM | Classified 72L gap 5.907 | Bruno Spengler
 8 g9 #48 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 72L gap 6.228 | Edoardo Mortara
 9 g20 #16 BMW Team RMG | BMW M4 DTM | Classified 72L gap 6.981 | Timo Glock
 10 g23 #100 BMW Team Schnitzer | BMW M4 DTM | Classified 72L gap 7.224 | Martin Tomczyk
 11 g7 #6 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 72L gap 10.510 | Robert Wickens
 12 g12 #84 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 72L gap 10.906 | Maximilian Götz
 13 g18 #34 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 72L gap 11.543 | Esteban Ocon
 14 g22 #17 Audi Sport Team Abt | Audi RS 5 DTM | Classified 72L gap 13.013 | Miguel Molina
 15 g15 #8 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 72L gap 14.094 | Christian Vietoris
 16 g13 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 72L gap 20.885 | Timo Scheider
 17 g16 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 58L gap 14 LAPS | Jamie Green
 18 g17 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | RET 70L gap RET | Mike Rockenfeller
 19 g8 #27 Audi Sport Team Rosberg | Audi RS 5 DTM | RET 68L gap RET | Adrien Tambay
 20 g19 #12 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | RET 63L gap RET | Daniel Juncadella
 21 g11 #13 BMW Team Schnitzer | BMW M4 DTM | RET 63L gap RET | António Félix da Costa
 22 g24 #2 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | RET 59L gap RET | Gary Paffett
 23 g4 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | RET 1L gap RET | Mattias Ekström
 24 g21 #18 BMW Team MTEK | BMW M4 DTM | RET 1L gap RET | Augusto Farfus
