# dtm-lausitzring-2016-r3-race1

Event: DTM Lausitzring Race 1 | Circuit: Lausitzring | Date: 2016-06-04
Scheduled: 00:40:00 | Official duration: 00:42:04.244 | Laps (winner): 32

## Qualifying (archive order)
Q1 #17 [DTMV8] 1:16.619 Audi Sport Team Abt | Miguel Molina
Q2 #53 [DTMV8] 1:16.696 Audi Sport Team Rosberg | Jamie Green
Q3 #11 [DTMV8] 1:16.771 BMW Team RMG | Marco Wittmann
Q4 #6 [DTMV8] 1:16.792 Mercedes-AMG Team HWA I | Robert Wickens
Q5 #22 [DTMV8] 1:16.844 Mercedes-AMG Team Mücke | Lucas Auer
Q6 #8 [DTMV8] 1:16.896 Mercedes-AMG Team Mücke | Christian Vietoris
Q7 #5 [DTMV8] 1:16.901 Audi Sport Team Abt Sportsline | Mattias Ekström
Q8 #36 [DTMV8] 1:16.901 BMW Team RBM | Maxime Martin
Q9 #27 [DTMV8] 1:16.961 Audi Sport Team Rosberg | Adrien Tambay
Q10 #51 [DTMV8] 1:16.993 Audi Sport Team Abt | Nico Müller
Q11 #48 [DTMV8] 1:16.997 Audi Sport Team Abt Sportsline | Edoardo Mortara
Q12 #2 [DTMV8] 1:17.059 Mercedes-AMG Team ART | Gary Paffett
Q13 #99 [DTMV8] 1:17.082 Audi Sport Team Phoenix | Mike Rockenfeller
Q14 #16 [DTMV8] 1:17.126 BMW Team RMG | Timo Glock
Q15 #84 [DTMV8] 1:17.172 Mercedes-AMG Team HWA II | Maximilian Götz
Q16 #7 [DTMV8] 1:17.188 BMW Team MTEK | Bruno Spengler
Q17 #34 [DTMV8] 1:17.225 Mercedes-AMG Team ART | Esteban Ocon
Q18 #10 [DTMV8] 1:17.228 Audi Sport Team Phoenix | Timo Scheider
Q19 #31 [DTMV8] 1:17.295 BMW Team RBM | Tom Blomqvist
Q20 #13 [DTMV8] 1:17.296 BMW Team Schnitzer | António Félix da Costa
Q21 #3 [DTMV8] 1:17.340 Mercedes-AMG Team HWA II | Paul di Resta
Q22 #12 [DTMV8] 1:17.356 Mercedes-AMG Team HWA I | Daniel Juncadella
Q23 #18 [DTMV8] 1:17.406 BMW Team MTEK | Augusto Farfus
Q24 #100 [DTMV8] 1:17.536 BMW Team Schnitzer | Martin Tomczyk

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #17 Miguel Molina 1:16.619 Audi Sport Team Abt
DTMV8: #17 Miguel Molina 1:16.619 Audi Sport Team Abt

## Fastest laps (archive)
Overall: #17 Miguel Molina 1:18.149 lap 10
DTMV8: #17 Miguel Molina 1:18.149 lap 10

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #17 Audi Sport Team Abt | Audi RS 5 DTM | Classified 32L gap — | Miguel Molina
 2 g2 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 32L gap 2.034 | Jamie Green
 3 g4 #6 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 32L gap 4.175 | Robert Wickens
 4 g3 #11 BMW Team RMG | BMW M4 DTM | Classified 32L gap 8.724 | Marco Wittmann
 5 g6 #8 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 32L gap 9.759 | Christian Vietoris
 6 g7 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 32L gap 10.398 | Mattias Ekström
 7 g5 #22 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 32L gap 10.794 | Lucas Auer
 8 g14 #48 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 32L gap 14.437 | Edoardo Mortara
 9 g8 #36 BMW Team RBM | BMW M4 DTM | Classified 32L gap 17.808 | Maxime Martin
 10 g10 #51 Audi Sport Team Abt | Audi RS 5 DTM | Classified 32L gap 18.414 | Nico Müller
 11 g15 #7 BMW Team MTEK | BMW M4 DTM | Classified 32L gap 18.965 | Bruno Spengler
 12 g13 #16 BMW Team RMG | BMW M4 DTM | Classified 32L gap 22.282 | Timo Glock
 13 g21 #3 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 32L gap 31.821 | Paul di Resta
 14 g11 #2 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 32L gap 33.128 | Gary Paffett
 15 g19 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 32L gap 36.391 | António Félix da Costa
 16 g20 #84 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 32L gap 38.400 | Maximilian Götz
 17 g17 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 32L gap 39.396 | Timo Scheider
 18 g22 #12 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 32L gap 40.298 | Daniel Juncadella
 19 g12 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 32L gap 41.509 | Mike Rockenfeller
 20 g9 #27 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 32L gap 42.741 | Adrien Tambay
 21 g23 #18 BMW Team MTEK | BMW M4 DTM | Classified 32L gap 43.286 | Augusto Farfus
 22 g18 #31 BMW Team RBM | BMW M4 DTM | Classified 32L gap 43.912 | Tom Blomqvist
 23 g16 #34 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 32L gap 49.778 | Esteban Ocon
 24 g24 #100 BMW Team Schnitzer | BMW M4 DTM | RET 5L gap RET | Martin Tomczyk
