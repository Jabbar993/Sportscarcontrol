# dtm-hungaroring-2016-r8-race2

Event: DTM Hungaroring Race 2 | Circuit: Hungaroring | Date: 2016-09-25
Scheduled: 01:00:00 | Official duration: 00:59:09.402 | Laps (winner): 36

## Qualifying (archive order)
Q1 #48 [DTMV8] 1:34.984 Audi Sport Team Abt Sportsline | Edoardo Mortara
Q2 #5 [DTMV8] 1:35.138 Audi Sport Team Abt Sportsline | Mattias Ekström
Q3 #11 [DTMV8] 1:35.139 BMW Team RMG | Marco Wittmann
Q4 #53 [DTMV8] 1:35.145 Audi Sport Team Rosberg | Jamie Green
Q5 #17 [DTMV8] 1:35.191 Audi Sport Team Abt | Miguel Molina
Q6 #36 [DTMV8] 1:35.303 BMW Team RBM | Maxime Martin
Q7 #31 [DTMV8] 1:35.373 BMW Team RBM | Tom Blomqvist
Q8 #6 [DTMV8] 1:35.388 Mercedes-AMG Team HWA I | Robert Wickens
Q9 #51 [DTMV8] 1:35.460 Audi Sport Team Abt | Nico Müller
Q10 #27 [DTMV8] 1:35.476 Audi Sport Team Rosberg | Adrien Tambay
Q11 #12 [DTMV8] 1:35.534 Mercedes-AMG Team HWA I | Daniel Juncadella
Q12 #13 [DTMV8] 1:35.537 BMW Team Schnitzer | António Félix da Costa
Q13 #10 [DTMV8] 1:35.562 Audi Sport Team Phoenix | Timo Scheider
Q14 #18 [DTMV8] 1:35.563 BMW Team MTEK | Augusto Farfus
Q15 #16 [DTMV8] 1:35.567 BMW Team RMG | Timo Glock
Q16 #99 [DTMV8] 1:35.651 Audi Sport Team Phoenix | Mike Rockenfeller
Q17 #100 [DTMV8] 1:35.723 BMW Team Schnitzer | Martin Tomczyk
Q18 #8 [DTMV8] 1:35.767 Mercedes-AMG Team Mücke | Christian Vietoris
Q19 #7 [DTMV8] 1:35.835 BMW Team MTEK | Bruno Spengler
Q20 #22 [DTMV8] 1:35.849 Mercedes-AMG Team Mücke | Lucas Auer
Q21 #3 [DTMV8] 1:35.859 Mercedes-AMG Team HWA II | Paul di Resta
Q22 #2 [DTMV8] 1:35.913 Mercedes-AMG Team ART | Gary Paffett
Q23 #84 [DTMV8] 1:35.961 Mercedes-AMG Team HWA II | Maximilian Götz
Q24 #88 [DTMV8] 1:36.062 Mercedes-AMG Team ART | Felix Rosenqvist

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #48 Edoardo Mortara 1:34.984 Audi Sport Team Abt Sportsline
DTMV8: #48 Edoardo Mortara 1:34.984 Audi Sport Team Abt Sportsline

## Fastest laps (archive)
Overall: #5 Mattias Ekström 1:36.538 lap 26
DTMV8: #5 Mattias Ekström 1:36.538 lap 26

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g2 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 36L gap — | Mattias Ekström
 2 g10 #27 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 36L gap 4.350 | Adrien Tambay
 3 g12 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 36L gap 24.209 | António Félix da Costa
 4 g7 #31 BMW Team RBM | BMW M4 DTM | Classified 36L gap 26.067 | Tom Blomqvist
 5 g15 #16 BMW Team RMG | BMW M4 DTM | Classified 36L gap 26.813 | Timo Glock
 6 g13 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 36L gap 31.792 | Timo Scheider
 7 g6 #36 BMW Team RBM | BMW M4 DTM | Classified 36L gap 38.310 | Maxime Martin
 8 g16 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 36L gap 38.675 | Mike Rockenfeller
 9 g17 #100 BMW Team Schnitzer | BMW M4 DTM | Classified 36L gap 39.966 | Martin Tomczyk
 10 g8 #6 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 36L gap 40.327 | Robert Wickens
 11 g24 #88 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 36L gap 40.710 | Felix Rosenqvist
 12 g19 #7 BMW Team MTEK | BMW M4 DTM | Classified 36L gap 41.317 | Bruno Spengler
 13 g21 #3 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 36L gap 41.777 | Paul di Resta
 14 g18 #8 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 36L gap 42.352 | Christian Vietoris
 15 g20 #22 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 36L gap 42.755 | Lucas Auer
 16 g22 #2 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 36L gap 43.015 | Gary Paffett
 17 g23 #84 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 36L gap 45.388 | Maximilian Götz
 18 g5 #17 Audi Sport Team Abt | Audi RS 5 DTM | Classified 36L gap 1:07.034 | Miguel Molina
 19 g1 #48 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 33L gap 3 LAPS | Edoardo Mortara
 20 g11 #12 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | RET 36L gap RET | Daniel Juncadella
 21 g3 #11 BMW Team RMG | BMW M4 DTM | RET 36L gap RET | Marco Wittmann
 22 g9 #51 Audi Sport Team Abt | Audi RS 5 DTM | RET 8L gap RET | Nico Müller
 23 g14 #18 BMW Team MTEK | BMW M4 DTM | RET 2L gap RET | Augusto Farfus
 24 g4 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | RET 1L gap RET | Jamie Green
