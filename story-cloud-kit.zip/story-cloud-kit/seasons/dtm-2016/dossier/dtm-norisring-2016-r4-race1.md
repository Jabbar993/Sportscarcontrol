# dtm-norisring-2016-r4-race1

Event: DTM Norisring Race 1 | Circuit: Norisring | Date: 2016-06-25
Scheduled: 00:40:00 | Official duration: 00:41:09.983 | Laps (winner): 49

## Qualifying (archive order)
Q1 #8 [DTMV8] 48.144 Mercedes-AMG Team Mücke | Christian Vietoris
Q2 #5 [DTMV8] 48.182 Audi Sport Team Abt Sportsline | Mattias Ekström
Q3 #53 [DTMV8] 48.194 Audi Sport Team Rosberg | Jamie Green
Q4 #6 [DTMV8] 48.250 Mercedes-AMG Team HWA I | Robert Wickens
Q5 #7 [DTMV8] 48.257 BMW Team MTEK | Bruno Spengler
Q6 #48 [DTMV8] 48.305 Audi Sport Team Abt Sportsline | Edoardo Mortara
Q7 #3 [DTMV8] 48.312 Mercedes-AMG Team HWA II | Paul di Resta
Q8 #22 [DTMV8] 48.342 Mercedes-AMG Team Mücke | Lucas Auer
Q9 #99 [DTMV8] 48.352 Audi Sport Team Phoenix | Mike Rockenfeller
Q10 #51 [DTMV8] 48.357 Audi Sport Team Abt | Nico Müller
Q11 #16 [DTMV8] 48.360 BMW Team RMG | Timo Glock
Q12 #18 [DTMV8] 48.362 BMW Team MTEK | Augusto Farfus
Q13 #11 [DTMV8] 48.376 BMW Team RMG | Marco Wittmann
Q14 #36 [DTMV8] 48.389 BMW Team RBM | Maxime Martin
Q15 #27 [DTMV8] 48.393 Audi Sport Team Rosberg | Adrien Tambay
Q16 #2 [DTMV8] 48.430 Mercedes-AMG Team ART | Gary Paffett
Q17 #84 [DTMV8] 48.445 Mercedes-AMG Team HWA II | Maximilian Götz
Q18 #17 [DTMV8] 48.464 Audi Sport Team Abt | Miguel Molina
Q19 #10 [DTMV8] 48.491 Audi Sport Team Phoenix | Timo Scheider
Q20 #31 [DTMV8] 48.500 BMW Team RBM | Tom Blomqvist
Q21 #13 [DTMV8] 48.526 BMW Team Schnitzer | António Félix da Costa
Q22 #12 [DTMV8] 48.538 Mercedes-AMG Team HWA I | Daniel Juncadella
Q23 #100 [DTMV8] 48.544 BMW Team Schnitzer | Martin Tomczyk
Q24 #34 [DTMV8] 48.574 Mercedes-AMG Team ART | Esteban Ocon

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #8 Christian Vietoris 48.144 Mercedes-AMG Team Mücke
DTMV8: #8 Christian Vietoris 48.144 Mercedes-AMG Team Mücke

## Fastest laps (archive)
Overall: #48 Edoardo Mortara 48.746 lap 20
DTMV8: #48 Edoardo Mortara 48.746 lap 20

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g6 #48 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 49L gap — | Edoardo Mortara
 2 g3 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 49L gap 0.531 | Jamie Green
 3 g7 #3 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 49L gap 0.903 | Paul di Resta
 4 g13 #11 BMW Team RMG | BMW M4 DTM | Classified 49L gap 4.135 | Marco Wittmann
 5 g5 #7 BMW Team MTEK | BMW M4 DTM | Classified 49L gap 6.731 | Bruno Spengler
 6 g14 #36 BMW Team RBM | BMW M4 DTM | Classified 49L gap 9.951 | Maxime Martin
 7 g15 #27 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 49L gap 10.875 | Adrien Tambay
 8 g17 #84 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 49L gap 13.501 | Maximilian Götz
 9 g21 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 49L gap 15.337 | António Félix da Costa
 10 g1 #8 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 49L gap 15.477 | Christian Vietoris
 11 g12 #18 BMW Team MTEK | BMW M4 DTM | Classified 49L gap 16.939 | Augusto Farfus
 12 g23 #100 BMW Team Schnitzer | BMW M4 DTM | Classified 49L gap 17.699 | Martin Tomczyk
 13 g8 #22 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 49L gap 17.985 | Lucas Auer
 14 g11 #16 BMW Team RMG | BMW M4 DTM | Classified 49L gap 18.674 | Timo Glock
 15 g16 #2 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 49L gap 19.208 | Gary Paffett
 16 g20 #31 BMW Team RBM | BMW M4 DTM | Classified 49L gap 19.571 | Tom Blomqvist
 17 g19 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 49L gap 20.202 | Timo Scheider
 18 g18 #17 Audi Sport Team Abt | Audi RS 5 DTM | Classified 49L gap 20.799 | Miguel Molina
 19 g9 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 49L gap 21.350 | Mike Rockenfeller
 20 g22 #12 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 49L gap 21.562 | Daniel Juncadella
 21 g10 #51 Audi Sport Team Abt | Audi RS 5 DTM | Classified 49L gap 22.171 | Nico Müller
 22 g24 #34 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | RET 32L gap RET | Esteban Ocon
 23 g2 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | RET 22L gap RET | Mattias Ekström
 24 g4 #6 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | RET 19L gap RET | Robert Wickens
