# dtm-moscowraceway-2016-r6-race1

Event: DTM Moscow Raceway Race 1 | Circuit: Moscow Raceway | Date: 2016-08-20
Scheduled: 00:40:00 | Official duration: 00:42:29.196 | Laps (winner): 22

## Qualifying (archive order)
Q1 #2 [DTMV8] 1:41.443 Mercedes-AMG Team ART | Gary Paffett
Q2 #6 [DTMV8] 1:42.048 Mercedes-AMG Team HWA I | Robert Wickens
Q3 #3 [DTMV8] 1:42.130 Mercedes-AMG Team HWA II | Paul di Resta
Q4 #84 [DTMV8] 1:42.164 Mercedes-AMG Team HWA II | Maximilian Götz
Q5 #5 [DTMV8] 1:42.450 Audi Sport Team Abt Sportsline | Mattias Ekström
Q6 #36 [DTMV8] 1:42.506 BMW Team RBM | Maxime Martin
Q7 #10 [DTMV8] 1:42.631 Audi Sport Team Phoenix | Timo Scheider
Q8 #16 [DTMV8] 1:42.631 BMW Team RMG | Timo Glock
Q9 #88 [DTMV8] 1:42.647 Mercedes-AMG Team ART | Felix Rosenqvist
Q10 #53 [DTMV8] 1:42.870 Audi Sport Team Rosberg | Jamie Green
Q11 #27 [DTMV8] 1:43.015 Audi Sport Team Rosberg | Adrien Tambay
Q12 #48 [DTMV8] 1:43.024 Audi Sport Team Abt Sportsline | Edoardo Mortara
Q13 #7 [DTMV8] 1:43.076 BMW Team MTEK | Bruno Spengler
Q14 #18 [DTMV8] 1:43.140 BMW Team MTEK | Augusto Farfus
Q15 #13 [DTMV8] 1:43.472 BMW Team Schnitzer | António Félix da Costa
Q16 #17 [DTMV8] 1:43.500 Audi Sport Team Abt | Miguel Molina
Q17 #51 [DTMV8] 1:43.521 Audi Sport Team Abt | Nico Müller
Q18 #22 [DTMV8] 1:43.660 Mercedes-AMG Team Mücke | Lucas Auer
Q19 #100 [DTMV8] 1:43.830 BMW Team Schnitzer | Martin Tomczyk
Q20 #11 [DTMV8] 1:43.856 BMW Team RMG | Marco Wittmann
Q21 #31 [DTMV8] 1:43.881 BMW Team RBM | Tom Blomqvist
Q22 #12 [DTMV8] 1:43.985 Mercedes-AMG Team HWA I | Daniel Juncadella
Q23 #99 [DTMV8] 1:44.488 Audi Sport Team Phoenix | Mike Rockenfeller
Q24 #8 [DTMV8] 1:44.800 Mercedes-AMG Team Mücke | Christian Vietoris

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #2 Gary Paffett 1:41.443 Mercedes-AMG Team ART
DTMV8: #2 Gary Paffett 1:41.443 Mercedes-AMG Team ART

## Fastest laps (archive)
Overall: #12 Daniel Juncadella 1:48.220 lap 21
DTMV8: #12 Daniel Juncadella 1:48.220 lap 21

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g2 #6 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 22L gap — | Robert Wickens
 2 g3 #3 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 22L gap 10.955 | Paul di Resta
 3 g1 #2 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 22L gap 12.293 | Gary Paffett
 4 g4 #84 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 22L gap 25.270 | Maximilian Götz
 5 g5 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 22L gap 25.874 | Mattias Ekström
 6 g6 #36 BMW Team RBM | BMW M4 DTM | Classified 22L gap 27.243 | Maxime Martin
 7 g10 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 22L gap 27.752 | Jamie Green
 8 g12 #48 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 22L gap 30.108 | Edoardo Mortara
 9 g7 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 22L gap 31.671 | Timo Scheider
 10 g9 #88 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 22L gap 32.848 | Felix Rosenqvist
 11 g8 #16 BMW Team RMG | BMW M4 DTM | Classified 22L gap 35.243 | Timo Glock
 12 g11 #27 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 22L gap 36.197 | Adrien Tambay
 13 g17 #51 Audi Sport Team Abt | Audi RS 5 DTM | Classified 22L gap 38.287 | Nico Müller
 14 g14 #18 BMW Team MTEK | BMW M4 DTM | Classified 22L gap 42.822 | Augusto Farfus
 15 g13 #7 BMW Team MTEK | BMW M4 DTM | Classified 22L gap 44.030 | Bruno Spengler
 16 g23 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 22L gap 44.781 | Mike Rockenfeller
 17 g16 #17 Audi Sport Team Abt | Audi RS 5 DTM | Classified 22L gap 46.951 | Miguel Molina
 18 g18 #22 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 22L gap 49.944 | Lucas Auer
 19 g20 #11 BMW Team RMG | BMW M4 DTM | Classified 22L gap 50.288 | Marco Wittmann
 20 g15 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 22L gap 51.313 | António Félix da Costa
 21 g19 #100 BMW Team Schnitzer | BMW M4 DTM | Classified 22L gap 59.926 | Martin Tomczyk
 22 g21 #31 BMW Team RBM | BMW M4 DTM | Classified 22L gap 1:02.697 | Tom Blomqvist
 23 g24 #8 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 22L gap 1:07.259 | Christian Vietoris
 24 g22 #12 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 22L gap 1:10.016 | Daniel Juncadella
