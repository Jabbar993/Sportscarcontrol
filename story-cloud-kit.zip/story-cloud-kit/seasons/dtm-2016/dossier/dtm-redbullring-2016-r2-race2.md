# dtm-redbullring-2016-r2-race2

Event: DTM Red Bull Ring Race 2 | Circuit: Red Bull Ring | Date: 2016-05-22
Scheduled: 01:00:00 | Official duration: 1:00:05.303 | Laps (winner): 41

## Qualifying (archive order)
Q1 #53 [DTMV8] 1:22.680 Audi Sport Team Rosberg | Jamie Green
Q2 #13 [DTMV8] 1:22.682 BMW Team Schnitzer | António Félix da Costa
Q3 #16 [DTMV8] 1:22.749 BMW Team RMG | Timo Glock
Q4 #36 [DTMV8] 1:22.799 BMW Team RBM | Maxime Martin
Q5 #48 [DTMV8] 1:22.812 Audi Sport Team Abt Sportsline | Edoardo Mortara
Q6 #18 [DTMV8] 1:22.812 BMW Team MTEK | Augusto Farfus
Q7 #7 [DTMV8] 1:22.845 BMW Team MTEK | Bruno Spengler
Q8 #31 [DTMV8] 1:22.847 BMW Team RBM | Tom Blomqvist
Q9 #99 [DTMV8] 1:22.878 Audi Sport Team Phoenix | Mike Rockenfeller
Q10 #11 [DTMV8] 1:22.883 BMW Team RMG | Marco Wittmann
Q11 #5 [DTMV8] 1:22.905 Audi Sport Team Abt Sportsline | Mattias Ekström
Q12 #27 [DTMV8] 1:22.910 Audi Sport Team Rosberg | Adrien Tambay
Q13 #51 [DTMV8] 1:22.986 Audi Sport Team Abt | Nico Müller
Q14 #10 [DTMV8] 1:23.003 Audi Sport Team Phoenix | Timo Scheider
Q15 #6 [DTMV8] 1:23.058 Mercedes-AMG Team HWA I | Robert Wickens
Q16 #12 [DTMV8] 1:23.070 Mercedes-AMG Team HWA I | Daniel Juncadella
Q17 #22 [DTMV8] 1:23.087 Mercedes-AMG Team Mücke | Lucas Auer
Q18 #100 [DTMV8] 1:23.139 BMW Team Schnitzer | Martin Tomczyk
Q19 #84 [DTMV8] 1:23.145 Mercedes-AMG Team HWA II | Maximilian Götz
Q20 #17 [DTMV8] 1:23.176 Audi Sport Team Abt | Miguel Molina
Q21 #34 [DTMV8] 1:23.189 Mercedes-AMG Team ART | Esteban Ocon
Q22 #8 [DTMV8] 1:23.210 Mercedes-AMG Team Mücke | Christian Vietoris
Q23 #2 [DTMV8] 1:23.269 Mercedes-AMG Team ART | Gary Paffett
Q24 #3 [DTMV8] 1:23.320 Mercedes-AMG Team HWA II | Paul di Resta

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #53 Jamie Green 1:22.680 Audi Sport Team Rosberg
DTMV8: #53 Jamie Green 1:22.680 Audi Sport Team Rosberg

## Fastest laps (archive)
Overall: #6 Robert Wickens 1:23.446 lap 40
DTMV8: #6 Robert Wickens 1:23.446 lap 40

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g3 #16 BMW Team RMG | BMW M4 DTM | Classified 41L gap — | Timo Glock
 2 g11 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 41L gap 2.976 | Mattias Ekström
 3 g1 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 41L gap 6.255 | Jamie Green
 4 g6 #18 BMW Team MTEK | BMW M4 DTM | Classified 41L gap 10.621 | Augusto Farfus
 5 g4 #36 BMW Team RBM | BMW M4 DTM | Classified 41L gap 11.432 | Maxime Martin
 6 g8 #31 BMW Team RBM | BMW M4 DTM | Classified 41L gap 12.111 | Tom Blomqvist
 7 g10 #11 BMW Team RMG | BMW M4 DTM | Classified 41L gap 12.814 | Marco Wittmann
 8 g9 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 41L gap 15.242 | Mike Rockenfeller
 9 g7 #7 BMW Team MTEK | BMW M4 DTM | Classified 41L gap 16.943 | Bruno Spengler
 10 g14 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 41L gap 19.667 | Timo Scheider
 11 g21 #2 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 41L gap 20.150 | Gary Paffett
 12 g12 #27 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 41L gap 20.745 | Adrien Tambay
 13 g16 #12 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 41L gap 21.444 | Daniel Juncadella
 14 g19 #17 Audi Sport Team Abt | Audi RS 5 DTM | Classified 41L gap 22.273 | Miguel Molina
 15 g22 #3 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 41L gap 22.837 | Paul di Resta
 16 g17 #22 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 41L gap 23.345 | Lucas Auer
 17 g20 #8 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 41L gap 24.155 | Christian Vietoris
 18 g24 #34 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 41L gap 25.683 | Esteban Ocon
 19 g23 #100 BMW Team Schnitzer | BMW M4 DTM | Classified 41L gap 26.312 | Martin Tomczyk
 20 g15 #6 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 41L gap 26.740 | Robert Wickens
 21 g2 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 41L gap 31.629 | António Félix da Costa
 22 g18 #84 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 41L gap 32.223 | Maximilian Götz
 23 g5 #48 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 23L gap 18 LAPS | Edoardo Mortara
 24 g13 #51 Audi Sport Team Abt | Audi RS 5 DTM | Classified 1L gap 40 LAPS | Nico Müller
