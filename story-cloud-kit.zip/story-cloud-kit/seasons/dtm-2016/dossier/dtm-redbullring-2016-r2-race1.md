# dtm-redbullring-2016-r2-race1

Event: DTM Red Bull Ring Race 1 | Circuit: Red Bull Ring | Date: 2016-05-21
Scheduled: 00:40:00 | Official duration: 00:42:10.795 | Laps (winner): 30

## Qualifying (archive order)
Q1 #11 [DTMV8] 1:22.795 BMW Team RMG | Marco Wittmann
Q2 #31 [DTMV8] 1:22.814 BMW Team RBM | Tom Blomqvist
Q3 #27 [DTMV8] 1:22.903 Audi Sport Team Rosberg | Adrien Tambay
Q4 #48 [DTMV8] 1:22.932 Audi Sport Team Abt Sportsline | Edoardo Mortara
Q5 #16 [DTMV8] 1:22.937 BMW Team RMG | Timo Glock
Q6 #36 [DTMV8] 1:22.957 BMW Team RBM | Maxime Martin
Q7 #13 [DTMV8] 1:22.997 BMW Team Schnitzer | António Félix da Costa
Q8 #3 [DTMV8] 1:22.998 Mercedes-AMG Team HWA II | Paul di Resta
Q9 #100 [DTMV8] 1:23.000 BMW Team Schnitzer | Martin Tomczyk
Q10 #5 [DTMV8] 1:23.005 Audi Sport Team Abt Sportsline | Mattias Ekström
Q11 #18 [DTMV8] 1:23.062 BMW Team MTEK | Augusto Farfus
Q12 #84 [DTMV8] 1:23.085 Mercedes-AMG Team HWA II | Maximilian Götz
Q13 #6 [DTMV8] 1:23.128 Mercedes-AMG Team HWA I | Robert Wickens
Q14 #7 [DTMV8] 1:23.150 BMW Team MTEK | Bruno Spengler
Q15 #51 [DTMV8] 1:23.218 Audi Sport Team Abt | Nico Müller
Q16 #12 [DTMV8] 1:23.223 Mercedes-AMG Team HWA I | Daniel Juncadella
Q17 #99 [DTMV8] 1:23.242 Audi Sport Team Phoenix | Mike Rockenfeller
Q18 #53 [DTMV8] 1:23.244 Audi Sport Team Rosberg | Jamie Green
Q19 #10 [DTMV8] 1:23.265 Audi Sport Team Phoenix | Timo Scheider
Q20 #22 [DTMV8] 1:23.368 Mercedes-AMG Team Mücke | Lucas Auer
Q21 #17 [DTMV8] 1:23.379 Audi Sport Team Abt | Miguel Molina
Q22 #34 [DTMV8] 1:23.416 Mercedes-AMG Team ART | Esteban Ocon
Q23 #2 [DTMV8] 1:23.459 Mercedes-AMG Team ART | Gary Paffett
Q24 #8 [DTMV8] 1:23.534 Mercedes-AMG Team Mücke | Christian Vietoris

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #11 Marco Wittmann 1:22.795 BMW Team RMG
DTMV8: #11 Marco Wittmann 1:22.795 BMW Team RMG

## Fastest laps (archive)
Overall: #5 Mattias Ekström 1:23.442 lap 19
DTMV8: #5 Mattias Ekström 1:23.442 lap 19

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #11 BMW Team RMG | BMW M4 DTM | Classified 30L gap — | Marco Wittmann
 2 g2 #31 BMW Team RBM | BMW M4 DTM | Classified 30L gap 0.726 | Tom Blomqvist
 3 g4 #48 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 30L gap 1.251 | Edoardo Mortara
 4 g5 #16 BMW Team RMG | BMW M4 DTM | Classified 30L gap 5.566 | Timo Glock
 5 g8 #100 BMW Team Schnitzer | BMW M4 DTM | Classified 30L gap 6.222 | Martin Tomczyk
 6 g6 #36 BMW Team RBM | BMW M4 DTM | Classified 30L gap 10.712 | Maxime Martin
 7 g7 #3 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 30L gap 12.182 | Paul di Resta
 8 g3 #27 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 30L gap 12.736 | Adrien Tambay
 9 g11 #18 BMW Team MTEK | BMW M4 DTM | Classified 30L gap 15.146 | Augusto Farfus
 10 g15 #51 Audi Sport Team Abt | Audi RS 5 DTM | Classified 30L gap 15.750 | Nico Müller
 11 g13 #6 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 30L gap 16.505 | Robert Wickens
 12 g17 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 30L gap 17.084 | Mike Rockenfeller
 13 g14 #7 BMW Team MTEK | BMW M4 DTM | Classified 30L gap 18.730 | Bruno Spengler
 14 g18 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 30L gap 21.135 | Jamie Green
 15 g12 #84 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 30L gap 21.292 | Maximilian Götz
 16 g9 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 30L gap 21.783 | Mattias Ekström
 17 g19 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 30L gap 22.534 | Timo Scheider
 18 g23 #2 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 30L gap 24.050 | Gary Paffett
 19 g21 #17 Audi Sport Team Abt | Audi RS 5 DTM | Classified 30L gap 24.743 | Miguel Molina
 20 g22 #34 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 30L gap 25.610 | Esteban Ocon
 21 g20 #22 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 30L gap 26.430 | Lucas Auer
 22 g10 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 30L gap 28.871 | António Félix da Costa
 23 g24 #8 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 5L gap 25 LAPS | Christian Vietoris
 24 g16 #12 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 4L gap 26 LAPS | Daniel Juncadella
