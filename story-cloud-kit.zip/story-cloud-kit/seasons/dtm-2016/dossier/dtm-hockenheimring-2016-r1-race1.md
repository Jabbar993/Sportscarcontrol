# dtm-hockenheimring-2016-r1-race1

Event: DTM Hockenheimring Race 1 | Circuit: Hockenheimring | Date: 2016-05-07
Scheduled: 00:40:00 | Official duration: 00:42:11.606 | Laps (winner): 25

## Qualifying (archive order)
Q1 #51 [DTMV8] 1:33.876 Audi Sport Team Abt | Nico Müller
Q2 #48 [DTMV8] 1:34.101 Audi Sport Team Abt Sportsline | Edoardo Mortara
Q3 #6 [DTMV8] 1:34.105 Mercedes-AMG Team HWA I | Robert Wickens
Q4 #53 [DTMV8] 1:34.106 Audi Sport Team Rosberg | Jamie Green
Q5 #99 [DTMV8] 1:34.131 Audi Sport Team Phoenix | Mike Rockenfeller
Q6 #8 [DTMV8] 1:34.149 Mercedes-AMG Team Mücke | Christian Vietoris
Q7 #3 [DTMV8] 1:34.157 Mercedes-AMG Team HWA II | Paul di Resta
Q8 #17 [DTMV8] 1:34.206 Audi Sport Team Abt | Miguel Molina
Q9 #5 [DTMV8] 1:34.209 Audi Sport Team Abt Sportsline | Mattias Ekström
Q10 #11 [DTMV8] 1:34.266 BMW Team RMG | Marco Wittmann
Q11 #2 [DTMV8] 1:34.302 Mercedes-AMG Team ART | Gary Paffett
Q12 #34 [DTMV8] 1:34.327 Mercedes-AMG Team ART | Esteban Ocon
Q13 #7 [DTMV8] 1:34.333 BMW Team MTEK | Bruno Spengler
Q14 #12 [DTMV8] 1:34.338 Mercedes-AMG Team HWA I | Daniel Juncadella
Q15 #18 [DTMV8] 1:34.350 BMW Team MTEK | Augusto Farfus
Q16 #16 [DTMV8] 1:34.357 BMW Team RMG | Timo Glock
Q17 #31 [DTMV8] 1:34.369 BMW Team RBM | Tom Blomqvist
Q18 #10 [DTMV8] 1:34.491 Audi Sport Team Phoenix | Timo Scheider
Q19 #84 [DTMV8] 1:34.548 Mercedes-AMG Team HWA II | Maximilian Götz
Q20 #13 [DTMV8] 1:34.607 BMW Team Schnitzer | António Félix da Costa
Q21 #36 [DTMV8] 1:34.703 BMW Team RBM | Maxime Martin
Q22 #100 [DTMV8] 1:34.705 BMW Team Schnitzer | Martin Tomczyk
Q23 #27 [DTMV8] 1:34.784 Audi Sport Team Rosberg | Adrien Tambay

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #51 Nico Müller 1:33.876 Audi Sport Team Abt
DTMV8: #51 Nico Müller 1:33.876 Audi Sport Team Abt

## Fastest laps (archive)
Overall: #6 Robert Wickens 1:35.465 lap 13
DTMV8: #6 Robert Wickens 1:35.465 lap 13

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g2 #48 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 25L gap — | Edoardo Mortara
 2 g3 #6 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 25L gap 1.657 | Robert Wickens
 3 g1 #51 Audi Sport Team Abt | Audi RS 5 DTM | Classified 25L gap 4.454 | Nico Müller
 4 g7 #3 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 25L gap 8.818 | Paul di Resta
 5 g6 #8 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 25L gap 10.192 | Christian Vietoris
 6 g13 #7 BMW Team MTEK | BMW M4 DTM | Classified 25L gap 20.097 | Bruno Spengler
 7 g20 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 25L gap 30.882 | António Félix da Costa
 8 g21 #36 BMW Team RBM | BMW M4 DTM | Classified 25L gap 41.360 | Maxime Martin
 9 g9 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 25L gap 46.455 | Mattias Ekström
 10 g8 #17 Audi Sport Team Abt | Audi RS 5 DTM | Classified 25L gap 47.198 | Miguel Molina
 11 g11 #2 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 25L gap 52.832 | Gary Paffett
 12 g22 #100 BMW Team Schnitzer | BMW M4 DTM | Classified 25L gap 55.137 | Martin Tomczyk
 13 g17 #31 BMW Team RBM | BMW M4 DTM | Classified 25L gap 55.530 | Tom Blomqvist
 14 g15 #18 BMW Team MTEK | BMW M4 DTM | Classified 25L gap 1:08.466 | Augusto Farfus
 15 g4 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 25L gap 1:09.184 | Jamie Green
 16 g10 #11 BMW Team RMG | BMW M4 DTM | Classified 25L gap 1:10.496 | Marco Wittmann
 17 g24 #22 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 20L gap 5 LAPS | Lucas Auer
 18 g19 #84 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | RET 6L gap RET | Maximilian Götz
 19 g5 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | RET 4L gap RET | Mike Rockenfeller
 20 g12 #34 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | RET 3L gap RET | Esteban Ocon
 21 g16 #16 BMW Team RMG | BMW M4 DTM | RET 2L gap RET | Timo Glock
 22 g14 #12 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | RET 2L gap RET | Daniel Juncadella
 23 g23 #27 Audi Sport Team Rosberg | Audi RS 5 DTM | RET 2L gap RET | Adrien Tambay
 24 g18 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | RET 1L gap RET | Timo Scheider
