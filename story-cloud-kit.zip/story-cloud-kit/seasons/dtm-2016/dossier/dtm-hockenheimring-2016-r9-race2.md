# dtm-hockenheimring-2016-r9-race2

Event: DTM Hockenheimring Race 2 | Circuit: Hockenheimring | Date: 2016-10-16
Scheduled: 01:00:00 | Official duration: 1:02:52.131 | Laps (winner): 39

## Qualifying (archive order)
Q1 #13 [DTMV8] 1:32.525 BMW Team Schnitzer | António Félix da Costa
Q2 #2 [DTMV8] 1:32.539 Mercedes-AMG Team ART | Gary Paffett
Q3 #31 [DTMV8] 1:32.589 BMW Team RBM | Tom Blomqvist
Q4 #36 [DTMV8] 1:32.601 BMW Team RBM | Maxime Martin
Q5 #11 [DTMV8] 1:32.616 BMW Team RMG | Marco Wittmann
Q6 #48 [DTMV8] 1:32.644 Audi Sport Team Abt Sportsline | Edoardo Mortara
Q7 #6 [DTMV8] 1:32.769 Mercedes-AMG Team HWA I | Robert Wickens
Q8 #16 [DTMV8] 1:32.805 BMW Team RMG | Timo Glock
Q9 #8 [DTMV8] 1:32.810 Mercedes-AMG Team Mücke | Christian Vietoris
Q10 #53 [DTMV8] 1:32.818 Audi Sport Team Rosberg | Jamie Green
Q11 #18 [DTMV8] 1:32.821 BMW Team MTEK | Augusto Farfus
Q12 #7 [DTMV8] 1:32.858 BMW Team MTEK | Bruno Spengler
Q13 #22 [DTMV8] 1:32.888 Mercedes-AMG Team Mücke | Lucas Auer
Q14 #51 [DTMV8] 1:32.911 Audi Sport Team Abt | Nico Müller
Q15 #88 [DTMV8] 1:32.929 Mercedes-AMG Team ART | Felix Rosenqvist
Q16 #27 [DTMV8] 1:32.938 Audi Sport Team Rosberg | Adrien Tambay
Q17 #99 [DTMV8] 1:32.956 Audi Sport Team Abt Sportsline | Mike Rockenfeller
Q18 #3 [DTMV8] 1:32.990 Mercedes-AMG Team HWA II | Paul di Resta
Q19 #100 [DTMV8] 1:33.002 BMW Team Schnitzer | Martin Tomczyk
Q20 #10 [DTMV8] 1:33.007 Audi Sport Team Phoenix | Timo Scheider
Q21 #12 [DTMV8] 1:33.059 Mercedes-AMG Team HWA I | Daniel Juncadella
Q22 #17 [DTMV8] 1:33.082 Audi Sport Team Abt | Miguel Molina
Q23 #72 [DTMV8] 1:33.158 Audi Sport Team Phoenix | René Rast
Q24 #84 [DTMV8] 1:33.280 Mercedes-AMG Team HWA II | Maximilian Götz

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #13 António Félix da Costa 1:32.525 BMW Team Schnitzer
DTMV8: #13 António Félix da Costa 1:32.525 BMW Team Schnitzer

## Fastest laps (archive)
Overall: #16 Timo Glock 1:34.659 lap 30
DTMV8: #16 Timo Glock 1:34.659 lap 30

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g6 #48 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 39L gap — | Edoardo Mortara
 2 g9 #8 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 39L gap 3.040 | Christian Vietoris
 3 g18 #3 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 39L gap 4.294 | Paul di Resta
 4 g5 #11 BMW Team RMG | BMW M4 DTM | Classified 39L gap 5.030 | Marco Wittmann
 5 g8 #16 BMW Team RMG | BMW M4 DTM | Classified 39L gap 6.103 | Timo Glock
 6 g4 #36 BMW Team RBM | BMW M4 DTM | Classified 39L gap 8.947 | Maxime Martin
 7 g3 #31 BMW Team RBM | BMW M4 DTM | Classified 39L gap 13.857 | Tom Blomqvist
 8 g10 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 39L gap 15.054 | Jamie Green
 9 g7 #6 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 39L gap 16.012 | Robert Wickens
 10 g19 #100 BMW Team Schnitzer | BMW M4 DTM | Classified 39L gap 21.313 | Martin Tomczyk
 11 g17 #99 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 39L gap 21.503 | Mike Rockenfeller
 12 g12 #7 BMW Team MTEK | BMW M4 DTM | Classified 39L gap 22.230 | Bruno Spengler
 13 g14 #51 Audi Sport Team Abt | Audi RS 5 DTM | Classified 39L gap 24.962 | Nico Müller
 14 g22 #17 Audi Sport Team Abt | Audi RS 5 DTM | Classified 39L gap 25.979 | Miguel Molina
 15 g2 #2 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 39L gap 27.937 | Gary Paffett
 16 g13 #22 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 39L gap 29.298 | Lucas Auer
 17 g23 #72 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 39L gap 36.530 | René Rast
 18 g20 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 39L gap 39.112 | Timo Scheider
 19 g24 #84 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 39L gap 55.972 | Maximilian Götz
 20 g21 #12 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | RET 33L gap RET | Daniel Juncadella
 21 g15 #88 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | RET 32L gap RET | Felix Rosenqvist
 22 g11 #18 BMW Team MTEK | BMW M4 DTM | RET 29L gap RET | Augusto Farfus
 23 g1 #13 BMW Team Schnitzer | BMW M4 DTM | RET 21L gap RET | António Félix da Costa
 24 g16 #27 Audi Sport Team Rosberg | Audi RS 5 DTM | RET 15L gap RET | Adrien Tambay
