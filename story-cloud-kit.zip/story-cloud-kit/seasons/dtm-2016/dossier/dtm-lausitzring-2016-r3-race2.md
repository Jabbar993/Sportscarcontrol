# dtm-lausitzring-2016-r3-race2

Event: DTM Lausitzring Race 2 | Circuit: Lausitzring | Date: 2016-06-05
Scheduled: 01:00:00 | Official duration: 1:02:11.261 | Laps (winner): 46

## Qualifying (archive order)
Q1 #22 [DTMV8] 1:16.861 Mercedes-AMG Team Mücke | Lucas Auer
Q2 #8 [DTMV8] 1:16.931 Mercedes-AMG Team Mücke | Christian Vietoris
Q3 #16 [DTMV8] 1:16.943 BMW Team RMG | Timo Glock
Q4 #6 [DTMV8] 1:17.000 Mercedes-AMG Team HWA I | Robert Wickens
Q5 #99 [DTMV8] 1:17.029 Audi Sport Team Phoenix | Mike Rockenfeller
Q6 #2 [DTMV8] 1:17.030 Mercedes-AMG Team ART | Gary Paffett
Q7 #53 [DTMV8] 1:17.044 Audi Sport Team Rosberg | Jamie Green
Q8 #11 [DTMV8] 1:17.061 BMW Team RMG | Marco Wittmann
Q9 #5 [DTMV8] 1:17.076 Audi Sport Team Abt Sportsline | Mattias Ekström
Q10 #31 [DTMV8] 1:17.142 BMW Team RBM | Tom Blomqvist
Q11 #84 [DTMV8] 1:17.147 Mercedes-AMG Team HWA II | Maximilian Götz
Q12 #36 [DTMV8] 1:17.162 BMW Team RBM | Maxime Martin
Q13 #7 [DTMV8] 1:17.167 BMW Team MTEK | Bruno Spengler
Q14 #17 [DTMV8] 1:17.184 Audi Sport Team Abt | Miguel Molina
Q15 #51 [DTMV8] 1:17.211 Audi Sport Team Abt | Nico Müller
Q16 #34 [DTMV8] 1:17.219 Mercedes-AMG Team ART | Esteban Ocon
Q17 #13 [DTMV8] 1:17.399 BMW Team Schnitzer | António Félix da Costa
Q18 #12 [DTMV8] 1:17.408 Mercedes-AMG Team HWA I | Daniel Juncadella
Q19 #18 [DTMV8] 1:17.482 BMW Team MTEK | Augusto Farfus
Q20 #27 [DTMV8] 1:17.495 Audi Sport Team Rosberg | Adrien Tambay
Q21 #3 [DTMV8] 1:17.510 Mercedes-AMG Team HWA II | Paul di Resta
Q22 #48 [DTMV8] 1:17.515 Audi Sport Team Abt Sportsline | Edoardo Mortara
Q23 #10 [DTMV8] 1:17.730 Audi Sport Team Phoenix | Timo Scheider
Q24 #100 [DTMV8] 1:18.003 BMW Team Schnitzer | Martin Tomczyk

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #22 Lucas Auer 1:16.861 Mercedes-AMG Team Mücke
DTMV8: #22 Lucas Auer 1:16.861 Mercedes-AMG Team Mücke

## Fastest laps (archive)
Overall: #53 Jamie Green 1:17.840 lap 26
DTMV8: #53 Jamie Green 1:17.840 lap 26

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #22 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 46L gap — | Lucas Auer
 2 g9 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 46L gap 3.763 | Mattias Ekström
 3 g3 #6 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 46L gap 6.386 | Robert Wickens
 4 g6 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 46L gap 6.770 | Jamie Green
 5 g5 #2 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 46L gap 12.292 | Gary Paffett
 6 g8 #11 BMW Team RMG | BMW M4 DTM | Classified 46L gap 16.839 | Marco Wittmann
 7 g7 #8 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 46L gap 17.355 | Christian Vietoris
 8 g15 #51 Audi Sport Team Abt | Audi RS 5 DTM | Classified 46L gap 18.099 | Nico Müller
 9 g13 #7 BMW Team MTEK | BMW M4 DTM | Classified 46L gap 21.872 | Bruno Spengler
 10 g2 #16 BMW Team RMG | BMW M4 DTM | Classified 46L gap 24.865 | Timo Glock
 11 g10 #31 BMW Team RBM | BMW M4 DTM | Classified 46L gap 34.033 | Tom Blomqvist
 12 g22 #48 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 46L gap 34.173 | Edoardo Mortara
 13 g12 #36 BMW Team RBM | BMW M4 DTM | Classified 46L gap 36.394 | Maxime Martin
 14 g17 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 46L gap 36.827 | António Félix da Costa
 15 g16 #34 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 46L gap 41.508 | Esteban Ocon
 16 g23 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 46L gap 42.387 | Timo Scheider
 17 g4 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 46L gap 45.110 | Mike Rockenfeller
 18 g24 #100 BMW Team Schnitzer | BMW M4 DTM | Classified 46L gap 51.198 | Martin Tomczyk
 19 g14 #17 Audi Sport Team Abt | Audi RS 5 DTM | Classified 46L gap 1:04.337 | Miguel Molina
 20 g20 #27 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 46L gap 1:14.175 | Adrien Tambay
 21 g21 #3 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 41L gap 5 LAPS | Paul di Resta
 22 g18 #12 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | RET 33L gap RET | Daniel Juncadella
 23 g11 #84 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | RET 30L gap RET | Maximilian Götz
 24 g19 #18 BMW Team MTEK | BMW M4 DTM | RET 8L gap RET | Augusto Farfus
