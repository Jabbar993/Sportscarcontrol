# dtm-nurburgring-2016-r7-race1

Event: DTM Nürburgring Race 1 | Circuit: Nürburgring | Date: 2016-09-10
Scheduled: 00:40:00 | Official duration: 00:42:47.780 | Laps (winner): 30

## Qualifying (archive order)
Q1 #22 [DTMV8] 1:22.900 Mercedes-AMG Team Mücke | Lucas Auer
Q2 #11 [DTMV8] 1:23.028 BMW Team RMG | Marco Wittmann
Q3 #31 [DTMV8] 1:23.149 BMW Team RBM | Tom Blomqvist
Q4 #53 [DTMV8] 1:23.161 Audi Sport Team Rosberg | Jamie Green
Q5 #48 [DTMV8] 1:23.167 Audi Sport Team Abt Sportsline | Edoardo Mortara
Q6 #12 [DTMV8] 1:23.232 Mercedes-AMG Team HWA I | Daniel Juncadella
Q7 #88 [DTMV8] 1:23.245 Mercedes-AMG Team ART | Felix Rosenqvist
Q8 #16 [DTMV8] 1:23.278 BMW Team RMG | Timo Glock
Q9 #7 [DTMV8] 1:23.284 BMW Team MTEK | Bruno Spengler
Q10 #3 [DTMV8] 1:23.304 Mercedes-AMG Team HWA II | Paul di Resta
Q11 #36 [DTMV8] 1:23.330 BMW Team RBM | Maxime Martin
Q12 #84 [DTMV8] 1:23.335 Mercedes-AMG Team HWA II | Maximilian Götz
Q13 #6 [DTMV8] 1:23.388 Mercedes-AMG Team HWA I | Robert Wickens
Q14 #2 [DTMV8] 1:23.398 Mercedes-AMG Team ART | Gary Paffett
Q15 #10 [DTMV8] 1:23.424 Audi Sport Team Phoenix | Timo Scheider
Q16 #8 [DTMV8] 1:23.441 Mercedes-AMG Team Mücke | Christian Vietoris
Q17 #100 [DTMV8] 1:23.497 BMW Team Schnitzer | Martin Tomczyk
Q18 #17 [DTMV8] 1:23.523 Audi Sport Team Abt | Miguel Molina
Q19 #5 [DTMV8] 1:23.544 Audi Sport Team Abt Sportsline | Mattias Ekström
Q20 #51 [DTMV8] 1:23.667 Audi Sport Team Abt | Nico Müller
Q21 #13 [DTMV8] 1:23.696 BMW Team Schnitzer | António Félix da Costa
Q22 #99 [DTMV8] 1:23.701 Audi Sport Team Phoenix | Mike Rockenfeller
Q23 #27 [DTMV8] 1:23.760 Audi Sport Team Rosberg | Adrien Tambay
Q24 #18 [DTMV8] 1:23.834 BMW Team MTEK | Augusto Farfus

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #22 Lucas Auer 1:22.900 Mercedes-AMG Team Mücke
DTMV8: #22 Lucas Auer 1:22.900 Mercedes-AMG Team Mücke

## Fastest laps (archive)
Overall: #53 Jamie Green 1:24.468 lap 6
DTMV8: #53 Jamie Green 1:24.468 lap 6

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #11 BMW Team RMG | BMW M4 DTM | Classified 30L gap — | Marco Wittmann
 2 g2 #31 BMW Team RBM | BMW M4 DTM | Classified 30L gap 7.136 | Tom Blomqvist
 3 g3 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 30L gap 9.031 | Jamie Green
 4 g4 #48 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 30L gap 9.783 | Edoardo Mortara
 5 g8 #16 BMW Team RMG | BMW M4 DTM | Classified 30L gap 11.768 | Timo Glock
 6 g10 #3 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 30L gap 15.256 | Paul di Resta
 7 g5 #22 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 30L gap 16.086 | Lucas Auer
 8 g11 #36 BMW Team RBM | BMW M4 DTM | Classified 30L gap 23.232 | Maxime Martin
 9 g13 #6 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 30L gap 32.197 | Robert Wickens
 10 g12 #84 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 30L gap 34.656 | Maximilian Götz
 11 g20 #51 Audi Sport Team Abt | Audi RS 5 DTM | Classified 30L gap 35.080 | Nico Müller
 12 g7 #88 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 30L gap 35.474 | Felix Rosenqvist
 13 g16 #8 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 30L gap 36.626 | Christian Vietoris
 14 g22 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 30L gap 39.610 | Mike Rockenfeller
 15 g18 #17 Audi Sport Team Abt | Audi RS 5 DTM | Classified 30L gap 42.009 | Miguel Molina
 16 g17 #100 BMW Team Schnitzer | BMW M4 DTM | Classified 30L gap 43.445 | Martin Tomczyk
 17 g6 #12 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 30L gap 43.974 | Daniel Juncadella
 18 g9 #7 BMW Team MTEK | BMW M4 DTM | Classified 30L gap 45.506 | Bruno Spengler
 19 g14 #2 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 30L gap 47.271 | Gary Paffett
 20 g21 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 30L gap 49.613 | António Félix da Costa
 21 g15 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 30L gap 53.224 | Timo Scheider
 22 g24 #18 BMW Team MTEK | BMW M4 DTM | Classified 30L gap 54.631 | Augusto Farfus
 23 g19 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | RET 23L gap RET | Mattias Ekström
 24 g23 #27 Audi Sport Team Rosberg | Audi RS 5 DTM | RET 9L gap RET | Adrien Tambay
