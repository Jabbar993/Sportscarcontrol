# dtm-hungaroring-2016-r8-race1

Event: DTM Hungaroring Race 1 | Circuit: Hungaroring | Date: 2016-09-24
Scheduled: 00:40:00 | Official duration: 00:42:20.736 | Laps (winner): 26

## Qualifying (archive order)
Q1 #48 [DTMV8] 1:35.282 Audi Sport Team Abt Sportsline | Edoardo Mortara
Q2 #53 [DTMV8] 1:35.364 Audi Sport Team Rosberg | Jamie Green
Q3 #17 [DTMV8] 1:35.449 Audi Sport Team Abt | Miguel Molina
Q4 #99 [DTMV8] 1:35.498 Audi Sport Team Phoenix | Mike Rockenfeller
Q5 #51 [DTMV8] 1:35.525 Audi Sport Team Abt | Nico Müller
Q6 #27 [DTMV8] 1:35.589 Audi Sport Team Rosberg | Adrien Tambay
Q7 #10 [DTMV8] 1:35.753 Audi Sport Team Phoenix | Timo Scheider
Q8 #5 [DTMV8] 1:35.810 Audi Sport Team Abt Sportsline | Mattias Ekström
Q9 #88 [DTMV8] 1:35.870 Mercedes-AMG Team ART | Felix Rosenqvist
Q10 #11 [DTMV8] 1:35.893 BMW Team RMG | Marco Wittmann
Q11 #31 [DTMV8] 1:35.923 BMW Team RBM | Tom Blomqvist
Q12 #100 [DTMV8] 1:35.926 BMW Team Schnitzer | Martin Tomczyk
Q13 #16 [DTMV8] 1:35.951 BMW Team RMG | Timo Glock
Q14 #36 [DTMV8] 1:35.986 BMW Team RBM | Maxime Martin
Q15 #13 [DTMV8] 1:35.992 BMW Team Schnitzer | António Félix da Costa
Q16 #12 [DTMV8] 1:36.023 Mercedes-AMG Team HWA I | Daniel Juncadella
Q17 #8 [DTMV8] 1:36.045 Mercedes-AMG Team Mücke | Christian Vietoris
Q18 #6 [DTMV8] 1:36.081 Mercedes-AMG Team HWA I | Robert Wickens
Q19 #2 [DTMV8] 1:36.218 Mercedes-AMG Team ART | Gary Paffett
Q20 #18 [DTMV8] 1:36.234 BMW Team MTEK | Augusto Farfus
Q21 #7 [DTMV8] 1:36.389 BMW Team MTEK | Bruno Spengler
Q22 #3 [DTMV8] 1:36.408 Mercedes-AMG Team HWA II | Paul di Resta
Q23 #22 [DTMV8] 1:36.528 Mercedes-AMG Team Mücke | Lucas Auer
Q24 #84 [DTMV8] 1:36.637 Mercedes-AMG Team HWA II | Maximilian Götz

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #48 Edoardo Mortara 1:35.282 Audi Sport Team Abt Sportsline
DTMV8: #48 Edoardo Mortara 1:35.282 Audi Sport Team Abt Sportsline

## Fastest laps (archive)
Overall: #48 Edoardo Mortara 1:36.959 lap 4
DTMV8: #48 Edoardo Mortara 1:36.959 lap 4

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #48 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 26L gap — | Edoardo Mortara
 2 g2 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 26L gap 1.090 | Jamie Green
 3 g3 #17 Audi Sport Team Abt | Audi RS 5 DTM | Classified 26L gap 9.240 | Miguel Molina
 4 g4 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 26L gap 10.602 | Mike Rockenfeller
 5 g5 #51 Audi Sport Team Abt | Audi RS 5 DTM | Classified 26L gap 11.535 | Nico Müller
 6 g6 #27 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 26L gap 21.045 | Adrien Tambay
 7 g10 #11 BMW Team RMG | BMW M4 DTM | Classified 26L gap 23.177 | Marco Wittmann
 8 g9 #88 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 26L gap 24.729 | Felix Rosenqvist
 9 g7 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 26L gap 25.754 | Timo Scheider
 10 g17 #6 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 26L gap 26.916 | Robert Wickens
 11 g15 #12 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 26L gap 29.399 | Daniel Juncadella
 12 g14 #36 BMW Team RBM | BMW M4 DTM | Classified 26L gap 32.843 | Maxime Martin
 13 g11 #31 BMW Team RBM | BMW M4 DTM | Classified 26L gap 33.546 | Tom Blomqvist
 14 g13 #16 BMW Team RMG | BMW M4 DTM | Classified 26L gap 34.316 | Timo Glock
 15 g21 #7 BMW Team MTEK | BMW M4 DTM | Classified 26L gap 36.197 | Bruno Spengler
 16 g23 #22 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 26L gap 37.259 | Lucas Auer
 17 g20 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 26L gap 44.405 | António Félix da Costa
 18 g16 #8 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 26L gap 45.334 | Christian Vietoris
 19 g8 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 26L gap 50.675 | Mattias Ekström
 20 g19 #18 BMW Team MTEK | BMW M4 DTM | Classified 26L gap 53.287 | Augusto Farfus
 21 g18 #2 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 26L gap 54.002 | Gary Paffett
 22 g12 #100 BMW Team Schnitzer | BMW M4 DTM | Classified 26L gap 54.939 | Martin Tomczyk
 23 g24 #84 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 26L gap 55.420 | Maximilian Götz
 24 g22 #3 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | RET 11L gap RET | Paul di Resta
