# dtm-moscowraceway-2016-r6-race2

Event: DTM Moscow Raceway Race 2 | Circuit: Moscow Raceway | Date: 2016-08-21
Scheduled: 01:00:00 | Official duration: 1:02:03.216 | Laps (winner): 40

## Qualifying (archive order)
Q1 #11 [DTMV8] 1:28.776 BMW Team RMG | Marco Wittmann
Q2 #31 [DTMV8] 1:28.878 BMW Team RBM | Tom Blomqvist
Q3 #36 [DTMV8] 1:29.027 BMW Team RBM | Maxime Martin
Q4 #6 [DTMV8] 1:29.180 Mercedes-AMG Team HWA I | Robert Wickens
Q5 #7 [DTMV8] 1:29.371 BMW Team MTEK | Bruno Spengler
Q6 #12 [DTMV8] 1:29.397 Mercedes-AMG Team HWA I | Daniel Juncadella
Q7 #18 [DTMV8] 1:29.411 BMW Team MTEK | Augusto Farfus
Q8 #16 [DTMV8] 1:29.522 BMW Team RMG | Timo Glock
Q9 #84 [DTMV8] 1:29.604 Mercedes-AMG Team HWA II | Maximilian Götz
Q10 #22 [DTMV8] 1:29.650 Mercedes-AMG Team Mücke | Lucas Auer
Q11 #13 [DTMV8] 1:29.759 BMW Team Schnitzer | António Félix da Costa
Q12 #3 [DTMV8] 1:29.760 Mercedes-AMG Team HWA II | Paul di Resta
Q13 #51 [DTMV8] 1:29.768 Audi Sport Team Abt | Nico Müller
Q14 #88 [DTMV8] 1:29.811 Mercedes-AMG Team ART | Felix Rosenqvist
Q15 #5 [DTMV8] 1:29.812 Audi Sport Team Abt Sportsline | Mattias Ekström
Q16 #17 [DTMV8] 1:29.815 Audi Sport Team Abt | Miguel Molina
Q17 #8 [DTMV8] 1:29.935 Mercedes-AMG Team Mücke | Christian Vietoris
Q18 #48 [DTMV8] 1:29.987 Audi Sport Team Abt Sportsline | Edoardo Mortara
Q19 #27 [DTMV8] 1:30.057 Audi Sport Team Rosberg | Adrien Tambay
Q20 #53 [DTMV8] 1:30.081 Audi Sport Team Rosberg | Jamie Green
Q21 #99 [DTMV8] 1:30.114 Audi Sport Team Phoenix | Mike Rockenfeller
Q22 #2 [DTMV8] 1:30.122 Mercedes-AMG Team ART | Gary Paffett
Q23 #100 [DTMV8] 1:30.158 BMW Team Schnitzer | Martin Tomczyk
Q24 #10 [DTMV8] 1:30.424 Audi Sport Team Phoenix | Timo Scheider

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #11 Marco Wittmann 1:28.776 BMW Team RMG
DTMV8: #11 Marco Wittmann 1:28.776 BMW Team RMG

## Fastest laps (archive)
Overall: #51 Nico Müller 1:30.269 lap 25
DTMV8: #51 Nico Müller 1:30.269 lap 25

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #11 BMW Team RMG | BMW M4 DTM | Classified 40L gap — | Marco Wittmann
 2 g2 #31 BMW Team RBM | BMW M4 DTM | Classified 40L gap 4.123 | Tom Blomqvist
 3 g4 #7 BMW Team MTEK | BMW M4 DTM | Classified 40L gap 18.119 | Bruno Spengler
 4 g6 #18 BMW Team MTEK | BMW M4 DTM | Classified 40L gap 24.650 | Augusto Farfus
 5 g3 #6 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 40L gap 38.818 | Robert Wickens
 6 g17 #48 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 40L gap 38.885 | Edoardo Mortara
 7 g12 #51 Audi Sport Team Abt | Audi RS 5 DTM | Classified 40L gap 39.158 | Nico Müller
 8 g18 #27 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 40L gap 41.193 | Adrien Tambay
 9 g14 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 40L gap 41.223 | Mattias Ekström
 10 g9 #22 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 40L gap 42.138 | Lucas Auer
 11 g15 #17 Audi Sport Team Abt | Audi RS 5 DTM | Classified 40L gap 42.245 | Miguel Molina
 12 g5 #12 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 40L gap 42.562 | Daniel Juncadella
 13 g23 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 40L gap 42.641 | Timo Scheider
 14 g16 #8 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 40L gap 46.076 | Christian Vietoris
 15 g20 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 40L gap 47.432 | Mike Rockenfeller
 16 g8 #84 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 40L gap 48.338 | Maximilian Götz
 17 g? #36 BMW Team RBM | BMW M4 DTM | Classified 40L gap 51.310 | Maxime Martin
 18 g21 #2 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 40L gap 52.078 | Gary Paffett
 19 g10 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 40L gap 55.563 | António Félix da Costa
 20 g11 #3 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 40L gap 57.467 | Paul di Resta
 21 g13 #88 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 40L gap 57.979 | Felix Rosenqvist
 22 g19 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 40L gap 1:01.627 | Jamie Green
 23 g22 #100 BMW Team Schnitzer | BMW M4 DTM | Classified 40L gap 1:04.773 | Martin Tomczyk
 24 g7 #16 BMW Team RMG | BMW M4 DTM | RET 31L gap RET | Timo Glock
