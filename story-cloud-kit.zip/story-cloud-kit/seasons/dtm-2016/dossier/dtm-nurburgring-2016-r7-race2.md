# dtm-nurburgring-2016-r7-race2

Event: DTM Nürburgring Race 2 | Circuit: Nürburgring | Date: 2016-09-11
Scheduled: 01:00:00 | Official duration: 1:01:31.597 | Laps (winner): 43

## Qualifying (archive order)
Q1 #22 [DTMV8] 1:22.728 Mercedes-AMG Team Mücke | Lucas Auer
Q2 #11 [DTMV8] 1:22.758 BMW Team RMG | Marco Wittmann
Q3 #7 [DTMV8] 1:22.843 BMW Team MTEK | Bruno Spengler
Q4 #31 [DTMV8] 1:22.896 BMW Team RBM | Tom Blomqvist
Q5 #18 [DTMV8] 1:22.898 BMW Team MTEK | Augusto Farfus
Q6 #48 [DTMV8] 1:22.918 Audi Sport Team Abt Sportsline | Edoardo Mortara
Q7 #53 [DTMV8] 1:22.943 Audi Sport Team Rosberg | Jamie Green
Q8 #17 [DTMV8] 1:22.948 Audi Sport Team Abt | Miguel Molina
Q9 #12 [DTMV8] 1:22.996 Mercedes-AMG Team HWA I | Daniel Juncadella
Q10 #5 [DTMV8] 1:23.007 Audi Sport Team Abt Sportsline | Mattias Ekström
Q11 #2 [DTMV8] 1:23.030 Mercedes-AMG Team ART | Gary Paffett
Q12 #88 [DTMV8] 1:23.031 Mercedes-AMG Team ART | Felix Rosenqvist
Q13 #16 [DTMV8] 1:23.090 BMW Team RMG | Timo Glock
Q14 #51 [DTMV8] 1:23.130 Audi Sport Team Abt | Nico Müller
Q15 #3 [DTMV8] 1:23.133 Mercedes-AMG Team HWA II | Paul di Resta
Q16 #10 [DTMV8] 1:23.144 Audi Sport Team Phoenix | Timo Scheider
Q17 #6 [DTMV8] 1:23.182 Mercedes-AMG Team HWA I | Robert Wickens
Q18 #8 [DTMV8] 1:23.204 Mercedes-AMG Team Mücke | Christian Vietoris
Q19 #36 [DTMV8] 1:23.379 BMW Team RBM | Maxime Martin
Q20 #99 [DTMV8] 1:23.382 Audi Sport Team Phoenix | Mike Rockenfeller
Q21 #27 [DTMV8] 1:23.401 Audi Sport Team Rosberg | Adrien Tambay
Q22 #13 [DTMV8] 1:23.491 BMW Team Schnitzer | António Félix da Costa
Q23 #100 [DTMV8] 1:23.517 BMW Team Schnitzer | Martin Tomczyk
Q24 #84 [DTMV8] 1:23.587 Mercedes-AMG Team HWA II | Maximilian Götz

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #22 Lucas Auer 1:22.728 Mercedes-AMG Team Mücke
DTMV8: #22 Lucas Auer 1:22.728 Mercedes-AMG Team Mücke

## Fastest laps (archive)
Overall: #51 Nico Müller 1:24.103 lap 33
DTMV8: #51 Nico Müller 1:24.103 lap 33

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g6 #48 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 43L gap — | Edoardo Mortara
 2 g1 #22 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 43L gap 3.726 | Lucas Auer
 3 g2 #11 BMW Team RMG | BMW M4 DTM | Classified 43L gap 7.526 | Marco Wittmann
 4 g10 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 43L gap 7.849 | Mattias Ekström
 5 g14 #51 Audi Sport Team Abt | Audi RS 5 DTM | Classified 43L gap 9.182 | Nico Müller
 6 g3 #7 BMW Team MTEK | BMW M4 DTM | Classified 43L gap 11.812 | Bruno Spengler
 7 g11 #2 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 43L gap 18.973 | Gary Paffett
 8 g4 #31 BMW Team RBM | BMW M4 DTM | Classified 43L gap 20.895 | Tom Blomqvist
 9 g9 #12 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 43L gap 21.826 | Daniel Juncadella
 10 g19 #36 BMW Team RBM | BMW M4 DTM | Classified 43L gap 27.220 | Maxime Martin
 11 g16 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 43L gap 27.931 | Timo Scheider
 12 g22 #100 BMW Team Schnitzer | BMW M4 DTM | Classified 43L gap 31.430 | Martin Tomczyk
 13 g17 #6 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 43L gap 32.446 | Robert Wickens
 14 g13 #16 BMW Team RMG | BMW M4 DTM | Classified 43L gap 34.178 | Timo Glock
 15 g24 #27 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 43L gap 37.429 | Adrien Tambay
 16 g7 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 43L gap 40.173 | Jamie Green
 17 g18 #8 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 43L gap 40.957 | Christian Vietoris
 18 g12 #88 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 43L gap 45.546 | Felix Rosenqvist
 19 g21 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 43L gap 54.822 | António Félix da Costa
 20 g8 #17 Audi Sport Team Abt | Audi RS 5 DTM | Classified 43L gap 54.909 | Miguel Molina
 21 g5 #18 BMW Team MTEK | BMW M4 DTM | Classified 43L gap 1:00.006 | Augusto Farfus
 22 g20 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 43L gap 1:00.571 | Mike Rockenfeller
 23 g23 #84 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 43L gap 1:08.880 | Maximilian Götz
 24 g15 #3 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | RET 1L gap RET | Paul di Resta
