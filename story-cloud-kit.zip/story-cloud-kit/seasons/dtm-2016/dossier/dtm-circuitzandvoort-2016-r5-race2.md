# dtm-circuitzandvoort-2016-r5-race2

Event: DTM Circuit Zandvoort Race 2 | Circuit: Zandvoort | Date: 2016-07-17
Scheduled: 01:00:00 | Official duration: 1:01:54.997 | Laps (winner): 39

## Qualifying (archive order)
Q1 #53 [DTMV8] 1:30.696 Audi Sport Team Rosberg | Jamie Green
Q2 #2 [DTMV8] 1:30.775 Mercedes-AMG Team ART | Gary Paffett
Q3 #8 [DTMV8] 1:30.792 Mercedes-AMG Team Mücke | Christian Vietoris
Q4 #48 [DTMV8] 1:30.859 Audi Sport Team Abt Sportsline | Edoardo Mortara
Q5 #6 [DTMV8] 1:30.937 Mercedes-AMG Team HWA I | Robert Wickens
Q6 #16 [DTMV8] 1:30.957 BMW Team RMG | Timo Glock
Q7 #11 [DTMV8] 1:31.046 BMW Team RMG | Marco Wittmann
Q8 #34 [DTMV8] 1:31.053 Mercedes-AMG Team ART | Esteban Ocon
Q9 #5 [DTMV8] 1:31.163 Audi Sport Team Abt Sportsline | Mattias Ekström
Q10 #51 [DTMV8] 1:31.193 Audi Sport Team Abt | Nico Müller
Q11 #31 [DTMV8] 1:31.244 BMW Team RBM | Tom Blomqvist
Q12 #17 [DTMV8] 1:31.247 Audi Sport Team Abt | Miguel Molina
Q13 #3 [DTMV8] 1:31.322 Mercedes-AMG Team HWA II | Paul di Resta
Q14 #7 [DTMV8] 1:31.333 BMW Team MTEK | Bruno Spengler
Q15 #13 [DTMV8] 1:31.333 BMW Team Schnitzer | António Félix da Costa
Q16 #100 [DTMV8] 1:31.346 BMW Team Schnitzer | Martin Tomczyk
Q17 #18 [DTMV8] 1:31.352 BMW Team MTEK | Augusto Farfus
Q18 #99 [DTMV8] 1:31.449 Audi Sport Team Phoenix | Mike Rockenfeller
Q19 #22 [DTMV8] 1:31.566 Mercedes-AMG Team Mücke | Lucas Auer
Q20 #10 [DTMV8] 1:31.623 Audi Sport Team Phoenix | Timo Scheider
Q21 #36 [DTMV8] 1:32.018 BMW Team RBM | Maxime Martin
Q22 #72 [DTMV8] 1:32.079 Audi Sport Team Rosberg | René Rast
Q23 #84 [DTMV8] 1:33.148 Mercedes-AMG Team HWA II | Maximilian Götz
Q24 #12 [DTMV8]  Mercedes-AMG Team HWA I | Daniel Juncadella

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #53 Jamie Green 1:30.696 Audi Sport Team Rosberg
DTMV8: #53 Jamie Green 1:30.696 Audi Sport Team Rosberg

## Fastest laps (archive)
Overall: #12 Daniel Juncadella 1:33.087 lap 20
DTMV8: #12 Daniel Juncadella 1:33.087 lap 20

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 39L gap — | Jamie Green
 2 g2 #2 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 39L gap 9.731 | Gary Paffett
 3 g4 #48 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 39L gap 14.153 | Edoardo Mortara
 4 g7 #11 BMW Team RMG | BMW M4 DTM | Classified 39L gap 18.833 | Marco Wittmann
 5 g10 #51 Audi Sport Team Abt | Audi RS 5 DTM | Classified 39L gap 19.629 | Nico Müller
 6 g6 #16 BMW Team RMG | BMW M4 DTM | Classified 39L gap 21.455 | Timo Glock
 7 g9 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 39L gap 24.135 | Mattias Ekström
 8 g13 #3 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 39L gap 28.983 | Paul di Resta
 9 g19 #22 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 39L gap 29.430 | Lucas Auer
 10 g11 #31 BMW Team RBM | BMW M4 DTM | Classified 39L gap 29.875 | Tom Blomqvist
 11 g16 #100 BMW Team Schnitzer | BMW M4 DTM | Classified 39L gap 34.349 | Martin Tomczyk
 12 g24 #12 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 39L gap 34.807 | Daniel Juncadella
 13 g17 #18 BMW Team MTEK | BMW M4 DTM | Classified 39L gap 36.509 | Augusto Farfus
 14 g14 #7 BMW Team MTEK | BMW M4 DTM | Classified 39L gap 37.729 | Bruno Spengler
 15 g18 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 39L gap 39.818 | Mike Rockenfeller
 16 g5 #6 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 39L gap 40.345 | Robert Wickens
 17 g15 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 39L gap 45.028 | António Félix da Costa
 18 g8 #34 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 39L gap 46.187 | Esteban Ocon
 19 g22 #72 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 39L gap 46.623 | René Rast
 20 g3 #8 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | RET 35L gap RET | Christian Vietoris
 21 g21 #36 BMW Team RBM | BMW M4 DTM | RET 28L gap RET | Maxime Martin
 22 g12 #17 Audi Sport Team Abt | Audi RS 5 DTM | RET 28L gap RET | Miguel Molina
 23 g23 #84 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | RET 24L gap RET | Maximilian Götz
 24 g20 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | RET 3L gap RET | Timo Scheider
 25 g? #27 Audi Sport Team Rosberg | Audi RS 5 DTM | DNS 0L gap DNS | Adrien Tambay
