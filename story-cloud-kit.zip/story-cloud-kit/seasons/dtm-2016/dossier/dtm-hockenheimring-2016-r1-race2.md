# dtm-hockenheimring-2016-r1-race2

Event: DTM Hockenheimring Race 2 | Circuit: Hockenheimring | Date: 2016-05-08
Scheduled: 01:00:00 | Official duration: 1:01:42.654 | Laps (winner): 37

## Qualifying (archive order)
Q1 #3 [DTMV8] 1:34.060 Mercedes-AMG Team HWA II | Paul di Resta
Q2 #18 [DTMV8] 1:34.186 BMW Team MTEK | Augusto Farfus
Q3 #2 [DTMV8] 1:34.198 Mercedes-AMG Team ART | Gary Paffett
Q4 #36 [DTMV8] 1:34.285 BMW Team RBM | Maxime Martin
Q5 #6 [DTMV8] 1:34.285 Mercedes-AMG Team HWA I | Robert Wickens
Q6 #16 [DTMV8] 1:34.344 BMW Team RMG | Timo Glock
Q7 #34 [DTMV8] 1:34.361 Mercedes-AMG Team ART | Esteban Ocon
Q8 #31 [DTMV8] 1:34.423 BMW Team RBM | Tom Blomqvist
Q9 #11 [DTMV8] 1:34.426 BMW Team RMG | Marco Wittmann
Q10 #13 [DTMV8] 1:34.449 BMW Team Schnitzer | António Félix da Costa
Q11 #53 [DTMV8] 1:34.451 Audi Sport Team Rosberg | Jamie Green
Q12 #48 [DTMV8] 1:34.478 Audi Sport Team Abt Sportsline | Edoardo Mortara
Q13 #7 [DTMV8] 1:34.550 BMW Team MTEK | Bruno Spengler
Q14 #100 [DTMV8] 1:34.592 BMW Team Schnitzer | Martin Tomczyk
Q15 #51 [DTMV8] 1:34.599 Audi Sport Team Abt | Nico Müller
Q16 #22 [DTMV8] 1:34.630 Mercedes-AMG Team Mücke | Lucas Auer
Q17 #84 [DTMV8] 1:34.709 Mercedes-AMG Team HWA II | Maximilian Götz
Q18 #99 [DTMV8] 1:34.772 Audi Sport Team Phoenix | Mike Rockenfeller
Q19 #27 [DTMV8] 1:34.779 Audi Sport Team Rosberg | Adrien Tambay
Q20 #5 [DTMV8] 1:34.824 Audi Sport Team Abt Sportsline | Mattias Ekström
Q21 #8 [DTMV8] 1:34.826 Mercedes-AMG Team Mücke | Christian Vietoris
Q22 #10 [DTMV8] 1:34.882 Audi Sport Team Phoenix | Timo Scheider
Q23 #12 [DTMV8] 1:35.147 Mercedes-AMG Team HWA I | Daniel Juncadella
Q24 #17 [DTMV8] 1:35.155 Audi Sport Team Abt | Miguel Molina

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #3 Paul di Resta 1:34.060 Mercedes-AMG Team HWA II
DTMV8: #3 Paul di Resta 1:34.060 Mercedes-AMG Team HWA II

## Fastest laps (archive)
Overall: #3 Paul di Resta 1:35.335 lap 16
DTMV8: #3 Paul di Resta 1:35.335 lap 16

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #3 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 37L gap — | Paul di Resta
 2 g2 #18 BMW Team MTEK | BMW M4 DTM | Classified 37L gap 13.905 | Augusto Farfus
 3 g4 #36 BMW Team RBM | BMW M4 DTM | Classified 37L gap 14.493 | Maxime Martin
 4 g3 #2 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | Classified 37L gap 15.055 | Gary Paffett
 5 g5 #6 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | Classified 37L gap 19.377 | Robert Wickens
 6 g8 #31 BMW Team RBM | BMW M4 DTM | Classified 37L gap 21.690 | Tom Blomqvist
 7 g15 #51 Audi Sport Team Abt | Audi RS 5 DTM | Classified 37L gap 22.220 | Nico Müller
 8 g9 #11 BMW Team RMG | BMW M4 DTM | Classified 37L gap 23.790 | Marco Wittmann
 9 g14 #100 BMW Team Schnitzer | BMW M4 DTM | Classified 37L gap 24.454 | Martin Tomczyk
 10 g18 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 37L gap 31.303 | Mike Rockenfeller
 11 g12 #48 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 37L gap 50.053 | Edoardo Mortara
 12 g17 #84 Mercedes-AMG Team HWA II | Mercedes-AMG C 63 DTM | Classified 37L gap 56.722 | Maximilian Götz
 13 g19 #27 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 37L gap 1:02.408 | Adrien Tambay
 14 g21 #8 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 37L gap 1:05.985 | Christian Vietoris
 15 g16 #22 Mercedes-AMG Team Mücke | Mercedes-AMG C 63 DTM | Classified 35L gap 2 LAPS | Lucas Auer
 16 g6 #16 BMW Team RMG | BMW M4 DTM | DSQ 37L gap DSQ | Timo Glock
 17 g24 #12 Mercedes-AMG Team HWA I | Mercedes-AMG C 63 DTM | RET 29L gap RET | Daniel Juncadella
 18 g23 #17 Audi Sport Team Abt | Audi RS 5 DTM | RET 22L gap RET | Miguel Molina
 19 g22 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | RET 18L gap RET | Timo Scheider
 20 g20 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | RET 16L gap RET | Mattias Ekström
 21 g10 #13 BMW Team Schnitzer | BMW M4 DTM | RET 11L gap RET | António Félix da Costa
 22 g13 #7 BMW Team MTEK | BMW M4 DTM | RET 1L gap RET | Bruno Spengler
 23 g7 #34 Mercedes-AMG Team ART | Mercedes-AMG C 63 DTM | RET 0L gap RET | Esteban Ocon
 24 g11 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | RET 0L gap RET | Jamie Green
