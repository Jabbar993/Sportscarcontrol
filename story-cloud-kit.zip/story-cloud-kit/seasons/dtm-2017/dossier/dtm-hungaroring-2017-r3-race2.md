# dtm-hungaroring-2017-r3-race2

Event: DTM Hungaroring Race 2 | Circuit: Hungaroring | Date: 2017-06-18
Scheduled: 00:55:00 | Official duration: 00:58:01.592 | Laps (winner): 35

## Qualifying (archive order)
Q1 #33 [DTMV8] 1:34.740 Audi Sport Team Rosberg | René Rast
Q2 #11 [DTMV8] 1:34.803 BMW Team RMG | Marco Wittmann
Q3 #5 [DTMV8] 1:34.896 Audi Sport Team Abt Sportsline | Mattias Ekström
Q4 #51 [DTMV8] 1:34.931 Audi Sport Team Abt Sportsline | Nico Müller
Q5 #99 [DTMV8] 1:35.018 Audi Sport Team Phoenix | Mike Rockenfeller
Q6 #53 [DTMV8] 1:35.050 Audi Sport Team Rosberg | Jamie Green
Q7 #22 [DTMV8] 1:35.109 Mercedes-AMG Motorsport BWT | Lucas Auer
Q8 #16 [DTMV8] 1:35.236 BMW Team RMG | Timo Glock
Q9 #15 [DTMV8] 1:35.246 BMW Team RMG | Augusto Farfus
Q10 #31 [DTMV8] 1:35.282 BMW Team RBM | Tom Blomqvist
Q11 #2 [DTMV8] 1:35.284 Mercedes-AMG Motorsport Mercedes me | Gary Paffett
Q12 #3 [DTMV8] 1:35.406 Mercedes-AMG Motorsport SILBERPFEIL Energy | Paul di Resta
Q13 #6 [DTMV8] 1:35.416 Mercedes-AMG Motorsport Mercedes me | Robert Wickens
Q14 #48 [DTMV8] 1:35.445 Mercedes-AMG Motorsport BWT | Edoardo Mortara
Q15 #77 [DTMV8] 1:35.562 Audi Sport Team Phoenix | Loïc Duval
Q16 #36 [DTMV8] 1:35.685 BMW Team RBM | Maxime Martin
Q17 #63 [DTMV8] 1:35.727 Mercedes-AMG Motorsport SILBERPFEIL Energy | Maro Engel
Q18 #7 [DTMV8] 1:35.874 BMW Team RBM | Bruno Spengler

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #33 René Rast 1:34.740 Audi Sport Team Rosberg
DTMV8: #33 René Rast 1:34.740 Audi Sport Team Rosberg

## Fastest laps (archive)
Overall: #5 Mattias Ekström 1:36.725 lap 5
DTMV8: #5 Mattias Ekström 1:36.725 lap 5

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 35L gap — | René Rast
 2 g3 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 35L gap 1.041 | Mattias Ekström
 3 g18 #36 BMW Team RBM | BMW M4 DTM | Classified 35L gap 1.506 | Maxime Martin
 4 g4 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 35L gap 1.861 | Nico Müller
 5 g6 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 35L gap 5.772 | Jamie Green
 6 g12 #3 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 35L gap 7.884 | Paul di Resta
 7 g8 #16 BMW Team RMG | BMW M4 DTM | Classified 35L gap 8.694 | Timo Glock
 8 g13 #6 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 35L gap 11.999 | Robert Wickens
 9 g11 #2 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 35L gap 12.653 | Gary Paffett
 10 g5 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 35L gap 13.159 | Mike Rockenfeller
 11 g14 #48 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 35L gap 13.630 | Edoardo Mortara
 12 g9 #15 BMW Team RMG | BMW M4 DTM | Classified 35L gap 15.087 | Augusto Farfus
 13 g10 #31 BMW Team RBM | BMW M4 DTM | Classified 35L gap 16.289 | Tom Blomqvist
 14 g17 #7 BMW Team RBM | BMW M4 DTM | Classified 35L gap 17.583 | Bruno Spengler
 15 g16 #63 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 35L gap 19.828 | Maro Engel
 16 g15 #77 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 35L gap 38.535 | Loïc Duval
 17 g2 #11 BMW Team RMG | BMW M4 DTM | Classified 33L gap 2 LAPS | Marco Wittmann
 18 g7 #22 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | RET 23L gap RET | Lucas Auer
