# dtm-nurburgring-2017-r7-race2

Event: DTM Nürburgring Race 2 | Circuit: Nürburgring | Date: 2017-09-10
Scheduled: 00:55:00 | Official duration: 00:56:49.795 | Laps (winner): 40

## Qualifying (archive order)
Q1 #11 [DTMV8] 1:20.936 BMW Team RMG | Marco Wittmann
Q2 #3 [DTMV8] 1:21.052 Mercedes-AMG Motorsport SILBERPFEIL Energy | Paul di Resta
Q3 #6 [DTMV8] 1:21.121 Mercedes-AMG Motorsport Mercedes me | Robert Wickens
Q4 #22 [DTMV8] 1:21.128 Mercedes-AMG Motorsport BWT | Lucas Auer
Q5 #31 [DTMV8] 1:21.135 BMW Team RBM | Tom Blomqvist
Q6 #16 [DTMV8] 1:21.226 BMW Team RMG | Timo Glock
Q7 #15 [DTMV8] 1:21.321 BMW Team RMG | Augusto Farfus
Q8 #2 [DTMV8] 1:21.331 Mercedes-AMG Motorsport Mercedes me | Gary Paffett
Q9 #7 [DTMV8] 1:21.346 BMW Team RBM | Bruno Spengler
Q10 #48 [DTMV8] 1:21.351 Mercedes-AMG Motorsport BWT | Edoardo Mortara
Q11 #53 [DTMV8] 1:21.486 Audi Sport Team Rosberg | Jamie Green
Q12 #36 [DTMV8] 1:21.512 BMW Team RBM | Maxime Martin
Q13 #33 [DTMV8] 1:21.561 Audi Sport Team Rosberg | René Rast
Q14 #5 [DTMV8] 1:21.584 Audi Sport Team Abt Sportsline | Mattias Ekström
Q15 #63 [DTMV8] 1:21.742 Mercedes-AMG Motorsport SILBERPFEIL Energy | Maro Engel
Q16 #99 [DTMV8] 1:21.829 Audi Sport Team Phoenix | Mike Rockenfeller
Q17 #51 [DTMV8] 1:22.237 Audi Sport Team Abt Sportsline | Nico Müller
Q18 #77 [DTMV8] 1:22.284 Audi Sport Team Phoenix | Loïc Duval

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #11 Marco Wittmann 1:20.936 BMW Team RMG
DTMV8: #11 Marco Wittmann 1:20.936 BMW Team RMG

## Fastest laps (archive)
Overall: #33 René Rast 1:22.308 lap 5
DTMV8: #33 René Rast 1:22.308 lap 5

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g3 #6 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 40L gap — | Robert Wickens
 2 g2 #3 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 40L gap 0.362 | Paul di Resta
 3 g1 #11 BMW Team RMG | BMW M4 DTM | Classified 40L gap 7.589 | Marco Wittmann
 4 g9 #7 BMW Team RBM | BMW M4 DTM | Classified 40L gap 7.955 | Bruno Spengler
 5 g14 #63 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 40L gap 15.995 | Maro Engel
 6 g13 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 40L gap 20.549 | Mattias Ekström
 7 g11 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 40L gap 22.887 | Jamie Green
 8 g6 #16 BMW Team RMG | BMW M4 DTM | Classified 40L gap 40.196 | Timo Glock
 9 g7 #15 BMW Team RMG | BMW M4 DTM | Classified 40L gap 40.307 | Augusto Farfus
 10 g5 #31 BMW Team RBM | BMW M4 DTM | Classified 40L gap 41.818 | Tom Blomqvist
 11 g12 #36 BMW Team RBM | BMW M4 DTM | Classified 40L gap 42.033 | Maxime Martin
 12 g18 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 40L gap 43.624 | René Rast
 13 g4 #22 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 40L gap 47.351 | Lucas Auer
 14 g8 #2 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 40L gap 48.758 | Gary Paffett
 15 g17 #77 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 40L gap 59.428 | Loïc Duval
 16 g10 #48 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 40L gap 1:19.821 | Edoardo Mortara
 17 g15 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 40L gap 1:27.978 | Mike Rockenfeller
 18 g16 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | RET 0L gap RET | Nico Müller
