# dtm-nurburgring-2017-r7-race1

Event: DTM Nürburgring Race 1 | Circuit: Nürburgring | Date: 2017-09-09
Scheduled: 00:55:00 | Official duration: 00:54:12.443 | Laps (winner): 33

## Qualifying (archive order)
Q1 #22 [DTMV8] 1:25.968 Mercedes-AMG Motorsport BWT | Lucas Auer
Q2 #11 [DTMV8] 1:26.067 BMW Team RMG | Marco Wittmann
Q3 #6 [DTMV8] 1:26.378 Mercedes-AMG Motorsport Mercedes me | Robert Wickens
Q4 #15 [DTMV8] 1:26.484 BMW Team RMG | Augusto Farfus
Q5 #3 [DTMV8] 1:26.912 Mercedes-AMG Motorsport SILBERPFEIL Energy | Paul di Resta
Q6 #31 [DTMV8] 1:27.044 BMW Team RBM | Tom Blomqvist
Q7 #33 [DTMV8] 1:27.062 Audi Sport Team Rosberg | René Rast
Q8 #16 [DTMV8] 1:27.191 BMW Team RMG | Timo Glock
Q9 #63 [DTMV8] 1:27.270 Mercedes-AMG Motorsport SILBERPFEIL Energy | Maro Engel
Q10 #36 [DTMV8] 1:27.446 BMW Team RBM | Maxime Martin
Q11 #5 [DTMV8] 1:27.682 Audi Sport Team Abt Sportsline | Mattias Ekström
Q12 #99 [DTMV8] 1:27.760 Audi Sport Team Phoenix | Mike Rockenfeller
Q13 #2 [DTMV8] 1:27.842 Mercedes-AMG Motorsport Mercedes me | Gary Paffett
Q14 #53 [DTMV8] 1:28.112 Audi Sport Team Rosberg | Jamie Green
Q15 #7 [DTMV8] 1:28.206 BMW Team RBM | Bruno Spengler
Q16 #48 [DTMV8] 1:28.338 Mercedes-AMG Motorsport BWT | Edoardo Mortara
Q17 #51 [DTMV8] 1:28.625 Audi Sport Team Abt Sportsline | Nico Müller
Q18 #77 [DTMV8] 1:29.274 Audi Sport Team Phoenix | Loïc Duval

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #22 Lucas Auer 1:25.968 Mercedes-AMG Motorsport BWT
DTMV8: #22 Lucas Auer 1:25.968 Mercedes-AMG Motorsport BWT

## Fastest laps (archive)
Overall: #51 Nico Müller 1:31.420 lap 18
DTMV8: #51 Nico Müller 1:31.420 lap 18

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #22 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 33L gap — | Lucas Auer
 2 g5 #3 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 33L gap 0.794 | Paul di Resta
 3 g3 #6 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 33L gap 1.568 | Robert Wickens
 4 g9 #63 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 33L gap 5.344 | Maro Engel
 5 g7 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 33L gap 9.758 | René Rast
 6 g14 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 33L gap 24.531 | Jamie Green
 7 g16 #48 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 33L gap 31.593 | Edoardo Mortara
 8 g4 #15 BMW Team RMG | BMW M4 DTM | Classified 33L gap 49.335 | Augusto Farfus
 9 g2 #11 BMW Team RMG | BMW M4 DTM | Classified 33L gap 56.886 | Marco Wittmann
 10 g13 #2 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 33L gap 59.072 | Gary Paffett
 11 g17 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 33L gap 1:01.058 | Nico Müller
 12 g8 #16 BMW Team RMG | BMW M4 DTM | Classified 33L gap 1:12.977 | Timo Glock
 13 g15 #7 BMW Team RBM | BMW M4 DTM | Classified 33L gap 1:27.191 | Bruno Spengler
 14 g12 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 33L gap 1:28.308 | Mike Rockenfeller
 15 g11 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 32L gap 1 LAP | Mattias Ekström
 16 g6 #31 BMW Team RBM | BMW M4 DTM | Classified 32L gap 1 LAP | Tom Blomqvist
 17 g10 #36 BMW Team RBM | BMW M4 DTM | Classified 32L gap 1 LAP | Maxime Martin
 18 g18 #77 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 32L gap 1 LAP | Loïc Duval
