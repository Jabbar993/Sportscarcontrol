# dtm-hockenheimring-2017-r9-race1

Event: DTM Hockenheimring Race 1 | Circuit: Hockenheimring | Date: 2017-10-14
Scheduled: 00:55:00 | Official duration: 00:56:52.478 | Laps (winner): 36

## Qualifying (archive order)
Q1 #16 [DTMV8] 1:30.648 BMW Team RMG | Timo Glock
Q2 #36 [DTMV8] 1:30.685 BMW Team RBM | Maxime Martin
Q3 #53 [DTMV8] 1:30.770 Audi Sport Team Rosberg | Jamie Green
Q4 #33 [DTMV8] 1:30.803 Audi Sport Team Rosberg | René Rast
Q5 #48 [DTMV8] 1:30.806 Mercedes-AMG Motorsport BWT | Edoardo Mortara
Q6 #6 [DTMV8] 1:30.836 Mercedes-AMG Motorsport Mercedes me | Robert Wickens
Q7 #99 [DTMV8] 1:30.839 Audi Sport Team Phoenix | Mike Rockenfeller
Q8 #11 [DTMV8] 1:30.850 BMW Team RMG | Marco Wittmann
Q9 #51 [DTMV8] 1:30.935 Audi Sport Team Abt Sportsline | Nico Müller
Q10 #5 [DTMV8] 1:30.956 Audi Sport Team Abt Sportsline | Mattias Ekström
Q11 #2 [DTMV8] 1:30.958 Mercedes-AMG Motorsport Mercedes me | Gary Paffett
Q12 #7 [DTMV8] 1:30.979 BMW Team RBM | Bruno Spengler
Q13 #3 [DTMV8] 1:31.026 Mercedes-AMG Motorsport SILBERPFEIL Energy | Paul di Resta
Q14 #15 [DTMV8] 1:31.037 BMW Team RMG | Augusto Farfus
Q15 #22 [DTMV8] 1:31.088 Mercedes-AMG Motorsport BWT | Lucas Auer
Q16 #31 [DTMV8] 1:31.125 BMW Team RBM | Tom Blomqvist
Q17 #63 [DTMV8] 1:31.390 Mercedes-AMG Motorsport SILBERPFEIL Energy | Maro Engel
Q18 #77 [DTMV8] 1:31.515 Audi Sport Team Phoenix | Loïc Duval

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #16 Timo Glock 1:30.648 BMW Team RMG
DTMV8: #16 Timo Glock 1:30.648 BMW Team RMG

## Fastest laps (archive)
Overall: #99 Mike Rockenfeller 1:32.819 lap 34
DTMV8: #99 Mike Rockenfeller 1:32.819 lap 34

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g3 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 36L gap — | Jamie Green
 2 g7 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 36L gap 3.939 | Mike Rockenfeller
 3 g1 #16 BMW Team RMG | BMW M4 DTM | Classified 36L gap 5.666 | Timo Glock
 4 g2 #36 BMW Team RBM | BMW M4 DTM | Classified 36L gap 10.448 | Maxime Martin
 5 g5 #48 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 36L gap 12.962 | Edoardo Mortara
 6 g4 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 36L gap 14.752 | René Rast
 7 g6 #6 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 36L gap 16.196 | Robert Wickens
 8 g15 #22 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 36L gap 23.633 | Lucas Auer
 9 g11 #2 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 36L gap 24.615 | Gary Paffett
 10 g12 #7 BMW Team RBM | BMW M4 DTM | Classified 36L gap 25.027 | Bruno Spengler
 11 g10 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 36L gap 25.764 | Mattias Ekström
 12 g9 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 36L gap 26.371 | Nico Müller
 13 g8 #11 BMW Team RMG | BMW M4 DTM | Classified 36L gap 27.426 | Marco Wittmann
 14 g13 #3 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 36L gap 29.288 | Paul di Resta
 15 g16 #31 BMW Team RBM | BMW M4 DTM | Classified 36L gap 30.867 | Tom Blomqvist
 16 g17 #63 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 36L gap 35.288 | Maro Engel
 17 g14 #15 BMW Team RMG | BMW M4 DTM | Classified 36L gap 37.358 | Augusto Farfus
 18 g18 #77 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 36L gap 42.024 | Loïc Duval
