# dtm-hockenheimring-2017-r9-race2

Event: DTM Hockenheimring Race 2 | Circuit: Hockenheimring | Date: 2017-10-15
Scheduled: 00:55:00 | Official duration: 00:56:47.699 | Laps (winner): 36

## Qualifying (archive order)
Q1 #31 [DTMV8] 1:30.491 BMW Team RBM | Tom Blomqvist
Q2 #33 [DTMV8] 1:30.555 Audi Sport Team Rosberg | René Rast
Q3 #11 [DTMV8] 1:30.564 BMW Team RMG | Marco Wittmann
Q4 #22 [DTMV8] 1:30.579 Mercedes-AMG Motorsport BWT | Lucas Auer
Q5 #53 [DTMV8] 1:30.590 Audi Sport Team Rosberg | Jamie Green
Q6 #6 [DTMV8] 1:30.656 Mercedes-AMG Motorsport Mercedes me | Robert Wickens
Q7 #36 [DTMV8] 1:30.672 BMW Team RBM | Maxime Martin
Q8 #99 [DTMV8] 1:30.721 Audi Sport Team Phoenix | Mike Rockenfeller
Q9 #15 [DTMV8] 1:30.739 BMW Team RMG | Augusto Farfus
Q10 #5 [DTMV8] 1:30.761 Audi Sport Team Abt Sportsline | Mattias Ekström
Q11 #2 [DTMV8] 1:30.799 Mercedes-AMG Motorsport Mercedes me | Gary Paffett
Q12 #16 [DTMV8] 1:30.848 BMW Team RMG | Timo Glock
Q13 #51 [DTMV8] 1:30.859 Audi Sport Team Abt Sportsline | Nico Müller
Q14 #7 [DTMV8] 1:30.987 BMW Team RBM | Bruno Spengler
Q15 #48 [DTMV8] 1:31.015 Mercedes-AMG Motorsport BWT | Edoardo Mortara
Q16 #63 [DTMV8] 1:31.162 Mercedes-AMG Motorsport SILBERPFEIL Energy | Maro Engel
Q17 #77 [DTMV8] 1:31.461 Audi Sport Team Phoenix | Loïc Duval
Q18 #3 [DTMV8] 1:31.800 Mercedes-AMG Motorsport SILBERPFEIL Energy | Paul di Resta

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #31 Tom Blomqvist 1:30.491 BMW Team RBM
DTMV8: #31 Tom Blomqvist 1:30.491 BMW Team RBM

## Fastest laps (archive)
Overall: #53 Jamie Green 1:32.456 lap 32
DTMV8: #53 Jamie Green 1:32.456 lap 32

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g3 #11 BMW Team RMG | BMW M4 DTM | Classified 36L gap — | Marco Wittmann
 2 g2 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 36L gap 3.143 | René Rast
 3 g7 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 36L gap 6.280 | Mike Rockenfeller
 4 g9 #2 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 36L gap 15.844 | Gary Paffett
 5 g15 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 36L gap 17.835 | Jamie Green
 6 g6 #36 BMW Team RBM | BMW M4 DTM | Classified 36L gap 19.372 | Maxime Martin
 7 g8 #15 BMW Team RMG | BMW M4 DTM | Classified 36L gap 20.386 | Augusto Farfus
 8 g14 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 36L gap 21.229 | Mattias Ekström
 9 g13 #48 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 36L gap 22.902 | Edoardo Mortara
 10 g4 #22 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 36L gap 29.260 | Lucas Auer
 11 g11 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 36L gap 30.428 | Nico Müller
 12 g10 #16 BMW Team RMG | BMW M4 DTM | Classified 36L gap 33.274 | Timo Glock
 13 g16 #63 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 36L gap 41.344 | Maro Engel
 14 g12 #7 BMW Team RBM | BMW M4 DTM | Classified 36L gap 41.591 | Bruno Spengler
 15 g17 #77 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 36L gap 42.972 | Loïc Duval
 16 g18 #3 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 36L gap 1:35.770 | Paul di Resta
 17 g5 #6 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 29L gap 7 LAPS | Robert Wickens
 18 g1 #31 BMW Team RBM | BMW M4 DTM | RET 0L gap RET | Tom Blomqvist
