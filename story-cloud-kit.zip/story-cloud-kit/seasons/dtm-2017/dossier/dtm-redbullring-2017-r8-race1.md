# dtm-redbullring-2017-r8-race1

Event: DTM Red Bull Ring Race 1 | Circuit: Red Bull Ring | Date: 2017-09-23
Scheduled: 00:55:00 | Official duration: 00:57:00.812 | Laps (winner): 40

## Qualifying (archive order)
Q1 #53 [DTMV8] 1:21.973 Audi Sport Team Rosberg | Jamie Green
Q2 #51 [DTMV8] 1:21.994 Audi Sport Team Abt Sportsline | Nico Müller
Q3 #5 [DTMV8] 1:22.046 Audi Sport Team Abt Sportsline | Mattias Ekström
Q4 #11 [DTMV8] 1:22.054 BMW Team RMG | Marco Wittmann
Q5 #99 [DTMV8] 1:22.095 Audi Sport Team Phoenix | Mike Rockenfeller
Q6 #33 [DTMV8] 1:22.246 Audi Sport Team Rosberg | René Rast
Q7 #6 [DTMV8] 1:22.292 Mercedes-AMG Motorsport Mercedes me | Robert Wickens
Q8 #36 [DTMV8] 1:22.392 BMW Team RBM | Maxime Martin
Q9 #16 [DTMV8] 1:22.441 BMW Team RMG | Timo Glock
Q10 #15 [DTMV8] 1:22.442 BMW Team RMG | Augusto Farfus
Q11 #3 [DTMV8] 1:22.502 Mercedes-AMG Motorsport SILBERPFEIL Energy | Paul di Resta
Q12 #22 [DTMV8] 1:22.531 Mercedes-AMG Motorsport BWT | Lucas Auer
Q13 #7 [DTMV8] 1:22.532 BMW Team RBM | Bruno Spengler
Q14 #48 [DTMV8] 1:22.554 Mercedes-AMG Motorsport BWT | Edoardo Mortara
Q15 #2 [DTMV8] 1:22.598 Mercedes-AMG Motorsport Mercedes me | Gary Paffett
Q16 #31 [DTMV8] 1:22.638 BMW Team RBM | Tom Blomqvist
Q17 #77 [DTMV8] 1:22.711 Audi Sport Team Phoenix | Loïc Duval
Q18 #63 [DTMV8] 1:22.905 Mercedes-AMG Motorsport SILBERPFEIL Energy | Maro Engel

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #53 Jamie Green 1:21.973 Audi Sport Team Rosberg
DTMV8: #53 Jamie Green 1:21.973 Audi Sport Team Rosberg

## Fastest laps (archive)
Overall: #53 Jamie Green 1:23.742 lap 7
DTMV8: #53 Jamie Green 1:23.742 lap 7

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g3 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 40L gap — | Mattias Ekström
 2 g1 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 40L gap 0.398 | Jamie Green
 3 g2 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 40L gap 0.602 | Nico Müller
 4 g7 #6 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 40L gap 21.625 | Robert Wickens
 5 g4 #11 BMW Team RMG | BMW M4 DTM | Classified 40L gap 22.118 | Marco Wittmann
 6 g8 #36 BMW Team RBM | BMW M4 DTM | Classified 40L gap 22.748 | Maxime Martin
 7 g5 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 40L gap 23.067 | Mike Rockenfeller
 8 g12 #22 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 40L gap 23.452 | Lucas Auer
 9 g14 #48 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 40L gap 23.761 | Edoardo Mortara
 10 g9 #16 BMW Team RMG | BMW M4 DTM | Classified 40L gap 25.559 | Timo Glock
 11 g11 #3 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 40L gap 25.938 | Paul di Resta
 12 g13 #7 BMW Team RBM | BMW M4 DTM | Classified 40L gap 26.447 | Bruno Spengler
 13 g6 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 40L gap 26.788 | René Rast
 14 g17 #77 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 40L gap 27.096 | Loïc Duval
 15 g18 #63 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 40L gap 27.514 | Maro Engel
 16 g16 #31 BMW Team RBM | BMW M4 DTM | Classified 40L gap 32.951 | Tom Blomqvist
 17 g15 #2 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 40L gap 45.721 | Gary Paffett
 18 g10 #15 BMW Team RMG | BMW M4 DTM | RET 0L gap RET | Augusto Farfus
