# dtm-moscowraceway-2017-r5-race1

Event: DTM Moscow Raceway Race 1 | Circuit: Moscow Raceway | Date: 2017-07-22
Scheduled: 00:55:00 | Official duration: 00:57:50.085 | Laps (winner): 38

## Qualifying (archive order)
Q1 #11 [DTMV8] 1:27.035 BMW Team RMG | Marco Wittmann
Q2 #33 [DTMV8] 1:27.155 Audi Sport Team Rosberg | René Rast
Q3 #99 [DTMV8] 1:27.253 Audi Sport Team Phoenix | Mike Rockenfeller
Q4 #15 [DTMV8] 1:27.340 BMW Team RMG | Augusto Farfus
Q5 #16 [DTMV8] 1:27.376 BMW Team RMG | Timo Glock
Q6 #5 [DTMV8] 1:27.393 Audi Sport Team Abt Sportsline | Mattias Ekström
Q7 #53 [DTMV8] 1:27.450 Audi Sport Team Rosberg | Jamie Green
Q8 #31 [DTMV8] 1:27.467 BMW Team RBM | Tom Blomqvist
Q9 #2 [DTMV8] 1:27.538 Mercedes-AMG Motorsport Mercedes me | Gary Paffett
Q10 #77 [DTMV8] 1:27.541 Audi Sport Team Phoenix | Loïc Duval
Q11 #7 [DTMV8] 1:27.612 BMW Team RBM | Bruno Spengler
Q12 #6 [DTMV8] 1:27.625 Mercedes-AMG Motorsport Mercedes me | Robert Wickens
Q13 #51 [DTMV8] 1:27.734 Audi Sport Team Abt Sportsline | Nico Müller
Q14 #22 [DTMV8] 1:27.757 Mercedes-AMG Motorsport BWT | Lucas Auer
Q15 #36 [DTMV8] 1:27.786 BMW Team RBM | Maxime Martin
Q16 #3 [DTMV8] 1:28.057 Mercedes-AMG Motorsport SILBERPFEIL Energy | Paul di Resta
Q17 #48 [DTMV8] 1:28.134 Mercedes-AMG Motorsport BWT | Edoardo Mortara
Q18 #63 [DTMV8] 1:28.382 Mercedes-AMG Motorsport SILBERPFEIL Energy | Maro Engel

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #11 Marco Wittmann 1:27.035 BMW Team RMG
DTMV8: #11 Marco Wittmann 1:27.035 BMW Team RMG

## Fastest laps (archive)
Overall: #6 Robert Wickens 1:29.573 lap 19
DTMV8: #6 Robert Wickens 1:29.573 lap 19

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 38L gap — | René Rast
 2 g2 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 38L gap 0.770 | Mike Rockenfeller
 3 g6 #11 BMW Team RMG | BMW M4 DTM | Classified 38L gap 3.899 | Marco Wittmann
 4 g11 #6 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 38L gap 6.098 | Robert Wickens
 5 g4 #16 BMW Team RMG | BMW M4 DTM | Classified 38L gap 9.498 | Timo Glock
 6 g13 #22 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 38L gap 14.663 | Lucas Auer
 7 g9 #2 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 38L gap 17.696 | Gary Paffett
 8 g5 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 38L gap 17.795 | Mattias Ekström
 9 g7 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 38L gap 24.310 | Jamie Green
 10 g18 #63 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 38L gap 25.329 | Maro Engel
 11 g15 #77 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 38L gap 25.876 | Loïc Duval
 12 g10 #7 BMW Team RBM | BMW M4 DTM | Classified 38L gap 27.607 | Bruno Spengler
 13 g17 #48 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 38L gap 29.359 | Edoardo Mortara
 14 g16 #3 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 38L gap 29.384 | Paul di Resta
 15 g12 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 38L gap 29.727 | Nico Müller
 16 g14 #36 BMW Team RBM | BMW M4 DTM | Classified 38L gap 30.201 | Maxime Martin
 17 g3 #15 BMW Team RMG | BMW M4 DTM | RET 34L gap RET | Augusto Farfus
 18 g8 #31 BMW Team RBM | BMW M4 DTM | RET 14L gap RET | Tom Blomqvist
