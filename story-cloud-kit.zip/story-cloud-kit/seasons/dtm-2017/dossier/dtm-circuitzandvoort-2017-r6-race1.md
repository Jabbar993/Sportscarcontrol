# dtm-circuitzandvoort-2017-r6-race1

Event: DTM Circuit Zandvoort Race 1 | Circuit: Zandvoort | Date: 2017-08-19
Scheduled: 00:55:00 | Official duration: 00:57:18.491 | Laps (winner): 37

## Qualifying (archive order)
Q1 #16 [DTMV8] 1:27.823 BMW Team RMG | Timo Glock
Q2 #15 [DTMV8] 1:27.907 BMW Team RMG | Augusto Farfus
Q3 #11 [DTMV8] 1:28.065 BMW Team RMG | Marco Wittmann
Q4 #36 [DTMV8] 1:28.155 BMW Team RBM | Maxime Martin
Q5 #33 [DTMV8] 1:28.287 Audi Sport Team Rosberg | René Rast
Q6 #77 [DTMV8] 1:28.331 Audi Sport Team Phoenix | Loïc Duval
Q7 #31 [DTMV8] 1:28.351 BMW Team RBM | Tom Blomqvist
Q8 #2 [DTMV8] 1:28.375 Mercedes-AMG Motorsport Mercedes me | Gary Paffett
Q9 #99 [DTMV8] 1:28.468 Audi Sport Team Phoenix | Mike Rockenfeller
Q10 #5 [DTMV8] 1:28.547 Audi Sport Team Abt Sportsline | Mattias Ekström
Q11 #3 [DTMV8] 1:28.567 Mercedes-AMG Motorsport SILBERPFEIL Energy | Paul di Resta
Q12 #6 [DTMV8] 1:28.652 Mercedes-AMG Motorsport Mercedes me | Robert Wickens
Q13 #63 [DTMV8] 1:28.656 Mercedes-AMG Motorsport SILBERPFEIL Energy | Maro Engel
Q14 #51 [DTMV8] 1:28.751 Audi Sport Team Abt Sportsline | Nico Müller
Q15 #53 [DTMV8] 1:28.819 Audi Sport Team Rosberg | Jamie Green
Q16 #22 [DTMV8] 1:28.861 Mercedes-AMG Motorsport BWT | Lucas Auer
Q17 #7 [DTMV8] 1:28.875 BMW Team RBM | Bruno Spengler
Q18 #48 [DTMV8] 1:28.983 Mercedes-AMG Motorsport BWT | Edoardo Mortara

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #16 Timo Glock 1:27.823 BMW Team RMG
DTMV8: #16 Timo Glock 1:27.823 BMW Team RMG

## Fastest laps (archive)
Overall: #33 René Rast 1:30.160 lap 21
DTMV8: #33 René Rast 1:30.160 lap 21

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #16 BMW Team RMG | BMW M4 DTM | Classified 37L gap — | Timo Glock
 2 g3 #11 BMW Team RMG | BMW M4 DTM | Classified 37L gap 0.178 | Marco Wittmann
 3 g4 #36 BMW Team RBM | BMW M4 DTM | Classified 37L gap 0.840 | Maxime Martin
 4 g9 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 37L gap 2.530 | Mike Rockenfeller
 5 g15 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 37L gap 3.164 | Jamie Green
 6 g2 #15 BMW Team RMG | BMW M4 DTM | Classified 37L gap 4.173 | Augusto Farfus
 7 g11 #3 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 37L gap 4.771 | Paul di Resta
 8 g8 #2 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 37L gap 5.382 | Gary Paffett
 9 g5 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 37L gap 5.911 | René Rast
 10 g14 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 37L gap 6.278 | Nico Müller
 11 g12 #6 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 37L gap 6.734 | Robert Wickens
 12 g18 #48 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 37L gap 7.929 | Edoardo Mortara
 13 g6 #77 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 37L gap 13.880 | Loïc Duval
 14 g17 #7 BMW Team RBM | BMW M4 DTM | Classified 37L gap 21.214 | Bruno Spengler
 15 g16 #22 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 37L gap 27.053 | Lucas Auer
 16 g13 #63 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 37L gap 52.140 | Maro Engel
 17 g10 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 34L gap 3 LAPS | Mattias Ekström
 18 g7 #31 BMW Team RBM | BMW M4 DTM | Classified 17L gap 20 LAPS | Tom Blomqvist
