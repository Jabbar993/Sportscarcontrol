# dtm-moscowraceway-2017-r5-race2

Event: DTM Moscow Raceway Race 2 | Circuit: Moscow Raceway | Date: 2017-07-23
Scheduled: 00:55:00 | Official duration: 00:56:41.087 | Laps (winner): 36

## Qualifying (archive order)
Q1 #7 [DTMV8] 1:26.579 BMW Team RBM | Bruno Spengler
Q2 #5 [DTMV8] 1:26.582 Audi Sport Team Abt Sportsline | Mattias Ekström
Q3 #33 [DTMV8] 1:26.735 Audi Sport Team Rosberg | René Rast
Q4 #3 [DTMV8] 1:26.887 Mercedes-AMG Motorsport SILBERPFEIL Energy | Paul di Resta
Q5 #16 [DTMV8] 1:26.902 BMW Team RMG | Timo Glock
Q6 #11 [DTMV8] 1:26.910 BMW Team RMG | Marco Wittmann
Q7 #36 [DTMV8] 1:26.937 BMW Team RBM | Maxime Martin
Q8 #77 [DTMV8] 1:26.946 Audi Sport Team Phoenix | Loïc Duval
Q9 #2 [DTMV8] 1:27.113 Mercedes-AMG Motorsport Mercedes me | Gary Paffett
Q10 #53 [DTMV8] 1:27.168 Audi Sport Team Rosberg | Jamie Green
Q11 #6 [DTMV8] 1:27.230 Mercedes-AMG Motorsport Mercedes me | Robert Wickens
Q12 #15 [DTMV8] 1:27.230 BMW Team RMG | Augusto Farfus
Q13 #22 [DTMV8] 1:27.230 Mercedes-AMG Motorsport BWT | Lucas Auer
Q14 #51 [DTMV8] 1:27.258 Audi Sport Team Abt Sportsline | Nico Müller
Q15 #99 [DTMV8] 1:27.303 Audi Sport Team Phoenix | Mike Rockenfeller
Q16 #48 [DTMV8] 1:27.332 Mercedes-AMG Motorsport BWT | Edoardo Mortara
Q17 #63 [DTMV8] 1:27.477 Mercedes-AMG Motorsport SILBERPFEIL Energy | Maro Engel
Q18 #31 [DTMV8] 1:26.518 BMW Team RBM | Tom Blomqvist

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #7 Bruno Spengler 1:26.579 BMW Team RBM
DTMV8: #7 Bruno Spengler 1:26.579 BMW Team RBM

## Fastest laps (archive)
Overall: #53 Jamie Green 1:28.436 lap 27
DTMV8: #53 Jamie Green 1:28.436 lap 27

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g17 #63 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 36L gap — | Maro Engel
 2 g2 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 36L gap 0.376 | Mattias Ekström
 3 g1 #7 BMW Team RBM | BMW M4 DTM | Classified 36L gap 3.981 | Bruno Spengler
 4 g3 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 36L gap 4.702 | René Rast
 5 g15 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 36L gap 5.410 | Jamie Green
 6 g6 #11 BMW Team RMG | BMW M4 DTM | Classified 36L gap 7.192 | Marco Wittmann
 7 g18 #31 BMW Team RBM | BMW M4 DTM | Classified 36L gap 8.391 | Tom Blomqvist
 8 g12 #22 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 36L gap 8.564 | Lucas Auer
 9 g10 #6 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 36L gap 8.982 | Robert Wickens
 10 g16 #48 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 36L gap 9.942 | Edoardo Mortara
 11 g11 #15 BMW Team RMG | BMW M4 DTM | Classified 36L gap 10.919 | Augusto Farfus
 12 g14 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 36L gap 12.416 | Mike Rockenfeller
 13 g5 #16 BMW Team RMG | BMW M4 DTM | Classified 36L gap 12.505 | Timo Glock
 14 g8 #77 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 36L gap 19.913 | Loïc Duval
 15 g13 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 36L gap 37.728 | Nico Müller
 16 g9 #2 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 36L gap 39.267 | Gary Paffett
 17 g7 #36 BMW Team RBM | BMW M4 DTM | RET 4L gap RET | Maxime Martin
 18 g4 #3 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | RET 0L gap RET | Paul di Resta
