# dtm-hungaroring-2017-r3-race1

Event: DTM Hungaroring Race 1 | Circuit: Hungaroring | Date: 2017-06-17
Scheduled: 00:55:00 | Official duration: 00:57:52.984 | Laps (winner): 34

## Qualifying (archive order)
Q1 #33 [DTMV8] 1:34.742 Audi Sport Team Rosberg | René Rast
Q2 #53 [DTMV8] 1:34.818 Audi Sport Team Rosberg | Jamie Green
Q3 #5 [DTMV8] 1:35.192 Audi Sport Team Abt Sportsline | Mattias Ekström
Q4 #51 [DTMV8] 1:35.226 Audi Sport Team Abt Sportsline | Nico Müller
Q5 #99 [DTMV8] 1:35.244 Audi Sport Team Phoenix | Mike Rockenfeller
Q6 #15 [DTMV8] 1:35.275 BMW Team RMG | Augusto Farfus
Q7 #77 [DTMV8] 1:35.378 Audi Sport Team Phoenix | Loïc Duval
Q8 #22 [DTMV8] 1:35.454 Mercedes-AMG Motorsport BWT | Lucas Auer
Q9 #2 [DTMV8] 1:35.457 Mercedes-AMG Motorsport Mercedes me | Gary Paffett
Q10 #31 [DTMV8] 1:35.466 BMW Team RBM | Tom Blomqvist
Q11 #6 [DTMV8] 1:35.506 Mercedes-AMG Motorsport Mercedes me | Robert Wickens
Q12 #36 [DTMV8] 1:35.539 BMW Team RBM | Maxime Martin
Q13 #3 [DTMV8] 1:35.575 Mercedes-AMG Motorsport SILBERPFEIL Energy | Paul di Resta
Q14 #16 [DTMV8] 1:35.577 BMW Team RMG | Timo Glock
Q15 #11 [DTMV8] 1:35.815 BMW Team RMG | Marco Wittmann
Q16 #48 [DTMV8] 1:36.039 Mercedes-AMG Motorsport BWT | Edoardo Mortara
Q17 #7 [DTMV8] 1:36.154 BMW Team RBM | Bruno Spengler
Q18 #63 [DTMV8] 1:36.484 Mercedes-AMG Motorsport SILBERPFEIL Energy | Maro Engel

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #33 René Rast 1:34.742 Audi Sport Team Rosberg
DTMV8: #33 René Rast 1:34.742 Audi Sport Team Rosberg

## Fastest laps (archive)
Overall: #99 Mike Rockenfeller 1:37.101 lap 20
DTMV8: #99 Mike Rockenfeller 1:37.101 lap 20

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g13 #3 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 34L gap — | Paul di Resta
 2 g14 #16 BMW Team RMG | BMW M4 DTM | Classified 34L gap 1.393 | Timo Glock
 3 g17 #7 BMW Team RBM | BMW M4 DTM | Classified 34L gap 4.598 | Bruno Spengler
 4 g5 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 34L gap 4.948 | Mike Rockenfeller
 5 g3 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 34L gap 8.937 | Mattias Ekström
 6 g1 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 34L gap 9.561 | René Rast
 7 g9 #2 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 34L gap 31.014 | Gary Paffett
 8 g15 #11 BMW Team RMG | BMW M4 DTM | Classified 34L gap 31.577 | Marco Wittmann
 9 g16 #48 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 34L gap 32.651 | Edoardo Mortara
 10 g4 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 34L gap 33.106 | Nico Müller
 11 g6 #15 BMW Team RMG | BMW M4 DTM | Classified 34L gap 35.742 | Augusto Farfus
 12 g8 #22 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 34L gap 36.780 | Lucas Auer
 13 g18 #63 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 34L gap 37.760 | Maro Engel
 14 g7 #77 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 34L gap 1:06.802 | Loïc Duval
 15 g10 #31 BMW Team RBM | BMW M4 DTM | Classified 25L gap 9 LAPS | Tom Blomqvist
 16 g2 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | DSQ 34L gap DSQ | Jamie Green
 17 g11 #6 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | RET 12L gap RET | Robert Wickens
 18 g12 #36 BMW Team RBM | BMW M4 DTM | RET 7L gap RET | Maxime Martin
