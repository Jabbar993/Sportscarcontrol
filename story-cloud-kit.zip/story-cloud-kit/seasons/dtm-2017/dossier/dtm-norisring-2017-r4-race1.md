# dtm-norisring-2017-r4-race1

Event: DTM Norisring Race 1 | Circuit: Norisring | Date: 2017-07-01
Scheduled: 00:55:00 | Official duration: 00:53:15.532 | Laps (winner): 61

## Qualifying (archive order)
Q1 #36 [DTMV8] 47.472 BMW Team RBM | Maxime Martin
Q2 #33 [DTMV8] 47.477 Audi Sport Team Rosberg | René Rast
Q3 #7 [DTMV8] 47.493 BMW Team RBM | Bruno Spengler
Q4 #31 [DTMV8] 47.527 BMW Team RBM | Tom Blomqvist
Q5 #22 [DTMV8] 47.584 Mercedes-AMG Motorsport BWT | Lucas Auer
Q6 #5 [DTMV8] 47.629 Audi Sport Team Abt Sportsline | Mattias Ekström
Q7 #11 [DTMV8] 47.676 BMW Team RMG | Marco Wittmann
Q8 #16 [DTMV8] 47.692 BMW Team RMG | Timo Glock
Q9 #53 [DTMV8] 47.714 Audi Sport Team Rosberg | Jamie Green
Q10 #51 [DTMV8] 47.718 Audi Sport Team Abt Sportsline | Nico Müller
Q11 #6 [DTMV8] 47.739 Mercedes-AMG Motorsport Mercedes me | Robert Wickens
Q12 #99 [DTMV8] 47.763 Audi Sport Team Phoenix | Mike Rockenfeller
Q13 #2 [DTMV8] 47.781 Mercedes-AMG Motorsport Mercedes me | Gary Paffett
Q14 #48 [DTMV8] 47.813 Mercedes-AMG Motorsport BWT | Edoardo Mortara
Q15 #63 [DTMV8] 47.881 Mercedes-AMG Motorsport SILBERPFEIL Energy | Maro Engel
Q16 #15 [DTMV8] 47.883 BMW Team RMG | Augusto Farfus
Q17 #3 [DTMV8] 48.014 Mercedes-AMG Motorsport SILBERPFEIL Energy | Paul di Resta
Q18 #77 [DTMV8] 48.123 Audi Sport Team Phoenix | Loïc Duval

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #36 Maxime Martin 47.472 BMW Team RBM
DTMV8: #36 Maxime Martin 47.472 BMW Team RBM

## Fastest laps (archive)
Overall: #31 Tom Blomqvist 48.345 lap 39
DTMV8: #31 Tom Blomqvist 48.345 lap 39

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g3 #7 BMW Team RBM | BMW M4 DTM | Classified 61L gap — | Bruno Spengler
 2 g1 #36 BMW Team RBM | BMW M4 DTM | Classified 61L gap 4.385 | Maxime Martin
 3 g6 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 61L gap 4.776 | Mattias Ekström
 4 g7 #11 BMW Team RMG | BMW M4 DTM | Classified 61L gap 10.812 | Marco Wittmann
 5 g8 #16 BMW Team RMG | BMW M4 DTM | Classified 61L gap 12.151 | Timo Glock
 6 g4 #31 BMW Team RBM | BMW M4 DTM | Classified 61L gap 12.828 | Tom Blomqvist
 7 g9 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 61L gap 18.573 | Jamie Green
 8 g14 #48 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 61L gap 20.328 | Edoardo Mortara
 9 g10 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 61L gap 21.355 | Nico Müller
 10 g13 #2 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 61L gap 34.707 | Gary Paffett
 11 g17 #3 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 61L gap 34.986 | Paul di Resta
 12 g2 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 61L gap 35.357 | René Rast
 13 g12 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 61L gap 41.287 | Mike Rockenfeller
 14 g15 #63 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 61L gap 42.528 | Maro Engel
 15 g18 #77 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 60L gap 1 LAP | Loïc Duval
 16 g16 #15 BMW Team RMG | BMW M4 DTM | RET 9L gap RET | Augusto Farfus
 17 g5 #22 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | RET 1L gap RET | Lucas Auer
 18 g11 #6 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | RET 0L gap RET | Robert Wickens
