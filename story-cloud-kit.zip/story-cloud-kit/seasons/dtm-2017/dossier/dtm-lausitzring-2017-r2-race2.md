# dtm-lausitzring-2017-r2-race2

Event: DTM Lausitzring Race 2 | Circuit: Lausitzring | Date: 2017-05-21
Scheduled: 00:55:00 | Official duration: 00:56:20.480 | Laps (winner): 43

## Qualifying (archive order)
Q1 #6 [DTMV8] 1:16.299 Mercedes-AMG Motorsport Mercedes me | Robert Wickens
Q2 #31 [DTMV8] 1:16.323 BMW Team RBM | Tom Blomqvist
Q3 #53 [DTMV8] 1:16.326 Audi Sport Team Rosberg | Jamie Green
Q4 #2 [DTMV8] 1:16.368 Mercedes-AMG Motorsport Mercedes me | Gary Paffett
Q5 #36 [DTMV8] 1:16.379 BMW Team RBM | Maxime Martin
Q6 #33 [DTMV8] 1:16.406 Audi Sport Team Rosberg | René Rast
Q7 #51 [DTMV8] 1:16.409 Audi Sport Team Abt Sportsline | Nico Müller
Q8 #5 [DTMV8] 1:16.441 Audi Sport Team Abt Sportsline | Mattias Ekström
Q9 #15 [DTMV8] 1:16.460 BMW Team RMG | Augusto Farfus
Q10 #11 [DTMV8] 1:16.579 BMW Team RMG | Marco Wittmann
Q11 #99 [DTMV8] 1:16.651 Audi Sport Team Phoenix | Mike Rockenfeller
Q12 #7 [DTMV8] 1:16.662 BMW Team RBM | Bruno Spengler
Q13 #16 [DTMV8] 1:16.704 BMW Team RMG | Timo Glock
Q14 #77 [DTMV8] 1:16.710 Audi Sport Team Phoenix | Loïc Duval
Q15 #22 [DTMV8] 1:16.812 Mercedes-AMG Motorsport BWT | Lucas Auer
Q16 #3 [DTMV8] 1:16.813 Mercedes-AMG Motorsport SILBERPFEIL Energy | Paul di Resta
Q17 #63 [DTMV8] 1:16.889 Mercedes-AMG Motorsport SILBERPFEIL Energy | Maro Engel
Q18 #48 [DTMV8] 1:17.127 Mercedes-AMG Motorsport BWT | Edoardo Mortara

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #6 Robert Wickens 1:16.299 Mercedes-AMG Motorsport Mercedes me
DTMV8: #6 Robert Wickens 1:16.299 Mercedes-AMG Motorsport Mercedes me

## Fastest laps (archive)
Overall: #33 René Rast 1:17.098 lap 25
DTMV8: #33 René Rast 1:17.098 lap 25

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g3 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 43L gap — | Jamie Green
 2 g8 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 43L gap 6.295 | Mattias Ekström
 3 g1 #6 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 43L gap 7.034 | Robert Wickens
 4 g4 #2 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 43L gap 7.387 | Gary Paffett
 5 g11 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 43L gap 9.750 | Mike Rockenfeller
 6 g7 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 43L gap 13.039 | Nico Müller
 7 g6 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 43L gap 16.370 | René Rast
 8 g5 #36 BMW Team RBM | BMW M4 DTM | Classified 43L gap 18.115 | Maxime Martin
 9 g10 #11 BMW Team RMG | BMW M4 DTM | Classified 43L gap 19.540 | Marco Wittmann
 10 g15 #22 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 43L gap 26.283 | Lucas Auer
 11 g18 #48 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 43L gap 34.419 | Edoardo Mortara
 12 g17 #63 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 43L gap 34.973 | Maro Engel
 13 g16 #3 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 43L gap 36.322 | Paul di Resta
 14 g9 #15 BMW Team RMG | BMW M4 DTM | Classified 43L gap 37.554 | Augusto Farfus
 15 g13 #16 BMW Team RMG | BMW M4 DTM | Classified 43L gap 38.815 | Timo Glock
 16 g12 #7 BMW Team RBM | BMW M4 DTM | Classified 43L gap 39.363 | Bruno Spengler
 17 g2 #31 BMW Team RBM | BMW M4 DTM | Classified 43L gap 39.994 | Tom Blomqvist
 18 g14 #77 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 43L gap 44.331 | Loïc Duval
