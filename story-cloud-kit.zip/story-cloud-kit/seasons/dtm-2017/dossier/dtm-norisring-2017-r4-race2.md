# dtm-norisring-2017-r4-race2

Event: DTM Norisring Race 2 | Circuit: Norisring | Date: 2017-07-02
Scheduled: 00:55:00 | Official duration: 1:29:22.150 | Laps (winner): 66

## Qualifying (archive order)
Q1 #31 [DTMV8] 47.252 BMW Team RBM | Tom Blomqvist
Q2 #6 [DTMV8] 47.256 Mercedes-AMG Motorsport Mercedes me | Robert Wickens
Q3 #51 [DTMV8] 47.289 Audi Sport Team Abt Sportsline | Nico Müller
Q4 #7 [DTMV8] 47.305 BMW Team RBM | Bruno Spengler
Q5 #5 [DTMV8] 47.329 Audi Sport Team Abt Sportsline | Mattias Ekström
Q6 #22 [DTMV8] 47.344 Mercedes-AMG Motorsport BWT | Lucas Auer
Q7 #36 [DTMV8] 47.355 BMW Team RBM | Maxime Martin
Q8 #99 [DTMV8] 47.395 Audi Sport Team Phoenix | Mike Rockenfeller
Q9 #16 [DTMV8] 47.400 BMW Team RMG | Timo Glock
Q10 #33 [DTMV8] 47.414 Audi Sport Team Rosberg | René Rast
Q11 #2 [DTMV8] 47.495 Mercedes-AMG Motorsport Mercedes me | Gary Paffett
Q12 #11 [DTMV8] 47.503 BMW Team RMG | Marco Wittmann
Q13 #3 [DTMV8] 47.510 Mercedes-AMG Motorsport SILBERPFEIL Energy | Paul di Resta
Q14 #53 [DTMV8] 47.526 Audi Sport Team Rosberg | Jamie Green
Q15 #15 [DTMV8] 47.534 BMW Team RMG | Augusto Farfus
Q16 #48 [DTMV8] 47.612 Mercedes-AMG Motorsport BWT | Edoardo Mortara
Q17 #77 [DTMV8] 47.814 Audi Sport Team Phoenix | Loïc Duval
Q18 #63 [DTMV8] 47.890 Mercedes-AMG Motorsport SILBERPFEIL Energy | Maro Engel

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #31 Tom Blomqvist 47.252 BMW Team RBM
DTMV8: #31 Tom Blomqvist 47.252 BMW Team RBM

## Fastest laps (archive)
Overall: #7 Bruno Spengler 47.846 lap 44
DTMV8: #7 Bruno Spengler 47.846 lap 44

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g7 #36 BMW Team RBM | BMW M4 DTM | Classified 66L gap — | Maxime Martin
 2 g6 #22 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 66L gap 2.903 | Lucas Auer
 3 g16 #48 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 66L gap 4.460 | Edoardo Mortara
 4 g5 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 66L gap 4.462 | Mattias Ekström
 5 g12 #11 BMW Team RMG | BMW M4 DTM | Classified 66L gap 4.487 | Marco Wittmann
 6 g13 #3 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 66L gap 5.708 | Paul di Resta
 7 g15 #15 BMW Team RMG | BMW M4 DTM | Classified 66L gap 11.613 | Augusto Farfus
 8 g14 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 66L gap 12.064 | Jamie Green
 9 g1 #31 BMW Team RBM | BMW M4 DTM | Classified 66L gap 12.694 | Tom Blomqvist
 10 g9 #16 BMW Team RMG | BMW M4 DTM | Classified 66L gap 13.347 | Timo Glock
 11 g2 #6 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 66L gap 15.163 | Robert Wickens
 12 g4 #7 BMW Team RBM | BMW M4 DTM | Classified 66L gap 15.360 | Bruno Spengler
 13 g3 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 66L gap 17.560 | Nico Müller
 14 g18 #63 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 66L gap 23.377 | Maro Engel
 15 g17 #77 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 65L gap 1 LAP | Loïc Duval
 16 g10 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | RET 33L gap RET | René Rast
 17 g8 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | RET 32L gap RET | Mike Rockenfeller
 18 g11 #2 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | RET 32L gap RET | Gary Paffett
