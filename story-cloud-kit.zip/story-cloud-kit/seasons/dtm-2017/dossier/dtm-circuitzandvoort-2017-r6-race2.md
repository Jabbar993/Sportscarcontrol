# dtm-circuitzandvoort-2017-r6-race2

Event: DTM Circuit Zandvoort Race 2 | Circuit: Zandvoort | Date: 2017-08-20
Scheduled: 00:55:00 | Official duration: 00:56:33.404 | Laps (winner): 37

## Qualifying (archive order)
Q1 #15 [DTMV8] 1:27.475 BMW Team RMG | Augusto Farfus
Q2 #11 [DTMV8] 1:27.616 BMW Team RMG | Marco Wittmann
Q3 #36 [DTMV8] 1:27.642 BMW Team RBM | Maxime Martin
Q4 #53 [DTMV8] 1:27.673 Audi Sport Team Rosberg | Jamie Green
Q5 #16 [DTMV8] 1:27.690 BMW Team RMG | Timo Glock
Q6 #33 [DTMV8] 1:27.832 Audi Sport Team Rosberg | René Rast
Q7 #99 [DTMV8] 1:27.892 Audi Sport Team Phoenix | Mike Rockenfeller
Q8 #2 [DTMV8] 1:27.926 Mercedes-AMG Motorsport Mercedes me | Gary Paffett
Q9 #7 [DTMV8] 1:27.991 BMW Team RBM | Bruno Spengler
Q10 #63 [DTMV8] 1:28.004 Mercedes-AMG Motorsport SILBERPFEIL Energy | Maro Engel
Q11 #6 [DTMV8] 1:28.037 Mercedes-AMG Motorsport Mercedes me | Robert Wickens
Q12 #5 [DTMV8] 1:28.089 Audi Sport Team Abt Sportsline | Mattias Ekström
Q13 #22 [DTMV8] 1:28.260 Mercedes-AMG Motorsport BWT | Lucas Auer
Q14 #31 [DTMV8] 1:28.292 BMW Team RBM | Tom Blomqvist
Q15 #77 [DTMV8] 1:28.302 Audi Sport Team Phoenix | Loïc Duval
Q16 #51 [DTMV8] 1:28.439 Audi Sport Team Abt Sportsline | Nico Müller
Q17 #48 [DTMV8] 1:28.775 Mercedes-AMG Motorsport BWT | Edoardo Mortara

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #15 Augusto Farfus 1:27.475 BMW Team RMG
DTMV8: #15 Augusto Farfus 1:27.475 BMW Team RMG

## Fastest laps (archive)
Overall: #77 Loïc Duval 1:29.168 lap 28
DTMV8: #77 Loïc Duval 1:29.168 lap 28

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g7 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 37L gap — | Mike Rockenfeller
 2 g15 #77 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 37L gap 16.581 | Loïc Duval
 3 g12 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 37L gap 58.073 | Mattias Ekström
 4 g16 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 37L gap 58.620 | Nico Müller
 5 g8 #2 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 37L gap 58.848 | Gary Paffett
 6 g3 #36 BMW Team RBM | BMW M4 DTM | Classified 37L gap 59.390 | Maxime Martin
 7 g5 #16 BMW Team RMG | BMW M4 DTM | Classified 37L gap 59.928 | Timo Glock
 8 g1 #15 BMW Team RMG | BMW M4 DTM | Classified 37L gap 1:00.069 | Augusto Farfus
 9 g4 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 37L gap 1:02.405 | Jamie Green
 10 g9 #7 BMW Team RBM | BMW M4 DTM | Classified 37L gap 1:12.009 | Bruno Spengler
 11 g10 #63 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 37L gap 1:30.127 | Maro Engel
 12 g17 #48 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 37L gap 1:30.761 | Edoardo Mortara
 13 g14 #31 BMW Team RBM | BMW M4 DTM | Classified 37L gap 1:31.278 | Tom Blomqvist
 14 g13 #22 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 36L gap 1 LAP | Lucas Auer
 15 g2 #11 BMW Team RMG | BMW M4 DTM | DSQ 37L gap DSQ | Marco Wittmann
 16 g11 #6 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | RET 33L gap RET | Robert Wickens
 17 g? #3 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | RET 0L gap RET | Paul di Resta
 18 g6 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | RET 0L gap RET | René Rast
