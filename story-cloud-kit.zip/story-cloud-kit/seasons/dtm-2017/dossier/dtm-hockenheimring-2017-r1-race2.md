# dtm-hockenheimring-2017-r1-race2

Event: DTM Hockenheimring Race 2 | Circuit: Hockenheimring | Date: 2017-05-07
Scheduled: 00:55:00 | Official duration: 00:56:53.264 | Laps (winner): 32

## Qualifying (archive order)
Q1 #16 [DTMV8] 1:31.406 BMW Team RMG | Timo Glock
Q2 #33 [DTMV8] 1:31.581 Audi Sport Team Rosberg | René Rast
Q3 #53 [DTMV8] 1:31.639 Audi Sport Team Rosberg | Jamie Green
Q4 #48 [DTMV8] 1:31.759 Mercedes-AMG Motorsport BWT | Edoardo Mortara
Q5 #99 [DTMV8] 1:31.764 Audi Sport Team Phoenix | Mike Rockenfeller
Q6 #7 [DTMV8] 1:31.924 BMW Team RBM | Bruno Spengler
Q7 #2 [DTMV8] 1:32.025 Mercedes-AMG Motorsport Mercedes me | Gary Paffett
Q8 #22 [DTMV8] 1:32.068 Mercedes-AMG Motorsport BWT | Lucas Auer
Q9 #63 [DTMV8] 1:32.081 Mercedes-AMG Motorsport SILBERPFEIL Energy | Maro Engel
Q10 #5 [DTMV8] 1:32.096 Audi Sport Team Abt Sportsline | Mattias Ekström
Q11 #3 [DTMV8] 1:32.103 Mercedes-AMG Motorsport SILBERPFEIL Energy | Paul di Resta
Q12 #51 [DTMV8] 1:32.228 Audi Sport Team Abt Sportsline | Nico Müller
Q13 #77 [DTMV8] 1:32.335 Audi Sport Team Phoenix | Loïc Duval
Q14 #31 [DTMV8] 1:32.393 BMW Team RBM | Tom Blomqvist
Q15 #36 [DTMV8] 1:32.529 BMW Team RBM | Maxime Martin
Q16 #6 [DTMV8] 1:32.552 Mercedes-AMG Motorsport Mercedes me | Robert Wickens
Q17 #11 [DTMV8] 1:32.661 BMW Team RMG | Marco Wittmann
Q18 #15 [DTMV8] 1:33.734 BMW Team RMG | Augusto Farfus

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #16 Timo Glock 1:31.406 BMW Team RMG
DTMV8: #16 Timo Glock 1:31.406 BMW Team RMG

## Fastest laps (archive)
Overall: #53 Jamie Green 1:33.614 lap 7
DTMV8: #53 Jamie Green 1:33.614 lap 7

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g3 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 32L gap — | Jamie Green
 2 g7 #2 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 32L gap 4.936 | Gary Paffett
 3 g17 #11 BMW Team RMG | BMW M4 DTM | Classified 32L gap 8.191 | Marco Wittmann
 4 g8 #22 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 32L gap 16.985 | Lucas Auer
 5 g12 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 32L gap 26.959 | Nico Müller
 6 g11 #3 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 32L gap 27.426 | Paul di Resta
 7 g5 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 32L gap 31.315 | Mike Rockenfeller
 8 g1 #16 BMW Team RMG | BMW M4 DTM | Classified 32L gap 1:06.250 | Timo Glock
 9 g6 #7 BMW Team RBM | BMW M4 DTM | Classified 32L gap 1:08.538 | Bruno Spengler
 10 g9 #63 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 32L gap 1:12.117 | Maro Engel
 11 g10 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 32L gap 1:12.944 | Mattias Ekström
 12 g14 #31 BMW Team RBM | BMW M4 DTM | Classified 32L gap 1:48.234 | Tom Blomqvist
 13 g4 #48 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 31L gap 1 LAP | Edoardo Mortara
 14 g18 #15 BMW Team RMG | BMW M4 DTM | RET 12L gap RET | Augusto Farfus
 15 g13 #77 Audi Sport Team Phoenix | Audi RS 5 DTM | RET 7L gap RET | Loïc Duval
 16 g2 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | RET 4L gap RET | René Rast
 17 g15 #36 BMW Team RBM | BMW M4 DTM | RET 3L gap RET | Maxime Martin
 18 g16 #6 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | RET 0L gap RET | Robert Wickens
