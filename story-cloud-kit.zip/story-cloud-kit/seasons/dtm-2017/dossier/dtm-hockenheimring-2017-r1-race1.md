# dtm-hockenheimring-2017-r1-race1

Event: DTM Hockenheimring Race 1 | Circuit: Hockenheimring | Date: 2017-05-06
Scheduled: 00:55:00 | Official duration: 00:57:23.598 | Laps (winner): 36

## Qualifying (archive order)
Q1 #22 [DTMV8] 1:30.849 Mercedes-AMG Motorsport BWT | Lucas Auer
Q2 #2 [DTMV8] 1:31.042 Mercedes-AMG Motorsport Mercedes me | Gary Paffett
Q3 #48 [DTMV8] 1:31.120 Mercedes-AMG Motorsport BWT | Edoardo Mortara
Q4 #16 [DTMV8] 1:31.161 BMW Team RMG | Timo Glock
Q5 #36 [DTMV8] 1:31.247 BMW Team RBM | Maxime Martin
Q6 #3 [DTMV8] 1:31.275 Mercedes-AMG Motorsport SILBERPFEIL Energy | Paul di Resta
Q7 #63 [DTMV8] 1:31.309 Mercedes-AMG Motorsport SILBERPFEIL Energy | Maro Engel
Q8 #51 [DTMV8] 1:31.490 Audi Sport Team Abt Sportsline | Nico Müller
Q9 #31 [DTMV8] 1:31.510 BMW Team RBM | Tom Blomqvist
Q10 #6 [DTMV8] 1:31.538 Mercedes-AMG Motorsport Mercedes me | Robert Wickens
Q11 #11 [DTMV8] 1:31.662 BMW Team RMG | Marco Wittmann
Q12 #53 [DTMV8] 1:31.805 Audi Sport Team Rosberg | Jamie Green
Q13 #7 [DTMV8] 1:31.834 BMW Team RBM | Bruno Spengler
Q14 #33 [DTMV8] 1:31.871 Audi Sport Team Rosberg | René Rast
Q15 #15 [DTMV8] 1:31.915 BMW Team RMG | Augusto Farfus
Q16 #99 [DTMV8] 1:31.965 Audi Sport Team Phoenix | Mike Rockenfeller
Q17 #5 [DTMV8] 1:32.082 Audi Sport Team Abt Sportsline | Mattias Ekström
Q18 #77 [DTMV8] 1:32.450 Audi Sport Team Phoenix | Loïc Duval

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #22 Lucas Auer 1:30.849 Mercedes-AMG Motorsport BWT
DTMV8: #22 Lucas Auer 1:30.849 Mercedes-AMG Motorsport BWT

## Fastest laps (archive)
Overall: #5 Mattias Ekström 1:33.201 lap 29
DTMV8: #5 Mattias Ekström 1:33.201 lap 29

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #22 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 36L gap — | Lucas Auer
 2 g4 #16 BMW Team RMG | BMW M4 DTM | Classified 36L gap 1.942 | Timo Glock
 3 g16 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 36L gap 3.351 | Mike Rockenfeller
 4 g3 #48 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 36L gap 3.984 | Edoardo Mortara
 5 g17 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 36L gap 4.275 | Mattias Ekström
 6 g14 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 36L gap 5.855 | René Rast
 7 g2 #2 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 36L gap 6.956 | Gary Paffett
 8 g6 #3 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 36L gap 13.648 | Paul di Resta
 9 g8 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 36L gap 17.510 | Nico Müller
 10 g11 #11 BMW Team RMG | BMW M4 DTM | Classified 36L gap 19.190 | Marco Wittmann
 11 g5 #36 BMW Team RBM | BMW M4 DTM | Classified 36L gap 20.800 | Maxime Martin
 12 g13 #7 BMW Team RBM | BMW M4 DTM | Classified 36L gap 21.504 | Bruno Spengler
 13 g15 #15 BMW Team RMG | BMW M4 DTM | Classified 36L gap 25.351 | Augusto Farfus
 14 g18 #77 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 36L gap 34.343 | Loïc Duval
 15 g10 #6 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 36L gap 43.948 | Robert Wickens
 16 g9 #31 BMW Team RBM | BMW M4 DTM | Classified 36L gap 44.956 | Tom Blomqvist
 17 g7 #63 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 36L gap 51.525 | Maro Engel
 18 g12 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 36L gap 1:02.944 | Jamie Green
