# dtm-redbullring-2017-r8-race2

Event: DTM Red Bull Ring Race 2 | Circuit: Red Bull Ring | Date: 2017-09-24
Scheduled: 00:55:00 | Official duration: 00:57:21.893 | Laps (winner): 39

## Qualifying (archive order)
Q1 #53 [DTMV8] 1:21.955 Audi Sport Team Rosberg | Jamie Green
Q2 #33 [DTMV8] 1:22.010 Audi Sport Team Rosberg | René Rast
Q3 #11 [DTMV8] 1:22.156 BMW Team RMG | Marco Wittmann
Q4 #99 [DTMV8] 1:22.206 Audi Sport Team Phoenix | Mike Rockenfeller
Q5 #51 [DTMV8] 1:22.206 Audi Sport Team Abt Sportsline | Nico Müller
Q6 #2 [DTMV8] 1:22.243 Mercedes-AMG Motorsport Mercedes me | Gary Paffett
Q7 #16 [DTMV8] 1:22.268 BMW Team RMG | Timo Glock
Q8 #5 [DTMV8] 1:22.337 Audi Sport Team Abt Sportsline | Mattias Ekström
Q9 #31 [DTMV8] 1:22.390 BMW Team RBM | Tom Blomqvist
Q10 #7 [DTMV8] 1:22.400 BMW Team RBM | Bruno Spengler
Q11 #36 [DTMV8] 1:22.405 BMW Team RBM | Maxime Martin
Q12 #15 [DTMV8] 1:22.429 BMW Team RMG | Augusto Farfus
Q13 #3 [DTMV8] 1:22.454 Mercedes-AMG Motorsport SILBERPFEIL Energy | Paul di Resta
Q14 #48 [DTMV8] 1:22.497 Mercedes-AMG Motorsport BWT | Edoardo Mortara
Q15 #63 [DTMV8] 1:22.526 Mercedes-AMG Motorsport SILBERPFEIL Energy | Maro Engel
Q16 #6 [DTMV8] 1:22.527 Mercedes-AMG Motorsport Mercedes me | Robert Wickens
Q17 #77 [DTMV8] 1:22.629 Audi Sport Team Phoenix | Loïc Duval
Q18 #22 [DTMV8] 1:22.682 Mercedes-AMG Motorsport BWT | Lucas Auer

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #53 Jamie Green 1:21.955 Audi Sport Team Rosberg
DTMV8: #53 Jamie Green 1:21.955 Audi Sport Team Rosberg

## Fastest laps (archive)
Overall: #53 Jamie Green 1:23.474 lap 8
DTMV8: #53 Jamie Green 1:23.474 lap 8

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g2 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 39L gap — | René Rast
 2 g4 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 39L gap 1.025 | Mike Rockenfeller
 3 g5 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 39L gap 1.824 | Nico Müller
 4 g6 #2 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 39L gap 3.741 | Gary Paffett
 5 g8 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 39L gap 6.136 | Mattias Ekström
 6 g3 #11 BMW Team RMG | BMW M4 DTM | Classified 39L gap 7.968 | Marco Wittmann
 7 g7 #16 BMW Team RMG | BMW M4 DTM | Classified 39L gap 8.181 | Timo Glock
 8 g18 #77 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 39L gap 8.457 | Loïc Duval
 9 g13 #3 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 39L gap 9.328 | Paul di Resta
 10 g16 #6 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 39L gap 11.305 | Robert Wickens
 11 g11 #36 BMW Team RBM | BMW M4 DTM | Classified 39L gap 12.126 | Maxime Martin
 12 g12 #15 BMW Team RMG | BMW M4 DTM | Classified 39L gap 12.696 | Augusto Farfus
 13 g9 #31 BMW Team RBM | BMW M4 DTM | Classified 39L gap 14.745 | Tom Blomqvist
 14 g1 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 39L gap 16.754 | Jamie Green
 15 g15 #63 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 39L gap 27.255 | Maro Engel
 16 g10 #7 BMW Team RBM | BMW M4 DTM | Classified 39L gap 28.571 | Bruno Spengler
 17 g14 #48 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | NC 32L gap 7 LAPS | Edoardo Mortara
 18 g17 #22 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | RET 0L gap RET | Lucas Auer
