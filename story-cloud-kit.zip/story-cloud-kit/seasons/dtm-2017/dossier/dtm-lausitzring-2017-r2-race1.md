# dtm-lausitzring-2017-r2-race1

Event: DTM Lausitzring Race 1 | Circuit: Lausitzring | Date: 2017-05-20
Scheduled: 00:55:00 | Official duration: 00:56:37.503 | Laps (winner): 43

## Qualifying (archive order)
Q1 #22 [DTMV8] 1:16.193 Mercedes-AMG Motorsport BWT | Lucas Auer
Q2 #6 [DTMV8] 1:16.298 Mercedes-AMG Motorsport Mercedes me | Robert Wickens
Q3 #36 [DTMV8] 1:16.404 BMW Team RBM | Maxime Martin
Q4 #33 [DTMV8] 1:16.420 Audi Sport Team Rosberg | René Rast
Q5 #16 [DTMV8] 1:16.424 BMW Team RMG | Timo Glock
Q6 #31 [DTMV8] 1:16.473 BMW Team RBM | Tom Blomqvist
Q7 #51 [DTMV8] 1:16.484 Audi Sport Team Abt Sportsline | Nico Müller
Q8 #99 [DTMV8] 1:16.506 Audi Sport Team Phoenix | Mike Rockenfeller
Q9 #2 [DTMV8] 1:16.510 Mercedes-AMG Motorsport Mercedes me | Gary Paffett
Q10 #48 [DTMV8] 1:16.542 Mercedes-AMG Motorsport BWT | Edoardo Mortara
Q11 #11 [DTMV8] 1:16.551 BMW Team RMG | Marco Wittmann
Q12 #53 [DTMV8] 1:16.560 Audi Sport Team Rosberg | Jamie Green
Q13 #5 [DTMV8] 1:16.751 Audi Sport Team Abt Sportsline | Mattias Ekström
Q14 #63 [DTMV8] 1:16.775 Mercedes-AMG Motorsport SILBERPFEIL Energy | Maro Engel
Q15 #15 [DTMV8] 1:16.804 BMW Team RMG | Augusto Farfus
Q16 #77 [DTMV8] 1:16.981 Audi Sport Team Phoenix | Loïc Duval
Q17 #3 [DTMV8] 1:17.020 Mercedes-AMG Motorsport SILBERPFEIL Energy | Paul di Resta
Q18 #7 [DTMV8] 1:17.097 BMW Team RBM | Bruno Spengler

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #22 Lucas Auer 1:16.193 Mercedes-AMG Motorsport BWT
DTMV8: #22 Lucas Auer 1:16.193 Mercedes-AMG Motorsport BWT

## Fastest laps (archive)
Overall: #33 René Rast 1:17.343 lap 31
DTMV8: #33 René Rast 1:17.343 lap 31

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #22 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 43L gap — | Lucas Auer
 2 g2 #6 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 43L gap 3.613 | Robert Wickens
 3 g4 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 43L gap 12.581 | René Rast
 4 g3 #36 BMW Team RBM | BMW M4 DTM | Classified 43L gap 17.660 | Maxime Martin
 5 g8 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 43L gap 17.810 | Mike Rockenfeller
 6 g9 #2 Mercedes-AMG Motorsport Mercedes me | Mercedes-AMG C 63 DTM | Classified 43L gap 20.253 | Gary Paffett
 7 g10 #48 Mercedes-AMG Motorsport BWT | Mercedes-AMG C 63 DTM | Classified 43L gap 21.366 | Edoardo Mortara
 8 g12 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 43L gap 22.319 | Mattias Ekström
 9 g13 #63 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 43L gap 26.361 | Maro Engel
 10 g18 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 43L gap 29.960 | Jamie Green
 11 g5 #16 BMW Team RMG | BMW M4 DTM | Classified 43L gap 34.423 | Timo Glock
 12 g14 #15 BMW Team RMG | BMW M4 DTM | Classified 43L gap 35.163 | Augusto Farfus
 13 g11 #11 BMW Team RMG | BMW M4 DTM | Classified 43L gap 36.280 | Marco Wittmann
 14 g17 #7 BMW Team RBM | BMW M4 DTM | Classified 43L gap 38.467 | Bruno Spengler
 15 g15 #77 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 43L gap 39.577 | Loïc Duval
 16 g16 #3 Mercedes-AMG Motorsport SILBERPFEIL Energy | Mercedes-AMG C 63 DTM | Classified 43L gap 48.526 | Paul di Resta
 17 g6 #31 BMW Team RBM | BMW M4 DTM | Classified 43L gap 1:01.476 | Tom Blomqvist
 18 g7 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | RET 34L gap RET | Nico Müller
