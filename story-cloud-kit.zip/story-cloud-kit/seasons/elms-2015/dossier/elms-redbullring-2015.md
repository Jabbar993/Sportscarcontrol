# elms-redbullring-2015

Event: 4 Hours of Red Bull Ring | Circuit: Red Bull Ring | Date: 2015-07-12
Scheduled: 04:00:00 | Official duration: 4:00:21.546 | Laps (winner): 151

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q23 #62 [GTC] 1:31.101 AF Corse | Francesco Castellacci
Q24 #63 [GTC] 1:31.316 AF Corse | Marco Cioci
Q25 #59 [GTC] 1:31.704 TDS Racing | Franck Perera
Q27 #64 [GTC] 1:33.074 AF Corse | Francisco Guedes
Q28 #68 [GTC] 1:33.329 Massive Motorsport | Casper Elgaard
Q13 #51 [LMGTE] 1:29.714 AF Corse | Raffaele Giammaria
Q14 #60 [LMGTE] 1:29.847 Formula Racing | Mikkel Mac
Q16 #56 [LMGTE] 1:30.064 AT Racing | Alessandro Pier Guidi
Q18 #66 [LMGTE] 1:30.296 JMW Motorsport | Samuel Tordoff
Q19 #88 [LMGTE] 1:30.352 Proton Competition | Richard Lietz
Q21 #52 [LMGTE] 1:30.640 BMW Team MarcVDS | Andy Priaulx
Q22 #86 [LMGTE] 1:30.881 Gulf Racing UK | Adam Carroll
Q1 #38 [LMP2] 1:22.983 Jota Sport | Harry Tincknell
Q2 #48 [LMP2] 1:23.324 Murphy Prototypes | Nathanaël Berthon
Q3 #37 [LMP2] 1:23.447 SMP Racing | Mikhail Aleshin
Q4 #46 [LMP2] 1:23.614 Thiriet by TDS Racing | Tristan Gommendy
Q5 #27 [LMP2] 1:23.750 SMP Racing | Nicolas Minassian
Q6 #29 [LMP2] 1:23.766 Pegasus Racing | Léo Roussel
Q7 #40 [LMP2] 1:23.948 Krohn Racing | Niclas Jönsson
Q8 #41 [LMP2] 1:23.959 Greaves Motorsport | Gary Hirsch
Q9 #33 [LMP2] 1:24.759 Eurasia Motorsport | Nico Pieter de Bruijn
Q10 #45 [LMP2] 1:24.912 Ibanez Racing | Ivan Bellarosa
Q11 #44 [LMP2] 1:26.420 Ibanez Racing | Yutaka Yamagishi
Q12 #25 [LMP2] 1:27.657 Algarve Pro Racing | James Winslow
Q15 #3 [LMP3] 1:29.851 Team LNT | Charlie Robertson
Q17 #15 [LMP3] 1:30.234 SVK By Speed Factory | Konstantin Calko
Q20 #2 [LMP3] 1:30.481 Team LNT | Mark Shulzhitskiy
Q26 #5 [LMP3] 1:31.765 Villorba Corse | Giorgio Sernagiotto

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #38 Harry Tincknell 1:22.983 Jota Sport
GTC: #62 Francesco Castellacci 1:31.101 AF Corse
LMGTE: #51 Raffaele Giammaria 1:29.714 AF Corse
LMP2: #38 Harry Tincknell 1:22.983 Jota Sport
LMP3: #3 Charlie Robertson 1:29.851 Team LNT

## Fastest laps (archive)
Overall: #38 Filipe Albuquerque 1:24.703
GTC: #62 Francesco Castellacci 1:32.956
LMGTE: #88 Sebastian Asch 1:31.196
LMP2: #38 Filipe Albuquerque 1:24.703
LMP3: #3 Charlie Robertson 1:30.397

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g1 #38 Jota Sport | Gibson 015S - Nissan | Classified 151L gap — | Simon Dolan / Filipe Albuquerque / Harry Tincknell
 2 g4 #46 Thiriet by TDS Racing | Oreca 05 - Nissan | Classified 151L gap 27.478 | Pierre Thiriet / Ludovic Badey / Tristan Gommendy
 3 g3 #37 SMP Racing | BR01 - Nissan | Classified 150L gap 1 Laps | Mikhail Aleshin / Anton Ladygin / Kirill Ladygin
 4 g8 #41 Greaves Motorsport | Gibson 015S - Nissan | Classified 150L gap 1 Laps | Gary Hirsch / Bjorn Wirdheim / Jon Lancaster
 5 g7 #40 Krohn Racing | Ligier JS P2 - Judd | Classified 150L gap 1 Laps | Tracy Krohn / Niclas Jönsson / Julien Canal
 6 g2 #48 Murphy Prototypes | Oreca 03R - Nissan | Classified 150L gap 1 Laps | Nathanaël Berthon / Michael Lyons / Mark Patterson
 7 g6 #29 Pegasus Racing | Morgan - Nissan | Classified 149L gap 2 Laps | Léo Roussel / David Cheng / Julien Schell
 8 g9 #33 Eurasia Motorsport | Oreca 03R - Nissan | Classified 149L gap 2 Laps | Pu Jun Jin / Nico Pieter de Bruijn
 9 g10 #45 Ibanez Racing | Oreca 03 - Nissan | Classified 149L gap 2 Laps | Ivan Bellarosa / José Ibanez
 15 g12 #25 Algarve Pro Racing | Ligier JS P2 - Nissan | Classified 143L gap 8 Laps | Michael Munemann / James Winslow / Andrea Roda
 26 g5 #27 SMP Racing | BR01 - Nissan | NC 100L gap NC | Maurizio Mediani / David Markozov / Nicolas Minassian
 28 g11 #44 Ibanez Racing | Oreca 03 - Nissan | NC 58L gap NC | Pierre Perret / Yutaka Yamagishi
== LMGTE
 10 g14 #60 Formula Racing | Ferrari F458 Italia | Classified 144L gap 7 Laps | Johnny Laursen / Mikkel Mac / Andrea Rizzoli
 11 g29 #55 AF Corse | Ferrari F458 Italia | Classified 144L gap 7 Laps | Duncan Cameron / Matt Griffin / Aaron Scott
 12 g13 #51 AF Corse | Ferrari F458 Italia | Classified 144L gap 7 Laps | Peter Mann / Raffaele Giammaria / Matteo Cressoni
 13 g21 #52 BMW Team MarcVDS | BMW Z4 | Classified 144L gap 7 Laps | Andy Priaulx / Henry Hassid / Jesse Krohn
 14 g19 #88 Proton Competition | Porsche 911 RSR | Classified 143L gap 8 Laps | Richard Lietz / Sebastian Asch / Christian Ried
 16 g18 #66 JMW Motorsport | Ferrari F458 Italia | Classified 143L gap 8 Laps | George Richardson / Robert Smith / Samuel Tordoff
 17 g22 #86 Gulf Racing UK | Porsche 911 RSR | Classified 142L gap 9 Laps | Michael Wainwright / Adam Carroll / Daniel Brown
 23 g16 #56 AT Racing | Ferrari F458 Italia | Classified 126L gap 25 Laps | Alexander Talkanitsa / Alexander Talka Jr / Alessandro Pier Guidi
== GTC
 18 g23 #62 AF Corse | Ferrari F458 Italia GT3 | Classified 141L gap 10 Laps | Thomas Flohr / Francesco Castellacci / Stuart Hall
 20 g25 #59 TDS Racing | BMW Z4 GT3 | Classified 139L gap 12 Laps | Franck Perera / Dino Lunardi / Eric Dermont
 21 g28 #68 Massive Motorsport | Aston Martin Vantage GT3 | Classified 139L gap 12 Laps | Casper Elgaard / Kristian Poulsen / Simon Moller
 24 g24 #63 AF Corse | Ferrari F458 Italia GT3 | Classified 118L gap 33 Laps | Giorgio Roda / Ilya Melnikov / Marco Cioci
 29 g27 #64 AF Corse | Ferrari F458 Italia GT3 | NC 44L gap NC | Mads Rasmussen / Felipe Barreiros / Francisco Guedes
== LMP3
 19 g15 #3 Team LNT | Ginetta - Nissan | Classified 141L gap 10 Laps | Chris Hoy / Charlie Robertson
 22 g26 #5 Villorba Corse | Ginetta - Nissan | Classified 133L gap 18 Laps | Roberto Lacorte / Giorgio Sernagiotto
 25 g20 #2 Team LNT | Ginetta - Nissan | Classified 116L gap 35 Laps | Mark Shulzhitskiy / Gaëtan Paletou
 27 g17 #15 SVK By Speed Factory | Ginetta - Nissan | NC 78L gap NC | Konstantin Calko / Jesus Fuster / Dainius Matijosaitis
