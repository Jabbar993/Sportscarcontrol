# elms-imola-2015

Event: 4 Hours of Imola | Circuit: Imola | Date: 2015-05-17
Scheduled: 04:00:00 | Official duration: 4:01:08.999 | Laps (winner): 138

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q22 #63 [GTC] 1:43.704 AF Corse | Marco Cioci
Q24 #62 [GTC] 1:43.986 AF Corse | Francesco Castellacci
Q25 #59 [GTC] 1:44.928 TDS Racing | Franck Perera
Q26 #68 [GTC] 1:45.856 Massive Motorsport | Kristian Poulsen
Q28 #64 [GTC] 1:47.828 AF Corse | Felipe Barreiros
Q12 #56 [LMGTE] 1:41.747 AT Racing | Alessandro Pier Guidi
Q13 #51 [LMGTE] 1:42.178 AF Corse | Raffaele Giammaria
Q14 #60 [LMGTE] 1:42.307 Formula Racing | Mikkel Mac
Q16 #55 [LMGTE] 1:42.514 AF Corse | Matt Griffin
Q17 #66 [LMGTE] 1:42.548 JMW Motorsport | Samuel Tordoff
Q18 #86 [LMGTE] 1:42.572 Gulf Racing UK | Adam Carroll
Q27 #88 [LMGTE] 1:46.927 Proton Competition | Richard Lietz
Q1 #38 [LMP2] 1:34.496 Jota Sport | Filipe Albuquerque
Q2 #48 [LMP2] 1:36.067 Murphy Prototypes | Nathanaël Berthon
Q3 #41 [LMP2] 1:36.204 Greaves Motorsport | Jon Lancaster
Q4 #29 [LMP2] 1:36.258 Pegasus Racing | Léo Roussel
Q5 #33 [LMP2] 1:36.755 Eurasia Motorsport | Nico Pieter de Bruijn
Q6 #45 [LMP2] 1:36.815 Ibanez Racing | Ivan Bellarosa
Q7 #37 [LMP2] 1:37.290 SMP Racing | Mikhail Aleshin
Q8 #27 [LMP2] 1:37.619 SMP Racing | Nicolas Minassian
Q9 #46 [LMP2] 1:37.978 Thiriet by TDS Racing | Tristan Gommendy
Q10 #40 [LMP2] 1:39.068 Krohn Racing | Tracy Krohn
Q11 #44 [LMP2] 1:39.071 Ibanez Racing | Yutaka Yamagishi
Q15 #3 [LMP3] 1:42.498 Team LNT | Charlie Robertson
Q19 #11 [LMP3] 1:42.996 Lanan Racing | Mark Shulzhitskiy
Q20 #7 [LMP3] 1:43.241 University of Bolton | Rob Garofall
Q21 #15 [LMP3] 1:43.607 SVK By Speed Factory | Konstantin Calko
Q23 #2 [LMP3] 1:43.751 Team LNT | Gaëtan Paletou

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #38 Filipe Albuquerque 1:34.496 Jota Sport
GTC: #63 Marco Cioci 1:43.704 AF Corse
LMGTE: #56 Alessandro Pier Guidi 1:41.747 AT Racing
LMP2: #38 Filipe Albuquerque 1:34.496 Jota Sport
LMP3: #3 Charlie Robertson 1:42.498 Team LNT

## Fastest laps (archive)
Overall: #46 Tristan Gommendy 1:36.650
GTC: #63 Marco Cioci 1:44.914
LMGTE: #56 Alessandro Pier Guidi 1:43.227
LMP2: #46 Tristan Gommendy 1:36.650
LMP3: #3 Charlie Robertson 1:43.679

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g9 #46 Thiriet by TDS Racing | Oreca 05 - Nissan | Classified 138L gap — | Pierre Thiriet / Ludovic Badey / Tristan Gommendy
 2 g2 #48 Murphy Prototypes | Oreca 03R - Nissan | Classified 138L gap 12.140 | Nathanaël Berthon / Michael Lyons / Mark Patterson
 3 g1 #38 Jota Sport | Gibson 015S - Nissan | Classified 138L gap — | Simon Dolan / Filipe Albuquerque / Harry Tincknell
 4 g3 #41 Greaves Motorsport | Gibson 015S - Nissan | Classified 137L gap 1 Laps | Gary Hirsch / Bjorn Wirdheim / Jon Lancaster
 5 g10 #40 Krohn Racing | Ligier JS P2 - Judd | Classified 137L gap 1 Laps | Tracy Krohn / Niclas Jonsson / Oswaldo Negri Jr.
 6 g6 #45 Ibanez Racing | Oreca 03 - Nissan | Classified 136L gap 2 Laps | Ivan Bellarosa / José Ibanez
 7 g5 #33 Eurasia Motorsport | Oreca 03R - Nissan | Classified 136L gap 2 Laps | Pu Jun Jin / Nico Pieter de Bruijn
 8 g7 #37 SMP Racing | BR01 - Nissan | Classified 132L gap 6 Laps | Mikhail Aleshin / Kirill Ladygin / Anton Ladygin
 17 g4 #29 Pegasus Racing | Morgan - Nissan | Classified 129L gap 9 Laps | Léo Roussel / David Cheng / Julien Schell
 27 g8 #27 SMP Racing | BR01 - Nissan | NC 81L gap NC | Maurizio Mediani / David Markozov / Nicolas Minassian
 30 g11 #44 Ibanez Racing | Oreca 03 - Nissan | NC 0L gap NC | Pierre Perret / Yutaka Yamagishi
== LMGTE
 9 g12 #56 AT Racing | Ferrari F458 Italia | Classified 132L gap 6 Laps | Alexander Talkanitsa / Alexander Talka Jr / Alessandro Pier Guidi
 10 g27 #88 Proton Competition | Porsche 911 RSR | Classified 132L gap 6 Laps | Richard Lietz / Marco Mapelli / Christian Ried
 11 g14 #60 Formula Racing | Ferrari F458 Italia | Classified 132L gap 6 Laps | Johnny Laursen / Mikkel Mac / Andrea Rizzoli
 12 g30 #52 BMW Team MarcVDS | BMW Z4 | Classified 132L gap 6 Laps | Andy Priaulx / Henry Hassid / Jesse Krohn
 13 g16 #55 AF Corse | Ferrari F458 Italia | Classified 132L gap 6 Laps | Duncan Cameron / Matt Griffin / Aaron Scott
 14 g17 #66 JMW Motorsport | Ferrari F458 Italia | Classified 130L gap 8 Laps | George Richardson / Robert Smith / Samuel Tordoff
 15 g13 #51 AF Corse | Ferrari F458 Italia | Classified 130L gap 8 Laps | Peter Mann / Raffaele Giammaria / Matteo Cressoni
 22 g18 #86 Gulf Racing UK | Porsche 911 RSR | Classified 124L gap 14 Laps | Michael Wainwright / Adam Carroll / Philip Keen
== GTC
 16 g24 #62 AF Corse | Ferrari F458 Italia GT3 | Classified 129L gap 9 Laps | Rino Mastronardi / Francesco Castellacci / Stuart Hall
 18 g22 #63 AF Corse | Ferrari F458 Italia GT3 | Classified 128L gap 10 Laps | Giorgio Roda / Ilya Melnikov / Marco Cioci
 19 g28 #64 AF Corse | Ferrari F458 Italia GT3 | Classified 127L gap 11 Laps | Mads Rasmussen / Felipe Barreiros / Francisco Guedes
 24 g25 #59 TDS Racing | BMW Z4 GT3 | Classified 106L gap 32 Laps | Franck Perera / Dino Lunardi / Eric Dermont
 26 g26 #68 Massive Motorsport | Aston Martin Vantage GT3 | NC 84L gap NC | Casper Elgaard / Kristian Poulsen / Simon Moller
== LMP3
 20 g20 #7 University of Bolton | Ginetta - Nissan | Classified 126L gap 12 Laps | Rob Garofall / Morten Dons
 21 g21 #15 SVK By Speed Factory | Ginetta - Nissan | Classified 124L gap 14 Laps | Konstantin Calko / Jesus Fuster / Dainius Matijosaitis
 23 g19 #11 Lanan Racing | Ginetta - Nissan | Classified 121L gap 17 Laps | Alex Craven / Mark Shulzhitskiy
 25 g15 #3 Team LNT | Ginetta - Nissan | NC 108L gap NC | Chris Hoy / Charlie Robertson
 28 g29 #5 Villorba Corse | Ginetta - Nissan | NC 54L gap NC | Roberto Lacorte / Giorgio Sernagiotto
 29 g23 #2 Team LNT | Ginetta - Nissan | NC 26L gap NC | Michael Simpson / Gaëtan Paletou
