# elms-castellet-2015

Event: 4 Hours of Le Castellet | Circuit: Paul Ricard | Date: 2015-09-06
Scheduled: 04:00:00 | Official duration: 4:01:29.450 | Laps (winner): 123

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q23 #59 [GTC] 1:58.396 TDS Racing | Franck Perera
Q24 #62 [GTC] 1:58.478 AF Corse | Francesco Castellacci
Q25 #63 [GTC] 1:58.752 AF Corse | Marco Cioci
Q26 #64 [GTC] 2:04.143 AF Corse | Mads Rasmussen
Q27 #68 [GTC] 2:06.522 Massive Motorsport | Simon Moller
Q13 #56 [LMGTE] 1:55.782 AT Racing | Alessandro Pier Guidi
Q14 #51 [LMGTE] 1:55.818 AF Corse | Andrea Bertolini
Q15 #60 [LMGTE] 1:56.024 Formula Racing | Mikkel Mac
Q16 #86 [LMGTE] 1:56.207 Gulf Racing UK | Adam Carroll
Q17 #66 [LMGTE] 1:56.225 JMW Motorsport | Rory Butcher
Q18 #55 [LMGTE] 1:56.545 AF Corse | Matt Griffin
Q21 #88 [LMGTE] 1:57.238 Proton Competition | Richard Lietz
Q22 #52 [LMGTE] 1:57.401 BMW Team MarcVDS | Andy Priaulx
Q1 #38 [LMP2] 1:46.917 Jota Sport | Harry Tincknell
Q2 #20 [LMP2] 1:47.065 AF Racing | Nicolas Minassian
Q3 #21 [LMP2] 1:47.498 AF Racing | Mikhail Aleshin
Q4 #46 [LMP2] 1:47.641 Thiriet by TDS Racing | Tristan Gommendy
Q5 #29 [LMP2] 1:48.074 Pegasus Racing | Léo Roussel
Q6 #48 [LMP2] 1:48.093 Murphy Prototypes | Nathanaël Berthon
Q7 #33 [LMP2] 1:48.822 Eurasia Motorsport | Richard Bradley
Q8 #41 [LMP2] 1:49.101 Greaves Motorsport | Jon Lancaster
Q9 #25 [LMP2] 1:51.612 Algarve Pro Racing | Michael Munemann
Q10 #40 [LMP2] 1:52.301 Krohn Racing | Tracy Krohn
Q11 #3 [LMP3] 1:55.431 Team LNT | Charlie Robertson
Q12 #2 [LMP3] 1:55.636 Team LNT | Michael Simpson
Q19 #15 [LMP3] 1:56.731 SVK By Speed Factory | Konstantin Calko
Q20 #5 [LMP3] 1:57.058 Villorba Corse | Giorgio Sernagiotto

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #38 Harry Tincknell 1:46.917 Jota Sport
GTC: #59 Franck Perera 1:58.396 TDS Racing
LMGTE: #56 Alessandro Pier Guidi 1:55.782 AT Racing
LMP2: #38 Harry Tincknell 1:46.917 Jota Sport
LMP3: #3 Charlie Robertson 1:55.431 Team LNT

## Fastest laps (archive)
Overall: #21 Mikhail Aleshin 1:49.769
GTC: #59 Dino Lunardi 2:00.214
LMGTE: #56 Alessandro Pier Guidi 1:58.120
LMP2: #21 Mikhail Aleshin 1:49.769
LMP3: #3 Charlie Robertson 1:57.032

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g8 #41 Greaves Motorsport | Gibson 015S - Nissan | Classified 123L gap — | Gary Hirsch / Bjorn Wirdheim / Jon Lancaster
 2 g3 #21 AF Racing | BR01 - Nissan | Classified 123L gap 5.169 | Mikhail Aleshin / Kirill Ladygin / Victor Shaytar
 3 g1 #38 Jota Sport | Gibson 015S - Nissan | Classified 123L gap 14.710 | Simon Dolan / Filipe Albuquerque / Harry Tincknell
 4 g2 #20 AF Racing | BR01 - Nissan | Classified 123L gap 46.170 | Maurizio Mediani / David Markozov / Nicolas Minassian
 5 g10 #40 Krohn Racing | Ligier JS P2 - Judd | Classified 122L gap 1 Laps | Tracy Krohn / Niclas Jönsson / Olivier Pla
 6 g4 #46 Thiriet by TDS Racing | Oreca 05 - Nissan | Classified 122L gap 1 Laps | Pierre Thiriet / Ludovic Badey / Tristan Gommendy
 7 g5 #29 Pegasus Racing | Morgan - Nissan | Classified 121L gap 2 Laps | Léo Roussel / David Cheng
 8 g9 #25 Algarve Pro Racing | Ligier JS P2 - Nissan | Classified 121L gap 2 Laps | Michael Munemann / James Winslow / Andrea Roda
 23 g7 #33 Eurasia Motorsport | Oreca 03R - Nissan | NC 114L gap NC | Nico Pieter de Bruijn / Richard Bradley
 25 g6 #48 Murphy Prototypes | Oreca 03R - Nissan | NC 61L gap NC | Nathanaël Berthon / Michael Lyons / Mark Patterson
== LMGTE
 9 g15 #60 Formula Racing | Ferrari F458 Italia | Classified 117L gap 6 Laps | Johnny Laursen / Mikkel Mac / Andrea Rizzoli
 10 g22 #52 BMW Team MarcVDS | BMW Z4 | Classified 116L gap 7 Laps | Andy Priaulx / Henry Hassid / Jesse Krohn
 11 g17 #66 JMW Motorsport | Ferrari F458 Italia | Classified 115L gap 8 Laps | Robert Smith / Rory Butcher / Jonny Cocker
 12 g21 #88 Proton Competition | Porsche 911 RSR | Classified 115L gap 8 Laps | Richard Lietz / Marco Mapelli / Christian Ried
 13 g13 #56 AT Racing | Ferrari F458 Italia | Classified 115L gap 8 Laps | Alexander Talkanitsa / Alexander Talka Jr / Alessandro Pier Guidi
 14 g18 #55 AF Corse | Ferrari F458 Italia | Classified 115L gap 8 Laps | Duncan Cameron / Matt Griffin / Aaron Scott
 15 g16 #86 Gulf Racing UK | Porsche 911 RSR | Classified 115L gap 8 Laps | Michael Wainwright / Adam Carroll / Philip Keen
 24 g14 #51 AF Corse | Ferrari F458 Italia | NC 100L gap NC | Peter Mann / Andrea Bertolini / Matteo Cressoni
== GTC
 16 g23 #59 TDS Racing | BMW Z4 GT3 | Classified 113L gap 10 Laps | Franck Perera / Dino Lunardi / Eric Dermont
 18 g24 #62 AF Corse | Ferrari F458 Italia GT3 | Classified 113L gap 10 Laps | Thomas Flohr / Francesco Castellacci / Stuart Hall
 20 g? #68 Massive Motorsport | Aston Martin Vantage GT3 | Classified 112L gap 11 Laps | Casper Elgaard / Kristian Poulsen / Simon Moller
 21 g26 #64 AF Corse | Ferrari F458 Italia GT3 | Classified 112L gap 11 Laps | Mads Rasmussen / Adrien de Leener / Francisco Guedes
 26 g25 #63 AF Corse | Ferrari F458 Italia GT3 | NC 61L gap NC | Giorgio Roda / Ilya Melnikov / Marco Cioci
== LMP3
 17 g11 #3 Team LNT | Ginetta - Nissan | Classified 113L gap 10 Laps | Chris Hoy / Charlie Robertson
 19 g20 #5 Villorba Corse | Ginetta - Nissan | Classified 113L gap 10 Laps | Roberto Lacorte / Giorgio Sernagiotto
 22 g19 #15 SVK By Speed Factory | Ginetta - Nissan | Classified 112L gap 11 Laps | Konstantin Calko / Mirco van Oostrum / Dainius Matijosaitis
 27 g12 #2 Team LNT | Ginetta - Nissan | NC 32L gap NC | Michael Simpson / Gaëtan Paletou
