# elms-silverstone-2015

Event: 4 Hours of Silverstone | Circuit: Silverstone | Date: 2015-04-11
Scheduled: 04:00:00 | Official duration: 4:01:15.279 | Laps (winner): 118

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q1 #41 [LMP2] 1:48.752 Greaves Motorsport | Jon Lancaster
Q2 #38 [LMP2] 1:49.212 Jota Sport | Harry Tincknell
Q3 #46 [LMP2] 1:49.353 Thiriet By Tds Racing | Tristan Gommendy
Q4 #34 [LMP2] 1:49.486 AF Corse | Mikhail Aleshin
Q5 #48 [LMP2] 1:49.681 Murphy Prototypes | Nathanaël Berthon
Q6 #33 [LMP2] 1:50.216 Eurasia Motorsport | Nico Pieter de Bruijn
Q7 #29 [LMP2] 1:50.757 Pegasus Racing | Leo Roussel
Q8 #45 [LMP2] 1:51.418 Ibanez Racing | Ivan Bellarosa
Q9 #32 [LMP2] 1:52.020 AF Corse | Nicolas Minassian
Q10 #44 [LMP2] 1:53.096 Ibanez Racing | Michele La Rosa
Q11 #40 [LMP2] 1:55.589 Krohn Racing | Tracy Krohn
Q12 #3 [LMP3] 1:59.892 Team LNT | Charlie Robertson
Q13 #81 [LMGTE] 2:00.151 AF Corse | Michele Rugolo
Q14 #88 [LMGTE] 2:00.269 Proton Competition | Klaus Bachler
Q15 #2 [LMP3] 2:00.457 Team LNT | Michael Simpson
Q16 #56 [LMGTE] 2:00.478 AT Racing | Alessandro Pier Guidi
Q17 #52 [LMGTE] 2:00.480 BMW Team MarcVDS | Andy Priaulx
Q18 #86 [LMGTE] 2:00.641 Gulf Racing UK | Adam Carroll
Q19 #66 [LMGTE] 2:00.997 JMW Motorsport | Samuel Tordoff
Q20 #55 [LMGTE] 2:01.110 AF Corse | Matt Griffin
Q21 #51 [LMGTE] 2:01.336 AF Corse | Raffaele Giammaria
Q22 #60 [LMGTE] 2:01.437 Formula Racing | Mikkel Mac
Q23 #59 [GTC] 2:01.939 TDS Racing | Franck Perera
Q24 #11 [LMP3] 2:02.045 Lanan Racing | Joey Foster
Q25 #7 [LMP3] 2:02.686 University Of Bolton | Rob Garofall
Q26 #63 [GTC] 2:03.002 AF Corse | Marco Cioci
Q27 #62 [GTC] 2:03.298 AF Corse | Francesco Castellacci
Q28 #64 [GTC] 2:03.564 AF Corse | Francisco Guedes
Q29 #68 [GTC] 2:04.046 Massive Motorsport | Casper Elgaard
Q30 #85 [GTC] 2:04.596 Gulf Racing UK | Daniel Brown
Q31 #15 [LMP3] 2:06.697 SVK By Speed Factory | Konstantin Calko

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #41 Jon Lancaster 1:48.752 Greaves Motorsport
LMP2: #41 Jon Lancaster 1:48.752 Greaves Motorsport
LMGTE: #81 Michele Rugolo 2:00.151 AF Corse
GTC: #59 Franck Perera 2:01.939 TDS Racing
LMP3: #3 Charlie Robertson 1:59.892 Team LNT

## Fastest laps (archive)
Overall: #38 Harry Tincknell 1:50.405
LMP2: #38 Harry Tincknell 1:50.405
LMGTE: #55 Matt Griffin 2:01.772
GTC: #59 Franck Perera 2:03.594
LMP3: #3 Charlie Robertson 2:01.214

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g1 #41 Greaves Motorsport | Gibson 015S - Nissan | Classified 118L | Gary Hirsch / Bjorn Wirdheim / Jon Lancaster
 2 g2 #38 Jota Sport | Gibson 015S - Nissan | Classified 118L gap 0.370 | Simon Dolan / Filipe Albuquerque / Harry Tincknell
 3 g3 #46 Thiriet By Tds Racing | Oreca 05 - Nissan | Classified 118L gap 20.063 | Pierre Thiriet / Ludovic Badey / Tristan Gommendy
 4 g11 #40 Krohn Racing | Ligier JS P2 - JUDD | Classified 117L gap 1 Laps | Tracy Krohn / Niclas Jönsson / Oswaldo Negri Jr.
 5 g6 #33 Eurasia Motorsport | Oreca 03R - Nissan | Classified 116L gap 2 Laps | Pu Jun Jin / Nico Pieter de Bruijn
 6 g9 #32 AF Corse | Oreca 03 - Nissan | Classified 114L gap 4 Laps | Maurizio Mediani / David Markozov / Nicolas Minassian
 7 g8 #45 Ibanez Racing | Oreca 03R - Nissan | Classified 114L gap 4 Laps | Pierre Perret / Ivan Bellarosa / José Ibanez
 19 g4 #34 AF Corse | Oreca 03 - Nissan | Classified 105L gap 13 Laps | Mikhail Aleshin / Kirill Ladygin / Anton Ladygin
 23 g10 #44 Ibanez Racing | Oreca 03 - Nissan | RET 99L gap RET | Michele La Rosa / Yutaka Yamagishi
 24 g5 #48 Murphy Prototypes | Oreca 03R - Nissan | RET 83L gap RET | Nathanaël Berthon / Michael Lyons / Mark Patterson
 27 g7 #29 Pegasus Racing | Morgan - Nissan | RET 64L gap RET | Leo Roussel / David Cheng / Jonathan Coleman
== LMGTE
 8 g18 #86 Gulf Racing UK | Porsche 911 RSR | Classified 110L gap 8 Laps | Michael Wainwright / Adam Carroll / Philip Keen
 9 g19 #66 JMW Motorsport | Ferrari F458 Italia | Classified 109L gap 9 Laps | George Richardson / Robert Smith / Samuel Tordoff
 10 g20 #55 AF Corse | Ferrari F458 Italia | Classified 109L gap 9 Laps | Duncan Cameron / Matt Griffin / Aaron Scott
 11 g17 #52 BMW Team MarcVDS | BMW Z4 | Classified 109L gap 9 Laps | Andy Priaulx / Henry Hassid / Jesse Krohn
 12 g14 #88 Proton Competition | Porsche 911 RSR | Classified 109L gap 9 Laps | Klaus Bachler / Khaled Al Qubaisi / Christian Ried
 13 g22 #60 Formula Racing | Ferrari F458 Italia | Classified 109L gap 9 Laps | Johnny Laursen / Mikkel Mac / Andrea Rizzoli
 15 g16 #56 AT Racing | Ferrari F458 Italia | Classified 107L gap 11 Laps | Alexander Talkanitsa / Alexander Talka Jr / Alessandro Pier Guidi
 29 g21 #51 AF Corse | Ferrari F458 Italia | RET 35L gap RET | Peter Mann / Raffaele Giammaria / Matteo Cressoni
 30 g13 #81 AF Corse | Ferrari F458 Italia | RET 32L gap RET | Stephen Wyatt / Michele Rugolo / Rui Aguas
== GTC
 14 g23 #59 TDS Racing | BMW Z4 GT3 | Classified 108L gap 10 Laps | Franck Perera / Dino Lunardi / Eric Dermont
 18 g28 #64 AF Corse | Ferrari F458 Italia GT3 | Classified 106L gap 12 Laps | Mads Rasmussen / Felipe Barreiros / Francisco Guedes
 22 g30 #85 Gulf Racing UK | Lamborghini Gallardo LP560 GT3 | Classified 92L gap 26 Laps | Roald Goethe / Daniel Brown / Archie Hamilton
 25 g26 #63 AF Corse | Ferrari F458 Italia GT3 | RET 67L gap RET | Giorgio Roda / Ilya Melnikov / Marco Cioci
 26 g29 #68 Massive Motorsport | Aston Martin Vantage GT3 | RET 65L gap RET | Casper Elgaard / Kristian Poulsen / Simon Moller
 31 g27 #62 AF Corse | Ferrari F458 Italia GT3 | RET 0L gap RET | Thomas Flohr / Francesco Castellacci / Stuart Hall
== LMP3
 16 g12 #3 Team LNT | Ginetta - Nissan | Classified 107L gap 11 Laps | Chris Hoy / Charlie Robertson
 17 g15 #2 Team LNT | Ginetta - Nissan | Classified 106L gap 12 Laps | Michael Simpson / Gaetan Paletou
 20 g25 #7 University Of Bolton | Ginetta - Nissan | Classified 105L gap 13 Laps | Rob Garofall / Jens Petersen
 21 g31 #15 SVK By Speed Factory | Ginetta - Nissan | Classified 102L gap 16 Laps | Konstantin Calko / Jesus Fuster / Dainius Matijosaitis
 28 g24 #11 Lanan Racing | Ginetta - Nissan | RET 52L gap RET | Alex Craven / Joey Foster / Charlie Hollings
