# elms-estoril-2015

Event: 4 Hours of Estoril | Circuit: Estoril | Date: 2015-10-18
Scheduled: 04:00:00 | Official duration: 4:00:01.077 | Laps (winner): 137

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q12 #59 [GTC] 1:52.723 TDS Racing | Franck Perera
Q14 #63 [GTC] 1:52.950 AF Corse | Marco Cioci
Q15 #62 [GTC] 1:53.014 AF Corse | Francesco Castellacci
Q18 #77 [GTC] 1:53.180 TF Sport | Richie Stanaway
Q22 #64 [GTC] 1:53.930 AF Corse | Francisco Guedes
Q27 #68 [GTC] 1:59.856 Massive Motorsport | Simon Moller
Q13 #88 [LMGTE] 1:52.945 Proton Competition | Richard Lietz
Q16 #60 [LMGTE] 1:53.034 Formula Racing | Mikkel Mac
Q17 #66 [LMGTE] 1:53.108 JMW Motorsport | James Calado
Q19 #56 [LMGTE] 1:53.498 AT Racing | Alessandro Pier Guidi
Q20 #51 [LMGTE] 1:53.732 AF Corse | Raffaele Giammaria
Q21 #55 [LMGTE] 1:53.734 AF Corse | Matt Griffin
Q23 #86 [LMGTE] 1:54.721 Gulf Racing UK | Adam Carroll
Q24 #99 [LMGTE] 1:55.065 Aston Martin Racing | Alex Macdowall
Q28 #52 [LMGTE] 2:06.423 BMW Team MarcVDS | Andy Priaulx
Q1 #38 [LMP2] 1:43.510 Jota Sport | Filipe Albuquerque
Q2 #40 [LMP2] 1:44.319 Krohn Racing | Olivier Pla
Q3 #46 [LMP2] 1:45.018 Thiriet by TDS Racing | Nicolas Lapierre
Q4 #21 [LMP2] 1:45.207 AF Racing | Mikhail Aleshin
Q5 #29 [LMP2] 1:45.281 Pegasus Racing | Léo Roussel
Q6 #33 [LMP2] 1:45.997 Eurasia Motorsport | Nico Pieter de Bruijn
Q7 #25 [LMP2] 1:46.273 Algarve Pro Racing | Andrea Roda
Q8 #48 [LMP2] 1:46.833 Murphy Prototypes | Nathanaël Berthon
Q9 #20 [LMP2] 1:47.796 AF Racing | Nicolas Minassian
Q10 #3 [LMP3] 1:50.469 Team LNT | Charlie Robertson
Q11 #9 [LMP3] 1:51.746 Graff | Garry Findlay
Q25 #5 [LMP3] 1:56.188 Villorba Corse | Giorgio Sernagiotto
Q26 #15 [LMP3] 1:57.052 SVK By Speed Factory | Konstantin Calko

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #38 Filipe Albuquerque 1:43.510 Jota Sport
GTC: #59 Franck Perera 1:52.723 TDS Racing
LMGTE: #88 Richard Lietz 1:52.945 Proton Competition
LMP2: #38 Filipe Albuquerque 1:43.510 Jota Sport
LMP3: #3 Charlie Robertson 1:50.469 Team LNT

## Fastest laps (archive)
Overall: #38 Harry Tincknell 1:33.077
GTC: #59 Dino Lunardi 1:41.864
LMGTE: #51 Matteo Cressoni 1:40.605
LMP2: #38 Harry Tincknell 1:33.077
LMP3: #3 Charlie Robertson 1:39.120

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g3 #46 Thiriet by TDS Racing | Oreca 05 - Nissan | Classified 137L gap — | Pierre Thiriet / Ludovic Badey / Nicolas Lapierre
 2 g10 #41 Greaves Motorsport | Gibson 015S - Nissan | Classified 137L gap — | Gary Hirsch / Bjorn Wirdheim / Jon Lancaster
 3 g4 #21 AF Racing | BR01 - Nissan | Classified 137L gap 20.413 | Mikhail Aleshin / Kirill Ladygin / Victor Shaytar
 4 g1 #38 Jota Sport | Gibson 015S - Nissan | Classified 136L gap 1 Laps | Simon Dolan / Filipe Albuquerque / Harry Tincknell
 5 g9 #20 AF Racing | BR01 - Nissan | Classified 136L gap 1 Laps | Maurizio Mediani / David Markozov / Nicolas Minassian
 6 g6 #33 Eurasia Motorsport | Oreca 03R - Nissan | Classified 135L gap 2 Laps | Pu Jun Jin / Nico Pieter de Bruijn
 7 g7 #25 Algarve Pro Racing | Ligier JS P2 - Nissan | Classified 131L gap 6 Laps | Michael Munemann / James Winslow / Andrea Roda
 8 g2 #40 Krohn Racing | Ligier JS P2 - Judd | Classified 131L gap 6 Laps | Tracy Krohn / Niclas Jönsson / Olivier Pla
 26 g8 #48 Murphy Prototypes | Oreca 03R - Nissan | NC 111L gap NC | Nathanaël Berthon / Michael Lyons / Mark Patterson
 30 g5 #29 Pegasus Racing | Morgan - Nissan | NC 0L gap NC | Léo Roussel / David Cheng / Jonathan Coleman
== LMGTE
 9 g29 #52 BMW Team MarcVDS | BMW Z4 | Classified 129L gap 8 Laps | Andy Priaulx / Henry Hassid / Jesse Krohn
 10 g25 #99 Aston Martin Racing | Aston Martin Vantage V8 | Classified 128L gap 9 Laps | Andrew Howard / Jonathan Adam / Alex Macdowall
 11 g24 #86 Gulf Racing UK | Porsche 911 RSR | Classified 128L gap 9 Laps | Michael Wainwright / Adam Carroll / Philip Keen
 12 g22 #55 AF Corse | Ferrari F458 Italia | Classified 128L gap 9 Laps | Duncan Cameron / Matt Griffin / Aaron Scott
 13 g17 #60 Formula Racing | Ferrari F458 Italia | Classified 127L gap 10 Laps | Johnny Laursen / Mikkel Mac / Andrea Rizzoli
 15 g20 #56 AT Racing | Ferrari F458 Italia | Classified 127L gap 10 Laps | Alexander Talkanitsa / Alexander Talka Jr / Alessandro Pier Guidi
 24 g21 #51 AF Corse | Ferrari F458 Italia | Classified 122L gap 15 Laps | Peter Mann / Raffaele Giammaria / Matteo Cressoni
 25 g14 #88 Proton Competition | Porsche 911 RSR | Classified 100L gap 37 Laps | Richard Lietz / Sebastian Asch / Christian Ried
 28 g18 #66 JMW Motorsport | Ferrari F458 Italia | NC 69L gap NC | Robert Smith / Rory Butcher / James Calado
== LMP3
 14 g30 #2 Team LNT | Ginetta - Nissan | Classified 127L gap 10 Laps | Michael Simpson / Gaëtan Paletou
 16 g12 #9 Graff | Ligier JS P3 - Nissan | Classified 126L gap 11 Laps | Eric Trouillet / Garry Findlay / Thomas Accary
 17 g11 #3 Team LNT | Ginetta - Nissan | Classified 125L gap 12 Laps | Chris Hoy / Charlie Robertson
 23 g27 #15 SVK By Speed Factory | Ginetta - Nissan | Classified 123L gap 14 Laps | Konstantin Calko / Jesus Fuster / Dainius Matijosaitis
 29 g26 #5 Villorba Corse | Ginetta - Nissan | NC 46L gap NC | Roberto Lacorte / Giorgio Sernagiotto
== GTC
 18 g15 #63 AF Corse | Ferrari F458 Italia GT3 | Classified 125L gap 12 Laps | Giorgio Roda / Ilya Melnikov / Marco Cioci
 19 g13 #59 TDS Racing | BMW Z4 GT3 | Classified 125L gap 12 Laps | Franck Perera / Dino Lunardi / Eric Dermont
 20 g23 #64 AF Corse | Ferrari F458 Italia GT3 | Classified 125L gap 12 Laps | Mads Rasmussen / Felipe Barreiros / Francisco Guedes
 21 g16 #62 AF Corse | Ferrari F458 Italia GT3 | Classified 124L gap 13 Laps | Thomas Flohr / Francesco Castellacci / Stuart Hall
 22 g19 #77 TF Sport | Aston Martin Vantage GT3 | Classified 123L gap 14 Laps | Salih Yoluc / Euan Hankey / Richie Stanaway
 27 g28 #68 Massive Motorsport | Aston Martin Vantage GT3 | NC 82L gap NC | Casper Elgaard / Kristian Poulsen / Simon Moller
