# elms-redbullring-2017

Event: 4 Hours of Red Bull Ring | Circuit: Red Bull Ring | Date: 2017-07-23
Scheduled: 04:00:00 | Official duration: 4:00:57.876 | Laps (winner): 169

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q29 #51 [LMGTE] 1:28.297 Spirit of Race | Andrea Bertolini
Q30 #55 [LMGTE] 1:28.476 Spirit of Race | Matt Griffin
Q31 #77 [LMGTE] 1:28.606 Proton Competition | Matteo Cairoli
Q32 #66 [LMGTE] 1:28.713 JMW Motorsport | Jonathan Cocker
Q33 #90 [LMGTE] 1:28.862 TF Sport | Nicki Thiim
Q34 #99 [LMGTE] 1:28.906 Beechdean AMR | Darren Turner
Q1 #22 [LMP2] 1:18.435 G-Drive Racing | Léo Roussel
Q2 #21 [LMP2] 1:18.440 DragonSpeed | Nicolas Lapierre
Q3 #32 [LMP2] 1:18.834 United Autosports | Filipe Albuquerque
Q4 #23 [LMP2] 1:19.605 Panis Barthez Competition | Nathanaël Berthon
Q5 #27 [LMP2] 1:19.746 SMP Racing | Egor Orudzhev
Q6 #40 [LMP2] 1:19.965 Graff | Gustavo Yacaman
Q7 #28 [LMP2] 1:19.967 Idec Sport Racing | Olivier Pla
Q8 #25 [LMP2] 1:20.100 Algarve Pro Racing | Andrea Pizzitola
Q9 #34 [LMP2] 1:20.182 Tockwith Motorsports | Nigel Moore
Q10 #47 [LMP2] 1:20.594 Cetilar Villorba Corse | Andrea Belicchi
Q11 #49 [LMP2] 1:20.882 High Class Racing | Anders Fjordbach
Q12 #29 [LMP2] 1:21.225 Racing Team Nederland | Jan Lammers
Q13 #39 [LMP2] 1:24.461 Graff | Enzo Guibbert
Q14 #7 [LMP3] 1:25.657 Duqueine Engineering | David Droux
Q15 #9 [LMP3] 1:25.854 AT Racing | Mikkel Jensen
Q16 #19 [LMP3] 1:26.052 M.Racing - YMR | Yann Ehrlacher
Q17 #3 [LMP3] 1:26.079 United Autosports | Wayne Boyd
Q18 #16 [LMP3] 1:26.281 Panis Barthez Competition | Simon Gachet
Q19 #2 [LMP3] 1:26.400 United Autosports | Sean Rayhall
Q20 #10 [LMP3] 1:26.415 Oregon Team | Dario Capitanio
Q21 #11 [LMP3] 1:26.467 Eurointernational | Giorgio Mondini
Q22 #17 [LMP3] 1:26.575 Ultimate | Matthieu Lahaye
Q23 #18 [LMP3] 1:26.708 M.Racing - YMR | Alexandre Cougnaud
Q24 #8 [LMP3] 1:26.802 Duqueine Engineering | Vincent Beltoise
Q25 #12 [LMP3] 1:26.820 Eurointernational | Ricky Capo
Q26 #13 [LMP3] 1:26.862 Inter Europol Competition | Martin Hippe
Q27 #15 [LMP3] 1:27.709 RLR MSport | Morten Dons
Q28 #4 [LMP3] 1:27.810 Cool Racing by GPC | Iradj Alexander
Q35 #5 [LMP3] 1:31.010 By Speed Factory | Jürgen Krebs

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #22 Léo Roussel 1:18.435 G-Drive Racing
LMGTE: #51 Andrea Bertolini 1:28.297 Spirit of Race
LMP2: #22 Léo Roussel 1:18.435 G-Drive Racing
LMP3: #7 David Droux 1:25.657 Duqueine Engineering

## Fastest laps (archive)
Overall: #22 Léo Roussel 1:20.177
LMGTE: #55 Matt Griffin 1:29.147
LMP2: #22 Léo Roussel 1:20.177
LMP3: #9 Mikkel Jensen 1:26.406

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g3 #32 United Autosports | Ligier JSP217 - Gibson | Classified 169L gap — | Will Owen / Hugo de Sadeleer / Filipe Albuquerque
 2 g1 #22 G-Drive Racing | Oreca 07 - Gibson | Classified 169L gap 4.554 | Memo Rojas / Nicolas Minassian / Léo Roussel
 3 g13 #39 Graff | Oreca 07 - Gibson | Classified 168L gap 1 Laps | Eric Trouillet / Paul Petit / Enzo Guibbert
 4 g6 #40 Graff | Oreca 07 - Gibson | Classified 168L gap 1 Laps | James Allen / Richard Bradley / Gustavo Yacaman
 5 g4 #23 Panis Barthez Competition | Ligier JSP217 - Gibson | Classified 167L gap 2 Laps | Fabien Barthez / Timothé Buret / Nathanaël Berthon
 6 g5 #27 SMP Racing | Dallara P217 - Gibson | Classified 167L gap 2 Laps | Matevos Isaakyan / Egor Orudzhev
 7 g12 #29 Racing Team Nederland | Dallara P217 - Gibson | Classified 165L gap 4 Laps | Jan Lammers / Frits van Eerd
 8 g11 #49 High Class Racing | Dallara P217 - Gibson | Classified 159L gap 10 Laps | Dennis Andersen / Anders Fjordbach
 26 g9 #34 Tockwith Motorsports | Ligier JSP217 - Gibson | Classified 146L gap 23 Laps | Nigel Moore / Philip Hanson
 28 g8 #25 Algarve Pro Racing | Ligier JSP217 - Gibson | NC 122L gap NC | Andrea Roda / Matthew Mcmurry / Andrea Pizzitola
 29 g2 #21 DragonSpeed | Oreca 07 - Gibson | NC 120L gap NC | Henrik Hedman / Nicolas Lapierre / Ben Hanley
 30 g10 #47 Cetilar Villorba Corse | Dallara P217 - Gibson | NC 120L gap NC | Roberto Lacorte / Giorgio Sernagiotto / Andrea Belicchi
 34 g7 #28 Idec Sport Racing | Ligier JSP217 - Gibson | NC 0L gap NC | Patrice Lafargue / Paul Lafargue Jr / Olivier Pla
== LMP3
 9 g21 #11 Eurointernational | Ligier JS P3 - Nissan | Classified 157L gap 12 Laps | Giorgio Mondini / Davide Uboldi
 10 g19 #2 United Autosports | Ligier JS P3 - Nissan | Classified 157L gap 12 Laps | John Falb / Sean Rayhall
 11 g23 #18 M.Racing - YMR | Ligier JS P3 - Nissan | Classified 157L gap 12 Laps | Alexandre Cougnaud / Antoine Jung / Romano Ricci
 12 g22 #17 Ultimate | Ligier JS P3 - Nissan | Classified 157L gap 12 Laps | Matthieu Lahaye / Jean-Baptiste Lahaye / François Heriau
 13 g26 #13 Inter Europol Competition | Ligier JS P3 - Nissan | Classified 156L gap 13 Laps | Jakub Smiechowski / Martin Hippe
 14 g15 #9 AT Racing | Ligier JS P3 - Nissan | Classified 155L gap 14 Laps | Alexander Talkanitsa / Alexander Talka Jr / Mikkel Jensen
 16 g20 #10 Oregon Team | Norma M 30 - Nissan | Classified 155L gap 14 Laps | Davide Roda / Andres Mendez / Dario Capitanio
 21 g27 #15 RLR MSport | Ligier JS P3 - Nissan | Classified 155L gap 14 Laps | John Farano / Morten Dons / Alex Kapadia
 23 g14 #7 Duqueine Engineering | Norma M 30 - Nissan | Classified 154L gap 15 Laps | Antonin Borga / David Droux / Nicolas Schatz
 24 g35 #5 By Speed Factory | Ligier JS P3 - Nissan | Classified 153L gap 16 Laps | Tim Müller / Jürgen Krebs
 25 g24 #8 Duqueine Engineering | Ligier JS P3 - Nissan | Classified 152L gap 17 Laps | Vincent Beltoise / Lucas Légeret / Douglas Lundberg
 27 g28 #4 Cool Racing by GPC | Ligier Onroak Ligier JSP3 | NC 150L gap NC | Alexandre Coigny / Iradj Alexander
 31 g25 #12 Eurointernational | Ligier JS P3 - Nissan | NC 44L gap NC | Andrea Dromedari / Ricky Capo / James Dayson
 32 g16 #19 M.Racing - YMR | Norma M 30 LMP3 | NC 41L gap NC | Yann Ehrlacher / Erwin Creed
 33 g36 #6 360 Racing | Ligier JS P3 - Nissan | NC 0L gap NC | Terrence Woodward / Ross Kaiser / Anthony Wells
 35 g18 #16 Panis Barthez Competition | LIGIER Ligier JSP3 | NC 0L gap NC | Eric Debard / Simon Gachet / Theo Bean
 36 g17 #3 United Autosports | Ligier JS P3 - Nissan | NC 0L gap NC | Mark Patterson / Wayne Boyd / Christian England
== LMGTE
 15 g30 #55 Spirit of Race | Ferrari 488 GTE | Classified 155L gap 14 Laps | Duncan Cameron / Matt Griffin / Aaron Scott
 17 g32 #66 JMW Motorsport | Ferrari 488 GTE | Classified 155L gap 14 Laps | Robert Smith / Jody Fannin / Jonathan Cocker
 18 g33 #90 TF Sport | Aston Martin Vantage V8 | Classified 155L gap 14 Laps | Salih Yoluc / Euan Hankey / Nicki Thiim
 19 g29 #51 Spirit of Race | Ferrari 488 GTE | Classified 155L gap 14 Laps | Gianluca Roda / Giorgio Roda / Andrea Bertolini
 20 g31 #77 Proton Competition | Porsche 911 RSR 991 | Classified 155L gap 14 Laps | Christian Ried / Joël Camathias / Matteo Cairoli
 22 g34 #99 Beechdean AMR | Aston Martin Vantage V8 | Classified 154L gap 15 Laps | Andrew Howard / Ross Gunn / Darren Turner
