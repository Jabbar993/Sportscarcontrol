# elms-portimao-2017

Event: 4 Hours of Portimão | Circuit: Portimão | Date: 2017-10-22
Scheduled: 04:00:00 | Official duration: 4:01:17.867 | Laps (winner): 139

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q23 #55 [LMGTE] 1:42.657 Spirit of Race | Matt Griffin
Q27 #66 [LMGTE] 1:43.297 JMW Motorsport | William Stevens
Q28 #77 [LMGTE] 1:43.370 Proton Competition | Matteo Cairoli
Q29 #51 [LMGTE] 1:43.601 Spirit of Race | Andrea Bertolini
Q30 #90 [LMGTE] 1:44.157 TF Sport | Nicki Thiim
Q31 #99 [LMGTE] 1:44.282 Beechdean AMR | Darren Turner
Q1 #23 [LMP2] 1:33.575 Panis Barthez Competition | Nathanaël Berthon
Q2 #21 [LMP2] 1:34.090 DragonSpeed | Nicolas Lapierre
Q3 #22 [LMP2] 1:34.235 G-Drive Racing | Ryo Hirakawa
Q4 #39 [LMP2] 1:34.240 Graff | Enzo Guibbert
Q5 #32 [LMP2] 1:34.551 United Autosports | Filipe Albuquerque
Q6 #28 [LMP2] 1:34.746 Idec Sport Racing | Paul Loup Chatin
Q7 #47 [LMP2] 1:35.110 Cetilar Villorba Corse | Andrea Belicchi
Q8 #27 [LMP2] 1:35.236 SMP Racing | Matevos Isaakyan
Q9 #40 [LMP2] 1:35.391 Graff | Richard Bradley
Q10 #49 [LMP2] 1:35.741 High Class Racing | Anders Fjordbach
Q11 #29 [LMP2] 1:36.127 Racing Team Nederland | Jan Lammers
Q12 #25 [LMP2] 1:36.286 Algarve Pro Racing | Andrea Pizzitola
Q13 #9 [LMP3] 1:40.660 AT Racing | Mikkel Jensen
Q14 #3 [LMP3] 1:40.824 United Autosports | Wayne Boyd
Q15 #16 [LMP3] 1:41.148 Panis Barthez Competition | Simon Gachet
Q16 #18 [LMP3] 1:41.343 M.Racing - YMR | Alexandre Cougnaud
Q17 #11 [LMP3] 1:41.358 Eurointernational | Giorgio Mondini
Q18 #6 [LMP3] 1:41.599 360 Racing | Ross Kaiser
Q19 #19 [LMP3] 1:41.691 M.Racing - YMR | Yann Ehrlacher
Q20 #15 [LMP3] 1:41.708 RLR MSport | Alex Kapadia
Q21 #8 [LMP3] 1:42.124 Duqueine Engineering | Lucas Légeret
Q22 #12 [LMP3] 1:42.143 Eurointernational | Ricky Capo
Q24 #5 [LMP3] 1:42.839 By Speed Factory | Timur Boguslavskiy
Q25 #13 [LMP3] 1:42.875 Inter Europol Competition | Jakub Smiechowski
Q26 #4 [LMP3] 1:43.187 Cool Racing by GPC | Iradj Alexander

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #23 Nathanaël Berthon 1:33.575 Panis Barthez Competition
LMGTE: #55 Matt Griffin 1:42.657 Spirit of Race
LMP2: #23 Nathanaël Berthon 1:33.575 Panis Barthez Competition
LMP3: #9 Mikkel Jensen 1:40.660 AT Racing

## Fastest laps (archive)
Overall: #21 Ben Hanley 1:35.048
LMGTE: #77 Matteo Cairoli 1:44.416
LMP2: #21 Ben Hanley 1:35.048
LMP3: #9 Mikkel Jensen 1:41.846

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g9 #40 Graff | Oreca 07 - Gibson | Classified 139L gap — | James Allen / Richard Bradley / Gustavo Yacaman
 2 g5 #32 United Autosports | Ligier JSP217 - Gibson | Classified 139L gap 38.169 | Will Owen / Hugo de Sadeleer / Filipe Albuquerque
 3 g8 #27 SMP Racing | Dallara P217 - Gibson | Classified 139L gap 59.254 | Matevos Isaakyan / Egor Orudzhev
 4 g3 #22 G-Drive Racing | Oreca 07 - Gibson | Classified 139L gap 1.944 | Memo Rojas / Ryo Hirakawa / Léo Roussel
 5 g7 #47 Cetilar Villorba Corse | Dallara P217 - Gibson | Classified 138L gap 1 Laps | Roberto Lacorte / Giorgio Sernagiotto / Andrea Belicchi
 6 g1 #23 Panis Barthez Competition | Ligier JSP217 - Gibson | Classified 138L gap 1 Laps | Fabien Barthez / Timothé Buret / Nathanaël Berthon
 7 g10 #49 High Class Racing | Dallara P217 - Gibson | Classified 137L gap 2 Laps | Dennis Andersen / Anders Fjordbach
 8 g11 #29 Racing Team Nederland | Dallara P217 - Gibson | Classified 137L gap 2 Laps | Jan Lammers / Frits van Eerd
 9 g2 #21 DragonSpeed | Oreca 07 - Gibson | Classified 137L gap 2 Laps | Henrik Hedman / Nicolas Lapierre / Ben Hanley
 10 g6 #28 Idec Sport Racing | Ligier JSP217 - Gibson | Classified 137L gap 2 Laps | Patrice Lafargue / Paul Lafargue Jr / Paul Loup Chatin
 27 g12 #25 Algarve Pro Racing | Ligier JSP217 - Gibson | Classified 103L gap 36 Laps | Matthew Mcmurry / Andrea Pizzitola
 28 g4 #39 Graff | Oreca 07 - Gibson | NC 102L gap NC | Ricardo Sanchez / Paul Petit / Enzo Guibbert
== LMP3
 11 g14 #3 United Autosports | Ligier JS P3 - Nissan | Classified 132L gap 7 Laps | Mark Patterson / Wayne Boyd / Christian England
 12 g35 #2 United Autosports | Ligier JS P3 - Nissan | Classified 132L gap 7 Laps | John Falb / Sean Rayhall
 13 g16 #18 M.Racing - YMR | Ligier JS P3 - Nissan | Classified 131L gap 8 Laps | Alexandre Cougnaud / Antoine Jung / Romano Ricci
 14 g32 #7 Duqueine Engineering | Norma M 30 - Nissan | Classified 131L gap 8 Laps | Antonin Borga / David Droux / Nicolas Schatz
 15 g18 #6 360 Racing | Ligier JS P3 - Nissan | Classified 131L gap 8 Laps | Terrence Woodward / Ross Kaiser / Anthony Wells
 16 g20 #15 RLR MSport | Ligier JS P3 - Nissan | Classified 130L gap 9 Laps | John Farano / Morten Dons / Alex Kapadia
 17 g13 #9 AT Racing | Ligier JS P3 - Nissan | Classified 130L gap 9 Laps | Alexander Talkanitsa / Alexander Talka Jr / Mikkel Jensen
 18 g34 #17 Ultimate | Ligier JS P3 - Nissan | Classified 130L gap 9 Laps | Matthieu Lahaye / Jean-Baptiste Lahaye / François Heriau
 19 g17 #11 Eurointernational | Ligier JS P3 - Nissan | Classified 129L gap 10 Laps | Giorgio Mondini / Andrea Dromedari
 22 g21 #8 Duqueine Engineering | Norma M 30 - Nissan | Classified 129L gap 10 Laps | Vincent Beltoise / Lucas Légeret / Nicolas Melin
 24 g26 #4 Cool Racing by GPC | Ligier JS P3 - Nissan | Classified 127L gap 12 Laps | Alexandre Coigny / Iradj Alexander
 26 g24 #5 By Speed Factory | Ligier JS P3 - Nissan | Classified 109L gap 30 Laps | Giorgio Maggi / Jürgen Krebs / Timur Boguslavskiy
 30 g33 #10 Oregon Team | Norma M 30 - Nissan | NC 67L gap NC | Antonio Fornè / Andres Mendez / Dario Capitanio
 31 g19 #19 M.Racing - YMR | Norma M 30 - Nissan | NC 51L gap NC | Yann Ehrlacher / Erwin Creed
 32 g25 #13 Inter Europol Competition | Ligier JS P3 - Nissan | NC 0L gap NC | Jakub Smiechowski / Martin Hippe
 34 g15 #16 Panis Barthez Competition | Ligier JS P3 - Nissan | NC 0L gap NC | Eric Debard / Simon Gachet / Theo Bean
 35 g22 #12 Eurointernational | Ligier JS P3 - Nissan | NC 0L gap NC | Ricky Capo / Maxwell Hanratty / James Dayson
== LMGTE
 20 g28 #77 Proton Competition | Porsche 911 RSR 991 | Classified 129L gap 10 Laps | Christian Ried / Joël Camathias / Matteo Cairoli
 21 g27 #66 JMW Motorsport | Ferrari 488 GTE | Classified 129L gap 10 Laps | Robert Smith / Jody Fannin / William Stevens
 23 g30 #90 TF Sport | Aston Martin Vantage V8 | Classified 128L gap 11 Laps | Salih Yoluc / Euan Hankey / Nicki Thiim
 25 g31 #99 Beechdean AMR | Aston Martin Vantage V8 | Classified 126L gap 13 Laps | Andrew Howard / Immanuel Vinke / Darren Turner
 29 g23 #55 Spirit of Race | Ferrari 488 GTE | NC 73L gap NC | Duncan Cameron / Matt Griffin / Aaron Scott
 33 g29 #51 Spirit of Race | Ferrari 488 GTE | NC 0L gap NC | Gianluca Roda / Giorgio Roda / Andrea Bertolini
