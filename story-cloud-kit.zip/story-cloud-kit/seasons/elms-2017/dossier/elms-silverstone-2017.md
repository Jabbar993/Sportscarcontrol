# elms-silverstone-2017

Event: 4 Hours of Silverstone | Circuit: Silverstone | Date: 2017-04-15
Scheduled: 04:00:00 | Official duration: 4:01:24.751 | Laps (winner): 126

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q1 #21 [LMP2] 1:44.040 DragonSpeed | Ben Hanley
Q2 #32 [LMP2] 1:44.314 United Autosports | Filipe Albuquerque
Q3 #39 [LMP2] 1:45.163 Graff | Enzo Guibbert
Q4 #22 [LMP2] 1:45.216 G-Drive Racing | Ryo Hirakawa
Q5 #25 [LMP2] 1:45.235 Algarve Pro Racing | Andrea Pizzitola
Q6 #34 [LMP2] 1:45.796 Tockwith Motorsports | Nigel Moore
Q7 #49 [LMP2] 1:46.408 High Class Racing | Anders Fjordbach
Q8 #23 [LMP2] 1:46.792 Panis Barthez Competition | Nathanaël Berthon
Q9 #28 [LMP2] 1:47.948 Idec Sport Racing | Paul Lafargue
Q10 #29 [LMP2] 1:49.706 Racing Team Nederland | Jan Lammers
Q11 #9 [LMP3] 1:53.665 AT Racing | Mikkel Jensen
Q12 #2 [LMP3] 1:53.786 United Autosports | Sean Rayhall
Q13 #3 [LMP3] 1:54.181 United Autosports | Wayne Boyd
Q14 #16 [LMP3] 1:54.574 Panis Barthez Competition | Simon Gachet
Q15 #18 [LMP3] 1:54.919 M.Racing - YMR | Alexandre Cougnaud
Q16 #19 [LMP3] 1:55.179 M.Racing - YMR | Yann Ehrlacher
Q17 #15 [LMP3] 1:55.269 RLR MSport | Alex Kapadia
Q18 #11 [LMP3] 1:55.307 Eurointernational | Giorgio Mondini
Q19 #6 [LMP3] 1:55.725 360 Racing | Ross Kaiser
Q20 #17 [LMP3] 1:55.784 Ultimate | Matthieu Lahaye
Q21 #7 [LMP3] 1:55.921 Duqueine Engineering | Antonin Borga
Q22 #10 [LMP3] 1:56.102 Oregon Team | Dario Capitanio
Q23 #5 [LMP3] 1:56.214 By Speed Factory | Tristan Viidas
Q24 #12 [LMP3] 1:56.233 Eurointernational | Maxwell Harnatty
Q25 #13 [LMP3] 1:56.383 Inter Europol Competition | Jakub Smiechowski
Q26 #8 [LMP3] 1:56.837 Duqueine Engineering | Vincent Beltoise
Q27 #4 [LMP3] 1:57.343 Cool Racing by GPC | Iradj Alexander
Q28 #40 [LMP2] 1:57.889 Graff | Richard Bradley
Q29 #90 [LMGTE] 1:58.269 TF Sport | Nicki Thiim
Q30 #99 [LMGTE] 1:58.466 Beechdean AMR | Ross Gunn
Q31 #55 [LMGTE] 1:59.791 Spirit of Race | Matt Griffin
Q32 #47 [LMP2] 1:59.927 Cetilar Villorba Corse | Andrea Belicchi
Q33 #77 [LMGTE] 2:00.379 Proton Competition | Matteo Cairoli
Q34 #51 [LMGTE] 2:00.554 Spirit of Race | Andrea Bertolini
Q35 #66 [LMGTE] 2:00.940 JMW Motorsport | Rory Butcher

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #21 Ben Hanley 1:44.040 DragonSpeed
LMP2: #21 Ben Hanley 1:44.040 DragonSpeed
LMP3: #9 Mikkel Jensen 1:53.665 AT Racing
LMGTE: #90 Nicki Thiim 1:58.269 TF Sport

## Fastest laps (archive)
LMGTE: #77 Matteo Cairoli 2:00.946
LMGTE: #55 Aaron Scott 2:01.442
Overall: #21 Ben Hanley 1:47.474
LMP2: #21 Ben Hanley 1:47.474
LMP3: #2 Sean Rayhall 1:56.474

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g2 #32 United Autosports | LIGIER JSP217 - Gibson | Classified 126L gap — | Will Owen / Hugo de Sadeleer / Filipe Albuquerque
 2 g4 #22 G-Drive Racing | Oreca 07 - Gibson | Classified 126L gap 6.339 | Memo Rojas / Ryo Hirakawa / Leo Roussel
 3 g7 #49 High Class Racing | Dallara P217 - Gibson | Classified 126L gap 28.158 | Dennis Andersen / Anders Fjordbach
 4 g28 #40 Graff | Oreca 07 - Gibson | Classified 126L gap 53.426 | James Allen / Franck Matelli / Richard Bradley
 5 g6 #34 Tockwith Motorsports | LIGIER JSP217 - Gibson | Classified 126L gap 6.871 | Nigel Moore / Philip Hanson
 6 g32 #47 Cetilar Villorba Corse | Dallara P217 - Gibson | Classified 126L gap 44.143 | Roberto Lacorte / Giorgio Sernagiotto / Andrea Belicchi
 7 g3 #39 Graff | Oreca 07 - Gibson | Classified 125L gap 1 Laps | Eric Trouillet / Paul Petit / Enzo Guibbert
 8 g9 #28 Idec Sport Racing | LIGIER JSP217 - Gibson | Classified 123L gap 3 Laps | Paul Lafargue / Patrice Lafargue / David Zollinger
 9 g8 #23 Panis Barthez Competition | LIGIER JSP217 - Gibson | Classified 123L gap 3 Laps | Fabien Barthez / Timothe Buret / Nathanaël Berthon
 10 g1 #21 DragonSpeed | Oreca 07 - Gibson | Classified 120L gap 6 Laps | Henrik Hedman / Nicolas Lapierre / Ben Hanley
 18 g10 #29 Racing Team Nederland | Dallara P217 - Gibson | Classified 117L gap 9 Laps | Jan Lammers / Frits van Eerd
 33 g5 #25 Algarve Pro Racing | LIGIER JSP217 - Gibson | NC 70L gap NC | Andrea Roda / Matthew McMurry / Andrea Pizzitola
== LMP3
 11 g12 #2 United Autosports | LIGIER JS P3 - Nissan | Classified 119L gap 7 Laps | John Falb / Sean Rayhall
 12 g20 #17 Ultimate | LIGIER JS P3 - Nissan | Classified 118L gap 8 Laps | Matthieu Lahaye / Jean-Baptiste Lahaye / François Heriau
 13 g13 #3 United Autosports | LIGIER JS P3 - Nissan | Classified 118L gap 8 Laps | Mark Patterson / Wayne Boyd / Christian England
 14 g11 #9 AT Racing | LIGIER JS P3 - Nissan | Classified 118L gap 8 Laps | Alexander Talkanitsa / Alexander Talka Jr / Mikkel Jensen
 15 g15 #18 M.Racing - YMR | LIGIER JS P3 - Nissan | Classified 118L gap 8 Laps | Alexandre Cougnaud / Antoine Jung / Romano Ricci
 16 g25 #13 Inter Europol Competition | LIGIER JS P3 - Nissan | Classified 118L gap 8 Laps | Jakub Smiechowski / Martin Hippe
 17 g19 #6 360 Racing | LIGIER JS P3 - Nissan | Classified 118L gap 8 Laps | Terrence Woodward / Ross Kaiser / Anthony Wells
 19 g17 #15 RLR MSport | LIGIER JS P3 - Nissan | Classified 117L gap 9 Laps | John Farano / Morten Dons / Alex Kapadia
 20 g14 #16 Panis Barthez Competition | LIGIER Ligier JSP3 | Classified 117L gap 9 Laps | Eric Debard / Simon Gachet / Theo Bean
 21 g16 #19 M.Racing - YMR | Norma M 30 LMP3 | Classified 116L gap 10 Laps | Yann Ehrlacher / Ricky Capo / Erwin Creed
 22 g21 #7 Duqueine Engineering | LIGIER JS P3 - Nissan | Classified 116L gap 10 Laps | Antonin Borga / David Droux / Nicolas Schatz
 23 g24 #12 Eurointernational | LIGIER JS P3 - Nissan | Classified 116L gap 10 Laps | Andrea Dromedari / Maxwell Harnatty / Maxime Pialat
 30 g22 #10 Oregon Team | Norma M 30 - Nissan | Classified 113L gap 13 Laps | Davide Roda / Andres Mendez / Dario Capitanio
 31 g27 #4 Cool Racing by GPC | LIGIER JS P3 - Nissan | Classified 112L gap 14 Laps | Iradj Alexander / Gino Forgione
 32 g23 #5 By Speed Factory | LIGIER JS P3 - Nissan | Classified 104L gap 22 Laps | Tim Müller / Jürgen Krebs / Tristan Viidas
 34 g26 #8 Duqueine Engineering | LIGIER JS P3 - Nissan | NC 41L gap NC | Vincent Beltoise / Henry Hassid
 35 g18 #11 Eurointernational | LIGIER JS P3 - Nissan | NC 0L gap NC | Giorgio Mondini / Davide Uboldi
== LMGTE
 24 g29 #90 TF Sport | Aston Martin Vantage V8 | Classified 116L gap 10 Laps | Salih Yoluc / Euan Hankey / Nicki Thiim
 25 g33 #77 Proton Competition | Porsche 911 RSR 991 | Classified 115L gap 11 Laps | Christian Ried / Joël Camathias / Matteo Cairoli
 26 g30 #99 Beechdean AMR | Aston Martin Vantage V8 | Classified 115L gap 11 Laps | Andrew Howard / Ross Gunn / Darren Turner
 27 g31 #55 Spirit of Race | Ferrari 488 GTE | Classified 115L gap 11 Laps | Duncan Cameron / Matt Griffin / Aaron Scott
 28 g35 #66 JMW Motorsport | Ferrari 458 Italia | Classified 114L gap 12 Laps | Rob Smith / Rory Butcher / Jody Fannin
 29 g34 #51 Spirit of Race | Ferrari 488 GTE | Classified 113L gap 13 Laps | Giorgio Roda / Gianluca Roda / Andrea Bertolini
