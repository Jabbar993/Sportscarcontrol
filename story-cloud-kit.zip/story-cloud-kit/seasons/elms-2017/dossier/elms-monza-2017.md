# elms-monza-2017

Event: 4 Hours of Monza | Circuit: Monza | Date: 2017-05-14
Scheduled: 04:00:00 | Official duration: 4:01:43.628 | Laps (winner): 132

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q29 #55 [LMGTE] 1:48.027 Spirit of Race | Matt Griffin
Q31 #50 [LMGTE] 1:48.293 Larbre Competition | Fernando Rees
Q32 #77 [LMGTE] 1:48.514 Proton Competition | Matteo Cairoli
Q33 #90 [LMGTE] 1:48.836 TF Sport | Nicki Thiim
Q34 #51 [LMGTE] 1:49.080 Spirit of Race | Andrea Bertolini
Q35 #66 [LMGTE] 1:49.644 JMW Motorsport | Jonathan Cocker
Q36 #99 [LMGTE] 1:49.833 Beechdean AMR | Ross Gunn
Q1 #39 [LMP2] 1:36.526 Graff | Enzo Guibbert
Q2 #21 [LMP2] 1:36.641 DragonSpeed | Nicolas Lapierre
Q3 #22 [LMP2] 1:36.751 G-Drive Racing | Ryo Hirakawa
Q4 #32 [LMP2] 1:36.872 United Autosports | Filipe Albuquerque
Q5 #25 [LMP2] 1:37.250 Algarve Pro Racing | Andrea Pizzitola
Q6 #47 [LMP2] 1:37.323 Cetilar Villorba Corse | Andrea Belicchi
Q7 #40 [LMP2] 1:37.336 Graff | Richard Bradley
Q8 #34 [LMP2] 1:37.883 Tockwith Motorsports | Nigel Moore
Q9 #49 [LMP2] 1:37.887 High Class Racing | Dennis Andersen
Q10 #28 [LMP2] 1:38.100 Idec Sport Racing | Olivier Pla
Q11 #23 [LMP2] 1:38.247 Panis Barthez Competition | Timothé Buret
Q12 #29 [LMP2] 1:38.694 Racing Team Nederland | Jan Lammers
Q13 #3 [LMP3] 1:45.725 United Autosports | Wayne Boyd
Q14 #19 [LMP3] 1:45.773 M.Racing - YMR | Ricky Capo
Q15 #17 [LMP3] 1:46.022 Ultimate | Matthieu Lahaye
Q16 #2 [LMP3] 1:46.056 United Autosports | Sean Rayhall
Q17 #18 [LMP3] 1:46.180 M.Racing - YMR | Alexandre Cougnaud
Q18 #7 [LMP3] 1:46.193 Duqueine Engineering | David Droux
Q19 #11 [LMP3] 1:46.343 Eurointernational | Giorgio Mondini
Q20 #10 [LMP3] 1:46.387 Oregon Team | Dario Capitanio
Q21 #16 [LMP3] 1:46.443 Panis Barthez Competition | Simon Gachet
Q22 #9 [LMP3] 1:46.511 AT Racing | Maurizio Mediani
Q23 #15 [LMP3] 1:46.584 RLR MSport | Alex Kapadia
Q24 #6 [LMP3] 1:46.603 360 Racing | Ross Kaiser
Q25 #8 [LMP3] 1:46.703 Duqueine Engineering | Lucas Légeret
Q26 #13 [LMP3] 1:46.746 Inter Europol Competition | Martin Hippe
Q27 #5 [LMP3] 1:47.005 By Speed Factory | Tristan Viidas
Q28 #4 [LMP3] 1:47.955 Cool Racing by GPC | Iradj Alexander
Q30 #12 [LMP3] 1:48.105 Eurointernational | Maxime Pialat

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #39 Enzo Guibbert 1:36.526 Graff
LMGTE: #55 Matt Griffin 1:48.027 Spirit of Race
LMP2: #39 Enzo Guibbert 1:36.526 Graff
LMP3: #3 Wayne Boyd 1:45.725 United Autosports

## Fastest laps (archive)
Overall: #40 Richard Bradley 1:38.673
LMGTE: #50 Fernando Rees 1:49.384
LMP2: #40 Richard Bradley 1:38.673
LMP3: #3 Wayne Boyd 1:47.514

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g3 #22 G-Drive Racing | Oreca 07 - Gibson | Classified 132L gap — | Memo Rojas / Ryo Hirakawa / Léo Roussel
 2 g2 #21 DragonSpeed | Oreca 07 - Gibson | Classified 132L gap 2.245 | Henrik Hedman / Nicolas Lapierre / Ben Hanley
 3 g9 #49 High Class Racing | Dallara P217 - Gibson | Classified 132L gap 7.215 | Dennis Andersen / Anders Fjordbach
 4 g1 #39 Graff | Oreca 07 - Gibson | Classified 132L gap 33.980 | Eric Trouillet / Paul Petit / Enzo Guibbert
 5 g6 #47 Cetilar Villorba Corse | Dallara P217 - Gibson | Classified 132L gap 54.798 | Roberto Lacorte / Giorgio Sernagiotto / Andrea Belicchi
 6 g4 #32 United Autosports | Ligier JSP217 - Gibson | Classified 132L gap 11.587 | Will Owen / Hugo de Sadeleer / Filipe Albuquerque
 7 g11 #23 Panis Barthez Competition | Ligier JSP217 - Gibson | Classified 132L gap 32.255 | Fabien Barthez / Timothé Buret
 8 g7 #40 Graff | Oreca 07 - Gibson | Classified 131L gap 1 Laps | James Allen / Franck Matelli / Richard Bradley
 9 g10 #28 Idec Sport Racing | Ligier JSP217 - Gibson | Classified 129L gap 3 Laps | Paul Lafargue / Patrice Lafargue / Olivier Pla
 10 g12 #29 Racing Team Nederland | Dallara P217 - Gibson | Classified 127L gap 5 Laps | Jan Lammers / Frits van Eerd
 30 g8 #34 Tockwith Motorsports | Ligier JSP217 - Gibson | Classified 115L gap 17 Laps | Nigel Moore / Philip Hanson
 34 g5 #25 Algarve Pro Racing | Ligier JSP217 - Gibson | NC 131L gap NC | Andrea Roda / Matthew Mcmurry / Andrea Pizzitola
== LMP3
 11 g14 #19 M.Racing - YMR | Norma M 30 - Nissan | Classified 124L gap 8 Laps | Ricky Capo / Erwin Creed
 12 g17 #18 M.Racing - YMR | Ligier JS P3 - Nissan | Classified 123L gap 9 Laps | Alexandre Cougnaud / Antoine Jung / Romano Ricci
 13 g15 #17 Ultimate | Ligier JS P3 - Nissan | Classified 123L gap 9 Laps | Matthieu Lahaye / Jean-Baptiste Lahaye / François Heriau
 14 g13 #3 United Autosports | Ligier JS P3 - Nissan | Classified 123L gap 9 Laps | Mark Patterson / Wayne Boyd / Christian England
 15 g19 #11 Eurointernational | Ligier JS P3 - Nissan | Classified 123L gap 9 Laps | Giorgio Mondini / Davide Uboldi
 16 g26 #13 Inter Europol Competition | Ligier JS P3 - Nissan | Classified 123L gap 9 Laps | Jakub Smiechowski / Martin Hippe
 17 g24 #6 360 Racing | Ligier JS P3 - Nissan | Classified 122L gap 10 Laps | Terrence Woodward / Ross Kaiser / Anthony Wells
 18 g18 #7 Duqueine Engineering | Ligier JS P3 - Nissan | Classified 122L gap 10 Laps | Antonin Borga / David Droux / Nicolas Schatz
 19 g16 #2 United Autosports | Ligier JS P3 - Nissan | Classified 122L gap 10 Laps | John Falb / Sean Rayhall
 20 g23 #15 RLR MSport | Ligier JS P3 - Nissan | Classified 122L gap 10 Laps | John Farano / Morten Dons / Alex Kapadia
 24 g21 #16 Panis Barthez Competition | LIGIER Ligier JSP3 | Classified 121L gap 11 Laps | Eric Debard / Simon Gachet / Theo Bean
 27 g30 #12 Eurointernational | Ligier JS P3 - Nissan | Classified 120L gap 12 Laps | Andrea Dromedari / Maxime Pialat / Maxwell Hanratty
 29 g25 #8 Duqueine Engineering | Ligier JS P3 - Nissan | Classified 119L gap 13 Laps | Vincent Beltoise / Henry Hassid / Lucas Légeret
 31 g28 #4 Cool Racing by GPC | Ligier JS P3 - Nissan | Classified 111L gap 21 Laps | Alexandre Coigny / Iradj Alexander / Gino Forgione
 32 g20 #10 Oregon Team | Norma M 30 - Nissan | Classified 105L gap 27 Laps | Davide Roda / Andres Mendez / Dario Capitanio
 33 g27 #5 By Speed Factory | Ligier JS P3 - Nissan | Classified 102L gap 30 Laps | Tim Müller / Jürgen Krebs / Tristan Viidas
 36 g22 #9 AT Racing | Ligier JS P3 - Nissan | NC 17L gap NC | Alexander Talkanitsa / Alexander Talka Jr / Maurizio Mediani
== LMGTE
 21 g35 #66 JMW Motorsport | Ferrari 458 Italia | Classified 121L gap 11 Laps | Robert Smith / Jody Fannin / Jonathan Cocker
 22 g33 #90 TF Sport | Aston Martin Vantage V8 | Classified 121L gap 11 Laps | Salih Yoluc / Euan Hankey / Nicki Thiim
 23 g36 #99 Beechdean AMR | Aston Martin Vantage V8 | Classified 121L gap 11 Laps | Andrew Howard / Ross Gunn / Darren Turner
 25 g34 #51 Spirit of Race | Ferrari 488 GTE | Classified 121L gap 11 Laps | Gianluca Roda / Giorgio Roda / Andrea Bertolini
 26 g32 #77 Proton Competition | Porsche 911 RSR 991 | Classified 120L gap 12 Laps | Christian Ried / Joël Camathias / Matteo Cairoli
 28 g31 #50 Larbre Competition | Chevrolet Corvette C7-Z06 | Classified 120L gap 12 Laps | Christian Philippon / Romain Brandela / Fernando Rees
 35 g29 #55 Spirit of Race | Ferrari 488 GTE | NC 55L gap NC | Duncan Cameron / Matt Griffin / Aaron Scott
