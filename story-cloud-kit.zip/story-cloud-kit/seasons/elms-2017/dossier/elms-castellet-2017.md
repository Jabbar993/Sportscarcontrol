# elms-castellet-2017

Event: 4 Hours of Le Castellet | Circuit: Paul Ricard | Date: 2017-08-27
Scheduled: 04:00:00 | Official duration: 4:00:16.217 | Laps (winner): 115

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q28 #55 [LMGTE] 2:04.202 Spirit of Race | Matt Griffin
Q29 #77 [LMGTE] 2:04.572 Proton Competition | Matteo Cairoli
Q30 #51 [LMGTE] 2:04.588 Spirit of Race | Andrea Bertolini
Q32 #66 [LMGTE] 2:04.779 JMW Motorsport | Jonathan Cocker
Q33 #90 [LMGTE] 2:05.043 TF Sport | Nicki Thiim
Q34 #99 [LMGTE] 2:05.109 Beechdean AMR | Darren Turner
Q1 #21 [LMP2] 1:52.761 DragonSpeed | Nicolas Lapierre
Q2 #22 [LMP2] 1:52.906 G-Drive Racing | Léo Roussel
Q3 #39 [LMP2] 1:53.051 Graff | Enzo Guibbert
Q4 #27 [LMP2] 1:53.194 SMP Racing | Matevos Isaakyan
Q5 #32 [LMP2] 1:53.530 United Autosports | Filipe Albuquerque
Q6 #47 [LMP2] 1:53.874 Cetilar Villorba Corse | Giorgio Sernagiotto
Q7 #23 [LMP2] 1:54.033 Panis Barthez Competition | Nathanaël Berthon
Q8 #25 [LMP2] 1:54.321 Algarve Pro Racing | Matthew Mcmurry
Q9 #28 [LMP2] 1:54.358 Idec Sport Racing | Olivier Pla
Q10 #40 [LMP2] 1:54.779 Graff | Gustavo Yacaman
Q11 #49 [LMP2] 1:54.831 High Class Racing | Anders Fjordbach
Q12 #29 [LMP2] 1:55.590 Racing Team Nederland | Jan Lammers
Q13 #6 [LMP3] 2:02.186 360 Racing | Ross Kaiser
Q14 #15 [LMP3] 2:02.471 RLR MSport | Alex Kapadia
Q15 #18 [LMP3] 2:02.608 M.Racing - YMR | Alexandre Cougnaud
Q16 #19 [LMP3] 2:02.817 M.Racing - YMR | Yann Ehrlacher
Q17 #2 [LMP3] 2:02.934 United Autosports | Sean Rayhall
Q18 #12 [LMP3] 2:02.951 Eurointernational | Ricky Capo
Q19 #16 [LMP3] 2:03.009 Panis Barthez Competition | Simon Gachet
Q20 #10 [LMP3] 2:03.013 Oregon Team | Dario Capitanio
Q21 #11 [LMP3] 2:03.065 Eurointernational | Giorgio Mondini
Q22 #17 [LMP3] 2:03.133 Ultimate | Matthieu Lahaye
Q23 #9 [LMP3] 2:03.218 AT Racing | Mikkel Jensen
Q24 #7 [LMP3] 2:03.237 Duqueine Engineering | Antonin Borga
Q25 #3 [LMP3] 2:03.258 United Autosports | Wayne Boyd
Q26 #8 [LMP3] 2:03.347 Duqueine Engineering | Vincent Beltoise
Q27 #13 [LMP3] 2:03.689 Inter Europol Competition | Jakub Smiechowski
Q31 #4 [LMP3] 2:04.747 Cool Racing by GPC | Iradj Alexander
Q35 #5 [LMP3] 2:07.052 By Speed Factory | Jürgen Krebs

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #21 Nicolas Lapierre 1:52.761 DragonSpeed
LMGTE: #55 Matt Griffin 2:04.202 Spirit of Race
LMP2: #21 Nicolas Lapierre 1:52.761 DragonSpeed
LMP3: #6 Ross Kaiser 2:02.186 360 Racing

## Fastest laps (archive)
Overall: #22 Léo Roussel 1:55.252
LMGTE: #51 Andrea Bertolini 2:07.426
LMP2: #22 Léo Roussel 1:55.252
LMP3: #7 Antonin Borga 2:04.268

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g4 #27 SMP Racing | Dallara P217 - Gibson | Classified 115L gap — | Matevos Isaakyan / Egor Orudzhev
 2 g2 #22 G-Drive Racing | Oreca 07 - Gibson | Classified 115L gap — | Memo Rojas / Nicolas Minassian / Léo Roussel
 3 g3 #39 Graff | Oreca 07 - Gibson | Classified 114L gap 1 Laps | Eric Trouillet / Paul Petit / Enzo Guibbert
 4 g7 #23 Panis Barthez Competition | Ligier JSP217 - Gibson | Classified 114L gap 1 Laps | Fabien Barthez / Timothé Buret / Nathanaël Berthon
 5 g5 #32 United Autosports | Ligier JSP217 - Gibson | Classified 114L gap 1 Laps | Will Owen / Hugo de Sadeleer / Filipe Albuquerque
 6 g10 #40 Graff | Oreca 07 - Gibson | Classified 114L gap 1 Laps | James Allen / Richard Bradley / Gustavo Yacaman
 7 g1 #21 DragonSpeed | Oreca 07 - Gibson | Classified 114L gap 1 Laps | Henrik Hedman / Nicolas Lapierre / Ben Hanley
 8 g8 #25 Algarve Pro Racing | Ligier JSP217 - Gibson | Classified 113L gap 2 Laps | Andrea Roda / Matthew Mcmurry / Andrea Pizzitola
 9 g11 #49 High Class Racing | Dallara P217 - Gibson | Classified 112L gap 3 Laps | Dennis Andersen / Anders Fjordbach
 10 g6 #47 Cetilar Villorba Corse | Dallara P217 - Gibson | Classified 111L gap 4 Laps | Roberto Lacorte / Giorgio Sernagiotto / Andrea Belicchi
 11 g9 #28 Idec Sport Racing | Ligier JSP217 - Gibson | Classified 111L gap 4 Laps | Patrice Lafargue / Paul Lafargue Jr / Olivier Pla
 12 g12 #29 Racing Team Nederland | Dallara P217 - Gibson | Classified 108L gap 7 Laps | Jan Lammers / Frits van Eerd
== LMP3
 13 g17 #2 United Autosports | Ligier JS P3 - Nissan | Classified 107L gap 8 Laps | John Falb / Sean Rayhall
 14 g27 #13 Inter Europol Competition | Ligier JS P3 - Nissan | Classified 107L gap 8 Laps | Jakub Smiechowski / Martin Hippe
 15 g15 #18 M.Racing - YMR | Ligier JS P3 - Nissan | Classified 107L gap 8 Laps | Alexandre Cougnaud / Antoine Jung / Romano Ricci
 16 g21 #11 Eurointernational | Ligier JS P3 - Nissan | Classified 107L gap 8 Laps | Giorgio Mondini / Marco Jacoboni
 17 g19 #16 Panis Barthez Competition | LIGIER Ligier JSP3 | Classified 107L gap 8 Laps | Eric Debard / Simon Gachet / Theo Bean
 18 g22 #17 Ultimate | Ligier JS P3 - Nissan | Classified 107L gap 8 Laps | Matthieu Lahaye / Jean-Baptiste Lahaye / François Heriau
 20 g14 #15 RLR MSport | Ligier JS P3 - Nissan | Classified 106L gap 9 Laps | John Farano / Morten Dons / Alex Kapadia
 25 g18 #12 Eurointernational | Ligier JS P3 - Nissan | Classified 106L gap 9 Laps | Andrea Dromedari / Ricky Capo / Maxwell Hanratty
 27 g? #5 By Speed Factory | Ligier JS P3 - Nissan | Classified 103L gap 12 Laps | Tim Müller / Jürgen Krebs
 28 g31 #4 Cool Racing by GPC | Ligier Onroak Ligier JSP3 | Classified 98L gap 17 Laps | Alexandre Coigny / Iradj Alexander
 29 g16 #19 M.Racing - YMR | Norma M 30 LMP3 | NC 97L gap NC | Yann Ehrlacher / Erwin Creed
 30 g13 #6 360 Racing | Ligier JS P3 - Nissan | NC 88L gap NC | Terrence Woodward / Ross Kaiser / Anthony Wells
 31 g20 #10 Oregon Team | Norma M 30 - Nissan | NC 87L gap NC | Davide Roda / Andres Mendez / Dario Capitanio
 32 g24 #7 Duqueine Engineering | Norma M 30 - Nissan | NC 75L gap NC | Antonin Borga / David Droux / Nicolas Schatz
 33 g26 #8 Duqueine Engineering | Norma M 30 - Nissan | NC 42L gap NC | Vincent Beltoise / Lucas Légeret / Nicolas Melin
 34 g23 #9 AT Racing | Ligier JS P3 - Nissan | NC 0L gap NC | Alexander Talkanitsa / Alexander Talka Jr / Mikkel Jensen
 35 g25 #3 United Autosports | Ligier JS P3 - Nissan | NC 0L gap NC | Mark Patterson / Wayne Boyd / Christian England
== LMGTE
 19 g28 #55 Spirit of Race | Ferrari 488 GTE | Classified 106L gap 9 Laps | Duncan Cameron / Matt Griffin / Aaron Scott
 21 g33 #90 TF Sport | Aston Martin Vantage V8 | Classified 106L gap 9 Laps | Salih Yoluc / Euan Hankey / Nicki Thiim
 22 g32 #66 JMW Motorsport | Ferrari 458 Italia | Classified 106L gap 9 Laps | Robert Smith / Jody Fannin / Jonathan Cocker
 23 g30 #51 Spirit of Race | Ferrari 488 GTE | Classified 106L gap 9 Laps | Gianluca Roda / Giorgio Roda / Andrea Bertolini
 24 g34 #99 Beechdean AMR | Aston Martin Vantage V8 | Classified 106L gap 9 Laps | Andrew Howard / Ross Gunn / Darren Turner
 26 g29 #77 Proton Competition | Porsche 911 RSR 991 | Classified 105L gap 10 Laps | Christian Ried / Joël Camathias / Matteo Cairoli
