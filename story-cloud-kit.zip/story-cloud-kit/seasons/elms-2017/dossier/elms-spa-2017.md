# elms-spa-2017

Event: 4 Hours of Spa-Francorchamps | Circuit: Spa-Francorchamps | Date: 2017-09-24
Scheduled: 04:00:00 | Official duration: 4:01:40.666 | Laps (winner): 97

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q28 #77 [LMGTE] 2:16.757 Proton Competition | Matteo Cairoli
Q29 #90 [LMGTE] 2:17.115 TF Sport | Nicki Thiim
Q30 #66 [LMGTE] 2:17.684 JMW Motorsport | William Stevens
Q31 #55 [LMGTE] 2:17.787 Spirit of Race | Matt Griffin
Q32 #51 [LMGTE] 2:17.855 Spirit of Race | Andrea Bertolini
Q33 #99 [LMGTE] 2:18.050 Beechdean AMR | Ross Gunn
Q1 #21 [LMP2] 2:02.457 DragonSpeed | Ben Hanley
Q2 #22 [LMP2] 2:02.832 G-Drive Racing | Ryo Hirakawa
Q3 #39 [LMP2] 2:03.053 Graff | Enzo Guibbert
Q4 #32 [LMP2] 2:03.330 United Autosports | Filipe Albuquerque
Q5 #40 [LMP2] 2:03.427 Graff | Richard Bradley
Q6 #25 [LMP2] 2:03.728 Algarve Pro Racing | Andrea Pizzitola
Q7 #23 [LMP2] 2:03.858 Panis Barthez Competition | Nathanaël Berthon
Q8 #28 [LMP2] 2:03.998 Idec Sport Racing | Paul Loup Chatin
Q9 #27 [LMP2] 2:04.324 SMP Racing | Egor Orudzhev
Q10 #47 [LMP2] 2:05.454 Cetilar Villorba Corse | Andrea Belicchi
Q11 #29 [LMP2] 2:05.561 Racing Team Nederland | Jan Lammers
Q12 #49 [LMP2] 2:06.180 High Class Racing | Anders Fjordbach
Q13 #9 [LMP3] 2:13.634 AT Racing | Mikkel Jensen
Q14 #3 [LMP3] 2:14.345 United Autosports | Wayne Boyd
Q15 #2 [LMP3] 2:14.487 United Autosports | Sean Rayhall
Q16 #6 [LMP3] 2:14.692 360 Racing | Ross Kaiser
Q17 #7 [LMP3] 2:15.005 Duqueine Engineering | David Droux
Q18 #16 [LMP3] 2:15.039 Panis Barthez Competition | Simon Gachet
Q19 #17 [LMP3] 2:15.224 Ultimate | Matthieu Lahaye
Q20 #10 [LMP3] 2:15.307 Oregon Team | Dario Capitanio
Q21 #15 [LMP3] 2:15.386 RLR MSport | Alex Kapadia
Q22 #11 [LMP3] 2:15.654 Eurointernational | Giorgio Mondini
Q23 #18 [LMP3] 2:15.853 M.Racing - YMR | Alexandre Cougnaud
Q24 #12 [LMP3] 2:15.978 Eurointernational | Ricky Capo
Q25 #13 [LMP3] 2:16.018 Inter Europol Competition | Jakub Smiechowski
Q26 #8 [LMP3] 2:16.087 Duqueine Engineering | Vincent Beltoise
Q27 #19 [LMP3] 2:16.392 M.Racing - YMR | Yann Ehrlacher
Q34 #4 [LMP3] 2:20.056 Cool Racing by GPC | Iradj Alexander
Q35 #5 [LMP3] 2:22.797 By Speed Factory | Jürgen Krebs

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #21 Ben Hanley 2:02.457 DragonSpeed
LMGTE: #77 Matteo Cairoli 2:16.757 Proton Competition
LMP2: #21 Ben Hanley 2:02.457 DragonSpeed
LMP3: #9 Mikkel Jensen 2:13.634 AT Racing

## Fastest laps (archive)
Overall: #22 Léo Roussel 2:05.236
LMGTE: #55 Matt Griffin 2:20.527
LMP2: #22 Léo Roussel 2:05.236
LMP3: #9 Mikkel Jensen 2:16.083

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g5 #40 Graff | Oreca 07 - Gibson | Classified 97L gap — | James Allen / Richard Bradley / Gustavo Yacaman
 2 g2 #22 G-Drive Racing | Oreca 07 - Gibson | Classified 97L gap 0.581 | Memo Rojas / Ryo Hirakawa / Léo Roussel
 3 g9 #27 SMP Racing | Dallara P217 - Gibson | Classified 97L gap 16.069 | Matevos Isaakyan / Egor Orudzhev
 4 g4 #32 United Autosports | Ligier JSP217 - Gibson | Classified 97L gap 17.018 | Will Owen / Hugo de Sadeleer / Filipe Albuquerque
 5 g1 #21 DragonSpeed | Oreca 07 - Gibson | Classified 97L gap 39.161 | Henrik Hedman / Nicolas Lapierre / Ben Hanley
 6 g3 #39 Graff | Oreca 07 - Gibson | Classified 97L gap 23.411 | Jonathan Hirschi / Paul Petit / Enzo Guibbert
 7 g10 #47 Cetilar Villorba Corse | Dallara P217 - Gibson | Classified 97L gap 53.656 | Roberto Lacorte / Giorgio Sernagiotto / Andrea Belicchi
 8 g12 #49 High Class Racing | Dallara P217 - Gibson | Classified 96L gap 1 Laps | Dennis Andersen / Anders Fjordbach
 9 g7 #23 Panis Barthez Competition | Ligier JSP217 - Gibson | Classified 96L gap 1 Laps | Fabien Barthez / Timothé Buret / Nathanaël Berthon
 10 g8 #28 Idec Sport Racing | Ligier JSP217 - Gibson | Classified 96L gap 1 Laps | Patrice Lafargue / Paul Lafargue Jr / Paul Loup Chatin
 11 g11 #29 Racing Team Nederland | Dallara P217 - Gibson | Classified 94L gap 3 Laps | Jan Lammers / Frits van Eerd
 35 g6 #25 Algarve Pro Racing | Ligier JSP217 - Gibson | NC 0L gap NC | Andrea Roda / Matthew Mcmurry / Andrea Pizzitola
== LMP3
 12 g13 #9 AT Racing | Ligier JS P3 - Nissan | Classified 92L gap 5 Laps | Alexander Talkanitsa / Alexander Talka Jr / Mikkel Jensen
 13 g17 #7 Duqueine Engineering | Norma M 30 - Nissan | Classified 91L gap 6 Laps | Antonin Borga / David Droux / Nicolas Schatz
 14 g15 #2 United Autosports | Ligier JS P3 - Nissan | Classified 91L gap 6 Laps | John Falb / Sean Rayhall
 15 g25 #13 Inter Europol Competition | Ligier JS P3 - Nissan | Classified 91L gap 6 Laps | Jakub Smiechowski / Martin Hippe
 16 g14 #3 United Autosports | Ligier JS P3 - Nissan | Classified 91L gap 6 Laps | Mark Patterson / Wayne Boyd / Christian England
 17 g23 #18 M.Racing - YMR | Ligier JS P3 - Nissan | Classified 91L gap 6 Laps | Alexandre Cougnaud / Antoine Jung / Romano Ricci
 18 g16 #6 360 Racing | Ligier JS P3 - Nissan | Classified 91L gap 6 Laps | Terrence Woodward / Ross Kaiser / Anthony Wells
 19 g19 #17 Ultimate | Ligier JS P3 - Nissan | Classified 91L gap 6 Laps | Matthieu Lahaye / Jean-Baptiste Lahaye / François Heriau
 23 g21 #15 RLR MSport | Ligier JS P3 - Nissan | Classified 90L gap 7 Laps | John Farano / Morten Dons / Alex Kapadia
 25 g20 #10 Oregon Team | Norma M 30 - Nissan | Classified 90L gap 7 Laps | Davide Roda / Andres Mendez / Dario Capitanio
 26 g24 #12 Eurointernational | Ligier JS P3 - Nissan | Classified 89L gap 8 Laps | Andrea Dromedari / Ricky Capo / Maxwell Hanratty
 27 g34 #4 Cool Racing by GPC | Ligier JS P3 - Nissan | Classified 89L gap 8 Laps | Alexandre Coigny / Iradj Alexander
 28 g26 #8 Duqueine Engineering | Norma M 30 - Nissan | Classified 88L gap 9 Laps | Vincent Beltoise / Lucas Légeret / Nicolas Melin
 31 g27 #19 M.Racing - YMR | Norma M 30 - Nissan | NC 52L gap NC | Yann Ehrlacher / Neale Muston
 32 g22 #11 Eurointernational | Ligier JS P3 - Nissan | NC 46L gap NC | Giorgio Mondini / Marco Jacoboni
 33 g18 #16 Panis Barthez Competition | Ligier JS P3 - Nissan | NC 45L gap NC | Eric Debard / Simon Gachet / Theo Bean
 34 g35 #5 By Speed Factory | Ligier JS P3 - Nissan | NC 32L gap NC | Tim Müller / Jürgen Krebs
== LMGTE
 20 g32 #51 Spirit of Race | Ferrari 488 GTE | Classified 91L gap 6 Laps | Rino Mastronardi / Giorgio Roda / Andrea Bertolini
 21 g30 #66 JMW Motorsport | Ferrari 488 GTE | Classified 90L gap 7 Laps | Robert Smith / Jody Fannin / William Stevens
 22 g33 #99 Beechdean AMR | Aston Martin Vantage V8 | Classified 90L gap 7 Laps | Andrew Howard / Ross Gunn / Darren Turner
 24 g31 #55 Spirit of Race | Ferrari 488 GTE | Classified 90L gap 7 Laps | Duncan Cameron / Matt Griffin / Aaron Scott
 29 g29 #90 TF Sport | Aston Martin Vantage V8 | Classified 88L gap 9 Laps | Salih Yoluc / Euan Hankey / Nicki Thiim
 30 g28 #77 Proton Competition | Porsche 911 RSR 991 | Classified 70L gap 27 Laps | Christian Ried / Joël Camathias / Matteo Cairoli
