# elms-monza-2018

Event: 4 Hours of Monza | Circuit: Monza | Date: 2018-05-13
Scheduled: 04:00:00 | Official duration: 4:01:02.607 | Laps (winner): 124

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q1 #80 [LMGTE] 1:47.493 Ebimotors | Riccardo Pera
Q2 #88 [LMGTE] 1:47.511 Proton Competition | Gianmaria Bruni
Q3 #55 [LMGTE] 1:47.574 Spirit of Race | Matt Griffin
Q4 #83 [LMGTE] 1:47.878 Krohn Racing | Andrea Bertolini
Q5 #77 [LMGTE] 1:48.199 Proton Competition | Marc Lieb
Q1 #21 [LMP2] 1:35.837 DragonSpeed | Ben Hanley
Q2 #29 [LMP2] 1:36.074 Duqueine Engineering | Nelson Panciatici
Q3 #26 [LMP2] 1:36.183 G-Drive Racing | Jean-Eric Vergne
Q4 #22 [LMP2] 1:36.414 United Autosports | Filipe Albuquerque
Q5 #30 [LMP2] 1:36.614 AVF By Adrián Vallés | Konstantin Tereschenko
Q6 #40 [LMP2] 1:36.641 G-Drive Racing | Enzo Guibbert
Q7 #28 [LMP2] 1:36.817 IDEC Sport | Memo Rojas
Q8 #32 [LMP2] 1:37.045 United Autosports | Wayne Boyd
Q9 #39 [LMP2] 1:37.065 Graff | Jonathan Hirschi
Q10 #24 [LMP2] 1:37.155 Racing Engineering | Olivier Pla
Q11 #23 [LMP2] 1:37.195 Panis Barthez Competition | William Stevens
Q12 #35 [LMP2] 1:37.242 SMP Racing | Matevos Isaakyan
Q13 #47 [LMP2] 1:37.279 Cetilar Villorba Corse | Felipe Nasr
Q14 #49 [LMP2] 1:37.678 High Class Racing | Anders Fjordbach
Q15 #27 [LMP2] 1:40.137 IDEC Sport | Erik Maris
Q16 #25 [LMP2] 1:41.523 Algarve Pro Racing | Ate de Jong
Q1 #17 [LMP3] 1:45.386 Ultimate | Matthieu Lahaye
Q2 #19 [LMP3] 1:45.610 M. Racing - YMR | David Droux
Q3 #2 [LMP3] 1:45.677 United Autosports | Sean Rayhall
Q4 #15 [LMP3] 1:45.744 RLR MSport | Job van Uitert
Q5 #10 [LMP3] 1:45.910 Oregon Team | Riccardo Ponzio
Q6 #11 [LMP3] 1:46.161 Eurointernational | Giorgio Mondini
Q7 #5 [LMP3] 1:46.222 NEFIS by Speed Factory | Timur Boguslavskiy
Q8 #8 [LMP3] 1:46.272 DKR Engineering | Miguel Toril
Q9 #20 [LMP3] 1:46.444 Racing for Poland | Alex Fontana
Q10 #6 [LMP3] 1:46.586 360 Racing | Ross Kaiser
Q11 #4 [LMP3] 1:46.590 COOL Racing | Antonin Borga
Q12 #3 [LMP3] 1:46.805 United Autosports | Matthew Bell
Q13 #7 [LMP3] 1:46.846 Ecurie Ecosse/Nielsen | Colin Noble
Q14 #18 [LMP3] 1:46.860 M. Racing - YMR | Natan Bihel
Q15 #13 [LMP3] 1:46.890 Inter Europol Competition | Jakub Smiechowski
Q16 #14 [LMP3] 1:46.981 Inter Europol Competition | Hendrik Still
Q17 #16 [LMP3] 1:47.827 BHK Motorsport | Francesco Dracone

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #21 Ben Hanley 1:35.837 DragonSpeed
LMGTE: #80 Riccardo Pera 1:47.493 Ebimotors
LMP2: #21 Ben Hanley 1:35.837 DragonSpeed
LMP3: #17 Matthieu Lahaye 1:45.386 Ultimate

## Fastest laps (archive)
Overall: #21 Ben Hanley 1:37.064
LMGTE: #80 Riccardo Pera 1:49.042
LMP2: #21 Ben Hanley 1:37.064
LMP3: #17 Matthieu Lahaye 1:47.651

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g3 #26 G-Drive Racing | Oreca 07 - Gibson | Classified 124L gap — | Roman Rusinov / Andrea Pizzitola / Jean-Eric Vergne
 2 g17 #33 TDS Racing | Oreca 07 - Gibson | Classified 124L gap 29.828 | Matthieu Vaxivière / François Perrodo / Loïc Duval
 3 g7 #28 IDEC Sport | Oreca 07 - Gibson | Classified 124L gap 31.936 | Paul Lafargue / Paul Loup Chatin / Memo Rojas
 4 g1 #21 DragonSpeed | Oreca 07 - Gibson | Classified 124L gap 48.707 | Henrik Hedman / Ben Hanley / Nicolas Lapierre
 5 g10 #24 Racing Engineering | Oreca 07 - Gibson | Classified 124L gap 34.838 | Norman Nato / Olivier Pla / Paul Petit
 6 g2 #29 Duqueine Engineering | Oreca 07 - Gibson | Classified 124L gap 2.250 | Pierre Ragues / Nicolas Jamin / Nelson Panciatici
 7 g11 #23 Panis Barthez Competition | Ligier JSP217 - Gibson | Classified 124L gap 13.212 | Timothé Buret / Julien Canal / William Stevens
 8 g18 #31 APR - Rebellion Racing | Oreca 07 - Gibson | Classified 124L gap 18.043 | Ryan Cullen / Harrison Newey / Gustavo Menezes
 9 g13 #47 Cetilar Villorba Corse | Dallara P217 - Gibson | Classified 123L gap 1 Laps | Roberto Lacorte / Giorgio Sernagiotto / Felipe Nasr
 10 g4 #22 United Autosports | Ligier JSP217 - Gibson | Classified 123L gap 1 Laps | Philip Hanson / Filipe Albuquerque
 11 g8 #32 United Autosports | Ligier JSP217 - Gibson | Classified 123L gap 1 Laps | William Owen / Hugo de Sadeleer / Wayne Boyd
 12 g15 #27 IDEC Sport | Ligier JSP217 - Gibson | Classified 120L gap 4 Laps | Patrice Lafargue / Erik Maris / William Cavailhes
 13 g16 #25 Algarve Pro Racing | Ligier JSP217 - Gibson | Classified 120L gap 4 Laps | Mark Patterson / Ate de Jong / Tacksung Kim
 34 g14 #49 High Class Racing | Dallara P217 - Gibson | Classified 104L gap 20 Laps | Dennis Andersen / Anders Fjordbach
 36 g12 #35 SMP Racing | Dallara P217 - Gibson | NC 62L gap NC | Victor Shaitar / Egor Orudzhev / Matevos Isaakyan
 37 g5 #30 AVF By Adrián Vallés | Dallara P217 - Gibson | NC 61L gap NC | Konstantin Tereschenko / Henrique Chaves
 41 g6 #40 G-Drive Racing | Oreca 07 - Gibson | NC 0L gap NC | James Allen / Enzo Guibbert / Jose Gutierrez
 42 g9 #39 Graff | Oreca 07 - Gibson | NC 0L gap NC | Alexandre Cougnaud / Jonathan Hirschi / Tristan Gommendy
== LMP3
 14 g24 #11 Eurointernational | Ligier JS P3 - Nissan | Classified 118L gap 6 Laps | Giorgio Mondini / Kay van Berlo
 15 g28 #6 360 Racing | Ligier JS P3 - Nissan | Classified 117L gap 7 Laps | Terrence Woodward / Ross Kaiser / James Swift
 16 g30 #3 United Autosports | Ligier JS P3 - Nissan | Classified 117L gap 7 Laps | Anthony Wells / Garret Grist / Matthew Bell
 17 g33 #13 Inter Europol Competition | Ligier JS P3 - Nissan | Classified 117L gap 7 Laps | Jakub Smiechowski / Martin Hippe
 18 g21 #2 United Autosports | Ligier JS P3 - Nissan | Classified 117L gap 7 Laps | John Falb / Sean Rayhall
 19 g25 #5 NEFIS by Speed Factory | Ligier JS P3 - Nissan | Classified 117L gap 7 Laps | Timur Boguslavskiy / Alexey Chuklin / Daniil Pronenko
 20 g19 #17 Ultimate | Norma M 30 - Nissan | Classified 116L gap 8 Laps | Matthieu Lahaye / Jean-Baptiste Lahaye / François Heriau
 22 g23 #10 Oregon Team | Norma M 30 - Nissan | Classified 116L gap 8 Laps | Clément Mateu / Andres Mendez / Riccardo Ponzio
 23 g29 #4 COOL Racing | Ligier JS P3 - Nissan | Classified 116L gap 8 Laps | Alexandre Coigny / Iradj Alexander / Antonin Borga
 26 g31 #7 Ecurie Ecosse/Nielsen | Ligier JS P3 - Nissan | Classified 116L gap 8 Laps | Colin Noble / Alex Kapadia / Christian Stubbe Olsen
 27 g22 #15 RLR MSport | Ligier JS P3 - Nissan | Classified 115L gap 9 Laps | John Farano / Job van Uitert / Rob Garofall
 28 g38 #16 BHK Motorsport | Ligier JS P3 - Nissan | Classified 115L gap 9 Laps | Francesco Dracone / Jacopo Baratto
 32 g20 #19 M. Racing - YMR | Norma M30 - Nissan | Classified 113L gap 11 Laps | Nicolas Ferrer / David Droux / Lucas Légeret
 33 g27 #20 Racing for Poland | Ligier JS P3 - Nissan | Classified 109L gap 15 Laps | Henning Enqvist / Tomasz Blicharski / Alex Fontana
 35 g34 #14 Inter Europol Competition | Ligier JS P3 - Nissan | Classified 99L gap 25 Laps | Paul Scheuschner / Luca Demarchi / Hendrik Still
 38 g32 #18 M. Racing - YMR | Ligier JS P3 - Nissan | NC 57L gap NC | Laurent Millara / Natan Bihel
 39 g41 #9 AT Racing | Ligier JS P3 - Nissan | NC 56L gap NC | Alexander Talkanitsa / Alexander Talka Jr / Mikkel Jensen
 40 g26 #8 DKR Engineering | Norma M 30 - Nissan | NC 46L gap NC | Alexander Toril / Jean Glorieux / Miguel Toril
== LMGTE
 21 g37 #55 Spirit of Race | Ferrari F488 GTE | Classified 116L gap 8 Laps | Duncan Cameron / Matt Griffin / Aaron Scott
 24 g40 #77 Proton Competition | Porsche 911 RSR | Classified 116L gap 8 Laps | Christian Ried / Marvin Dienst / Marc Lieb
 25 g35 #80 Ebimotors | Porsche 911 RSR | Classified 116L gap 8 Laps | Fabio Babini / Riccardo Pera / Raymond Narac
 29 g42 #66 JMW Motorsport | Ferrari F488 GTE | Classified 115L gap 9 Laps | Liam Griffin / Alex MacDowall / Miguel Molina
 30 g36 #88 Proton Competition | Porsche 911 RSR | Classified 115L gap 9 Laps | Gianluca Roda / Giorgio Roda Jr / Gianmaria Bruni
 31 g39 #83 Krohn Racing | Ferrari F488 GTE | Classified 114L gap 10 Laps | Tracy Krohn / Niclas Jönsson / Andrea Bertolini
