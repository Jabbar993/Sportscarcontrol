# elms-silverstone-2018

Event: 4 Hours of Silverstone | Circuit: Silverstone | Date: 2018-08-18
Scheduled: 04:00:00 | Official duration: 4:01:37.859 | Laps (winner): 128

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q1 #77 [LMGTE] 1:58.704 Proton Competition | Dennis Olsen
Q2 #88 [LMGTE] 1:58.764 Proton Competition | Matteo Cairoli
Q3 #86 [LMGTE] 1:58.845 Gulf Racing UK | Benjamin Barker
Q4 #66 [LMGTE] 1:58.972 JMW Motorsport | Miguel Molina
Q5 #55 [LMGTE] 1:59.141 Spirit of Race | Matt Griffin
Q6 #80 [LMGTE] 1:59.378 Ebimotors | Riccardo Pera
Q7 #83 [LMGTE] 1:59.521 Krohn Racing | Andrea Bertolini
Q1 #23 [LMP2] 1:43.690 Panis Barthez Competition | William Stevens
Q2 #26 [LMP2] 1:44.426 G-Drive Racing | Jean-Eric Vergne
Q3 #21 [LMP2] 1:44.539 DragonSpeed | Ben Hanley
Q4 #29 [LMP2] 1:44.782 Duqueine Engineering | Nicolas Jamin
Q5 #40 [LMP2] 1:44.856 G-Drive Racing | James Allen
Q6 #49 [LMP2] 1:45.374 High Class Racing | Anders Fjordbach
Q7 #24 [LMP2] 1:45.390 Racing Engineering | Norman Nato
Q8 #28 [LMP2] 1:45.436 IDEC Sport | Paul Loup Chatin
Q9 #39 [LMP2] 1:45.637 Graff | Tristan Gommendy
Q10 #32 [LMP2] 1:45.673 United Autosports | Wayne Boyd
Q11 #31 [LMP2] 1:45.710 APR - Rebellion Racing | Gustavo Menezes
Q12 #22 [LMP2] 1:45.929 United Autosports | Filipe Albuquerque
Q13 #47 [LMP2] 1:46.059 Cetillar Villorba Corse | Felipe Nasr
Q14 #30 [LMP2] 1:46.246 AVF By Adrián Vallés | Henrique Chaves
Q15 #25 [LMP2] 1:51.655 Algarve Pro Racing | Tacksung Kim
Q1 #12 [LMP3] 1:55.508 Eurointernational | Mattia Drudi
Q2 #6 [LMP3] 1:55.554 360 Racing | Ross Kaiser
Q3 #2 [LMP3] 1:55.662 United Autosports | Sean Rayhall
Q4 #3 [LMP3] 1:55.803 United Autosports | Matthew Bell
Q5 #17 [LMP3] 1:56.079 Ultimate | Matthieu Lahaye
Q6 #15 [LMP3] 1:56.195 RLR MSport | Job van Uitert
Q7 #7 [LMP3] 1:56.323 Ecurie Ecosse/Nielsen | Alex Kapadia
Q8 #9 [LMP3] 1:56.487 AT Racing | Yann Clairay
Q9 #11 [LMP3] 1:56.732 Eurointernational | Giorgio Mondini
Q10 #5 [LMP3] 1:56.754 NEFIS by Speed Factory | Alexey Chuklin
Q11 #13 [LMP3] 1:57.279 Inter Europol Competition | Jakub Smiechowski
Q12 #19 [LMP3] 1:57.452 M. Racing - YMR | David Droux
Q13 #18 [LMP3] 1:57.690 M. Racing - YMR | Natan Bihel
Q14 #10 [LMP3] 1:57.860 Oregon Team | Riccardo Ponzio
Q15 #4 [LMP3] 1:57.927 COOL Racing | Iradj Alexander
Q16 #14 [LMP3] 1:57.979 Inter Europol Competition | Luca Demarchi
Q17 #34 [LMP3] 1:58.043 Team Virage | Jacob Rattenbury
Q18 #16 [LMP3] 1:58.182 BHK Motorsport | Francesco Dracone

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #23 William Stevens 1:43.690 Panis Barthez Competition
LMGTE: #77 Dennis Olsen 1:58.704 Proton Competition
LMP2: #23 William Stevens 1:43.690 Panis Barthez Competition
LMP3: #12 Mattia Drudi 1:55.508 Eurointernational

## Fastest laps (archive)
Overall: #26 Jean-Eric Vergne 1:47.225
LMGTE: #88 Matteo Cairoli 2:00.290
LMP2: #26 Jean-Eric Vergne 1:47.225
LMP3: #12 Mattia Drudi 1:57.769

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g2 #26 G-Drive Racing | Oreca 07 - Gibson | Classified 128L gap — | Roman Rusinov / Andrea Pizzitola / Jean-Eric Vergne
 2 g3 #21 DragonSpeed | Oreca 07 - Gibson | Classified 127L gap 1 Laps | Henrik Hedman / Ben Hanley / Nicolas Lapierre
 3 g8 #28 IDEC Sport | Oreca 07 - Gibson | Classified 127L gap 1 Laps | Paul Lafargue / Paul Loup Chatin / Memo Rojas
 4 g9 #39 Graff | Oreca 07 - Gibson | Classified 127L gap 1 Laps | Alexandre Cougnaud / Jonathan Hirschi / Tristan Gommendy
 5 g11 #31 APR - Rebellion Racing | Oreca 07 - Gibson | Classified 127L gap 1 Laps | Ryan Cullen / Harrison Newey / Gustavo Menezes
 6 g1 #23 Panis Barthez Competition | Ligier JSP217 - Gibson | Classified 127L gap 1 Laps | Timothé Buret / Julien Canal / William Stevens
 7 g4 #29 Duqueine Engineering | Oreca 07 - Gibson | Classified 127L gap 1 Laps | Pierre Ragues / Nicolas Jamin / Nelson Panciatici
 8 g14 #30 AVF By Adrián Vallés | Dallara P217 - Gibson | Classified 126L gap 2 Laps | Konstantin Tereschenko / Henrique Chaves
 9 g6 #49 High Class Racing | Dallara P217 - Gibson | Classified 126L gap 2 Laps | Dennis Andersen / Anders Fjordbach
 10 g10 #32 United Autosports | Ligier JSP217 - Gibson | Classified 125L gap 3 Laps | Will Owen / Hugo de Sadeleer / Wayne Boyd
 11 g15 #25 Algarve Pro Racing | Ligier JSP217 - Gibson | Classified 120L gap 8 Laps | Mark Patterson / Ate de Jong / Tacksung Kim
 12 g5 #40 G-Drive Racing | Oreca 07 - Gibson | Classified 120L gap 8 Laps | James Allen / Jose Gutierrez / Garry Findlay
 35 g13 #47 Cetilar Villorba Corse | Dallara P217 - Gibson | Classified 98L gap 30 Laps | Roberto Lacorte / Giorgio Sernagiotto / Felipe Nasr
 37 g7 #24 Racing Engineering | Oreca 07 - Gibson | NC 110L gap NC | Norman Nato / Matthieu Vaxiviere / Paul Petit
 40 g16 #35 SMP Racing | Dallara P217 - Gibson | NC 35L gap NC | Victor Shaitar / Matevos Isaakyan
 41 g12 #22 United Autosports | Ligier JSP217 - Gibson | NC 34L gap NC | Philip Hanson / Filipe Albuquerque
== LMP3
 13 g20 #3 United Autosports | Ligier JS P3 - Nissan | Classified 117L gap 11 Laps | Anthony Wells / Garret Grist / Matthew Bell
 14 g23 #7 Ecurie Ecosse/Nielsen | Ligier JS P3 - Nissan | Classified 117L gap 11 Laps | Colin Noble / Alex Kapadia / Christian Stubbe Olsen
 15 g21 #17 Ultimate | Norma M 30 - Nissan | Classified 117L gap 11 Laps | Matthieu Lahaye / Jean-Baptiste Lahaye / François Heriau
 16 g18 #6 360 Racing | Ligier JS P3 - Nissan | Classified 117L gap 11 Laps | Terrence Woodward / Ross Kaiser / James Swift
 17 g27 #13 Inter Europol Competition | Ligier JS P3 - Nissan | Classified 116L gap 12 Laps | Jakub Smiechowski / Martin Hippe
 18 g22 #15 RLR MSport | Ligier JS P3 - Nissan | Classified 116L gap 12 Laps | John Farano / Job van Uitert / Robert Garofall
 19 g19 #2 United Autosports | Ligier JS P3 - Nissan | Classified 116L gap 12 Laps | John Falb / Sean Rayhall
 20 g28 #19 M. Racing - YMR | Norma M 30 - Nissan | Classified 116L gap 12 Laps | David Droux / Lucas Légeret / Romano Ricci
 21 g24 #9 AT Racing | Ligier JS P3 - Nissan | Classified 116L gap 12 Laps | Alexander Talkanitsa / Alexander Talka Jr / Yann Clairay
 22 g17 #12 Eurointernational | Ligier JS P3 - Nissan | Classified 116L gap 12 Laps | Andrea Dromedari / Mattia Drudi
 23 g31 #4 COOL Racing | Ligier JS P3 - Nissan | Classified 116L gap 12 Laps | Christian Vaglio / Iradj Alexander / Lucas Borga
 24 g34 #16 BHK Motorsport | Ligier JS P3 - Nissan | Classified 115L gap 13 Laps | Francesco Dracone / Jacopo Baratto
 29 g32 #14 Inter Europol Competition | Ligier JS P3 - Nissan | Classified 114L gap 14 Laps | Paul Scheuschner / Luca Demarchi / Hendrik Still
 30 g30 #10 Oregon Team | Norma M 30 - Nissan | Classified 114L gap 14 Laps | Clément Mateu / Andres Mendez / Riccardo Ponzio
 33 g33 #34 Team Virage | Ligier JS P3 - Nissan | Classified 110L gap 18 Laps | Henning Enqvist / Jacob Rattenbury / Jean-Marc Littman
 34 g25 #11 Eurointernational | Ligier JS P3 - Nissan | Classified 103L gap 25 Laps | Giorgio Mondini / Kay van Berlo
 38 g26 #5 NEFIS by Speed Factory | Ligier JS P3 - Nissan | NC 84L gap NC | Timur Boguslavskiy / Alexey Chuklin / Daniil Pronenko
 39 g29 #18 M. Racing - YMR | Ligier JS P3 - Nissan | NC 61L gap NC | Laurent Millara / Natan Bihel
== LMGTE
 25 g38 #66 JMW Motorsport | Ferrari F488 GTE | Classified 115L gap 13 Laps | Liam Griffin / Alex MacDowall / Miguel Molina
 26 g36 #88 Proton Competition | Porsche Porsche 911 RSR | Classified 115L gap 13 Laps | Gianluca Roda / Giorgio Roda Jr / Matteo Cairoli
 27 g39 #55 Spirit of Race | Ferrari F488 GTE | Classified 115L gap 13 Laps | Duncan Cameron / Matt Griffin / Aaron Scott
 28 g35 #77 Proton Competition | Porsche Porsche 911 RSR | Classified 115L gap 13 Laps | Christian Ried / Marvin Dienst / Dennis Olsen
 31 g37 #86 Gulf Racing | Porsche 911 RSR 991 | Classified 114L gap 14 Laps | Michael Wainwright / Benjamin Barker / Alexander Davison
 32 g41 #83 Krohn Racing | Ferrari F488 GTE | Classified 112L gap 16 Laps | Tracy Krohn / Niclas Jönsson / Andrea Bertolini
 36 g40 #80 Ebimotors | Porsche Porsche 911 RSR | NC 112L gap NC | Fabio Babini / Riccardo Pera / Bret Curtis
