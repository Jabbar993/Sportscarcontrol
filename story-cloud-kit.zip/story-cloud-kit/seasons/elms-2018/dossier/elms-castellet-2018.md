# elms-castellet-2018

Event: 4 Hours of Le Castellet | Circuit: Paul Ricard | Date: 2018-04-15
Scheduled: 04:00:00 | Official duration: 4:00:23.793 | Laps (winner): 129

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q1 #88 [LMGTE] 1:53.377 Proton Competition | Matteo Cairoli
Q2 #66 [LMGTE] 1:54.562 JMW Motorsport | Miguel Molina
Q3 #77 [LMGTE] 1:54.830 Proton Competition | Dennis Olsen
Q4 #83 [LMGTE] 1:54.905 Krohn Racing | Andrea Bertolini
Q5 #55 [LMGTE] 1:54.949 Spirit Of Race | Matt Griffin
Q6 #80 [LMGTE] 1:55.183 EbiMotors | Riccardo Pera
Q7 #54 [LMGTE] 1:55.790 Spirit Of Race | Francesco Castellacci
Q1 #28 [LMP2] 1:41.194 IDEC Sport | Paul-Loup Chatin
Q2 #33 [LMP2] 1:41.638 TDS Racing | Matthieu Vaxiviere
Q3 #21 [LMP2] 1:41.904 DragonSpeed | Ben Hanley
Q4 #24 [LMP2] 1:42.130 Racing Engineering | Norman Nato
Q5 #29 [LMP2] 1:42.138 Duqueine Engineering | Nelson Panciatici
Q6 #31 [LMP2] 1:42.194 APR - Rebellion Racing | Harrison Newey
Q7 #23 [LMP2] 1:42.199 Panis Barthez Competition | Will Stevens
Q8 #36 [LMP2] 1:42.230 Signatech Alpine Matmut | André Negrão
Q9 #35 [LMP2] 1:42.507 SMP Racing | Egor Orudzhev
Q10 #40 [LMP2] 1:42.582 G-Drive Racing | Enzo Guibbert
Q11 #30 [LMP2] 1:42.660 AVF By Adrián Vallés | Henrique Chaves
Q12 #26 [LMP2] 1:42.850 G-Drive Racing | Alexandre Imperatori
Q13 #39 [LMP2] 1:43.139 Graff | Tristan Gommendy
Q14 #32 [LMP2] 1:43.410 United Autosports | Hugo de Sadeleer
Q15 #49 [LMP2] 1:43.717 High Class Racing | Anders Fjordbach
Q16 #47 [LMP2] 1:43.895 Cetilar Villorba Corse | Andrea Belicchi
Q17 #22 [LMP2] 1:44.043 United Autosports | Bruno Senna
Q18 #27 [LMP2] 1:46.016 IDEC Sport | Patrice Lafargue
Q19 #25 [LMP2] 1:47.194 Algarve Pro Racing | Mark Patterson
Q1 #19 [LMP3] 1:51.930 M.Racing - YMR | David Droux
Q2 #17 [LMP3] 1:51.991 Ultimate | Matthieu Lahaye
Q3 #8 [LMP3] 1:52.104 DKR Engineering | Miguel Toril
Q4 #15 [LMP3] 1:52.108 RLR MSport | Job van Uitert
Q5 #2 [LMP3] 1:52.641 United Autosports | Sean Rayhall
Q6 #3 [LMP3] 1:52.711 United Autosports | Matthew Bell
Q7 #6 [LMP3] 1:52.783 360 Racing | Ross Kaiser
Q8 #11 [LMP3] 1:53.009 EuroInternational | Giorgio Mondini
Q9 #18 [LMP3] 1:53.070 M.Racing - YMR | Natan Bihel
Q10 #5 [LMP3] 1:53.198 NEFIS by Speed Factory | Alexey Chuklin
Q11 #9 [LMP3] 1:53.383 AT Racing | Yann Clairay
Q12 #13 [LMP3] 1:53.400 Inter Europol Competition | Jakub Smiechowski
Q13 #7 [LMP3] 1:53.638 Ecurie Ecosse/Nielsen | Alex Kapadia
Q14 #4 [LMP3] 1:53.872 Cool Racing | Antonin Borga
Q15 #12 [LMP3] 1:54.027 EuroInternational | Maxwell Hanratty
Q16 #10 [LMP3] 1:54.172 Oregon Team | Riccardo Ponzio
Q17 #14 [LMP3] 1:54.582 Inter Europol Competition | Henning Enqvist
Q18 #16 [LMP3] 1:55.159 BHK Motorsport | Francesco Dracone

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #28 Paul-Loup Chatin 1:41.194 IDEC Sport
LMP2: #28 Paul-Loup Chatin 1:41.194 IDEC Sport
LMP3: #19 David Droux 1:51.930 M.Racing - YMR
LMGTE: #88 Matteo Cairoli 1:53.377 Proton Competition

## Fastest laps (archive)
LMGTE: #66 Miguel Molina 1:54.670
LMGTE: #88 Matteo Cairoli 1:54.888
Overall: #24 Norman Nato 1:42.540
LMP2: #24 Norman Nato 1:42.540
LMP3: #15 Job van Uitert 1:52.941

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g4 #24 Racing Engineering | Oreca 07 - Gibson | Classified 129L gap — | Norman Nato / Olivier Pla / Paul Petit
 2 g2 #33 TDS Racing | Oreca 07 - Gibson | Classified 129L gap 4.827 | Matthieu Vaxiviere / François Perrodo / Loïc Duval
 3 g5 #29 Duqueine Engineering | Oreca 07 - Gibson | Classified 129L gap 7.875 | Pierre Ragues / Nicolas Jamin / Nelson Panciatici
 4 g12 #26 G-Drive Racing | Oreca 07 - Gibson | Classified 129L gap 11.415 | Roman Rusinov / Andrea Pizzitola / Alexandre Imperatori
 5 g8 #36 Signatech Alpine Matmut | Alpine A470 - Gibson | Classified 129L gap 29.577 | André Negrão / Pierre Thiriet
 6 g10 #40 G-Drive Racing | Oreca 07 - Gibson | Classified 129L gap — | James Allen / Enzo Guibbert / Jose Gutierrez
 7 g1 #28 IDEC Sport | Oreca 07 - Gibson | Classified 128L gap 1 Laps | Paul Lafargue / Paul-Loup Chatin / Memo Rojas
 8 g7 #23 Panis Barthez Competition | Ligier JSP217 - Gibson | Classified 128L gap 1 Laps | Timothe Buret / Julien Canal / Will Stevens
 9 g14 #32 United Autosports | Ligier JSP217 - Gibson | Classified 128L gap 1 Laps | Will Owen / Hugo de Sadeleer / Wayne Boyd
 10 g13 #39 Graff | Oreca 07 - Gibson | Classified 128L gap 1 Laps | Alexandre Cougnaud / Jonathan Hirschi / Tristan Gommendy
 11 g11 #30 AVF By Adrián Vallés | Dallara P217 - Gibson | Classified 128L gap 1 Laps | Konstantin Tereschenko / Henrique Chaves
 12 g17 #22 United Autosports | Ligier JSP217 - Gibson | Classified 128L gap 1 Laps | Philip Hanson / Bruno Senna
 13 g15 #49 High Class Racing | Dallara P217 - Gibson | Classified 127L gap 2 Laps | Dennis Andersen / Anders Fjordbach
 14 g16 #47 Cetilar Villorba Corse | Dallara P217 - Gibson | Classified 127L gap 2 Laps | Roberto Lacorte / Giorgio Sernagiotto / Andrea Belicchi
 15 g6 #31 APR - Rebellion Racing | Oreca 07 - Gibson | Classified 127L gap 2 Laps | Ryan Cullen / Harrison Newey / Gustavo Menezes
 37 g19 #25 Algarve Pro Racing | Ligier JSP217 - Gibson | Classified 111L gap 18 Laps | Mark Patterson / Ate de Jong / Tacksung Kim
 39 g9 #35 SMP Racing | Dallara P217 - Gibson | NC 121L gap NC | Victor Shaitar / Egor Orudzhev / Matevos Isaakyan
 41 g18 #27 IDEC Sport | Ligier JSP217 - Gibson | NC 77L gap NC | Patrice Lafargue / Erik Maris / William Cavailhes
 42 g3 #21 DragonSpeed | Oreca 07 - Gibson | NC 62L gap NC | Henrik Hedman / Ben Hanley / Nicolas Lapierre
== LMP3
 16 g23 #15 RLR MSport | Ligier JS P3 - Nissan | Classified 119L gap 10 Laps | John Farano / Job van Uitert / Rob Garofall
 17 g20 #19 M.Racing - YMR | Norma M30 - Nissan | Classified 119L gap 10 Laps | Nicolas Ferrer / David Droux / Lucas Légeret
 18 g27 #11 EuroInternational | Ligier JS P3 - Nissan | Classified 119L gap 10 Laps | Giorgio Mondini / Kay van Berlo
 19 g26 #6 360 Racing | Ligier JS P3 - Nissan | Classified 119L gap 10 Laps | Terrence Woodward / Ross Kaiser / James Swift
 20 g24 #2 United Autosports | Ligier JS P3 - Nissan | Classified 119L gap 10 Laps | John Falb / Sean Rayhall
 21 g32 #13 Inter Europol Competition | Ligier JS P3 - Nissan | Classified 118L gap 11 Laps | Jakub Smiechowski / Martin Hippe
 22 g25 #3 United Autosports | Ligier JS P3 - Nissan | Classified 118L gap 11 Laps | Anthony Wells / Garret Grist / Matthew Bell
 23 g31 #9 AT Racing | Ligier JS P3 - Nissan | Classified 118L gap 11 Laps | Alexander Talkanitsa / Alexander Talka Jr / Yann Clairay
 24 g33 #7 Ecurie Ecosse/Nielsen | Ligier JS P3 - Nissan | Classified 118L gap 11 Laps | Colin Noble / Alex Kapadia / Christian Stubbe Olsen
 25 g34 #4 Cool Racing | Ligier JS P3 - Nissan | Classified 118L gap 11 Laps | Alexandre Coigny / Iradj Alexander / Antonin Borga
 28 g36 #10 Oregon Team | Norma M 30 - Nissan | Classified 117L gap 12 Laps | Clément Mateu / Andres Mendez / Riccardo Ponzio
 30 g38 #14 Inter Europol Competition | Ligier JS P3 - Nissan | Classified 117L gap 12 Laps | Paul Scheuschner / Luca Demarchi / Henning Enqvist
 31 g28 #18 M.Racing - YMR | Ligier JS P3 - Nissan | Classified 117L gap 12 Laps | Laurent Millara / Natan Bihel
 33 g35 #12 EuroInternational | Ligier JS P3 - Nissan | Classified 116L gap 13 Laps | Andrea Dromedari / Maxwell Hanratty / James Dayson
 34 g42 #16 BHK Motorsport | Ligier JS P3 - Nissan | Classified 116L gap 13 Laps | Francesco Dracone / Jacopo Baratto
 36 g29 #5 NEFIS by Speed Factory | Ligier JS P3 - Nissan | Classified 115L gap 14 Laps | Timur Boguslavskiy / Alexey Chuklin / Daniil Pronenko
 40 g21 #17 Ultimate | Norma M 30 - Nissan | NC 83L gap NC | Matthieu Lahaye / Jean-Baptiste Lahaye / François Heriau
 45 g22 #8 DKR Engineering | Norma M 30 - Nissan | NC 0L gap NC | Miguel Toril / Jean Glorieux / Alexander Toril
== LMGTE
 26 g37 #66 JMW Motorsport | Ferrari F488 GTE | Classified 118L gap 11 Laps | Liam Griffin / Alex MacDowall / Miguel Molina
 27 g30 #88 Proton Competition | Porsche 911 RSR | Classified 118L gap 11 Laps | Gianluca Roda / Giorgio Roda Jr / Matteo Cairoli
 29 g43 #80 EbiMotors | Porsche 911 RSR | Classified 117L gap 12 Laps | Fabio Babini / Riccardo Pera / Raymond Narac
 32 g40 #83 Krohn Racing | Ferrari F488 GTE | Classified 117L gap 12 Laps | Tracy Krohn / Niclas Jönsson / Andrea Bertolini
 35 g39 #77 Proton Competition | Porsche 911 RSR | Classified 116L gap 13 Laps | Christian Ried / Marvin Dienst / Dennis Olsen
 38 g44 #54 Spirit Of Race | Ferrari F488 GTE | Classified 107L gap 22 Laps | Thomas Flohr / Francesco Castellacci
 43 g41 #55 Spirit Of Race | Ferrari F488 GTE | NC 54L gap NC | Duncan Cameron / Matt Griffin / Aaron Scott
 44 g? #86 Gulf Racing | Porsche 911 RSR | NC 45L gap NC | Michael Wainwright / Alex Davison / Ben Barker
