# elms-portimao-2018

Event: 4 Hours of Portimão | Circuit: Portimão | Date: 2018-10-28
Scheduled: 04:00:00 | Official duration: 4:01:29.956 | Laps (winner): 140

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q1 #66 [LMGTE] 1:42.765 JMW Motorsport | Miguel Molina
Q2 #77 [LMGTE] 1:43.073 Proton Competition | Dennis Olsen
Q3 #88 [LMGTE] 1:43.099 Proton Competition | Matteo Cairoli
Q4 #55 [LMGTE] 1:43.239 Spirit of Race | Matt Griffin
Q5 #80 [LMGTE] 1:43.620 Ebimotors | Riccardo Pera
Q6 #83 [LMGTE] 1:44.053 Krohn Racing | Andrea Bertolini
Q1 #29 [LMP2] 1:33.197 Duqueine Engineering | Nicolas Jamin
Q2 #23 [LMP2] 1:33.257 Panis Barthez Competition | William Stevens
Q3 #22 [LMP2] 1:33.363 United Autosports | Filipe Albuquerque
Q4 #28 [LMP2] 1:33.652 IDEC Sport | Paul Loup Chatin
Q5 #26 [LMP2] 1:33.836 G-Drive Racing | Jean-Eric Vergne
Q6 #21 [LMP2] 1:33.876 DragonSpeed | Nicolas Lapierre
Q7 #32 [LMP2] 1:34.050 United Autosports | William Owen
Q8 #30 [LMP2] 1:34.272 AVF By Adrián Vallés | Henrique Chaves
Q9 #47 [LMP2] 1:34.457 Cetilar Villorba Corse | Felipe Nasr
Q10 #40 [LMP2] 1:34.470 G-Drive Racing | James Allen
Q11 #31 [LMP2] 1:34.536 APR - Rebellion Racing | Ryan Cullen
Q12 #24 [LMP2] 1:34.634 Racing Engineering | Olivier Pla
Q13 #39 [LMP2] 1:34.885 Graff | Alexandre Cougnaud
Q14 #49 [LMP2] 1:35.848 High Class Racing | Anders Fjordbach
Q15 #25 [LMP2] 1:37.402 Algarve Pro Racing | Tacksung Kim
Q1 #19 [LMP3] 1:40.715 M. Racing - YMR | Lucas Légeret
Q2 #17 [LMP3] 1:40.776 Ultimate | Matthieu Lahaye
Q3 #9 [LMP3] 1:40.999 AT Racing | Mikkel Jensen
Q4 #8 [LMP3] 1:41.157 DKR Engineering | Marvin Klein
Q5 #2 [LMP3] 1:41.522 United Autosports | Scott Andrews
Q6 #4 [LMP3] 1:41.636 COOL Racing | Antonin Borga
Q7 #15 [LMP3] 1:41.638 RLR MSport | Job van Uitert
Q8 #7 [LMP3] 1:41.648 Ecurie Ecosse/Nielsen | Alex Kapadia
Q9 #13 [LMP3] 1:41.800 Inter Europol Competition | Jakub Smiechowski
Q10 #6 [LMP3] 1:41.806 360 Racing | Ross Kaiser
Q11 #14 [LMP3] 1:41.984 Inter Europol Competition | Moritz Müller-Crepon
Q12 #18 [LMP3] 1:42.132 M. Racing - YMR | Natan Bihel
Q13 #5 [LMP3] 1:42.392 NEFIS by Speed Factory | Daniil Pronenko
Q14 #3 [LMP3] 1:42.514 United Autosports | Matthew Bell
Q15 #12 [LMP3] 1:42.798 Eurointernational | Luca Demarchi
Q16 #10 [LMP3] 1:43.133 Oregon Team | Riccardo Ponzio
Q17 #16 [LMP3] 1:43.154 BHK Motorsport | Francesco Dracone

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #29 Nicolas Jamin 1:33.197 Duqueine Engineering
LMGTE: #66 Miguel Molina 1:42.765 JMW Motorsport
LMP2: #29 Nicolas Jamin 1:33.197 Duqueine Engineering
LMP3: #19 Lucas Légeret 1:40.715 M. Racing - YMR

## Fastest laps (archive)
Overall: #21 Nicolas Lapierre 1:35.078
LMGTE: #66 Miguel Molina 1:43.386
LMP2: #21 Nicolas Lapierre 1:35.078
LMP3: #9 Mikkel Jensen 1:42.259

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g3 #22 United Autosports | Ligier JSP217 - Gibson | Classified 140L gap — | Philip Hanson / Filipe Albuquerque
 2 g2 #23 Panis Barthez Competition | Ligier JSP217 - Gibson | Classified 140L gap 0.520 | Timothé Buret / Julien Canal / William Stevens
 3 g7 #32 United Autosports | Ligier JSP217 - Gibson | Classified 140L gap 14.647 | William Owen / Hugo de Sadeleer / Wayne Boyd
 4 g5 #26 G-Drive Racing | Oreca 07 - Gibson | Classified 140L gap 15.185 | Roman Rusinov / Andrea Pizzitola / Jean-Eric Vergne
 5 g12 #24 Racing Engineering | Oreca 07 - Gibson | Classified 140L gap — | Norman Nato / Olivier Pla / Paul Petit
 6 g4 #28 IDEC Sport | Oreca 07 - Gibson | Classified 139L gap 1 Laps | Gabriel Aubry / Paul Loup Chatin / Memo Rojas
 7 g10 #40 G-Drive Racing | Oreca 07 - Gibson | Classified 139L gap 1 Laps | James Allen / Julien Falchero / Henning Enqvist
 8 g13 #39 Graff | Oreca 07 - Gibson | Classified 139L gap 1 Laps | Alexandre Cougnaud / Jonathan Hirschi / Tristan Gommendy
 9 g14 #49 High Class Racing | Dallara P217 - Gibson | Classified 138L gap 2 Laps | Dennis Andersen / Anders Fjordbach
 11 g15 #25 Algarve Pro Racing | Ligier JSP217 - Gibson | Classified 132L gap 8 Laps | Mark Patterson / Ate de Jong / Tacksung Kim
 24 g9 #47 Cetilar Villorba Corse | Dallara P217 - Gibson | Classified 129L gap 11 Laps | Roberto Lacorte / Giorgio Sernagiotto / Felipe Nasr
 28 g11 #31 APR - Rebellion Racing | Oreca 07 - Gibson | Classified 127L gap 13 Laps | Ryan Cullen / Harrison Newey / Gustavo Menezes
 35 g6 #21 DragonSpeed | Oreca 07 - Gibson | Classified 100L gap 40 Laps | Henrik Hedman / Ben Hanley / Nicolas Lapierre
 38 g8 #30 AVF By Adrián Vallés | Dallara P217 - Gibson | NC 68L gap NC | Konstantin Tereschenko / Henrique Chaves
 39 g1 #29 Duqueine Engineering | Oreca 07 - Gibson | NC 52L gap NC | Pierre Ragues / Nicolas Jamin / Nelson Panciatici
== LMP3
 10 g24 #13 Inter Europol Competition | Ligier JS P3 - Nissan | Classified 132L gap 8 Laps | Jakub Smiechowski / Martin Hippe
 12 g23 #7 Ecurie Ecosse/Nielsen | Ligier JS P3 - Nissan | Classified 132L gap 8 Laps | Colin Noble / Alex Kapadia / Christian Stubbe Olsen
 13 g20 #2 United Autosports | Ligier JS P3 - Nissan | Classified 132L gap 8 Laps | John Falb / Scott Andrews
 14 g28 #5 NEFIS by Speed Factory | Ligier JS P3 - Nissan | Classified 132L gap 8 Laps | Timur Boguslavskiy / Alexey Chuklin / Daniil Pronenko
 15 g22 #15 RLR MSport | Ligier JS P3 - Nissan | Classified 131L gap 9 Laps | John Farano / Job van Uitert / Robert Garofall
 16 g18 #9 AT Racing | Ligier JS P3 - Nissan | Classified 131L gap 9 Laps | Alexander Talkanitsa / Alexander Talka Jr / Mikkel Jensen
 17 g29 #3 United Autosports | Ligier JS P3 - Nissan | Classified 131L gap 9 Laps | Anthony Wells / Garett Grist / Matthew Bell
 18 g26 #14 Inter Europol Competition | Ligier JS P3 - Nissan | Classified 131L gap 9 Laps | Paul Scheuschner / Moritz Müller-Crepon
 19 g19 #8 DKR Engineering | Norma M 30 - Nissan | Classified 131L gap 9 Laps | Christian Vaglio / Marvin Klein / Nicolas Maulini
 21 g16 #19 M. Racing - YMR | Norma M 30 - Nissan | Classified 130L gap 10 Laps | David Droux / Lucas Légeret / Michael Benham
 26 g35 #16 BHK Motorsport | Ligier JS P3 - Nissan | Classified 128L gap 12 Laps | Francesco Dracone / Jacopo Baratto
 27 g17 #17 Ultimate | Norma M 30 - Nissan | Classified 128L gap 12 Laps | Matthieu Lahaye / Jean-Baptiste Lahaye / François Heriau
 30 g21 #4 COOL Racing | Ligier JS P3 - Nissan | Classified 127L gap 13 Laps | Alexandre Coigny / Iradj Alexander / Antonin Borga
 31 g31 #12 Eurointernational | Ligier JS P3 - Nissan | Classified 126L gap 14 Laps | James Dayson / Vadim Meshcheriakov / Luca Demarchi
 32 g34 #10 Oregon Team | Norma M 30 - Nissan | Classified 115L gap 25 Laps | Clément Mateu / Andres Mendez / Riccardo Ponzio
 33 g25 #6 360 Racing | Ligier JS P3 - Nissan | Classified 105L gap 35 Laps | Terrence Woodward / Ross Kaiser
 34 g27 #18 M. Racing - YMR | Ligier JS P3 - Nissan | Classified 102L gap 38 Laps | Laurent Millara / Natan Bihel
 36 g39 #11 Eurointernational | Ligier JS P3 - Nissan | NC 85L gap NC | Giorgio Mondini / Kay van Berlo
== LMGTE
 20 g32 #77 Proton Competition | Porsche Porsche 911 RSR | Classified 130L gap 10 Laps | Christian Ried / Marvin Dienst / Dennis Olsen
 22 g30 #66 JMW Motorsport | Ferrari F488 GTE | Classified 129L gap 11 Laps | Liam Griffin / Alex MacDowall / Miguel Molina
 23 g33 #88 Proton Competition | Porsche Porsche 911 RSR | Classified 129L gap 11 Laps | Gianluca Roda / Giorgio Roda Jr / Matteo Cairoli
 25 g36 #55 Spirit of Race | Ferrari F488 GTE | Classified 129L gap 11 Laps | Duncan Cameron / Matt Griffin / Aaron Scott
 29 g38 #83 Krohn Racing | Ferrari F488 GTE | Classified 127L gap 13 Laps | Tracy Krohn / Niclas Jönsson / Andrea Bertolini
 37 g37 #80 Ebimotors | Porsche Porsche 911 RSR | NC 82L gap NC | Fabio Babini / Riccardo Pera / Gianluca Giraudi
