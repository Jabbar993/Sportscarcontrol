# elms-spa-2018

Event: 4 Hours of Spa-Francorchamps | Circuit: Spa-Francorchamps | Date: 2018-09-23
Scheduled: 04:00:00 | Official duration: 2:01:20.812 | Laps (winner): 40

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q1 #88 [LMGTE] 2:15.654 Proton Competition | Matteo Cairoli
Q2 #77 [LMGTE] 2:16.354 Proton Competition | Dennis Olsen
Q3 #80 [LMGTE] 2:17.183 Ebimotors | Riccardo Pera
Q4 #66 [LMGTE] 2:17.810 JMW Motorsport | Miguel Molina
Q5 #55 [LMGTE] 2:17.977 Spirit of Race | Matt Griffin
Q6 #83 [LMGTE] 2:23.542 Krohn Racing | Tracy Krohn
Q1 #26 [LMP2] 2:00.735 G-Drive Racing | Jean-Eric Vergne
Q2 #22 [LMP2] 2:00.912 United Autosports | Filipe Albuquerque
Q3 #29 [LMP2] 2:01.251 Duqueine Engineering | Nelson Panciatici
Q4 #28 [LMP2] 2:01.512 IDEC Sport | Paul Loup Chatin
Q5 #31 [LMP2] 2:01.665 APR - Rebellion Racing | Gustavo Menezes
Q6 #24 [LMP2] 2:01.761 Racing Engineering | Norman Nato
Q7 #21 [LMP2] 2:02.121 DragonSpeed | Ben Hanley
Q8 #30 [LMP2] 2:02.172 AVF By Adrián Vallés | Konstantin Tereschenko
Q9 #32 [LMP2] 2:02.241 United Autosports | Hugo de Sadeleer
Q10 #23 [LMP2] 2:02.404 Panis Barthez Competition | William Stevens
Q11 #47 [LMP2] 2:02.405 Cetilar Villorba Corse | Felipe Nasr
Q12 #49 [LMP2] 2:02.788 High Class Racing | Anders Fjordbach
Q13 #27 [LMP2] 2:03.585 IDEC Sport | Aurélien Panis
Q14 #25 [LMP2] 2:05.614 Algarve Pro Racing | Matthew Mcmurry
Q1 #17 [LMP3] 2:13.634 Ultimate | Matthieu Lahaye
Q2 #11 [LMP3] 2:13.699 Eurointernational | Mattia Drudi
Q3 #6 [LMP3] 2:13.874 360 Racing | Ross Kaiser
Q4 #7 [LMP3] 2:13.983 Ecurie Ecosse/Nielsen | Colin Noble
Q5 #15 [LMP3] 2:14.062 RLR MSport | Job van Uitert
Q6 #8 [LMP3] 2:14.248 DKR Engineering | Marvin Klein
Q7 #19 [LMP3] 2:14.279 M. Racing - YMR | David Droux
Q8 #2 [LMP3] 2:14.367 United Autosports | Scott Andrews
Q9 #9 [LMP3] 2:14.418 AT Racing | Yann Clairay
Q10 #3 [LMP3] 2:14.539 United Autosports | Matthew Bell
Q11 #4 [LMP3] 2:14.658 COOL Racing | Antonin Borga
Q12 #13 [LMP3] 2:14.832 Inter Europol Competition | Jakub Smiechowski
Q13 #5 [LMP3] 2:15.022 NEFIS by Speed Factory | Alexey Chuklin
Q14 #10 [LMP3] 2:15.323 Oregon Team | Riccardo Ponzio
Q15 #14 [LMP3] 2:15.800 Inter Europol Competition | Moritz Müller-Crepon
Q16 #16 [LMP3] 2:17.173 BHK Motorsport | Francesco Dracone
Q17 #18 [LMP3] 2:17.617 M. Racing - YMR | Natan Bihel
Q18 #12 [LMP3] 2:24.588 Eurointernational | James Dayson

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #26 Jean-Eric Vergne 2:00.735 G-Drive Racing
LMGTE: #88 Matteo Cairoli 2:15.654 Proton Competition
LMP2: #26 Jean-Eric Vergne 2:00.735 G-Drive Racing
LMP3: #17 Matthieu Lahaye 2:13.634 Ultimate

## Fastest laps (archive)
Overall: #29 Nicolas Jamin 2:29.009
LMGTE: #80 Riccardo Pera 2:41.896
LMP2: #29 Nicolas Jamin 2:29.009
LMP3: #4 Antonin Borga 2:38.152

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g2 #22 United Autosports | Ligier JSP217 - Gibson | Classified 40L gap — | Philip Hanson / Filipe Albuquerque
 2 g7 #21 DragonSpeed | Oreca 07 - Gibson | Classified 40L gap 1.862 | Henrik Hedman / Ben Hanley / Nicolas Lapierre
 3 g10 #23 Panis Barthez Competition | Ligier JSP217 - Gibson | Classified 40L gap 8.702 | Timothé Buret / Julien Canal / William Stevens
 4 g4 #28 IDEC Sport | Oreca 07 - Gibson | Classified 40L gap 12.760 | Gabriel Aubry / Paul Loup Chatin / Memo Rojas
 5 g3 #29 Duqueine Engineering | Oreca 07 - Gibson | Classified 40L gap 17.389 | Pierre Ragues / Nicolas Jamin / Nelson Panciatici
 6 g9 #32 United Autosports | Ligier JSP217 - Gibson | Classified 40L gap 19.113 | William Owen / Hugo de Sadeleer / Wayne Boyd
 7 g6 #24 Racing Engineering | Oreca 07 - Gibson | Classified 40L gap 21.203 | Norman Nato / Olivier Pla / Paul Petit
 8 g16 #39 Graff | Oreca 07 - Gibson | Classified 40L gap 23.237 | Alexandre Cougnaud / Jonathan Hirschi / Tristan Gommendy
 9 g8 #30 AVF By Adrián Vallés | Dallara P217 - Gibson | Classified 40L gap 25.093 | Konstantin Tereschenko / Henrique Chaves
 10 g11 #47 Cetilar Villorba Corse | Dallara P217 - Gibson | Classified 40L gap 25.741 | Roberto Lacorte / Giorgio Sernagiotto / Felipe Nasr
 12 g15 #40 G-Drive Racing | Oreca 07 - Gibson | Classified 40L gap 58.042 | James Allen / Julien Falchero / Henning Enqvist
 14 g1 #26 G-Drive Racing | Oreca 07 - Gibson | Classified 40L gap — | Roman Rusinov / Andrea Pizzitola / Jean-Eric Vergne
 22 g14 #25 Algarve Pro Racing | Ligier JSP217 - Gibson | Classified 39L gap 1 Laps | Mark Patterson / Matthew Mcmurry / Tacksung Kim
 31 g13 #27 IDEC Sport | Ligier JSP217 - Gibson | Classified 34L gap 6 Laps | Nicolas Minassian / Erik Maris / Aurélien Panis
 32 g5 #31 APR - Rebellion Racing | Oreca 07 - Gibson | Classified 31L gap 9 Laps | Ryan Cullen / Harrison Newey / Gustavo Menezes
 38 g12 #49 High Class Racing | Dallara P217 - Gibson | NC 0L gap NC | Dennis Andersen / Anders Fjordbach
== LMP3
 11 g24 #2 United Autosports | Ligier JS P3 - Nissan | Classified 40L gap 43.501 | John Falb / Scott Andrews
 13 g21 #15 RLR MSport | Ligier JS P3 - Nissan | Classified 40L gap 22.167 | John Farano / Job van Uitert / Robert Garofall
 15 g19 #6 360 Racing | Ligier JS P3 - Nissan | Classified 39L gap 1 Laps | Terrence Woodward / Ross Kaiser
 16 g26 #3 United Autosports | Ligier JS P3 - Nissan | Classified 39L gap 1 Laps | Anthony Wells / Garret Grist / Matthew Bell
 17 g36 #18 M. Racing - YMR | Ligier JS P3 - Nissan | Classified 39L gap 1 Laps | Laurent Millara / Natan Bihel
 19 g27 #4 COOL Racing | Ligier JS P3 - Nissan | Classified 39L gap 1 Laps | Alexandre Coigny / Antonin Borga
 23 g30 #10 Oregon Team | Norma M 30 - Nissan | Classified 39L gap 1 Laps | Clément Mateu / Andres Mendez / Riccardo Ponzio
 24 g23 #19 M. Racing - YMR | Norma M 30 - Nissan | Classified 39L gap 1 Laps | David Droux / Lucas Légeret / Romano Ricci
 26 g20 #7 Ecurie Ecosse/Nielsen | Ligier JS P3 - Nissan | Classified 38L gap 2 Laps | Colin Noble / Alex Kapadia / Christian Stubbe Olsen
 27 g29 #5 NEFIS by Speed Factory | Ligier JS P3 - Nissan | Classified 38L gap 2 Laps | Timur Boguslavskiy / Alexey Chuklin / Daniil Pronenko
 28 g22 #8 DKR Engineering | Norma M 30 - Nissan | Classified 38L gap 2 Laps | Christian Vaglio / Marvin Klein
 29 g28 #13 Inter Europol Competition | Ligier JS P3 - Nissan | Classified 37L gap 3 Laps | Jakub Smiechowski / Martin Hippe
 30 g18 #11 Eurointernational | Ligier JS P3 - Nissan | Classified 34L gap 6 Laps | Mattia Drudi / Kay van Berlo / Giorgio Mondini
 33 g40 #12 Eurointernational | Ligier JS P3 - Nissan | Classified 31L gap 9 Laps | Andrea Dromedari / James Dayson
 35 g32 #14 Inter Europol Competition | Ligier JS P3 - Nissan | Classified 30L gap 10 Laps | Paul Scheuschner / Luca Demarchi / Moritz Müller-Crepon
 37 g25 #9 AT Racing | Ligier JS P3 - Nissan | NC 0L gap NC | Alexander Talkanitsa / Alexander Talka Jr / Yann Clairay
 39 g17 #17 Ultimate | Norma M 30 - Nissan | NC 0L gap NC | Matthieu Lahaye / Jean-Baptiste Lahaye / François Heriau
 40 g34 #16 BHK Motorsport | Ligier JS P3 - Nissan | NC 0L gap NC | Francesco Dracone / Jacopo Baratto
== LMGTE
 18 g35 #80 Ebimotors | Porsche Porsche 911 RSR | Classified 39L gap 1 Laps | Fabio Babini / Riccardo Pera / Bret Curtis
 20 g38 #55 Spirit of Race | Ferrari F488 GTE | Classified 39L gap 1 Laps | Duncan Cameron / Matt Griffin / Aaron Scott
 21 g31 #88 Proton Competition | Porsche Porsche 911 RSR | Classified 39L gap 1 Laps | Gianluca Roda / Giorgio Roda Jr / Matteo Cairoli
 25 g37 #66 JMW Motorsport | Ferrari F488 GTE | Classified 38L gap 2 Laps | Liam Griffin / Alex MacDowall / Miguel Molina
 34 g33 #77 Proton Competition | Porsche Porsche 911 RSR | Classified 31L gap 9 Laps | Christian Ried / Marvin Dienst / Dennis Olsen
 36 g39 #83 Krohn Racing | Ferrari F488 GTE | NC 0L gap NC | Tracy Krohn / Niclas Jönsson / Andrea Bertolini
