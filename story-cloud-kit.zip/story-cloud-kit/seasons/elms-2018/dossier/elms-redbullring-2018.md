# elms-redbullring-2018

Event: 4 Hours of Red Bull Ring | Circuit: Red Bull Ring | Date: 2018-07-22
Scheduled: 04:00:00 | Official duration: 4:00:14.242 | Laps (winner): 160

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q1 #66 [LMGTE] 1:28.827 JMW Motorsport | Miguel Molina
Q2 #88 [LMGTE] 1:28.925 Proton Competition | Matteo Cairoli
Q3 #83 [LMGTE] 1:28.967 Krohn Racing | Andrea Bertolini
Q4 #55 [LMGTE] 1:29.190 Spirit of Race | Matt Griffin
Q5 #77 [LMGTE] 1:29.259 Proton Competition | Dennis Olsen
Q6 #80 [LMGTE] 1:29.366 Ebimotors | Riccardo Pera
Q1 #28 [LMP2] 1:19.246 IDEC Sport | Paul Loup Chatin
Q2 #29 [LMP2] 1:19.265 Duqueine Engineering | Nicolas Jamin
Q3 #24 [LMP2] 1:19.387 Racing Engineering | Norman Nato
Q4 #21 [LMP2] 1:19.423 DragonSpeed | Nicolas Lapierre
Q5 #26 [LMP2] 1:19.562 G-Drive Racing | Andrea Pizzitola
Q6 #33 [LMP2] 1:19.743 TDS Racing | Loïc Duval
Q7 #22 [LMP2] 1:19.950 United Autosports | Filipe Albuquerque
Q8 #40 [LMP2] 1:19.959 G-Drive Racing | James Allen
Q9 #39 [LMP2] 1:20.179 Graff | Tristan Gommendy
Q10 #47 [LMP2] 1:20.234 Cetilar Villorba Corse | Felipe Nasr
Q11 #35 [LMP2] 1:20.351 SMP Racing | Matevos Isaakyan
Q12 #32 [LMP2] 1:20.383 United Autosports | William Owen
Q13 #49 [LMP2] 1:20.609 High Class Racing | Anders Fjordbach
Q14 #31 [LMP2] 1:20.622 APR - Rebellion Racing | Gustavo Menezes
Q15 #23 [LMP2] 1:21.091 Panis Barthez Competition | William Stevens
Q16 #30 [LMP2] 1:21.362 AVF By Adrián Vallés | Konstantin Tereschenko
Q17 #25 [LMP2] 1:23.522 Algarve Pro Racing | Mark Patterson
Q18 #27 [LMP2] 1:23.695 IDEC Sport | Erik Maris
Q1 #17 [LMP3] 1:26.519 Ultimate | Matthieu Lahaye
Q2 #19 [LMP3] 1:26.583 M. Racing - YMR | Lucas Légeret
Q3 #15 [LMP3] 1:26.703 RLR MSport | Job van Uitert
Q4 #4 [LMP3] 1:26.751 COOL Racing | Antonin Borga
Q5 #8 [LMP3] 1:26.917 DKR Engineering | Ricardo Sanchez
Q6 #9 [LMP3] 1:26.960 AT Racing | Mikkel Jensen
Q7 #10 [LMP3] 1:27.008 Oregon Team | Riccardo Ponzio
Q8 #2 [LMP3] 1:27.032 United Autosports | Sean Rayhall
Q9 #7 [LMP3] 1:27.192 Ecurie Ecosse/Nielsen | Colin Noble
Q10 #3 [LMP3] 1:27.354 United Autosports | Matthew Bell
Q11 #11 [LMP3] 1:27.365 Eurointernational | Giorgio Mondini
Q12 #13 [LMP3] 1:27.486 Inter Europol Competition | Jakub Smiechowski
Q13 #5 [LMP3] 1:27.654 NEFIS by Speed Factory | Alexey Chuklin
Q14 #18 [LMP3] 1:27.890 M. Racing - YMR | Natan Bihel
Q15 #6 [LMP3] 1:28.133 360 Racing | Ross Kaiser
Q16 #16 [LMP3] 1:28.368 BHK Motorsport | Francesco Dracone
Q17 #12 [LMP3] 1:28.893 Eurointernational | Andrea Dromedari

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #28 Paul Loup Chatin 1:19.246 IDEC Sport
LMGTE: #66 Miguel Molina 1:28.827 JMW Motorsport
LMP2: #28 Paul Loup Chatin 1:19.246 IDEC Sport
LMP3: #17 Matthieu Lahaye 1:26.519 Ultimate

## Fastest laps (archive)
Overall: #24 Norman Nato 1:20.330
LMGTE: #88 Matteo Cairoli 1:29.517
LMP2: #24 Norman Nato 1:20.330
LMP3: #9 Mikkel Jensen 1:27.757

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g5 #26 G-Drive Racing | Oreca 07 - Gibson | Classified 160L gap — | Roman Rusinov / Andrea Pizzitola / Jean-Eric Vergne
 2 g3 #24 Racing Engineering | Oreca 07 - Gibson | Classified 160L gap 20.126 | Norman Nato / Olivier Pla / Paul Petit
 3 g7 #22 United Autosports | Ligier JSP217 - Gibson | Classified 160L gap 54.166 | Philip Hanson / Filipe Albuquerque
 4 g1 #28 IDEC Sport | Oreca 07 - Gibson | Classified 160L gap 56.087 | Paul Lafargue / Paul Loup Chatin / Memo Rojas
 5 g4 #21 DragonSpeed | Oreca 07 - Gibson | Classified 159L gap 1 Laps | Henrik Hedman / Ben Hanley / Nicolas Lapierre
 6 g14 #31 APR - Rebellion Racing | Oreca 07 - Gibson | Classified 159L gap 1 Laps | Ryan Cullen / Harrison Newey / Gustavo Menezes
 7 g11 #35 SMP Racing | Dallara P217 - Gibson | Classified 159L gap 1 Laps | Victor Shaitar / Egor Orudzhev / Matevos Isaakyan
 8 g9 #39 Graff | Oreca 07 - Gibson | Classified 159L gap 1 Laps | Alexandre Cougnaud / Jonathan Hirschi / Tristan Gommendy
 9 g6 #33 TDS Racing | Oreca 07 - Gibson | Classified 159L gap 1 Laps | Matthieu Vaxivière / François Perrodo / Loïc Duval
 10 g15 #23 Panis Barthez Competition | Ligier JSP217 - Gibson | Classified 158L gap 2 Laps | Timothé Buret / Julien Canal / William Stevens
 11 g10 #47 Cetilar Villorba Corse | Dallara P217 - Gibson | Classified 158L gap 2 Laps | Roberto Lacorte / Giorgio Sernagiotto / Felipe Nasr
 12 g13 #49 High Class Racing | Dallara P217 - Gibson | Classified 158L gap 2 Laps | Dennis Andersen / Anders Fjordbach
 13 g8 #40 G-Drive Racing | Oreca 07 - Gibson | Classified 158L gap 2 Laps | James Allen / Jose Gutierrez
 14 g16 #30 AVF By Adrián Vallés | Dallara P217 - Gibson | Classified 158L gap 2 Laps | Konstantin Tereschenko / Henrique Chaves
 15 g12 #32 United Autosports | Ligier JSP217 - Gibson | Classified 157L gap 3 Laps | William Owen / Hugo de Sadeleer / Wayne Boyd
 16 g18 #27 IDEC Sport | Ligier JSP217 - Gibson | Classified 154L gap 6 Laps | Patrice Lafargue / Erik Maris / Nicolas Minassian
 17 g17 #25 Algarve Pro Racing | Ligier JSP217 - Gibson | Classified 152L gap 8 Laps | Mark Patterson / Ate de Jong / Tacksung Kim
 42 g2 #29 Duqueine Engineering | Oreca 07 - Gibson | DSQ 160L gap DSQ | Pierre Ragues / Nicolas Jamin / Nelson Panciatici
== LMP3
 18 g21 #15 RLR MSport | Ligier JS P3 - Nissan | Classified 148L gap 12 Laps | John Farano / Job van Uitert / Robert Garofall
 19 g27 #7 Ecurie Ecosse/Nielsen | Ligier JS P3 - Nissan | Classified 148L gap 12 Laps | Colin Noble / Alex Kapadia / Christian Stubbe Olsen
 20 g30 #13 Inter Europol Competition | Ligier JS P3 - Nissan | Classified 148L gap 12 Laps | Jakub Smiechowski / Martin Hippe
 21 g19 #17 Ultimate | Norma M 30 - Nissan | Classified 148L gap 12 Laps | Matthieu Lahaye / Jean-Baptiste Lahaye / François Heriau
 22 g24 #9 AT Racing | Ligier JS P3 - Nissan | Classified 147L gap 13 Laps | Alexander Talkanitsa / Alexander Talka Jr / Mikkel Jensen
 23 g31 #5 NEFIS by Speed Factory | Ligier JS P3 - Nissan | Classified 147L gap 13 Laps | Timur Boguslavskiy / Alexey Chuklin / Daniil Pronenko
 25 g29 #11 Eurointernational | Ligier JS P3 - Nissan | Classified 147L gap 13 Laps | Giorgio Mondini / Kay van Berlo
 26 g33 #6 360 Racing | Ligier JS P3 - Nissan | Classified 146L gap 14 Laps | Terrence Woodward / Ross Kaiser
 28 g32 #18 M. Racing - YMR | Ligier JS P3 - Nissan | Classified 146L gap 14 Laps | Laurent Millara / Natan Bihel
 29 g22 #4 COOL Racing | Ligier JS P3 - Nissan | Classified 146L gap 14 Laps | Alexandre Coigny / Iradj Alexander / Antonin Borga
 32 g42 #14 Inter Europol Competition | Ligier JS P3 - Nissan | Classified 145L gap 15 Laps | Paul Scheuschner / Luca Demarchi / Guglielmo Belotti
 33 g28 #3 United Autosports | Ligier JS P3 - Nissan | Classified 145L gap 15 Laps | Anthony Wells / Garret Grist / Matthew Bell
 34 g36 #12 Eurointernational | Ligier JS P3 - Nissan | Classified 144L gap 16 Laps | Andrea Dromedari / Maxwell Hanratty / James Dayson
 36 g23 #8 DKR Engineering | Norma M 30 - Nissan | Classified 142L gap 18 Laps | Ricardo Sanchez / Henning Enqvist / Fabien Lavergne
 37 g34 #16 BHK Motorsport | Ligier JS P3 - Nissan | Classified 139L gap 21 Laps | Francesco Dracone / Jacopo Baratto
 38 g25 #10 Oregon Team | Norma M 30 - Nissan | Classified 132L gap 28 Laps | Clément Mateu / Andres Mendez / Riccardo Ponzio
 39 g20 #19 M. Racing - YMR | Norma M 30 - Nissan | NC 112L gap NC | Alain Ferté / David Droux / Lucas Légeret
 40 g26 #2 United Autosports | Ligier JS P3 - Nissan | NC 70L gap NC | Sean Rayhall / John Falb
== LMGTE
 24 g37 #88 Proton Competition | Porsche 911 RSR | Classified 147L gap 13 Laps | Gianluca Roda / Giorgio Roda Jr / Matteo Cairoli
 27 g39 #55 Spirit of Race | Ferrari F488 GTE | Classified 146L gap 14 Laps | Duncan Cameron / Matt Griffin / Aaron Scott
 30 g41 #80 Ebimotors | Porsche 911 RSR | Classified 146L gap 14 Laps | Fabio Babini / Riccardo Pera / Bret Curtis
 31 g40 #77 Proton Competition | Porsche 911 RSR | Classified 145L gap 15 Laps | Christian Ried / Marvin Dienst / Dennis Olsen
 35 g38 #83 Krohn Racing | Ferrari F488 GTE | Classified 143L gap 17 Laps | Tracy Krohn / Niclas Jönsson / Andrea Bertolini
 41 g35 #66 JMW Motorsport | Ferrari F488 GTE | NC 43L gap NC | Liam Griffin / Alex MacDowall / Miguel Molina
