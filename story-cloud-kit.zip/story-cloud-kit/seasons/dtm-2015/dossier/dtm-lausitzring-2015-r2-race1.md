# dtm-lausitzring-2015-r2-race1

Event: DTM Lausitzring Race 1 | Circuit: Lausitzring | Date: 2015-05-30
Scheduled: 00:40:00 | Official duration: 00:42:15.135 | Laps (winner): 32

## Qualifying (archive order)
Q1 #17 [DTMV8] 1:17.438 Audi Sport Team Abt Sportsline | Miguel Molina
Q2 #53 [DTMV8] 1:17.559 Audi Sport Team Rosberg | Jamie Green
Q3 #48 [DTMV8] 1:17.564 Audi Sport Team Abt | Edoardo Mortara
Q4 #5 [DTMV8] 1:17.607 Audi Sport Team Abt Sportsline | Mattias Ekström
Q5 #94 [DTMV8] 1:17.621 gooix/Original-Teile Mercedes-AMG | Pascal Wehrlein
Q6 #1 [DTMV8] 1:17.635 BMW Team RMG | Marco Wittmann
Q7 #6 [DTMV8] 1:17.648 Silberpfeil Energy Mercedes-AMG | Robert Wickens
Q8 #36 [DTMV8] 1:17.729 BMW Team RMG | Maxime Martin
Q9 #31 [DTMV8] 1:17.890 BMW Team RBM | Tom Blomqvist
Q10 #3 [DTMV8] 1:17.902 Silberpfeil Energy Mercedes-AMG | Paul di Resta
Q11 #10 [DTMV8] 1:17.935 Audi Sport Team Phoenix | Timo Scheider
Q12 #13 [DTMV8] 1:17.956 BMW Team Schnitzer | António Félix da Costa
Q13 #12 [DTMV8] 1:17.964 Petronas Mercedes-AMG | Daniel Juncadella
Q14 #99 [DTMV8] 1:17.981 Audi Sport Team Phoenix | Mike Rockenfeller
Q15 #7 [DTMV8] 1:18.014 BMW Team MTEK | Bruno Spengler
Q16 #51 [DTMV8] 1:18.030 Audi Sport Team Rosberg | Nico Müller
Q17 #77 [DTMV8] 1:18.078 BMW Team Schnitzer | Martin Tomczyk
Q18 #16 [DTMV8] 1:18.115 BMW Team MTEK | Timo Glock
Q19 #18 [DTMV8] 1:18.132 BMW Team RBM | Augusto Farfus
Q20 #8 [DTMV8] 1:18.220 gooix/Original-Teile Mercedes-AMG | Christian Vietoris
Q21 #22 [DTMV8] 1:18.260 Euronics/BWT Mercedes-AMG | Lucas Auer
Q22 #84 [DTMV8] 1:18.321 Petronas Mercedes-AMG | Maximilian Götz
Q23 #2 [DTMV8] 1:18.457 Euronics/BWT Mercedes-AMG | Gary Paffett
Q24 #27 [DTMV8]  Audi Sport Team Abt | Adrien Tambay

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #17 Miguel Molina 1:17.438 Audi Sport Team Abt Sportsline
DTMV8: #17 Miguel Molina 1:17.438 Audi Sport Team Abt Sportsline

## Fastest laps (archive)
Overall: #53 Jamie Green 1:18.599 lap 26
DTMV8: #53 Jamie Green 1:18.599 lap 26

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g2 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 32L gap — | Jamie Green
 2 g3 #48 Audi Sport Team Abt | Audi RS 5 DTM | Classified 32L gap 4.261 | Edoardo Mortara
 3 g4 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 32L gap 5.220 | Mattias Ekström
 4 g1 #17 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 32L gap 6.969 | Miguel Molina
 5 g5 #94 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 32L gap 8.122 | Pascal Wehrlein
 6 g6 #6 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 32L gap 10.657 | Robert Wickens
 7 g7 #36 BMW Team RMG | BMW M4 DTM | Classified 32L gap 13.014 | Maxime Martin
 8 g10 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 32L gap 13.361 | Timo Scheider
 9 g14 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 32L gap 16.719 | Mike Rockenfeller
 10 g13 #12 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 32L gap 19.619 | Daniel Juncadella
 11 g15 #7 BMW Team MTEK | BMW M4 DTM | Classified 32L gap 22.391 | Bruno Spengler
 12 g17 #77 BMW Team Schnitzer | BMW M4 DTM | Classified 32L gap 27.031 | Martin Tomczyk
 13 g11 #1 BMW Team RMG | BMW M4 DTM | Classified 32L gap 28.364 | Marco Wittmann
 14 g9 #3 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 32L gap 28.522 | Paul di Resta
 15 g21 #84 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 32L gap 29.026 | Maximilian Götz
 16 g24 #27 Audi Sport Team Abt | Audi RS 5 DTM | Classified 32L gap 29.439 | Adrien Tambay
 17 g19 #8 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 32L gap 35.480 | Christian Vietoris
 18 g18 #16 BMW Team MTEK | BMW M4 DTM | Classified 32L gap 36.370 | Timo Glock
 19 g12 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 32L gap 37.537 | António Félix da Costa
 20 g16 #51 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 32L gap 42.297 | Nico Müller
 21 g20 #22 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 32L gap 42.480 | Lucas Auer
 22 g8 #31 BMW Team RBM | BMW M4 DTM | Classified 32L gap 45.087 | Tom Blomqvist
 23 g22 #2 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 32L gap 49.803 | Gary Paffett
 24 g23 #18 BMW Team RBM | BMW M4 DTM | RET 2L gap RET | Augusto Farfus
