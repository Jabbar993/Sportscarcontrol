# dtm-norisring-2015-r3-race1

Event: DTM Norisring Race 1 | Circuit: Norisring | Date: 2015-06-27
Scheduled: 00:40:00 | Official duration: 00:41:02.170 | Laps (winner): 46

## Qualifying (archive order)
Q1 #8 [DTMV8] 50.640 gooix/Original-Teile Mercedes-AMG | Christian Vietoris
Q2 #2 [DTMV8] 50.679 Euronics/BWT Mercedes-AMG | Gary Paffett
Q3 #53 [DTMV8] 50.687 Audi Sport Team Rosberg | Jamie Green
Q4 #3 [DTMV8] 50.751 Silberpfeil Energy Mercedes-AMG | Paul di Resta
Q5 #94 [DTMV8] 50.807 gooix/Original-Teile Mercedes-AMG | Pascal Wehrlein
Q6 #18 [DTMV8] 50.876 BMW Team RBM | Augusto Farfus
Q7 #6 [DTMV8] 50.938 Silberpfeil Energy Mercedes-AMG | Robert Wickens
Q8 #1 [DTMV8] 50.965 BMW Team RMG | Marco Wittmann
Q9 #17 [DTMV8] 51.069 Audi Sport Team Abt Sportsline | Miguel Molina
Q10 #77 [DTMV8] 51.088 BMW Team Schnitzer | Martin Tomczyk
Q11 #12 [DTMV8] 51.090 Petronas Mercedes-AMG | Daniel Juncadella
Q12 #22 [DTMV8] 51.126 Euronics/BWT Mercedes-AMG | Lucas Auer
Q13 #7 [DTMV8] 51.152 BMW Team MTEK | Bruno Spengler
Q14 #36 [DTMV8] 51.198 BMW Team RMG | Maxime Martin
Q15 #16 [DTMV8] 51.236 BMW Team MTEK | Timo Glock
Q16 #48 [DTMV8] 51.262 Audi Sport Team Abt | Edoardo Mortara
Q17 #31 [DTMV8] 51.283 BMW Team RBM | Tom Blomqvist
Q18 #13 [DTMV8] 51.326 BMW Team Schnitzer | António Félix da Costa
Q19 #51 [DTMV8] 51.327 Audi Sport Team Rosberg | Nico Müller
Q20 #84 [DTMV8] 51.381 Petronas Mercedes-AMG | Maximilian Götz
Q21 #5 [DTMV8] 51.404 Audi Sport Team Abt Sportsline | Mattias Ekström
Q22 #99 [DTMV8] 51.517 Audi Sport Team Phoenix | Mike Rockenfeller
Q23 #27 [DTMV8] 51.524 Audi Sport Team Abt | Adrien Tambay
Q24 #10 [DTMV8] 51.539 Audi Sport Team Phoenix | Timo Scheider

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #8 Christian Vietoris 50.640 gooix/Original-Teile Mercedes-AMG
DTMV8: #8 Christian Vietoris 50.640 gooix/Original-Teile Mercedes-AMG

## Fastest laps (archive)
Overall: #53 Jamie Green 49.297 lap 35
DTMV8: #53 Jamie Green 49.297 lap 35

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g5 #94 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 46L gap — | Pascal Wehrlein
 2 g7 #6 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 46L gap 0.356 | Robert Wickens
 3 g2 #2 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 46L gap 0.742 | Gary Paffett
 4 g1 #8 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 46L gap 1.362 | Christian Vietoris
 5 g13 #7 BMW Team MTEK | BMW M4 DTM | Classified 46L gap 2.784 | Bruno Spengler
 6 g10 #77 BMW Team Schnitzer | BMW M4 DTM | Classified 46L gap 4.902 | Martin Tomczyk
 7 g3 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 46L gap 5.279 | Jamie Green
 8 g6 #18 BMW Team RBM | BMW M4 DTM | Classified 46L gap 8.572 | Augusto Farfus
 9 g8 #1 BMW Team RMG | BMW M4 DTM | Classified 46L gap 8.943 | Marco Wittmann
 10 g11 #12 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 46L gap 9.262 | Daniel Juncadella
 11 g16 #48 Audi Sport Team Abt | Audi RS 5 DTM | Classified 46L gap 11.482 | Edoardo Mortara
 12 g18 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 46L gap 13.318 | António Félix da Costa
 13 g15 #16 BMW Team MTEK | BMW M4 DTM | Classified 46L gap 15.990 | Timo Glock
 14 g22 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 46L gap 17.695 | Mike Rockenfeller
 15 g12 #22 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 46L gap 17.935 | Lucas Auer
 16 g24 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 46L gap 20.717 | Timo Scheider
 17 g21 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 46L gap 21.469 | Mattias Ekström
 18 g19 #51 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 46L gap 25.638 | Nico Müller
 19 g23 #27 Audi Sport Team Abt | Audi RS 5 DTM | Classified 46L gap 40.423 | Adrien Tambay
 20 g9 #17 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 46L gap 47.794 | Miguel Molina
 21 g20 #84 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | RET 17L gap RET | Maximilian Götz
 22 g4 #3 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | RET 17L gap RET | Paul di Resta
 23 g17 #31 BMW Team RBM | BMW M4 DTM | RET 10L gap RET | Tom Blomqvist
 24 g14 #36 BMW Team RMG | BMW M4 DTM | RET 5L gap RET | Maxime Martin
