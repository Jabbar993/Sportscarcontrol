# dtm-redbullring-2015-r5-race1

Event: DTM Red Bull Ring Race 1 | Circuit: Red Bull Ring | Date: 2015-08-01
Scheduled: 00:40:00 | Official duration: 00:41:41.536 | Laps (winner): 29

## Qualifying (archive order)
Q1 #48 [DTMV8] 1:24.714 Audi Sport Team Abt | Edoardo Mortara
Q2 #53 [DTMV8] 1:24.907 Audi Sport Team Rosberg | Jamie Green
Q3 #94 [DTMV8] 1:24.926 gooix/Original-Teile Mercedes-AMG | Pascal Wehrlein
Q4 #3 [DTMV8] 1:25.006 Silberpfeil Energy Mercedes-AMG | Paul di Resta
Q5 #18 [DTMV8] 1:25.018 BMW Team RBM | Augusto Farfus
Q6 #8 [DTMV8] 1:25.134 gooix/Original-Teile Mercedes-AMG | Christian Vietoris
Q7 #6 [DTMV8] 1:25.146 Silberpfeil Energy Mercedes-AMG | Robert Wickens
Q8 #2 [DTMV8] 1:25.189 Euronics/BWT Mercedes-AMG | Gary Paffett
Q9 #5 [DTMV8] 1:25.191 Audi Sport Team Abt Sportsline | Mattias Ekström
Q10 #99 [DTMV8] 1:25.214 Audi Sport Team Phoenix | Mike Rockenfeller
Q11 #27 [DTMV8] 1:25.292 Audi Sport Team Abt | Adrien Tambay
Q12 #1 [DTMV8] 1:25.295 BMW Team RMG | Marco Wittmann
Q13 #13 [DTMV8] 1:25.313 BMW Team Schnitzer | António Félix da Costa
Q14 #51 [DTMV8] 1:25.320 Audi Sport Team Rosberg | Nico Müller
Q15 #7 [DTMV8] 1:25.341 BMW Team MTEK | Bruno Spengler
Q16 #10 [DTMV8] 1:25.368 Audi Sport Team Phoenix | Timo Scheider
Q17 #12 [DTMV8] 1:25.371 Petronas Mercedes-AMG | Daniel Juncadella
Q18 #77 [DTMV8] 1:25.446 BMW Team Schnitzer | Martin Tomczyk
Q19 #36 [DTMV8] 1:25.476 BMW Team RMG | Maxime Martin
Q20 #17 [DTMV8] 1:25.479 Audi Sport Team Abt Sportsline | Miguel Molina
Q21 #31 [DTMV8] 1:25.485 BMW Team RBM | Tom Blomqvist
Q22 #84 [DTMV8] 1:25.530 Petronas Mercedes-AMG | Maximilian Götz
Q23 #16 [DTMV8] 1:25.599 BMW Team MTEK | Timo Glock
Q24 #22 [DTMV8] 1:25.661 Euronics/BWT Mercedes-AMG | Lucas Auer

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #48 Edoardo Mortara 1:24.714 Audi Sport Team Abt
DTMV8: #48 Edoardo Mortara 1:24.714 Audi Sport Team Abt

## Fastest laps (archive)
Overall: #48 Edoardo Mortara 1:25.632 lap 10
DTMV8: #48 Edoardo Mortara 1:25.632 lap 10

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #48 Audi Sport Team Abt | Audi RS 5 DTM | Classified 29L gap — | Edoardo Mortara
 2 g3 #94 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 29L gap 1.792 | Pascal Wehrlein
 3 g4 #3 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 29L gap 11.200 | Paul di Resta
 4 g6 #8 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 29L gap 17.958 | Christian Vietoris
 5 g9 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 29L gap 19.300 | Mattias Ekström
 6 g5 #18 BMW Team RBM | BMW M4 DTM | Classified 29L gap 19.902 | Augusto Farfus
 7 g8 #2 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 29L gap 23.272 | Gary Paffett
 8 g10 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 29L gap 23.534 | Mike Rockenfeller
 9 g12 #1 BMW Team RMG | BMW M4 DTM | Classified 29L gap 29.879 | Marco Wittmann
 10 g11 #27 Audi Sport Team Abt | Audi RS 5 DTM | Classified 29L gap 30.368 | Adrien Tambay
 11 g17 #12 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 29L gap 31.966 | Daniel Juncadella
 12 g14 #51 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 29L gap 37.797 | Nico Müller
 13 g13 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 29L gap 38.532 | António Félix da Costa
 14 g19 #36 BMW Team RMG | BMW M4 DTM | Classified 29L gap 39.350 | Maxime Martin
 15 g15 #7 BMW Team MTEK | BMW M4 DTM | Classified 29L gap 39.925 | Bruno Spengler
 16 g16 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 29L gap 40.422 | Timo Scheider
 17 g21 #31 BMW Team RBM | BMW M4 DTM | Classified 29L gap 45.267 | Tom Blomqvist
 18 g20 #17 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 29L gap 45.684 | Miguel Molina
 19 g23 #16 BMW Team MTEK | BMW M4 DTM | Classified 29L gap 46.800 | Timo Glock
 20 g22 #84 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 29L gap 47.375 | Maximilian Götz
 21 g24 #22 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 29L gap 49.453 | Lucas Auer
 22 g18 #77 BMW Team Schnitzer | BMW M4 DTM | RET 10L gap RET | Martin Tomczyk
 23 g7 #6 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | RET 7L gap RET | Robert Wickens
 24 g2 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | RET 3L gap RET | Jamie Green
