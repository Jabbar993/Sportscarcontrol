# dtm-nurburgring-2015-r8-race2

Event: DTM Nürburgring Race 2 | Circuit: Nürburgring | Date: 2015-09-27
Scheduled: 01:00:00 | Official duration: 1:02:00.166 | Laps (winner): 43

## Qualifying (archive order)
Q1 #17 [DTMV8] 1:21.732 Audi Sport Team Abt Sportsline | Miguel Molina
Q2 #31 [DTMV8] 1:21.939 BMW Team RBM | Tom Blomqvist
Q3 #53 [DTMV8] 1:22.021 Audi Sport Team Rosberg | Jamie Green
Q4 #3 [DTMV8] 1:22.046 Silberpfeil Energy Mercedes-AMG | Paul di Resta
Q5 #7 [DTMV8] 1:22.049 BMW Team MTEK | Bruno Spengler
Q6 #18 [DTMV8] 1:22.086 BMW Team RBM | Augusto Farfus
Q7 #6 [DTMV8] 1:22.096 Silberpfeil Energy Mercedes-AMG | Robert Wickens
Q8 #84 [DTMV8] 1:22.217 Petronas Mercedes-AMG | Maximilian Götz
Q9 #94 [DTMV8] 1:22.219 gooix/Original-Teile Mercedes-AMG | Pascal Wehrlein
Q10 #1 [DTMV8] 1:22.239 BMW Team RMG | Marco Wittmann
Q11 #16 [DTMV8] 1:22.295 BMW Team MTEK | Timo Glock
Q12 #99 [DTMV8] 1:22.301 Audi Sport Team Phoenix | Mike Rockenfeller
Q13 #10 [DTMV8] 1:22.310 Audi Sport Team Phoenix | Timo Scheider
Q14 #12 [DTMV8] 1:22.312 Petronas Mercedes-AMG | Daniel Juncadella
Q15 #22 [DTMV8] 1:22.317 Euronics/BWT Mercedes-AMG | Lucas Auer
Q16 #36 [DTMV8] 1:22.344 BMW Team RMG | Maxime Martin
Q17 #5 [DTMV8] 1:22.405 Audi Sport Team Abt Sportsline | Mattias Ekström
Q18 #13 [DTMV8] 1:22.410 BMW Team Schnitzer | António Félix da Costa
Q19 #8 [DTMV8] 1:22.417 gooix/Original-Teile Mercedes-AMG | Christian Vietoris
Q20 #48 [DTMV8] 1:22.474 Audi Sport Team Abt | Edoardo Mortara
Q21 #51 [DTMV8] 1:22.514 Audi Sport Team Rosberg | Nico Müller
Q22 #27 [DTMV8] 1:22.667 Audi Sport Team Abt | Adrien Tambay
Q23 #77 [DTMV8] 1:23.820 BMW Team Schnitzer | Martin Tomczyk

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #17 Miguel Molina 1:21.732 Audi Sport Team Abt Sportsline
DTMV8: #17 Miguel Molina 1:21.732 Audi Sport Team Abt Sportsline

## Fastest laps (archive)
Overall: #17 Miguel Molina 1:23.417 lap 16
DTMV8: #17 Miguel Molina 1:23.417 lap 16

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #17 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 43L gap — | Miguel Molina
 2 g4 #3 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 43L gap 7.500 | Paul di Resta
 3 g5 #7 BMW Team MTEK | BMW M4 DTM | Classified 43L gap 8.791 | Bruno Spengler
 4 g2 #31 BMW Team RBM | BMW M4 DTM | Classified 43L gap 19.824 | Tom Blomqvist
 5 g9 #94 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 43L gap 25.581 | Pascal Wehrlein
 6 g8 #84 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 43L gap 26.326 | Maximilian Götz
 7 g12 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 43L gap 26.626 | Mike Rockenfeller
 8 g6 #18 BMW Team RBM | BMW M4 DTM | Classified 43L gap 34.305 | Augusto Farfus
 9 g24 #77 BMW Team Schnitzer | BMW M4 DTM | Classified 43L gap 37.205 | Martin Tomczyk
 10 g14 #12 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 43L gap 38.059 | Daniel Juncadella
 11 g17 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 43L gap 38.848 | Mattias Ekström
 12 g22 #27 Audi Sport Team Abt | Audi RS 5 DTM | Classified 43L gap 38.980 | Adrien Tambay
 13 g16 #36 BMW Team RMG | BMW M4 DTM | Classified 43L gap 41.174 | Maxime Martin
 14 g19 #8 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 43L gap 41.451 | Christian Vietoris
 15 g18 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 43L gap 42.656 | António Félix da Costa
 16 g21 #51 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 43L gap 43.205 | Nico Müller
 17 g3 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 43L gap 47.506 | Jamie Green
 18 g10 #1 BMW Team RMG | BMW M4 DTM | Classified 43L gap 1:02.291 | Marco Wittmann
 19 g15 #22 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 43L gap 1:05.555 | Lucas Auer
 20 g11 #16 BMW Team MTEK | BMW M4 DTM | Classified 43L gap 1:11.458 | Timo Glock
 21 g20 #48 Audi Sport Team Abt | Audi RS 5 DTM | RET 28L gap RET | Edoardo Mortara
 22 g23 #2 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | RET 8L gap RET | Gary Paffett
 23 g7 #6 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | RET 1L gap RET | Robert Wickens
 24 g13 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | RET 0L gap RET | Timo Scheider
