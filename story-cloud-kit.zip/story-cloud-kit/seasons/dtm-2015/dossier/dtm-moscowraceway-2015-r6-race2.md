# dtm-moscowraceway-2015-r6-race2

Event: DTM Moscow Raceway Race 2 | Circuit: Moscow Raceway | Date: 2015-08-30
Scheduled: 01:00:00 | Official duration: 1:02:14.818 | Laps (winner): 41

## Qualifying (archive order)
Q1 #99 [DTMV8] 1:28.540 Audi Sport Team Phoenix | Mike Rockenfeller
Q2 #5 [DTMV8] 1:28.578 Audi Sport Team Abt Sportsline | Mattias Ekström
Q3 #7 [DTMV8] 1:28.580 BMW Team MTEK | Bruno Spengler
Q4 #36 [DTMV8] 1:28.587 BMW Team RMG | Maxime Martin
Q5 #53 [DTMV8] 1:28.592 Audi Sport Team Rosberg | Jamie Green
Q6 #51 [DTMV8] 1:28.592 Audi Sport Team Rosberg | Nico Müller
Q7 #2 [DTMV8] 1:28.632 Euronics/BWT Mercedes-AMG | Gary Paffett
Q8 #31 [DTMV8] 1:28.650 BMW Team RBM | Tom Blomqvist
Q9 #18 [DTMV8] 1:28.658 BMW Team RBM | Augusto Farfus
Q10 #1 [DTMV8] 1:28.686 BMW Team RMG | Marco Wittmann
Q11 #94 [DTMV8] 1:28.739 gooix/Original-Teile Mercedes-AMG | Pascal Wehrlein
Q12 #12 [DTMV8] 1:28.772 Petronas Mercedes-AMG | Daniel Juncadella
Q13 #48 [DTMV8] 1:28.777 Audi Sport Team Abt | Edoardo Mortara
Q14 #16 [DTMV8] 1:28.881 BMW Team MTEK | Timo Glock
Q15 #22 [DTMV8] 1:28.896 Euronics/BWT Mercedes-AMG | Lucas Auer
Q16 #93 [DTMV8] 1:28.913 Audi Sport Team Phoenix | Antonio Giovinazzi
Q17 #6 [DTMV8] 1:28.970 Silberpfeil Energy Mercedes-AMG | Robert Wickens
Q18 #84 [DTMV8] 1:28.978 Petronas Mercedes-AMG | Maximilian Götz
Q19 #17 [DTMV8] 1:29.050 Audi Sport Team Abt Sportsline | Miguel Molina
Q20 #27 [DTMV8] 1:29.059 Audi Sport Team Abt | Adrien Tambay
Q21 #13 [DTMV8] 1:29.109 BMW Team Schnitzer | António Félix da Costa
Q22 #3 [DTMV8] 1:29.156 Silberpfeil Energy Mercedes-AMG | Paul di Resta
Q23 #8 [DTMV8] 1:29.261 gooix/Original-Teile Mercedes-AMG | Christian Vietoris
Q24 #77 [DTMV8] 1:29.408 BMW Team Schnitzer | Martin Tomczyk

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #99 Mike Rockenfeller 1:28.540 Audi Sport Team Phoenix
DTMV8: #99 Mike Rockenfeller 1:28.540 Audi Sport Team Phoenix

## Fastest laps (archive)
Overall: #99 Mike Rockenfeller 1:29.870 lap 21
DTMV8: #99 Mike Rockenfeller 1:29.870 lap 21

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 41L gap — | Mike Rockenfeller
 2 g2 #7 BMW Team MTEK | BMW M4 DTM | Classified 41L gap 4.132 | Bruno Spengler
 3 g5 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 41L gap 9.204 | Mattias Ekström
 4 g3 #36 BMW Team RMG | BMW M4 DTM | Classified 41L gap 11.789 | Maxime Martin
 5 g4 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 41L gap 12.585 | Jamie Green
 6 g7 #2 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 41L gap 14.393 | Gary Paffett
 7 g10 #1 BMW Team RMG | BMW M4 DTM | Classified 41L gap 16.593 | Marco Wittmann
 8 g13 #48 Audi Sport Team Abt | Audi RS 5 DTM | Classified 41L gap 18.050 | Edoardo Mortara
 9 g6 #51 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 41L gap 18.548 | Nico Müller
 10 g11 #94 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 41L gap 18.810 | Pascal Wehrlein
 11 g9 #18 BMW Team RBM | BMW M4 DTM | Classified 41L gap 24.207 | Augusto Farfus
 12 g8 #31 BMW Team RBM | BMW M4 DTM | Classified 41L gap 24.939 | Tom Blomqvist
 13 g12 #12 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 41L gap 25.237 | Daniel Juncadella
 14 g18 #17 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 41L gap 25.686 | Miguel Molina
 15 g21 #3 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 41L gap 27.253 | Paul di Resta
 16 g19 #27 Audi Sport Team Abt | Audi RS 5 DTM | Classified 41L gap 32.423 | Adrien Tambay
 17 g14 #16 BMW Team MTEK | BMW M4 DTM | Classified 41L gap 33.412 | Timo Glock
 18 g17 #84 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 41L gap 36.718 | Maximilian Götz
 19 g15 #22 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 41L gap 36.947 | Lucas Auer
 20 g22 #8 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 41L gap 43.030 | Christian Vietoris
 21 g24 #93 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 41L gap 53.048 | Antonio Giovinazzi
 22 g20 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 41L gap 1:15.152 | António Félix da Costa
 23 g16 #6 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 41L gap 1:25.033 | Robert Wickens
 24 g23 #77 BMW Team Schnitzer | BMW M4 DTM | RET 18L gap RET | Martin Tomczyk
