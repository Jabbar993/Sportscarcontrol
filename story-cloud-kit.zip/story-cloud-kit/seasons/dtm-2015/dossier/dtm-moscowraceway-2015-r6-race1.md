# dtm-moscowraceway-2015-r6-race1

Event: DTM Moscow Raceway Race 1 | Circuit: Moscow Raceway | Date: 2015-08-29
Scheduled: 00:40:00 | Official duration: 00:41:56.506 | Laps (winner): 24

## Qualifying (archive order)
Q1 #1 [DTMV8] 1:28.810 BMW Team RMG | Marco Wittmann
Q2 #94 [DTMV8] 1:28.979 gooix/Original-Teile Mercedes-AMG | Pascal Wehrlein
Q3 #53 [DTMV8] 1:28.985 Audi Sport Team Rosberg | Jamie Green
Q4 #16 [DTMV8] 1:29.003 BMW Team MTEK | Timo Glock
Q5 #31 [DTMV8] 1:29.066 BMW Team RBM | Tom Blomqvist
Q6 #5 [DTMV8] 1:29.085 Audi Sport Team Abt Sportsline | Mattias Ekström
Q7 #7 [DTMV8] 1:29.093 BMW Team MTEK | Bruno Spengler
Q8 #17 [DTMV8] 1:29.133 Audi Sport Team Abt Sportsline | Miguel Molina
Q9 #12 [DTMV8] 1:29.143 Petronas Mercedes-AMG | Daniel Juncadella
Q10 #51 [DTMV8] 1:29.147 Audi Sport Team Rosberg | Nico Müller
Q11 #27 [DTMV8] 1:29.184 Audi Sport Team Abt | Adrien Tambay
Q12 #48 [DTMV8] 1:29.211 Audi Sport Team Abt | Edoardo Mortara
Q13 #3 [DTMV8] 1:29.256 Silberpfeil Energy Mercedes-AMG | Paul di Resta
Q14 #99 [DTMV8] 1:29.280 Audi Sport Team Phoenix | Mike Rockenfeller
Q15 #84 [DTMV8] 1:29.297 Petronas Mercedes-AMG | Maximilian Götz
Q16 #36 [DTMV8] 1:29.304 BMW Team RMG | Maxime Martin
Q17 #13 [DTMV8] 1:29.350 BMW Team Schnitzer | António Félix da Costa
Q18 #22 [DTMV8] 1:29.401 Euronics/BWT Mercedes-AMG | Lucas Auer
Q19 #93 [DTMV8] 1:29.487 Audi Sport Team Phoenix | Antonio Giovinazzi
Q20 #2 [DTMV8] 1:29.519 Euronics/BWT Mercedes-AMG | Gary Paffett
Q21 #18 [DTMV8] 1:29.541 BMW Team RBM | Augusto Farfus
Q22 #6 [DTMV8] 1:29.557 Silberpfeil Energy Mercedes-AMG | Robert Wickens
Q23 #77 [DTMV8] 1:29.766 BMW Team Schnitzer | Martin Tomczyk
Q24 #8 [DTMV8] 1:29.878 gooix/Original-Teile Mercedes-AMG | Christian Vietoris

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #1 Marco Wittmann 1:28.810 BMW Team RMG
DTMV8: #1 Marco Wittmann 1:28.810 BMW Team RMG

## Fastest laps (archive)
Overall: #94 Pascal Wehrlein 1:29.891 lap 23
DTMV8: #94 Pascal Wehrlein 1:29.891 lap 23

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g2 #94 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 24L gap — | Pascal Wehrlein
 2 g1 #1 BMW Team RMG | BMW M4 DTM | Classified 24L gap 1.853 | Marco Wittmann
 3 g7 #7 BMW Team MTEK | BMW M4 DTM | Classified 24L gap 2.536 | Bruno Spengler
 4 g3 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 24L gap 2.967 | Jamie Green
 5 g9 #12 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 24L gap 3.249 | Daniel Juncadella
 6 g12 #48 Audi Sport Team Abt | Audi RS 5 DTM | Classified 24L gap 4.332 | Edoardo Mortara
 7 g20 #2 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 24L gap 8.867 | Gary Paffett
 8 g5 #31 BMW Team RBM | BMW M4 DTM | Classified 24L gap 10.039 | Tom Blomqvist
 9 g10 #51 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 24L gap 10.350 | Nico Müller
 10 g14 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 24L gap 11.001 | Mike Rockenfeller
 11 g17 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 24L gap 11.409 | António Félix da Costa
 12 g22 #6 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 24L gap 11.813 | Robert Wickens
 13 g18 #22 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 24L gap 12.234 | Lucas Auer
 14 g13 #3 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 24L gap 12.600 | Paul di Resta
 15 g21 #18 BMW Team RBM | BMW M4 DTM | Classified 24L gap 15.248 | Augusto Farfus
 16 g15 #84 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 24L gap 15.534 | Maximilian Götz
 17 g23 #77 BMW Team Schnitzer | BMW M4 DTM | Classified 24L gap 15.649 | Martin Tomczyk
 18 g16 #36 BMW Team RMG | BMW M4 DTM | Classified 24L gap 16.350 | Maxime Martin
 19 g19 #93 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 24L gap 17.132 | Antonio Giovinazzi
 20 g11 #27 Audi Sport Team Abt | Audi RS 5 DTM | RET 16L gap RET | Adrien Tambay
 21 g6 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | RET 10L gap RET | Mattias Ekström
 22 g4 #16 BMW Team MTEK | BMW M4 DTM | RET 10L gap RET | Timo Glock
 23 g8 #17 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | RET 0L gap RET | Miguel Molina
 24 g24 #8 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | RET 0L gap RET | Christian Vietoris
