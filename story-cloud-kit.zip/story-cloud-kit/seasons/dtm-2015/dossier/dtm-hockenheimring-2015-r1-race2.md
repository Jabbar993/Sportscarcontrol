# dtm-hockenheimring-2015-r1-race2

Event: DTM Hockenheimring Race 2 | Circuit: Hockenheimring | Date: 2015-05-03
Scheduled: 01:00:00 | Official duration: 1:02:43.856 | Laps (winner): 35

## Qualifying (archive order)
Q1 #99 [DTMV8] 1:34.516 Audi Sport Team Phoenix | Mike Rockenfeller
Q2 #17 [DTMV8] 1:34.546 Audi Sport Team Abt Sportsline | Miguel Molina
Q3 #5 [DTMV8] 1:34.721 Audi Sport Team Abt Sportsline | Mattias Ekström
Q4 #1 [DTMV8] 1:34.968 BMW Team RMG | Marco Wittmann
Q5 #48 [DTMV8] 1:35.089 Audi Sport Team Abt | Edoardo Mortara
Q6 #77 [DTMV8] 1:35.112 BMW Team Schnitzer | Martin Tomczyk
Q7 #13 [DTMV8] 1:35.113 BMW Team Schnitzer | António Félix da Costa
Q8 #36 [DTMV8] 1:35.304 BMW Team RMG | Maxime Martin
Q9 #6 [DTMV8] 1:35.361 Silberpfeil Energy Mercedes-AMG | Robert Wickens
Q10 #3 [DTMV8] 1:35.397 Silberpfeil Energy Mercedes-AMG | Paul di Resta
Q11 #18 [DTMV8] 1:35.446 BMW Team RBM | Augusto Farfus
Q12 #10 [DTMV8] 1:35.485 Audi Sport Team Phoenix | Timo Scheider
Q13 #7 [DTMV8] 1:35.514 BMW Team MTEK | Bruno Spengler
Q14 #51 [DTMV8] 1:35.537 Audi Sport Team Rosberg | Nico Müller
Q15 #16 [DTMV8] 1:35.577 BMW Team MTEK | Timo Glock
Q16 #94 [DTMV8] 1:35.579 gooix/Original-Teile Mercedes-AMG | Pascal Wehrlein
Q17 #53 [DTMV8] 1:35.817 Audi Sport Team Rosberg | Jamie Green
Q18 #22 [DTMV8] 1:36.017 Euronics/BWT Mercedes-AMG | Lucas Auer
Q19 #31 [DTMV8] 1:36.101 BMW Team RBM | Tom Blomqvist
Q20 #84 [DTMV8] 1:36.528 Petronas Mercedes-AMG | Maximilian Götz
Q21 #8 [DTMV8] 1:36.988 gooix/Original-Teile Mercedes-AMG | Christian Vietoris
Q22 #12 [DTMV8] 1:39.171 Petronas Mercedes-AMG | Daniel Juncadella
Q23 #2 [DTMV8] 1:35.270 Euronics/BWT Mercedes-AMG | Gary Paffett
Q24 #27 [DTMV8] 1:35.373 Audi Sport Team Abt | Adrien Tambay

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #99 Mike Rockenfeller 1:34.516 Audi Sport Team Phoenix
DTMV8: #99 Mike Rockenfeller 1:34.516 Audi Sport Team Phoenix

## Fastest laps (archive)
Overall: #10 Timo Scheider 1:35.766 lap 8
DTMV8: #10 Timo Scheider 1:35.766 lap 8

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g2 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 35L gap — | Mattias Ekström
 2 g4 #48 Audi Sport Team Abt | Audi RS 5 DTM | Classified 35L gap 7.361 | Edoardo Mortara
 3 g23 #2 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 35L gap 8.171 | Gary Paffett
 4 g6 #77 BMW Team Schnitzer | BMW M4 DTM | Classified 35L gap 18.785 | Martin Tomczyk
 5 g3 #1 BMW Team RMG | BMW M4 DTM | Classified 35L gap 28.929 | Marco Wittmann
 6 g1 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 35L gap 29.819 | Mike Rockenfeller
 7 g9 #6 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 35L gap 30.678 | Robert Wickens
 8 g15 #94 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 35L gap 34.085 | Pascal Wehrlein
 9 g12 #7 BMW Team MTEK | BMW M4 DTM | Classified 35L gap 38.929 | Bruno Spengler
 10 g14 #16 BMW Team MTEK | BMW M4 DTM | Classified 35L gap 39.812 | Timo Glock
 11 g20 #8 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 35L gap 42.630 | Christian Vietoris
 12 g11 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 35L gap 46.180 | Timo Scheider
 13 g17 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 35L gap 48.527 | Jamie Green
 14 g8 #36 BMW Team RMG | BMW M4 DTM | Classified 35L gap 49.838 | Maxime Martin
 15 g21 #12 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 35L gap 50.379 | Daniel Juncadella
 16 g19 #84 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 35L gap 53.207 | Maximilian Götz
 17 g22 #31 BMW Team RBM | BMW M4 DTM | Classified 35L gap 1:06.932 | Tom Blomqvist
 18 g5 #17 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 35L gap 1:11.439 | Miguel Molina
 19 g13 #51 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 35L gap 1:12.182 | Nico Müller
 20 g7 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 35L gap 1:21.578 | António Félix da Costa
 21 g16 #18 BMW Team RBM | BMW M4 DTM | Classified 35L gap 1:24.372 | Augusto Farfus
 22 g10 #3 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 35L gap 1:34.157 | Paul di Resta
 23 g24 #27 Audi Sport Team Abt | Audi RS 5 DTM | RET 12L gap RET | Adrien Tambay
 24 g18 #22 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | DNS 0L gap DNS | Lucas Auer
