# dtm-norisring-2015-r3-race2

Event: DTM Norisring Race 2 | Circuit: Norisring | Date: 2015-06-28
Scheduled: 01:00:00 | Official duration: 1:01:35.767 | Laps (winner): 74

## Qualifying (archive order)
Q1 #7 [DTMV8] 48.280 BMW Team MTEK | Bruno Spengler
Q2 #8 [DTMV8] 48.284 gooix/Original-Teile Mercedes-AMG | Christian Vietoris
Q3 #6 [DTMV8] 48.293 Silberpfeil Energy Mercedes-AMG | Robert Wickens
Q4 #5 [DTMV8] 48.401 Audi Sport Team Abt Sportsline | Mattias Ekström
Q5 #22 [DTMV8] 48.422 Euronics/BWT Mercedes-AMG | Lucas Auer
Q6 #94 [DTMV8] 48.425 gooix/Original-Teile Mercedes-AMG | Pascal Wehrlein
Q7 #53 [DTMV8] 48.445 Audi Sport Team Rosberg | Jamie Green
Q8 #3 [DTMV8] 48.472 Silberpfeil Energy Mercedes-AMG | Paul di Resta
Q9 #36 [DTMV8] 48.484 BMW Team RMG | Maxime Martin
Q10 #12 [DTMV8] 48.490 Petronas Mercedes-AMG | Daniel Juncadella
Q11 #2 [DTMV8] 48.516 Euronics/BWT Mercedes-AMG | Gary Paffett
Q12 #18 [DTMV8] 48.547 BMW Team RBM | Augusto Farfus
Q13 #27 [DTMV8] 48.548 Audi Sport Team Abt | Adrien Tambay
Q14 #16 [DTMV8] 48.559 BMW Team MTEK | Timo Glock
Q15 #51 [DTMV8] 48.563 Audi Sport Team Rosberg | Nico Müller
Q16 #84 [DTMV8] 48.585 Petronas Mercedes-AMG | Maximilian Götz
Q17 #13 [DTMV8] 48.610 BMW Team Schnitzer | António Félix da Costa
Q18 #48 [DTMV8] 48.620 Audi Sport Team Abt | Edoardo Mortara
Q19 #99 [DTMV8] 48.671 Audi Sport Team Phoenix | Mike Rockenfeller
Q20 #31 [DTMV8] 48.719 BMW Team RBM | Tom Blomqvist
Q21 #77 [DTMV8] 48.767 BMW Team Schnitzer | Martin Tomczyk
Q22 #1 [DTMV8] 48.815 BMW Team RMG | Marco Wittmann
Q23 #10 [DTMV8] 48.878 Audi Sport Team Phoenix | Timo Scheider
Q24 #17 [DTMV8] 48.905 Audi Sport Team Abt Sportsline | Miguel Molina

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #7 Bruno Spengler 48.280 BMW Team MTEK
DTMV8: #7 Bruno Spengler 48.280 BMW Team MTEK

## Fastest laps (archive)
Overall: #6 Robert Wickens 48.178 lap 70
DTMV8: #6 Robert Wickens 48.178 lap 70

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g3 #6 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 74L gap — | Robert Wickens
 2 g2 #8 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 74L gap 7.239 | Christian Vietoris
 3 g1 #7 BMW Team MTEK | BMW M4 DTM | Classified 74L gap 10.975 | Bruno Spengler
 4 g4 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 74L gap 11.595 | Mattias Ekström
 5 g6 #94 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 74L gap 14.956 | Pascal Wehrlein
 6 g8 #3 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 74L gap 15.378 | Paul di Resta
 7 g11 #2 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 74L gap 16.098 | Gary Paffett
 8 g10 #12 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 74L gap 17.489 | Daniel Juncadella
 9 g5 #22 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 74L gap 32.871 | Lucas Auer
 10 g9 #36 BMW Team RMG | BMW M4 DTM | Classified 74L gap 34.605 | Maxime Martin
 11 g21 #77 BMW Team Schnitzer | BMW M4 DTM | Classified 74L gap 38.455 | Martin Tomczyk
 12 g17 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 74L gap 38.937 | António Félix da Costa
 13 g22 #1 BMW Team RMG | BMW M4 DTM | Classified 74L gap 47.827 | Marco Wittmann
 14 g13 #27 Audi Sport Team Abt | Audi RS 5 DTM | Classified 73L gap 1 LAP | Adrien Tambay
 15 g18 #48 Audi Sport Team Abt | Audi RS 5 DTM | Classified 73L gap 1 LAP | Edoardo Mortara
 16 g23 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 73L gap 1 LAP | Timo Scheider
 17 g24 #17 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 73L gap 1 LAP | Miguel Molina
 18 g7 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 73L gap 1 LAP | Jamie Green
 19 g15 #51 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 65L gap 9 LAPS | Nico Müller
 20 g20 #31 BMW Team RBM | BMW M4 DTM | DSQ 73L gap DSQ | Tom Blomqvist
 21 g14 #16 BMW Team MTEK | BMW M4 DTM | RET 3L gap RET | Timo Glock
 22 g16 #84 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | RET 2L gap RET | Maximilian Götz
 23 g19 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | RET 1L gap RET | Mike Rockenfeller
 24 g12 #18 BMW Team RBM | BMW M4 DTM | RET 1L gap RET | Augusto Farfus
