# dtm-lausitzring-2015-r2-race2

Event: DTM Lausitzring Race 2 | Circuit: Lausitzring | Date: 2015-05-31
Scheduled: 01:00:00 | Official duration: 1:02:33.014 | Laps (winner): 46

## Qualifying (archive order)
Q1 #53 [DTMV8] 1:17.386 Audi Sport Team Rosberg | Jamie Green
Q2 #5 [DTMV8] 1:17.906 Audi Sport Team Abt Sportsline | Mattias Ekström
Q3 #10 [DTMV8] 1:17.931 Audi Sport Team Phoenix | Timo Scheider
Q4 #17 [DTMV8] 1:17.940 Audi Sport Team Abt Sportsline | Miguel Molina
Q5 #36 [DTMV8] 1:17.954 BMW Team RMG | Maxime Martin
Q6 #48 [DTMV8] 1:18.024 Audi Sport Team Abt | Edoardo Mortara
Q7 #18 [DTMV8] 1:18.042 BMW Team RBM | Augusto Farfus
Q8 #51 [DTMV8] 1:18.049 Audi Sport Team Rosberg | Nico Müller
Q9 #99 [DTMV8] 1:18.053 Audi Sport Team Phoenix | Mike Rockenfeller
Q10 #12 [DTMV8] 1:18.056 Petronas Mercedes-AMG | Daniel Juncadella
Q11 #2 [DTMV8] 1:18.068 Euronics/BWT Mercedes-AMG | Gary Paffett
Q12 #31 [DTMV8] 1:18.088 BMW Team RBM | Tom Blomqvist
Q13 #7 [DTMV8] 1:18.121 BMW Team MTEK | Bruno Spengler
Q14 #94 [DTMV8] 1:18.151 gooix/Original-Teile Mercedes-AMG | Pascal Wehrlein
Q15 #8 [DTMV8] 1:18.205 gooix/Original-Teile Mercedes-AMG | Christian Vietoris
Q16 #6 [DTMV8] 1:18.216 Silberpfeil Energy Mercedes-AMG | Robert Wickens
Q17 #1 [DTMV8] 1:18.241 BMW Team RMG | Marco Wittmann
Q18 #13 [DTMV8] 1:18.256 BMW Team Schnitzer | António Félix da Costa
Q19 #22 [DTMV8] 1:18.276 Euronics/BWT Mercedes-AMG | Lucas Auer
Q20 #27 [DTMV8] 1:18.334 Audi Sport Team Abt | Adrien Tambay
Q21 #16 [DTMV8] 1:18.346 BMW Team MTEK | Timo Glock
Q22 #3 [DTMV8] 1:18.449 Silberpfeil Energy Mercedes-AMG | Paul di Resta
Q23 #77 [DTMV8] 1:18.484 BMW Team Schnitzer | Martin Tomczyk
Q24 #84 [DTMV8]  Petronas Mercedes-AMG | Maximilian Götz

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #53 Jamie Green 1:17.386 Audi Sport Team Rosberg
DTMV8: #53 Jamie Green 1:17.386 Audi Sport Team Rosberg

## Fastest laps (archive)
Overall: #53 Jamie Green 1:18.504 lap 5
DTMV8: #53 Jamie Green 1:18.504 lap 5

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 46L gap — | Jamie Green
 2 g2 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 46L gap 2.144 | Mattias Ekström
 3 g4 #17 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 46L gap 5.038 | Miguel Molina
 4 g3 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 46L gap 5.678 | Timo Scheider
 5 g6 #48 Audi Sport Team Abt | Audi RS 5 DTM | Classified 46L gap 7.708 | Edoardo Mortara
 6 g10 #12 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 46L gap 9.165 | Daniel Juncadella
 7 g14 #8 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 46L gap 9.906 | Christian Vietoris
 8 g5 #36 BMW Team RMG | BMW M4 DTM | Classified 46L gap 10.789 | Maxime Martin
 9 g8 #51 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 46L gap 11.187 | Nico Müller
 10 g9 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 46L gap 12.055 | Mike Rockenfeller
 11 g23 #77 BMW Team Schnitzer | BMW M4 DTM | Classified 46L gap 12.267 | Martin Tomczyk
 12 g21 #16 BMW Team MTEK | BMW M4 DTM | Classified 46L gap 12.864 | Timo Glock
 13 g13 #94 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 46L gap 14.741 | Pascal Wehrlein
 14 g17 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 46L gap 14.750 | António Félix da Costa
 15 g22 #3 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 46L gap 15.937 | Paul di Resta
 16 g24 #84 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 46L gap 16.470 | Maximilian Götz
 17 g16 #1 BMW Team RMG | BMW M4 DTM | Classified 46L gap 19.903 | Marco Wittmann
 18 g15 #6 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 46L gap 21.325 | Robert Wickens
 19 g18 #7 BMW Team MTEK | BMW M4 DTM | Classified 46L gap 41.439 | Bruno Spengler
 20 g20 #27 Audi Sport Team Abt | Audi RS 5 DTM | Classified 42L gap 4 LAPS | Adrien Tambay
 21 g19 #22 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 36L gap 10 LAPS | Lucas Auer
 22 g7 #18 BMW Team RBM | BMW M4 DTM | RET 30L gap RET | Augusto Farfus
 23 g11 #2 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | RET 4L gap RET | Gary Paffett
 24 g12 #31 BMW Team RBM | BMW M4 DTM | RET 2L gap RET | Tom Blomqvist
