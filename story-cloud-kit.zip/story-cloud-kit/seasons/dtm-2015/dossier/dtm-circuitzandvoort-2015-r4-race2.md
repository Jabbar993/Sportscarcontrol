# dtm-circuitzandvoort-2015-r4-race2

Event: DTM Circuit Zandvoort Race 2 | Circuit: Zandvoort | Date: 2015-07-12
Scheduled: 01:00:00 | Official duration: 1:02:07.601 | Laps (winner): 39

## Qualifying (archive order)
Q1 #13 [DTMV8] 1:30.483 BMW Team Schnitzer | António Félix da Costa
Q2 #7 [DTMV8] 1:30.541 BMW Team MTEK | Bruno Spengler
Q3 #18 [DTMV8] 1:30.623 BMW Team RBM | Augusto Farfus
Q4 #1 [DTMV8] 1:30.650 BMW Team RMG | Marco Wittmann
Q5 #17 [DTMV8] 1:30.674 Audi Sport Team Abt Sportsline | Miguel Molina
Q6 #94 [DTMV8] 1:30.809 gooix/Original-Teile Mercedes-AMG | Pascal Wehrlein
Q7 #16 [DTMV8] 1:30.834 BMW Team MTEK | Timo Glock
Q8 #12 [DTMV8] 1:30.850 Petronas Mercedes-AMG | Daniel Juncadella
Q9 #2 [DTMV8] 1:30.864 Euronics/BWT Mercedes-AMG | Gary Paffett
Q10 #8 [DTMV8] 1:30.899 gooix/Original-Teile Mercedes-AMG | Christian Vietoris
Q11 #36 [DTMV8] 1:30.908 BMW Team RMG | Maxime Martin
Q12 #48 [DTMV8] 1:30.946 Audi Sport Team Abt | Edoardo Mortara
Q13 #77 [DTMV8] 1:30.970 BMW Team Schnitzer | Martin Tomczyk
Q14 #84 [DTMV8] 1:31.039 Petronas Mercedes-AMG | Maximilian Götz
Q15 #6 [DTMV8] 1:31.116 Silberpfeil Energy Mercedes-AMG | Robert Wickens
Q16 #5 [DTMV8] 1:31.150 Audi Sport Team Abt Sportsline | Mattias Ekström
Q17 #27 [DTMV8] 1:31.218 Audi Sport Team Abt | Adrien Tambay
Q18 #53 [DTMV8] 1:31.239 Audi Sport Team Rosberg | Jamie Green
Q19 #99 [DTMV8] 1:31.308 Audi Sport Team Phoenix | Mike Rockenfeller
Q20 #51 [DTMV8] 1:31.394 Audi Sport Team Rosberg | Nico Müller
Q21 #31 [DTMV8] 1:31.425 BMW Team RBM | Tom Blomqvist
Q22 #10 [DTMV8] 1:31.491 Audi Sport Team Phoenix | Timo Scheider
Q23 #3 [DTMV8] 1:31.505 Silberpfeil Energy Mercedes-AMG | Paul di Resta
Q24 #22 [DTMV8] 1:31.719 Euronics/BWT Mercedes-AMG | Lucas Auer

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #13 António Félix da Costa 1:30.483 BMW Team Schnitzer
DTMV8: #13 António Félix da Costa 1:30.483 BMW Team Schnitzer

## Fastest laps (archive)
Overall: #16 Timo Glock 1:33.635 lap 15
DTMV8: #16 Timo Glock 1:33.635 lap 15

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 39L gap — | António Félix da Costa
 2 g3 #18 BMW Team RBM | BMW M4 DTM | Classified 39L gap 0.473 | Augusto Farfus
 3 g2 #7 BMW Team MTEK | BMW M4 DTM | Classified 39L gap 1.091 | Bruno Spengler
 4 g7 #16 BMW Team MTEK | BMW M4 DTM | Classified 39L gap 1.710 | Timo Glock
 5 g4 #1 BMW Team RMG | BMW M4 DTM | Classified 39L gap 4.975 | Marco Wittmann
 6 g6 #94 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 39L gap 10.954 | Pascal Wehrlein
 7 g16 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 39L gap 11.275 | Mattias Ekström
 8 g10 #8 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 39L gap 11.567 | Christian Vietoris
 9 g17 #27 Audi Sport Team Abt | Audi RS 5 DTM | Classified 39L gap 11.910 | Adrien Tambay
 10 g9 #2 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 39L gap 12.247 | Gary Paffett
 11 g19 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 39L gap 12.661 | Mike Rockenfeller
 12 g5 #17 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 39L gap 15.130 | Miguel Molina
 13 g18 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 39L gap 15.942 | Jamie Green
 14 g23 #3 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 39L gap 16.456 | Paul di Resta
 15 g22 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 39L gap 16.853 | Timo Scheider
 16 g14 #84 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 39L gap 18.319 | Maximilian Götz
 17 g11 #36 BMW Team RMG | BMW M4 DTM | Classified 39L gap 29.708 | Maxime Martin
 18 g21 #31 BMW Team RBM | BMW M4 DTM | Classified 39L gap 32.670 | Tom Blomqvist
 19 g15 #6 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 39L gap 52.235 | Robert Wickens
 20 g24 #22 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 39L gap 52.818 | Lucas Auer
 21 g20 #51 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 31L gap 8 LAPS | Nico Müller
 22 g8 #12 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | RET 21L gap RET | Daniel Juncadella
 23 g12 #48 Audi Sport Team Abt | Audi RS 5 DTM | RET 21L gap RET | Edoardo Mortara
 24 g13 #77 BMW Team Schnitzer | BMW M4 DTM | RET 16L gap RET | Martin Tomczyk
