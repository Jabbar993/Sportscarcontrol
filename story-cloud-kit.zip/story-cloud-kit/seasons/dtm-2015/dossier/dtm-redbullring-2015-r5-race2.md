# dtm-redbullring-2015-r5-race2

Event: DTM Red Bull Ring Race 2 | Circuit: Red Bull Ring | Date: 2015-08-02
Scheduled: 01:00:00 | Official duration: 1:01:47.136 | Laps (winner): 34

## Qualifying (archive order)
Q1 #5 [DTMV8] 1:42.010 Audi Sport Team Abt Sportsline | Mattias Ekström
Q2 #99 [DTMV8] 1:42.015 Audi Sport Team Phoenix | Mike Rockenfeller
Q3 #2 [DTMV8] 1:42.155 Euronics/BWT Mercedes-AMG | Gary Paffett
Q4 #94 [DTMV8] 1:42.422 gooix/Original-Teile Mercedes-AMG | Pascal Wehrlein
Q5 #6 [DTMV8] 1:42.566 Silberpfeil Energy Mercedes-AMG | Robert Wickens
Q6 #48 [DTMV8] 1:42.659 Audi Sport Team Abt | Edoardo Mortara
Q7 #10 [DTMV8] 1:42.849 Audi Sport Team Phoenix | Timo Scheider
Q8 #8 [DTMV8] 1:42.853 gooix/Original-Teile Mercedes-AMG | Christian Vietoris
Q9 #3 [DTMV8] 1:43.064 Silberpfeil Energy Mercedes-AMG | Paul di Resta
Q10 #27 [DTMV8] 1:43.155 Audi Sport Team Abt | Adrien Tambay
Q11 #51 [DTMV8] 1:43.251 Audi Sport Team Rosberg | Nico Müller
Q12 #84 [DTMV8] 1:43.604 Petronas Mercedes-AMG | Maximilian Götz
Q13 #12 [DTMV8] 1:43.651 Petronas Mercedes-AMG | Daniel Juncadella
Q14 #77 [DTMV8] 1:43.743 BMW Team Schnitzer | Martin Tomczyk
Q15 #36 [DTMV8] 1:43.772 BMW Team RMG | Maxime Martin
Q16 #22 [DTMV8] 1:44.110 Euronics/BWT Mercedes-AMG | Lucas Auer
Q17 #53 [DTMV8] 1:44.192 Audi Sport Team Rosberg | Jamie Green
Q18 #13 [DTMV8] 1:44.251 BMW Team Schnitzer | António Félix da Costa
Q19 #17 [DTMV8] 1:44.419 Audi Sport Team Abt Sportsline | Miguel Molina
Q20 #7 [DTMV8] 1:44.509 BMW Team MTEK | Bruno Spengler
Q21 #1 [DTMV8] 1:44.707 BMW Team RMG | Marco Wittmann
Q22 #31 [DTMV8] 1:44.830 BMW Team RBM | Tom Blomqvist
Q23 #18 [DTMV8] 1:44.983 BMW Team RBM | Augusto Farfus
Q24 #16 [DTMV8] 1:45.348 BMW Team MTEK | Timo Glock

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #5 Mattias Ekström 1:42.010 Audi Sport Team Abt Sportsline
DTMV8: #5 Mattias Ekström 1:42.010 Audi Sport Team Abt Sportsline

## Fastest laps (archive)
Overall: #5 Mattias Ekström 1:41.547 lap 31
DTMV8: #5 Mattias Ekström 1:41.547 lap 31

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 34L gap — | Mattias Ekström
 2 g3 #2 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 34L gap 4.334 | Gary Paffett
 3 g6 #48 Audi Sport Team Abt | Audi RS 5 DTM | Classified 34L gap 23.555 | Edoardo Mortara
 4 g2 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 34L gap 25.445 | Mike Rockenfeller
 5 g11 #51 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 34L gap 29.964 | Nico Müller
 6 g16 #22 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 34L gap 43.726 | Lucas Auer
 7 g12 #84 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 34L gap 44.620 | Maximilian Götz
 8 g8 #8 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 34L gap 1:00.668 | Christian Vietoris
 9 g9 #3 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 34L gap 1:01.506 | Paul di Resta
 10 g18 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 34L gap 1:05.663 | António Félix da Costa
 11 g21 #1 BMW Team RMG | BMW M4 DTM | Classified 34L gap 1:06.995 | Marco Wittmann
 12 g14 #77 BMW Team Schnitzer | BMW M4 DTM | Classified 34L gap 1:07.700 | Martin Tomczyk
 13 g19 #17 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 34L gap 1:10.505 | Miguel Molina
 14 g24 #16 BMW Team MTEK | BMW M4 DTM | Classified 34L gap 1:11.638 | Timo Glock
 15 g20 #7 BMW Team MTEK | BMW M4 DTM | Classified 34L gap 1:13.669 | Bruno Spengler
 16 g10 #27 Audi Sport Team Abt | Audi RS 5 DTM | Classified 34L gap 1:15.250 | Adrien Tambay
 17 g17 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 34L gap 1:22.362 | Jamie Green
 18 g23 #18 BMW Team RBM | BMW M4 DTM | Classified 34L gap 1:26.870 | Augusto Farfus
 19 g15 #36 BMW Team RMG | BMW M4 DTM | Classified 34L gap 1:40.397 | Maxime Martin
 20 g5 #6 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 33L gap 1 LAP | Robert Wickens
 21 g4 #94 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 33L gap 1 LAP | Pascal Wehrlein
 22 g22 #31 BMW Team RBM | BMW M4 DTM | Classified 28L gap 6 LAPS | Tom Blomqvist
 23 g13 #12 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 27L gap 7 LAPS | Daniel Juncadella
 24 g7 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | DSQ 34L gap DSQ | Timo Scheider
