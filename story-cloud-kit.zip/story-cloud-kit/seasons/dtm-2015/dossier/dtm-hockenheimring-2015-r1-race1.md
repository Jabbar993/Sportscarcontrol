# dtm-hockenheimring-2015-r1-race1

Event: DTM Hockenheimring Race 1 | Circuit: Hockenheimring | Date: 2015-05-02
Scheduled: 00:40:00 | Official duration: 00:42:47.133 | Laps (winner): 26

## Qualifying (archive order)
Q1 #53 [DTMV8] 1:33.044 Audi Sport Team Rosberg | Jamie Green
Q2 #94 [DTMV8] 1:33.160 gooix/Original-Teile Mercedes-AMG | Pascal Wehrlein
Q3 #48 [DTMV8] 1:33.331 Audi Sport Team Abt | Edoardo Mortara
Q4 #51 [DTMV8] 1:33.338 Audi Sport Team Rosberg | Nico Müller
Q5 #3 [DTMV8] 1:33.340 Silberpfeil Energy Mercedes-AMG | Paul di Resta
Q6 #99 [DTMV8] 1:33.342 Audi Sport Team Phoenix | Mike Rockenfeller
Q7 #27 [DTMV8] 1:33.342 Audi Sport Team Abt | Adrien Tambay
Q8 #31 [DTMV8] 1:33.358 BMW Team RBM | Tom Blomqvist
Q9 #17 [DTMV8] 1:33.489 Audi Sport Team Abt Sportsline | Miguel Molina
Q10 #5 [DTMV8] 1:33.502 Audi Sport Team Abt Sportsline | Mattias Ekström
Q11 #36 [DTMV8] 1:33.526 BMW Team RMG | Maxime Martin
Q12 #10 [DTMV8] 1:33.567 Audi Sport Team Phoenix | Timo Scheider
Q13 #12 [DTMV8] 1:33.580 Petronas Mercedes-AMG | Daniel Juncadella
Q14 #1 [DTMV8] 1:33.591 BMW Team RMG | Marco Wittmann
Q15 #13 [DTMV8] 1:33.604 BMW Team Schnitzer | António Félix da Costa
Q16 #8 [DTMV8] 1:33.621 gooix/Original-Teile Mercedes-AMG | Christian Vietoris
Q17 #7 [DTMV8] 1:33.652 BMW Team MTEK | Bruno Spengler
Q18 #77 [DTMV8] 1:33.842 BMW Team Schnitzer | Martin Tomczyk
Q19 #84 [DTMV8] 1:34.056 Petronas Mercedes-AMG | Maximilian Götz
Q20 #16 [DTMV8] 1:34.109 BMW Team MTEK | Timo Glock
Q21 #6 [DTMV8] 1:34.121 Silberpfeil Energy Mercedes-AMG | Robert Wickens
Q22 #22 [DTMV8] 1:34.168 Euronics/BWT Mercedes-AMG | Lucas Auer
Q23 #18 [DTMV8] 1:33.310 BMW Team RBM | Augusto Farfus
Q24 #2 [DTMV8] 1:33.582 Euronics/BWT Mercedes-AMG | Gary Paffett

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #53 Jamie Green 1:33.044 Audi Sport Team Rosberg
DTMV8: #53 Jamie Green 1:33.044 Audi Sport Team Rosberg

## Fastest laps (archive)
Overall: #3 Paul di Resta 1:34.751 lap 4
DTMV8: #3 Paul di Resta 1:34.751 lap 4

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 26L gap — | Jamie Green
 2 g2 #94 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 26L gap 2.327 | Pascal Wehrlein
 3 g5 #3 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 26L gap 3.221 | Paul di Resta
 4 g3 #48 Audi Sport Team Abt | Audi RS 5 DTM | Classified 26L gap 3.930 | Edoardo Mortara
 5 g6 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 26L gap 4.667 | Mike Rockenfeller
 6 g4 #51 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 26L gap 5.203 | Nico Müller
 7 g11 #36 BMW Team RMG | BMW M4 DTM | Classified 26L gap 11.140 | Maxime Martin
 8 g20 #16 BMW Team MTEK | BMW M4 DTM | Classified 26L gap 13.840 | Timo Glock
 9 g14 #1 BMW Team RMG | BMW M4 DTM | Classified 26L gap 14.465 | Marco Wittmann
 10 g23 #18 BMW Team RBM | BMW M4 DTM | Classified 26L gap 15.458 | Augusto Farfus
 11 g17 #7 BMW Team MTEK | BMW M4 DTM | Classified 26L gap 15.968 | Bruno Spengler
 12 g10 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 26L gap 16.247 | Mattias Ekström
 13 g15 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 26L gap 18.233 | António Félix da Costa
 14 g16 #8 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 26L gap 20.797 | Christian Vietoris
 15 g7 #27 Audi Sport Team Abt | Audi RS 5 DTM | Classified 26L gap 25.038 | Adrien Tambay
 16 g19 #84 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 26L gap 25.434 | Maximilian Götz
 17 g22 #22 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | RET 16L gap RET | Lucas Auer
 18 g18 #77 BMW Team Schnitzer | BMW M4 DTM | RET 15L gap RET | Martin Tomczyk
 19 g24 #2 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | RET 15L gap RET | Gary Paffett
 20 g13 #12 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | RET 10L gap RET | Daniel Juncadella
 21 g9 #17 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | RET 9L gap RET | Miguel Molina
 22 g8 #31 BMW Team RBM | BMW M4 DTM | RET 6L gap RET | Tom Blomqvist
 23 g21 #6 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | RET 1L gap RET | Robert Wickens
 24 g12 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | RET 1L gap RET | Timo Scheider
