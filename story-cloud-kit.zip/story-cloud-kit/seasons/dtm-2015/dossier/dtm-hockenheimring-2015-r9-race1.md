# dtm-hockenheimring-2015-r9-race1

Event: DTM Hockenheimring Race 1 | Circuit: Hockenheimring | Date: 2015-10-17
Scheduled: 00:40:00 | Official duration: 00:42:27.725 | Laps (winner): 26

## Qualifying (archive order)
Q1 #36 [DTMV8] 1:32.637 BMW Team RMG | Maxime Martin
Q2 #10 [DTMV8] 1:32.711 Audi Sport Team Phoenix | Timo Scheider
Q3 #17 [DTMV8] 1:32.726 Audi Sport Team Abt Sportsline | Miguel Molina
Q4 #3 [DTMV8] 1:32.766 Silberpfeil Energy Mercedes-AMG | Paul di Resta
Q5 #53 [DTMV8] 1:32.790 Audi Sport Team Rosberg | Jamie Green
Q6 #99 [DTMV8] 1:32.793 Audi Sport Team Phoenix | Mike Rockenfeller
Q7 #5 [DTMV8] 1:32.795 Audi Sport Team Abt Sportsline | Mattias Ekström
Q8 #31 [DTMV8] 1:32.808 BMW Team RBM | Tom Blomqvist
Q9 #48 [DTMV8] 1:32.820 Audi Sport Team Abt | Edoardo Mortara
Q10 #22 [DTMV8] 1:32.828 Euronics/BWT Mercedes-AMG | Lucas Auer
Q11 #13 [DTMV8] 1:32.847 BMW Team Schnitzer | António Félix da Costa
Q12 #2 [DTMV8] 1:32.889 Euronics/BWT Mercedes-AMG | Gary Paffett
Q13 #94 [DTMV8] 1:32.892 gooix/Original-Teile Mercedes-AMG | Pascal Wehrlein
Q14 #18 [DTMV8] 1:32.905 BMW Team RBM | Augusto Farfus
Q15 #27 [DTMV8] 1:32.989 Audi Sport Team Abt | Adrien Tambay
Q16 #1 [DTMV8] 1:33.041 BMW Team RMG | Marco Wittmann
Q17 #84 [DTMV8] 1:33.072 Petronas Mercedes-AMG | Maximilian Götz
Q18 #7 [DTMV8] 1:33.089 BMW Team MTEK | Bruno Spengler
Q19 #6 [DTMV8] 1:33.165 Silberpfeil Energy Mercedes-AMG | Robert Wickens
Q20 #51 [DTMV8] 1:33.283 Audi Sport Team Rosberg | Nico Müller
Q21 #16 [DTMV8] 1:33.382 BMW Team MTEK | Timo Glock
Q22 #77 [DTMV8] 1:33.407 BMW Team Schnitzer | Martin Tomczyk
Q23 #12 [DTMV8] 1:33.511 Petronas Mercedes-AMG | Daniel Juncadella
Q24 #8 [DTMV8] 1:33.531 gooix/Original-Teile Mercedes-AMG | Christian Vietoris

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #36 Maxime Martin 1:32.637 BMW Team RMG
DTMV8: #36 Maxime Martin 1:32.637 BMW Team RMG

## Fastest laps (archive)
Overall: #10 Timo Scheider 1:34.364 lap 8
DTMV8: #10 Timo Scheider 1:34.364 lap 8

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g2 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 26L gap — | Timo Scheider
 2 g5 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 26L gap 2.875 | Jamie Green
 3 g1 #36 BMW Team RMG | BMW M4 DTM | Classified 26L gap 3.756 | Maxime Martin
 4 g4 #3 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 26L gap 4.865 | Paul di Resta
 5 g6 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 26L gap 11.708 | Mike Rockenfeller
 6 g16 #1 BMW Team RMG | BMW M4 DTM | Classified 26L gap 15.768 | Marco Wittmann
 7 g8 #31 BMW Team RBM | BMW M4 DTM | Classified 26L gap 16.972 | Tom Blomqvist
 8 g13 #94 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 26L gap 22.034 | Pascal Wehrlein
 9 g7 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 26L gap 23.719 | Mattias Ekström
 10 g17 #84 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 26L gap 24.137 | Maximilian Götz
 11 g11 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 26L gap 25.405 | António Félix da Costa
 12 g24 #8 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 26L gap 25.597 | Christian Vietoris
 13 g23 #12 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 26L gap 26.780 | Daniel Juncadella
 14 g20 #51 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 26L gap 32.108 | Nico Müller
 15 g22 #77 BMW Team Schnitzer | BMW M4 DTM | Classified 26L gap 41.299 | Martin Tomczyk
 16 g10 #22 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 26L gap 43.679 | Lucas Auer
 17 g3 #17 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 26L gap 1:01.566 | Miguel Molina
 18 g21 #16 BMW Team MTEK | BMW M4 DTM | Classified 24L gap 2 LAPS | Timo Glock
 19 g18 #7 BMW Team MTEK | BMW M4 DTM | Classified 20L gap 6 LAPS | Bruno Spengler
 20 g9 #48 Audi Sport Team Abt | Audi RS 5 DTM | RET 17L gap RET | Edoardo Mortara
 21 g19 #6 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | RET 14L gap RET | Robert Wickens
 22 g14 #18 BMW Team RBM | BMW M4 DTM | RET 4L gap RET | Augusto Farfus
 23 g12 #2 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | RET 3L gap RET | Gary Paffett
 24 g15 #27 Audi Sport Team Abt | Audi RS 5 DTM | RET 1L gap RET | Adrien Tambay
