# dtm-nurburgring-2015-r8-race1

Event: DTM Nürburgring Race 1 | Circuit: Nürburgring | Date: 2015-09-26
Scheduled: 00:40:00 | Official duration: 00:48:17.036 | Laps (winner): 25

## Qualifying (archive order)
Q1 #22 [DTMV8] 1:21.915 Euronics/BWT Mercedes-AMG | Lucas Auer
Q2 #36 [DTMV8] 1:21.999 BMW Team RMG | Maxime Martin
Q3 #94 [DTMV8] 1:22.030 gooix/Original-Teile Mercedes-AMG | Pascal Wehrlein
Q4 #7 [DTMV8] 1:22.032 BMW Team MTEK | Bruno Spengler
Q5 #48 [DTMV8] 1:22.068 Audi Sport Team Abt | Edoardo Mortara
Q6 #84 [DTMV8] 1:22.072 Petronas Mercedes-AMG | Maximilian Götz
Q7 #53 [DTMV8] 1:22.073 Audi Sport Team Rosberg | Jamie Green
Q8 #99 [DTMV8] 1:22.089 Audi Sport Team Phoenix | Mike Rockenfeller
Q9 #12 [DTMV8] 1:22.120 Petronas Mercedes-AMG | Daniel Juncadella
Q10 #17 [DTMV8] 1:22.121 Audi Sport Team Abt Sportsline | Miguel Molina
Q11 #31 [DTMV8] 1:22.151 BMW Team RBM | Tom Blomqvist
Q12 #1 [DTMV8] 1:22.156 BMW Team RMG | Marco Wittmann
Q13 #6 [DTMV8] 1:22.223 Silberpfeil Energy Mercedes-AMG | Robert Wickens
Q14 #2 [DTMV8] 1:22.242 Euronics/BWT Mercedes-AMG | Gary Paffett
Q15 #51 [DTMV8] 1:22.338 Audi Sport Team Rosberg | Nico Müller
Q16 #18 [DTMV8] 1:22.365 BMW Team RBM | Augusto Farfus
Q17 #5 [DTMV8] 1:22.372 Audi Sport Team Abt Sportsline | Mattias Ekström
Q18 #16 [DTMV8] 1:22.381 BMW Team MTEK | Timo Glock
Q19 #10 [DTMV8] 1:22.536 Audi Sport Team Phoenix | Timo Scheider
Q20 #13 [DTMV8] 1:22.574 BMW Team Schnitzer | António Félix da Costa
Q21 #8 [DTMV8] 1:22.712 gooix/Original-Teile Mercedes-AMG | Christian Vietoris
Q22 #77 [DTMV8]  BMW Team Schnitzer | Martin Tomczyk
Q23 #3 [DTMV8]  Silberpfeil Energy Mercedes-AMG | Paul di Resta
Q24 #27 [DTMV8]  Audi Sport Team Abt | Adrien Tambay

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #22 Lucas Auer 1:21.915 Euronics/BWT Mercedes-AMG
DTMV8: #22 Lucas Auer 1:21.915 Euronics/BWT Mercedes-AMG

## Fastest laps (archive)
Overall: #36 Maxime Martin 1:23.502 lap 7
DTMV8: #36 Maxime Martin 1:23.502 lap 7

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g2 #36 BMW Team RMG | BMW M4 DTM | Classified 25L gap — | Maxime Martin
 2 g5 #48 Audi Sport Team Abt | Audi RS 5 DTM | Classified 25L gap 2.543 | Edoardo Mortara
 3 g3 #94 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 25L gap 2.955 | Pascal Wehrlein
 4 g14 #2 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 25L gap 14.227 | Gary Paffett
 5 g6 #84 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 25L gap 15.293 | Maximilian Götz
 6 g1 #22 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 25L gap 16.750 | Lucas Auer
 7 g12 #1 BMW Team RMG | BMW M4 DTM | Classified 25L gap 17.349 | Marco Wittmann
 8 g13 #6 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 25L gap 20.620 | Robert Wickens
 9 g20 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 25L gap 22.189 | António Félix da Costa
 10 g17 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 25L gap 23.857 | Mattias Ekström
 11 g8 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 25L gap 24.398 | Mike Rockenfeller
 12 g22 #3 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 25L gap 25.032 | Paul di Resta
 13 g18 #16 BMW Team MTEK | BMW M4 DTM | Classified 25L gap 25.383 | Timo Glock
 14 g23 #27 Audi Sport Team Abt | Audi RS 5 DTM | Classified 25L gap 25.756 | Adrien Tambay
 15 g21 #8 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 25L gap 26.413 | Christian Vietoris
 16 g15 #51 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 25L gap 27.142 | Nico Müller
 17 g9 #12 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 25L gap 27.724 | Daniel Juncadella
 18 g16 #18 BMW Team RBM | BMW M4 DTM | Classified 25L gap 1:00.378 | Augusto Farfus
 19 g4 #7 BMW Team MTEK | BMW M4 DTM | Classified 18L gap 7 LAPS | Bruno Spengler
 20 g19 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | RET 11L gap RET | Timo Scheider
 21 g11 #31 BMW Team RBM | BMW M4 DTM | RET 9L gap RET | Tom Blomqvist
 22 g7 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | RET 0L gap RET | Jamie Green
 23 g10 #17 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | RET 0L gap RET | Miguel Molina
 24 g? #77 BMW Team Schnitzer | BMW M4 DTM | DNS 0L gap DNS | Martin Tomczyk
