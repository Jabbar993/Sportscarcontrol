# dtm-motorsportarenaosche-2015-r7-race2

Event: DTM Motorsport Arena Oschersleben Race 2 | Circuit: Oschersleben | Date: 2015-09-13
Scheduled: 01:00:00 | Official duration: 00:57:30.221 | Laps (winner): 40

## Qualifying (archive order)
Q1 #18 [DTMV8] 1:20.632 BMW Team RBM | Augusto Farfus
Q2 #31 [DTMV8] 1:20.651 BMW Team RBM | Tom Blomqvist
Q3 #94 [DTMV8] 1:20.659 gooix/Original-Teile Mercedes-AMG | Pascal Wehrlein
Q4 #13 [DTMV8] 1:20.670 BMW Team Schnitzer | António Félix da Costa
Q5 #3 [DTMV8] 1:20.687 Silberpfeil Energy Mercedes-AMG | Paul di Resta
Q6 #1 [DTMV8] 1:20.710 BMW Team RMG | Marco Wittmann
Q7 #16 [DTMV8] 1:20.743 BMW Team MTEK | Timo Glock
Q8 #8 [DTMV8] 1:20.782 gooix/Original-Teile Mercedes-AMG | Christian Vietoris
Q9 #17 [DTMV8] 1:20.915 Audi Sport Team Abt Sportsline | Miguel Molina
Q10 #7 [DTMV8] 1:20.985 BMW Team MTEK | Bruno Spengler
Q11 #2 [DTMV8] 1:20.999 Euronics/BWT Mercedes-AMG | Gary Paffett
Q12 #77 [DTMV8] 1:21.002 BMW Team Schnitzer | Martin Tomczyk
Q13 #99 [DTMV8] 1:21.043 Audi Sport Team Phoenix | Mike Rockenfeller
Q14 #53 [DTMV8] 1:21.074 Audi Sport Team Rosberg | Jamie Green
Q15 #36 [DTMV8] 1:21.104 BMW Team RMG | Maxime Martin
Q16 #48 [DTMV8] 1:21.109 Audi Sport Team Abt | Edoardo Mortara
Q17 #22 [DTMV8] 1:21.151 Euronics/BWT Mercedes-AMG | Lucas Auer
Q18 #5 [DTMV8] 1:21.153 Audi Sport Team Abt Sportsline | Mattias Ekström
Q19 #84 [DTMV8] 1:21.220 Petronas Mercedes-AMG | Maximilian Götz
Q20 #10 [DTMV8] 1:21.251 Audi Sport Team Phoenix | Timo Scheider
Q21 #51 [DTMV8] 1:21.261 Audi Sport Team Rosberg | Nico Müller
Q22 #12 [DTMV8] 1:21.319 Petronas Mercedes-AMG | Daniel Juncadella
Q23 #27 [DTMV8] 1:21.450 Audi Sport Team Abt | Adrien Tambay
Q24 #6 [DTMV8] 1:22.893 Silberpfeil Energy Mercedes-AMG | Robert Wickens

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #18 Augusto Farfus 1:20.632 BMW Team RBM
DTMV8: #18 Augusto Farfus 1:20.632 BMW Team RBM

## Fastest laps (archive)
Overall: #31 Tom Blomqvist 1:22.388 lap 17
DTMV8: #31 Tom Blomqvist 1:22.388 lap 17

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g2 #31 BMW Team RBM | BMW M4 DTM | Classified 40L gap — | Tom Blomqvist
 2 g1 #18 BMW Team RBM | BMW M4 DTM | Classified 40L gap 7.712 | Augusto Farfus
 3 g6 #1 BMW Team RMG | BMW M4 DTM | Classified 40L gap 13.080 | Marco Wittmann
 4 g4 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 40L gap 18.820 | António Félix da Costa
 5 g3 #94 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 40L gap 19.486 | Pascal Wehrlein
 6 g5 #3 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 40L gap 22.741 | Paul di Resta
 7 g7 #16 BMW Team MTEK | BMW M4 DTM | Classified 40L gap 26.196 | Timo Glock
 8 g13 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 40L gap 31.492 | Jamie Green
 9 g14 #36 BMW Team RMG | BMW M4 DTM | Classified 40L gap 32.162 | Maxime Martin
 10 g10 #7 BMW Team MTEK | BMW M4 DTM | Classified 40L gap 34.389 | Bruno Spengler
 11 g18 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 40L gap 35.173 | Mattias Ekström
 12 g20 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 40L gap 39.006 | Timo Scheider
 13 g11 #2 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 40L gap 48.174 | Gary Paffett
 14 g23 #27 Audi Sport Team Abt | Audi RS 5 DTM | Classified 40L gap 48.987 | Adrien Tambay
 15 g22 #12 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 40L gap 49.355 | Daniel Juncadella
 16 g24 #6 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 40L gap 59.030 | Robert Wickens
 17 g17 #22 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 40L gap 59.500 | Lucas Auer
 18 g19 #84 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 40L gap 1:03.738 | Maximilian Götz
 19 g16 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 40L gap 1:04.302 | Mike Rockenfeller
 20 g12 #77 BMW Team Schnitzer | BMW M4 DTM | Classified 40L gap 1:04.762 | Martin Tomczyk
 21 g8 #8 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 40L gap 1:11.880 | Christian Vietoris
 22 g15 #48 Audi Sport Team Abt | Audi RS 5 DTM | RET 21L gap RET | Edoardo Mortara
 23 g21 #51 Audi Sport Team Rosberg | Audi RS 5 DTM | RET 0L gap RET | Nico Müller
 24 g9 #17 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | RET 0L gap RET | Miguel Molina
