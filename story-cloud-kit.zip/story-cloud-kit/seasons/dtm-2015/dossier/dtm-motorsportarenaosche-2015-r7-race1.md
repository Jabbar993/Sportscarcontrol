# dtm-motorsportarenaosche-2015-r7-race1

Event: DTM Motorsport Arena Oschersleben Race 1 | Circuit: Oschersleben | Date: 2015-09-12
Scheduled: 00:40:00 | Official duration: 00:42:25.324 | Laps (winner): 28

## Qualifying (archive order)
Q1 #16 [DTMV8] 1:19.821 BMW Team MTEK | Timo Glock
Q2 #18 [DTMV8] 1:19.877 BMW Team RBM | Augusto Farfus
Q3 #31 [DTMV8] 1:19.893 BMW Team RBM | Tom Blomqvist
Q4 #13 [DTMV8] 1:19.907 BMW Team Schnitzer | António Félix da Costa
Q5 #7 [DTMV8] 1:19.927 BMW Team MTEK | Bruno Spengler
Q6 #94 [DTMV8] 1:19.935 gooix/Original-Teile Mercedes-AMG | Pascal Wehrlein
Q7 #1 [DTMV8] 1:19.992 BMW Team RMG | Marco Wittmann
Q8 #77 [DTMV8] 1:20.019 BMW Team Schnitzer | Martin Tomczyk
Q9 #17 [DTMV8] 1:20.019 Audi Sport Team Abt Sportsline | Miguel Molina
Q10 #48 [DTMV8] 1:20.076 Audi Sport Team Abt | Edoardo Mortara
Q11 #2 [DTMV8] 1:20.136 Euronics/BWT Mercedes-AMG | Gary Paffett
Q12 #36 [DTMV8] 1:20.175 BMW Team RMG | Maxime Martin
Q13 #53 [DTMV8] 1:20.206 Audi Sport Team Rosberg | Jamie Green
Q14 #12 [DTMV8] 1:20.223 Petronas Mercedes-AMG | Daniel Juncadella
Q15 #3 [DTMV8] 1:20.232 Silberpfeil Energy Mercedes-AMG | Paul di Resta
Q16 #51 [DTMV8] 1:20.380 Audi Sport Team Rosberg | Nico Müller
Q17 #99 [DTMV8] 1:20.444 Audi Sport Team Phoenix | Mike Rockenfeller
Q18 #8 [DTMV8] 1:20.452 gooix/Original-Teile Mercedes-AMG | Christian Vietoris
Q19 #10 [DTMV8] 1:20.464 Audi Sport Team Phoenix | Timo Scheider
Q20 #6 [DTMV8] 1:20.479 Silberpfeil Energy Mercedes-AMG | Robert Wickens
Q21 #84 [DTMV8] 1:20.505 Petronas Mercedes-AMG | Maximilian Götz
Q22 #27 [DTMV8] 1:20.659 Audi Sport Team Abt | Adrien Tambay
Q23 #22 [DTMV8] 1:20.702 Euronics/BWT Mercedes-AMG | Lucas Auer
Q24 #5 [DTMV8] 1:20.810 Audi Sport Team Abt Sportsline | Mattias Ekström

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #16 Timo Glock 1:19.821 BMW Team MTEK
DTMV8: #16 Timo Glock 1:19.821 BMW Team MTEK

## Fastest laps (archive)
Overall: #16 Timo Glock 1:22.245 lap 15
DTMV8: #16 Timo Glock 1:22.245 lap 15

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #16 BMW Team MTEK | BMW M4 DTM | Classified 28L gap — | Timo Glock
 2 g5 #7 BMW Team MTEK | BMW M4 DTM | Classified 28L gap 1.876 | Bruno Spengler
 3 g4 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 28L gap 7.881 | António Félix da Costa
 4 g2 #18 BMW Team RBM | BMW M4 DTM | Classified 28L gap 10.051 | Augusto Farfus
 5 g6 #94 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 28L gap 12.734 | Pascal Wehrlein
 6 g7 #1 BMW Team RMG | BMW M4 DTM | Classified 28L gap 13.399 | Marco Wittmann
 7 g3 #31 BMW Team RBM | BMW M4 DTM | Classified 28L gap 14.040 | Tom Blomqvist
 8 g8 #77 BMW Team Schnitzer | BMW M4 DTM | Classified 28L gap 18.542 | Martin Tomczyk
 9 g9 #17 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 28L gap 28.264 | Miguel Molina
 10 g14 #12 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 28L gap 30.648 | Daniel Juncadella
 11 g12 #36 BMW Team RMG | BMW M4 DTM | Classified 28L gap 33.639 | Maxime Martin
 12 g19 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 28L gap 33.928 | Timo Scheider
 13 g15 #3 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 28L gap 34.438 | Paul di Resta
 14 g23 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 28L gap 39.684 | Mattias Ekström
 15 g24 #22 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 28L gap 40.100 | Lucas Auer
 16 g21 #84 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 28L gap 40.654 | Maximilian Götz
 17 g22 #27 Audi Sport Team Abt | Audi RS 5 DTM | Classified 28L gap 41.131 | Adrien Tambay
 18 g18 #8 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 28L gap 41.898 | Christian Vietoris
 19 g10 #48 Audi Sport Team Abt | Audi RS 5 DTM | Classified 22L gap 6 LAPS | Edoardo Mortara
 20 g17 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | RET 16L gap RET | Mike Rockenfeller
 21 g11 #2 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | RET 14L gap RET | Gary Paffett
 22 g16 #51 Audi Sport Team Rosberg | Audi RS 5 DTM | RET 13L gap RET | Nico Müller
 23 g13 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | RET 8L gap RET | Jamie Green
 24 g20 #6 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | RET 4L gap RET | Robert Wickens
