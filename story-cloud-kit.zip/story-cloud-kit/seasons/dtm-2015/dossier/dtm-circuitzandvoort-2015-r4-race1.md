# dtm-circuitzandvoort-2015-r4-race1

Event: DTM Circuit Zandvoort Race 1 | Circuit: Zandvoort | Date: 2015-07-11
Scheduled: 00:40:00 | Official duration: 00:42:30.240 | Laps (winner): 25

## Qualifying (archive order)
Q1 #18 [DTMV8] 1:31.266 BMW Team RBM | Augusto Farfus
Q2 #1 [DTMV8] 1:31.274 BMW Team RMG | Marco Wittmann
Q3 #13 [DTMV8] 1:31.274 BMW Team Schnitzer | António Félix da Costa
Q4 #36 [DTMV8] 1:31.363 BMW Team RMG | Maxime Martin
Q5 #2 [DTMV8] 1:31.570 Euronics/BWT Mercedes-AMG | Gary Paffett
Q6 #53 [DTMV8] 1:31.627 Audi Sport Team Rosberg | Jamie Green
Q7 #16 [DTMV8] 1:31.647 BMW Team MTEK | Timo Glock
Q8 #31 [DTMV8] 1:31.650 BMW Team RBM | Tom Blomqvist
Q9 #7 [DTMV8] 1:31.656 BMW Team MTEK | Bruno Spengler
Q10 #17 [DTMV8] 1:31.668 Audi Sport Team Abt Sportsline | Miguel Molina
Q11 #27 [DTMV8] 1:31.686 Audi Sport Team Abt | Adrien Tambay
Q12 #48 [DTMV8] 1:31.701 Audi Sport Team Abt | Edoardo Mortara
Q13 #99 [DTMV8] 1:31.735 Audi Sport Team Phoenix | Mike Rockenfeller
Q14 #77 [DTMV8] 1:31.758 BMW Team Schnitzer | Martin Tomczyk
Q15 #94 [DTMV8] 1:31.775 gooix/Original-Teile Mercedes-AMG | Pascal Wehrlein
Q16 #51 [DTMV8] 1:31.783 Audi Sport Team Rosberg | Nico Müller
Q17 #8 [DTMV8] 1:31.855 gooix/Original-Teile Mercedes-AMG | Christian Vietoris
Q18 #6 [DTMV8] 1:31.855 Silberpfeil Energy Mercedes-AMG | Robert Wickens
Q19 #5 [DTMV8] 1:32.005 Audi Sport Team Abt Sportsline | Mattias Ekström
Q20 #22 [DTMV8] 1:32.141 Euronics/BWT Mercedes-AMG | Lucas Auer
Q21 #10 [DTMV8] 1:32.215 Audi Sport Team Phoenix | Timo Scheider
Q22 #3 [DTMV8] 1:32.251 Silberpfeil Energy Mercedes-AMG | Paul di Resta
Q23 #12 [DTMV8] 1:32.264 Petronas Mercedes-AMG | Daniel Juncadella
Q24 #84 [DTMV8] 1:32.564 Petronas Mercedes-AMG | Maximilian Götz

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #18 Augusto Farfus 1:31.266 BMW Team RBM
DTMV8: #18 Augusto Farfus 1:31.266 BMW Team RBM

## Fastest laps (archive)
Overall: #13 António Félix da Costa 1:33.462 lap 9
DTMV8: #13 António Félix da Costa 1:33.462 lap 9

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g2 #1 BMW Team RMG | BMW M4 DTM | Classified 25L gap — | Marco Wittmann
 2 g3 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 25L gap 0.464 | António Félix da Costa
 3 g4 #36 BMW Team RMG | BMW M4 DTM | Classified 25L gap 2.229 | Maxime Martin
 4 g1 #18 BMW Team RBM | BMW M4 DTM | Classified 25L gap 3.768 | Augusto Farfus
 5 g9 #7 BMW Team MTEK | BMW M4 DTM | Classified 25L gap 4.514 | Bruno Spengler
 6 g7 #16 BMW Team MTEK | BMW M4 DTM | Classified 25L gap 6.054 | Timo Glock
 7 g8 #31 BMW Team RBM | BMW M4 DTM | Classified 25L gap 7.273 | Tom Blomqvist
 8 g13 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 25L gap 7.837 | Mike Rockenfeller
 9 g16 #51 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 25L gap 8.677 | Nico Müller
 10 g15 #94 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 25L gap 9.041 | Pascal Wehrlein
 11 g5 #2 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 25L gap 12.217 | Gary Paffett
 12 g17 #8 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 25L gap 12.906 | Christian Vietoris
 13 g19 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 25L gap 15.738 | Mattias Ekström
 14 g21 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 25L gap 17.847 | Timo Scheider
 15 g24 #84 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 25L gap 20.492 | Maximilian Götz
 16 g23 #12 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 25L gap 24.636 | Daniel Juncadella
 17 g20 #22 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 25L gap 25.656 | Lucas Auer
 18 g11 #27 Audi Sport Team Abt | Audi RS 5 DTM | Classified 25L gap 30.023 | Adrien Tambay
 19 g6 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | RET 17L gap RET | Jamie Green
 20 g18 #6 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | RET 15L gap RET | Robert Wickens
 21 g10 #17 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | RET 13L gap RET | Miguel Molina
 22 g12 #48 Audi Sport Team Abt | Audi RS 5 DTM | RET 6L gap RET | Edoardo Mortara
 23 g14 #77 BMW Team Schnitzer | BMW M4 DTM | RET 5L gap RET | Martin Tomczyk
 24 g22 #3 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | RET 0L gap RET | Paul di Resta
