# dtm-hockenheimring-2015-r9-race2

Event: DTM Hockenheimring Race 2 | Circuit: Hockenheimring | Date: 2015-10-18
Scheduled: 01:00:00 | Official duration: 1:02:02.198 | Laps (winner): 39

## Qualifying (archive order)
Q1 #2 [DTMV8] 1:32.645 Euronics/BWT Mercedes-AMG | Gary Paffett
Q2 #53 [DTMV8] 1:32.683 Audi Sport Team Rosberg | Jamie Green
Q3 #5 [DTMV8] 1:32.729 Audi Sport Team Abt Sportsline | Mattias Ekström
Q4 #17 [DTMV8] 1:32.746 Audi Sport Team Abt Sportsline | Miguel Molina
Q5 #36 [DTMV8] 1:32.826 BMW Team RMG | Maxime Martin
Q6 #27 [DTMV8] 1:32.845 Audi Sport Team Abt | Adrien Tambay
Q7 #51 [DTMV8] 1:32.861 Audi Sport Team Rosberg | Nico Müller
Q8 #10 [DTMV8] 1:32.936 Audi Sport Team Phoenix | Timo Scheider
Q9 #84 [DTMV8] 1:32.958 Petronas Mercedes-AMG | Maximilian Götz
Q10 #18 [DTMV8] 1:32.976 BMW Team RBM | Augusto Farfus
Q11 #3 [DTMV8] 1:32.991 Silberpfeil Energy Mercedes-AMG | Paul di Resta
Q12 #31 [DTMV8] 1:33.056 BMW Team RBM | Tom Blomqvist
Q13 #48 [DTMV8] 1:33.064 Audi Sport Team Abt | Edoardo Mortara
Q14 #99 [DTMV8] 1:33.093 Audi Sport Team Phoenix | Mike Rockenfeller
Q15 #7 [DTMV8] 1:33.096 BMW Team MTEK | Bruno Spengler
Q16 #1 [DTMV8] 1:33.098 BMW Team RMG | Marco Wittmann
Q17 #94 [DTMV8] 1:33.120 gooix/Original-Teile Mercedes-AMG | Pascal Wehrlein
Q18 #12 [DTMV8] 1:33.163 Petronas Mercedes-AMG | Daniel Juncadella
Q19 #13 [DTMV8] 1:33.223 BMW Team Schnitzer | António Félix da Costa
Q20 #6 [DTMV8] 1:33.255 Silberpfeil Energy Mercedes-AMG | Robert Wickens
Q21 #16 [DTMV8] 1:33.481 BMW Team MTEK | Timo Glock
Q22 #22 [DTMV8] 1:33.549 Euronics/BWT Mercedes-AMG | Lucas Auer
Q23 #77 [DTMV8] 1:33.639 BMW Team Schnitzer | Martin Tomczyk
Q24 #8 [DTMV8] 1:33.801 gooix/Original-Teile Mercedes-AMG | Christian Vietoris

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #2 Gary Paffett 1:32.645 Euronics/BWT Mercedes-AMG
DTMV8: #2 Gary Paffett 1:32.645 Euronics/BWT Mercedes-AMG

## Fastest laps (archive)
Overall: #48 Edoardo Mortara 1:34.086 lap 25
DTMV8: #48 Edoardo Mortara 1:34.086 lap 25

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g2 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 39L gap — | Jamie Green
 2 g3 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 39L gap 1.351 | Mattias Ekström
 3 g13 #48 Audi Sport Team Abt | Audi RS 5 DTM | Classified 39L gap 18.914 | Edoardo Mortara
 4 g11 #3 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 39L gap 28.694 | Paul di Resta
 5 g8 #10 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 39L gap 30.581 | Timo Scheider
 6 g5 #36 BMW Team RMG | BMW M4 DTM | Classified 39L gap 38.003 | Maxime Martin
 7 g19 #13 BMW Team Schnitzer | BMW M4 DTM | Classified 39L gap 39.190 | António Félix da Costa
 8 g15 #7 BMW Team MTEK | BMW M4 DTM | Classified 39L gap 39.761 | Bruno Spengler
 9 g1 #2 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 39L gap 40.197 | Gary Paffett
 10 g23 #77 BMW Team Schnitzer | BMW M4 DTM | Classified 39L gap 47.682 | Martin Tomczyk
 11 g4 #17 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 39L gap 49.554 | Miguel Molina
 12 g18 #12 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 39L gap 55.955 | Daniel Juncadella
 13 g9 #84 Petronas Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 39L gap 1:00.941 | Maximilian Götz
 14 g10 #18 BMW Team RBM | BMW M4 DTM | Classified 39L gap 1:04.344 | Augusto Farfus
 15 g14 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 39L gap 1:07.538 | Mike Rockenfeller
 16 g7 #51 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 39L gap 1:15.417 | Nico Müller
 17 g12 #31 BMW Team RBM | BMW M4 DTM | Classified 39L gap 1:19.406 | Tom Blomqvist
 18 g20 #6 Silberpfeil Energy Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 39L gap 1:21.170 | Robert Wickens
 19 g22 #22 Euronics/BWT Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 39L gap 1:23.359 | Lucas Auer
 20 g17 #94 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | Classified 39L gap 1:31.948 | Pascal Wehrlein
 21 g21 #16 BMW Team MTEK | BMW M4 DTM | Classified 39L gap 1:54.040 | Timo Glock
 22 g6 #27 Audi Sport Team Abt | Audi RS 5 DTM | RET 15L gap RET | Adrien Tambay
 23 g24 #8 gooix/Original-Teile Mercedes-AMG | Mercedes-AMG C 63 DTM | RET 15L gap RET | Christian Vietoris
 24 g16 #1 BMW Team RMG | BMW M4 DTM | RET 7L gap RET | Marco Wittmann
