# dtm-hockenheimring-2019-r1-race1

Event: DTM Hockenheimring Race 1 | Circuit: Hockenheimring | Date: 2019-05-04
Scheduled: 00:55:00 | Official duration: 1:03:30.158 | Laps (winner): 34

## Qualifying (archive order)
Q1 #11 [Class1] 1:48.215 BMW Team RMG | Marco Wittmann
Q2 #99 [Class1] 1:48.281 Audi Sport Team Phoenix | Mike Rockenfeller
Q3 #3 [Class1] 1:49.191 R-Motorsport | Paul di Resta
Q4 #33 [Class1] 1:49.510 Audi Sport Team Rosberg | René Rast
Q5 #4 [Class1] 1:49.535 Audi Sport Team Abt Sportsline | Robin Frijns
Q6 #76 [Class1] 1:49.762 R-Motorsport | Jake Dennis
Q7 #31 [Class1] 1:50.331 BMW Team RBM | Sheldon van der Linde
Q8 #16 [Class1] 1:50.509 BMW Team RMR | Timo Glock
Q9 #47 [Class1] 1:50.626 BMW Team RBM | Joel Eriksson
Q10 #51 [Class1] 1:50.839 Audi Sport Team Abt Sportsline | Nico Müller
Q11 #23 [Class1] 1:50.884 R-Motorsport | Daniel Juncadella
Q12 #28 [Class1] 1:50.909 Audi Sport Team Phoenix | Loïc Duval
Q13 #53 [Class1] 1:50.914 Audi Sport Team Rosberg | Jamie Green
Q14 #7 [Class1] 1:51.094 BMW Team RMG | Bruno Spengler
Q15 #21 [Class1] 1:51.287 WRT Team Audi Sport | Pietro Fittipaldi
Q16 #27 [Class1] 1:52.901 WRT Team Audi Sport | Jonathan Aberdein
Q17 #62 [Class1] 1:55.470 R-Motorsport | Ferdinand Habsburg
Q18 #25 [Class1]  BMW Team RMR | Philipp Eng

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #11 Marco Wittmann 1:48.215 BMW Team RMG
Class1: #11 Marco Wittmann 1:48.215 BMW Team RMG

## Fastest laps (archive)
Overall: #16 Timo Glock 1:42.469 lap 34
Class1: #16 Timo Glock 1:42.469 lap 34

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== Class1
 1 g1 #11 BMW Team RMG | BMW M4 DTM | Classified 34L gap — | Marco Wittmann
 2 g2 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 34L gap 13.727 | Mike Rockenfeller
 3 g5 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 34L gap 34.681 | Robin Frijns
 4 g8 #16 BMW Team RMR | BMW M4 DTM | Classified 34L gap 37.407 | Timo Glock
 5 g12 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 34L gap 1:03.383 | Loïc Duval
 6 g7 #31 BMW Team RBM | BMW M4 DTM | Classified 34L gap 1:05.453 | Sheldon van der Linde
 7 g14 #7 BMW Team RMG | BMW M4 DTM | Classified 34L gap 1:13.886 | Bruno Spengler
 8 g10 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 34L gap 1:29.780 | Nico Müller
 9 g11 #23 R-Motorsport | Aston Martin Vantage DTM | Classified 34L gap 1:30.322 | Daniel Juncadella
 10 g15 #21 WRT Team Audi Sport | Audi RS 5 DTM | Classified 34L gap 1:31.873 | Pietro Fittipaldi
 11 g6 #76 R-Motorsport | Aston Martin Vantage DTM | Classified 34L gap 1:36.899 | Jake Dennis
 12 g13 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 33L gap 1 LAP | Jamie Green
 13 g9 #47 BMW Team RBM | BMW M4 DTM | Classified 33L gap 1 LAP | Joel Eriksson
 14 g18 #25 BMW Team RMR | BMW M4 DTM | Classified 33L gap 1 LAP | Philipp Eng
 15 g16 #27 WRT Team Audi Sport | Audi RS 5 DTM | Classified 33L gap 1 LAP | Jonathan Aberdein
 16 g4 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 28L gap 6 LAPS | René Rast
 17 g3 #3 R-Motorsport | Aston Martin Vantage DTM | RET 17L gap RET | Paul di Resta
 18 g17 #62 R-Motorsport | Aston Martin Vantage DTM | RET 2L gap RET | Ferdinand Habsburg
