# dtm-norisring-2019-r4-race2

Event: DTM Norisring Race 2 | Circuit: Norisring | Date: 2019-07-07
Scheduled: 00:55:00 | Official duration: 00:56:15.610 | Laps (winner): 70

## Qualifying (archive order)
Q1 #33 [Class1] 46.146 Audi Sport Team Rosberg | René Rast
Q2 #53 [Class1] 46.153 Audi Sport Team Rosberg | Jamie Green
Q3 #51 [Class1] 46.153 Audi Sport Team Abt Sportsline | Nico Müller
Q4 #28 [Class1] 46.186 Audi Sport Team Phoenix | Loïc Duval
Q5 #25 [Class1] 46.192 BMW Team RMR | Philipp Eng
Q6 #99 [Class1] 46.257 Audi Sport Team Phoenix | Mike Rockenfeller
Q7 #7 [Class1] 46.373 BMW Team RMG | Bruno Spengler
Q8 #31 [Class1] 46.490 BMW Team RBM | Sheldon van der Linde
Q9 #11 [Class1] 46.514 BMW Team RMG | Marco Wittmann
Q10 #27 [Class1] 46.564 WRT Team Audi Sport | Jonathan Aberdein
Q11 #4 [Class1] 46.591 Audi Sport Team Abt Sportsline | Robin Frijns
Q12 #47 [Class1] 46.604 BMW Team RBM | Joel Eriksson
Q13 #23 [Class1] 46.712 R-Motorsport | Daniel Juncadella
Q14 #3 [Class1] 46.745 R-Motorsport | Paul di Resta
Q15 #62 [Class1] 46.750 R-Motorsport | Ferdinand Habsburg
Q16 #21 [Class1] 46.777 WRT Team Audi Sport | Pietro Fittipaldi
Q17 #76 [Class1] 46.950 R-Motorsport | Jake Dennis
Q18 #16 [Class1] 51.883 BMW Team RMR | Timo Glock

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #33 René Rast 46.146 Audi Sport Team Rosberg
Class1: #33 René Rast 46.146 Audi Sport Team Rosberg

## Fastest laps (archive)
Overall: #51 Nico Müller 46.618 lap 8
Class1: #51 Nico Müller 46.618 lap 8

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== Class1
 1 g5 #7 BMW Team RMG | BMW M4 DTM | Classified 70L gap — | Bruno Spengler
 2 g7 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 70L gap 5.765 | Jamie Green
 3 g11 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 70L gap 6.833 | Mike Rockenfeller
 4 g10 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 70L gap 11.695 | Robin Frijns
 5 g4 #25 BMW Team RMR | BMW M4 DTM | Classified 70L gap 16.365 | Philipp Eng
 6 g3 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 70L gap 17.590 | Loïc Duval
 7 g1 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 70L gap 25.480 | René Rast
 8 g2 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 70L gap 29.080 | Nico Müller
 9 g17 #16 BMW Team RMR | BMW M4 DTM | Classified 70L gap 33.536 | Timo Glock
 10 g13 #23 R-Motorsport | Aston Martin Vantage DTM | Classified 70L gap 37.941 | Daniel Juncadella
 11 g15 #62 R-Motorsport | Aston Martin Vantage DTM | Classified 70L gap 39.516 | Ferdinand Habsburg
 12 g18 #76 R-Motorsport | Aston Martin Vantage DTM | Classified 69L gap 1 LAP | Jake Dennis
 13 g12 #47 BMW Team RBM | BMW M4 DTM | Classified 69L gap 1 LAP | Joel Eriksson
 14 g9 #27 WRT Team Audi Sport | Audi RS 5 DTM | Classified 69L gap 1 LAP | Jonathan Aberdein
 15 g16 #21 WRT Team Audi Sport | Audi RS 5 DTM | Classified 68L gap 2 LAPS | Pietro Fittipaldi
 16 g8 #11 BMW Team RMG | BMW M4 DTM | Classified 64L gap 6 LAPS | Marco Wittmann
 17 g6 #31 BMW Team RBM | BMW M4 DTM | RET 51L gap RET | Sheldon van der Linde
 18 g14 #3 R-Motorsport | Aston Martin Vantage DTM | RET 44L gap RET | Paul di Resta
