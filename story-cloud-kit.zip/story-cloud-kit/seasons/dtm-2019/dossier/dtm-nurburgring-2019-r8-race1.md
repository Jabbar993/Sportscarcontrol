# dtm-nurburgring-2019-r8-race1

Event: DTM Nürburgring Race 1 | Circuit: Nürburgring | Date: 2019-09-14
Scheduled: 00:55:00 | Official duration: 00:57:29.693 | Laps (winner): 41

## Qualifying (archive order)
Q1 #33 [Class1] 1:19.642 Audi Sport Team Rosberg | René Rast
Q2 #7 [Class1] 1:19.822 BMW Team RMG | Bruno Spengler
Q3 #51 [Class1] 1:19.908 Audi Sport Team Abt Sportsline | Nico Müller
Q4 #99 [Class1] 1:19.914 Audi Sport Team Phoenix | Mike Rockenfeller
Q5 #27 [Class1] 1:19.943 WRT Team Audi Sport | Jonathan Aberdein
Q6 #31 [Class1] 1:20.108 BMW Team RBM | Sheldon van der Linde
Q7 #16 [Class1] 1:20.141 BMW Team RMR | Timo Glock
Q8 #28 [Class1] 1:20.177 Audi Sport Team Phoenix | Loïc Duval
Q9 #53 [Class1] 1:20.196 Audi Sport Team Rosberg | Jamie Green
Q10 #4 [Class1] 1:20.215 Audi Sport Team Abt Sportsline | Robin Frijns
Q11 #11 [Class1] 1:20.468 BMW Team RMG | Marco Wittmann
Q12 #21 [Class1] 1:20.485 WRT Team Audi Sport | Pietro Fittipaldi
Q13 #3 [Class1] 1:20.502 R-Motorsport | Paul di Resta
Q14 #47 [Class1] 1:20.559 BMW Team RBM | Joel Eriksson
Q15 #23 [Class1] 1:20.750 R-Motorsport | Daniel Juncadella
Q16 #62 [Class1] 1:25.139 R-Motorsport | Ferdinand Habsburg
Q17 #25 [Class1]  BMW Team RMR | Philipp Eng
Q18 #76 [Class1]  R-Motorsport | Jake Dennis

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #33 René Rast 1:19.642 Audi Sport Team Rosberg
Class1: #33 René Rast 1:19.642 Audi Sport Team Rosberg

## Fastest laps (archive)
Overall: #33 René Rast 1:21.358 lap 2
Class1: #33 René Rast 1:21.358 lap 2

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== Class1
 1 g1 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 41L gap — | René Rast
 2 g2 #7 BMW Team RMG | BMW M4 DTM | Classified 41L gap 10.787 | Bruno Spengler
 3 g11 #11 BMW Team RMG | BMW M4 DTM | Classified 41L gap 17.299 | Marco Wittmann
 4 g5 #27 WRT Team Audi Sport | Audi RS 5 DTM | Classified 41L gap 24.537 | Jonathan Aberdein
 5 g8 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 41L gap 27.158 | Loïc Duval
 6 g9 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 41L gap 27.338 | Jamie Green
 7 g6 #31 BMW Team RBM | BMW M4 DTM | Classified 41L gap 27.650 | Sheldon van der Linde
 8 g13 #47 BMW Team RBM | BMW M4 DTM | Classified 41L gap 27.880 | Joel Eriksson
 9 g7 #16 BMW Team RMR | BMW M4 DTM | Classified 41L gap 30.924 | Timo Glock
 10 g14 #23 R-Motorsport | Aston Martin Vantage DTM | Classified 41L gap 32.590 | Daniel Juncadella
 11 g16 #62 R-Motorsport | Aston Martin Vantage DTM | Classified 41L gap 38.344 | Ferdinand Habsburg
 12 g12 #3 R-Motorsport | Aston Martin Vantage DTM | Classified 41L gap 42.114 | Paul di Resta
 13 g17 #25 BMW Team RMR | BMW M4 DTM | Classified 41L gap 45.746 | Philipp Eng
 14 g15 #21 WRT Team Audi Sport | Audi RS 5 DTM | Classified 41L gap 1:04.566 | Pietro Fittipaldi
 15 g3 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 41L gap 1:09.161 | Nico Müller
 16 g4 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | RET 25L gap RET | Mike Rockenfeller
 17 g18 #76 R-Motorsport | Aston Martin Vantage DTM | RET 25L gap RET | Jake Dennis
 18 g10 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | DSQ 41L gap DSQ | Robin Frijns
