# dtm-hockenheimring-2019-r1-race2

Event: DTM Hockenheimring Race 2 | Circuit: Hockenheimring | Date: 2019-05-05
Scheduled: 00:55:00 | Official duration: 00:58:53.819 | Laps (winner): 37

## Qualifying (archive order)
Q1 #25 [Class1] 1:28.972 BMW Team RMR | Philipp Eng
Q2 #11 [Class1] 1:29.388 BMW Team RMG | Marco Wittmann
Q3 #4 [Class1] 1:29.712 Audi Sport Team Abt Sportsline | Robin Frijns
Q4 #51 [Class1] 1:29.734 Audi Sport Team Abt Sportsline | Nico Müller
Q5 #7 [Class1] 1:29.899 BMW Team RMG | Bruno Spengler
Q6 #16 [Class1] 1:29.910 BMW Team RMR | Timo Glock
Q7 #53 [Class1] 1:29.911 Audi Sport Team Rosberg | Jamie Green
Q8 #28 [Class1] 1:29.915 Audi Sport Team Phoenix | Loïc Duval
Q9 #47 [Class1] 1:29.920 BMW Team RBM | Joel Eriksson
Q10 #31 [Class1] 1:29.957 BMW Team RBM | Sheldon van der Linde
Q11 #99 [Class1] 1:30.088 Audi Sport Team Phoenix | Mike Rockenfeller
Q12 #27 [Class1] 1:30.122 WRT Team Audi Sport | Jonathan Aberdein
Q13 #21 [Class1] 1:30.126 WRT Team Audi Sport | Pietro Fittipaldi
Q14 #23 [Class1] 1:30.273 R-Motorsport | Daniel Juncadella
Q15 #3 [Class1] 1:30.403 R-Motorsport | Paul di Resta
Q16 #33 [Class1] 1:30.568 Audi Sport Team Rosberg | René Rast
Q17 #62 [Class1] 1:30.702 R-Motorsport | Ferdinand Habsburg
Q18 #76 [Class1] 1:31.031 R-Motorsport | Jake Dennis

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #25 Philipp Eng 1:28.972 BMW Team RMR
Class1: #25 Philipp Eng 1:28.972 BMW Team RMR

## Fastest laps (archive)
Overall: #21 Pietro Fittipaldi 1:30.401 lap 35
Class1: #21 Pietro Fittipaldi 1:30.401 lap 35

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== Class1
 1 g16 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 37L gap — | René Rast
 2 g4 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 37L gap 11.922 | Nico Müller
 3 g3 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 37L gap 12.184 | Robin Frijns
 4 g1 #25 BMW Team RMR | BMW M4 DTM | Classified 37L gap 17.952 | Philipp Eng
 5 g5 #7 BMW Team RMG | BMW M4 DTM | Classified 37L gap 22.769 | Bruno Spengler
 6 g6 #16 BMW Team RMR | BMW M4 DTM | Classified 37L gap 37.615 | Timo Glock
 7 g15 #3 R-Motorsport | Aston Martin Vantage DTM | Classified 37L gap 37.920 | Paul di Resta
 8 g2 #11 BMW Team RMG | BMW M4 DTM | Classified 37L gap 44.294 | Marco Wittmann
 9 g7 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 37L gap 47.031 | Jamie Green
 10 g9 #47 BMW Team RBM | BMW M4 DTM | Classified 37L gap 49.079 | Joel Eriksson
 11 g18 #76 R-Motorsport | Aston Martin Vantage DTM | Classified 37L gap 49.114 | Jake Dennis
 12 g12 #27 WRT Team Audi Sport | Audi RS 5 DTM | Classified 37L gap 58.396 | Jonathan Aberdein
 13 g17 #62 R-Motorsport | Aston Martin Vantage DTM | Classified 37L gap 1:04.833 | Ferdinand Habsburg
 14 g10 #31 BMW Team RBM | BMW M4 DTM | Classified 37L gap 1:16.566 | Sheldon van der Linde
 15 g13 #21 WRT Team Audi Sport | Audi RS 5 DTM | Classified 36L gap 1 LAP | Pietro Fittipaldi
 16 g14 #23 R-Motorsport | Aston Martin Vantage DTM | Classified 34L gap 3 LAPS | Daniel Juncadella
 17 g11 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | RET 7L gap RET | Mike Rockenfeller
 18 g8 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | RET 6L gap RET | Loïc Duval
