# dtm-norisring-2019-r4-race1

Event: DTM Norisring Race 1 | Circuit: Norisring | Date: 2019-07-06
Scheduled: 00:55:00 | Official duration: 00:57:31.554 | Laps (winner): 69

## Qualifying (archive order)
Q1 #51 [Class1] 46.337 Audi Sport Team Abt Sportsline | Nico Müller
Q2 #25 [Class1] 46.412 BMW Team RMR | Philipp Eng
Q3 #7 [Class1] 46.492 BMW Team RMG | Bruno Spengler
Q4 #33 [Class1] 46.524 Audi Sport Team Rosberg | René Rast
Q5 #47 [Class1] 46.527 BMW Team RBM | Joel Eriksson
Q6 #11 [Class1] 46.532 BMW Team RMG | Marco Wittmann
Q7 #27 [Class1] 46.617 WRT Team Audi Sport | Jonathan Aberdein
Q8 #53 [Class1] 46.728 Audi Sport Team Rosberg | Jamie Green
Q9 #4 [Class1] 46.782 Audi Sport Team Abt Sportsline | Robin Frijns
Q10 #31 [Class1] 46.813 BMW Team RBM | Sheldon van der Linde
Q11 #23 [Class1] 46.893 R-Motorsport | Daniel Juncadella
Q12 #16 [Class1] 46.898 BMW Team RMR | Timo Glock
Q13 #21 [Class1] 47.029 WRT Team Audi Sport | Pietro Fittipaldi
Q14 #3 [Class1] 47.125 R-Motorsport | Paul di Resta
Q15 #62 [Class1] 47.221 R-Motorsport | Ferdinand Habsburg
Q16 #76 [Class1] 47.276 R-Motorsport | Jake Dennis
Q17 #28 [Class1]  Audi Sport Team Phoenix | Loïc Duval
Q18 #99 [Class1]  Audi Sport Team Phoenix | Mike Rockenfeller

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #51 Nico Müller 46.337 Audi Sport Team Abt Sportsline
Class1: #51 Nico Müller 46.337 Audi Sport Team Abt Sportsline

## Fastest laps (archive)
Overall: #51 Nico Müller 47.391 lap 33
Class1: #51 Nico Müller 47.391 lap 33

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== Class1
 1 g4 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 69L gap — | René Rast
 2 g1 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 69L gap 34.498 | Nico Müller
 3 g5 #47 BMW Team RBM | BMW M4 DTM | Classified 69L gap 34.692 | Joel Eriksson
 4 g17 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 69L gap 39.521 | Loïc Duval
 5 g3 #7 BMW Team RMG | BMW M4 DTM | Classified 69L gap 42.111 | Bruno Spengler
 6 g11 #23 R-Motorsport | Aston Martin Vantage DTM | Classified 69L gap 43.581 | Daniel Juncadella
 7 g2 #25 BMW Team RMR | BMW M4 DTM | Classified 69L gap 45.357 | Philipp Eng
 8 g6 #11 BMW Team RMG | BMW M4 DTM | Classified 69L gap 48.526 | Marco Wittmann
 9 g16 #76 R-Motorsport | Aston Martin Vantage DTM | Classified 68L gap 1 LAP | Jake Dennis
 10 g15 #62 R-Motorsport | Aston Martin Vantage DTM | Classified 68L gap 1 LAP | Ferdinand Habsburg
 11 g8 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 68L gap 1 LAP | Jamie Green
 12 g14 #3 R-Motorsport | Aston Martin Vantage DTM | Classified 67L gap 2 LAPS | Paul di Resta
 13 g7 #27 WRT Team Audi Sport | Audi RS 5 DTM | Classified 66L gap 3 LAPS | Jonathan Aberdein
 14 g10 #31 BMW Team RBM | BMW M4 DTM | RET 31L gap RET | Sheldon van der Linde
 15 g9 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | RET 28L gap RET | Robin Frijns
 16 g18 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | RET 25L gap RET | Mike Rockenfeller
 17 g12 #16 BMW Team RMR | BMW M4 DTM | RET 9L gap RET | Timo Glock
 18 g13 #21 WRT Team Audi Sport | Audi RS 5 DTM | RET 0L gap RET | Pietro Fittipaldi
