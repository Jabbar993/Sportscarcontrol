# dtm-brandshatch-2019-r6-race1

Event: DTM Brands Hatch Race 1 | Circuit: Brands Hatch | Date: 2019-08-10
Scheduled: 00:55:00 | Official duration: 00:56:39.275 | Laps (winner): 42

## Qualifying (archive order)
Q1 #11 [Class1] 1:15.654 BMW Team RMG | Marco Wittmann
Q2 #33 [Class1] 1:15.723 Audi Sport Team Rosberg | René Rast
Q3 #28 [Class1] 1:16.012 Audi Sport Team Phoenix | Loïc Duval
Q4 #3 [Class1] 1:16.067 R-Motorsport | Paul di Resta
Q5 #4 [Class1] 1:16.249 Audi Sport Team Abt Sportsline | Robin Frijns
Q6 #31 [Class1] 1:16.304 BMW Team RBM | Sheldon van der Linde
Q7 #76 [Class1] 1:16.342 R-Motorsport | Jake Dennis
Q8 #51 [Class1] 1:16.365 Audi Sport Team Abt Sportsline | Nico Müller
Q9 #16 [Class1] 1:16.384 BMW Team RMR | Timo Glock
Q10 #23 [Class1] 1:16.533 R-Motorsport | Daniel Juncadella
Q11 #25 [Class1] 1:16.541 BMW Team RMR | Philipp Eng
Q12 #99 [Class1] 1:16.600 Audi Sport Team Phoenix | Mike Rockenfeller
Q13 #53 [Class1] 1:16.675 Audi Sport Team Rosberg | Jamie Green
Q14 #7 [Class1] 1:17.087 BMW Team RMG | Bruno Spengler
Q15 #62 [Class1] 1:17.510 R-Motorsport | Ferdinand Habsburg
Q16 #21 [Class1] 1:27.390 WRT Team Audi Sport | Pietro Fittipaldi
Q17 #47 [Class1]  BMW Team RBM | Joel Eriksson
Q18 #27 [Class1]  WRT Team Audi Sport | Jonathan Aberdein

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #11 Marco Wittmann 1:15.654 BMW Team RMG
Class1: #11 Marco Wittmann 1:15.654 BMW Team RMG

## Fastest laps (archive)
Overall: #25 Philipp Eng 1:17.862 lap 28
Class1: #25 Philipp Eng 1:17.862 lap 28

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== Class1
 1 g1 #11 BMW Team RMG | BMW M4 DTM | Classified 42L gap — | Marco Wittmann
 2 g2 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 42L gap 0.374 | René Rast
 3 g8 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 42L gap 8.566 | Nico Müller
 4 g5 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 42L gap 15.646 | Robin Frijns
 5 g3 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 42L gap 18.236 | Loïc Duval
 6 g11 #25 BMW Team RMR | BMW M4 DTM | Classified 42L gap 18.813 | Philipp Eng
 7 g12 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 42L gap 20.056 | Mike Rockenfeller
 8 g6 #31 BMW Team RBM | BMW M4 DTM | Classified 42L gap 29.909 | Sheldon van der Linde
 9 g16 #27 WRT Team Audi Sport | Audi RS 5 DTM | Classified 42L gap 37.087 | Jonathan Aberdein
 10 g10 #23 R-Motorsport | Aston Martin Vantage DTM | Classified 42L gap 37.385 | Daniel Juncadella
 11 g13 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 42L gap 48.996 | Jamie Green
 12 g14 #7 BMW Team RMG | BMW M4 DTM | Classified 42L gap 52.465 | Bruno Spengler
 13 g9 #16 BMW Team RMR | BMW M4 DTM | Classified 42L gap 1:05.237 | Timo Glock
 14 g4 #3 R-Motorsport | Aston Martin Vantage DTM | Classified 39L gap 3 LAPS | Paul di Resta
 15 g15 #62 R-Motorsport | Aston Martin Vantage DTM | Classified 38L gap 4 LAPS | Ferdinand Habsburg
 16 g7 #76 R-Motorsport | Aston Martin Vantage DTM | RET 0L gap RET | Jake Dennis
 17 g17 #21 WRT Team Audi Sport | Audi RS 5 DTM | DNS 0L gap DNS | Pietro Fittipaldi
 18 g? #47 BMW Team RBM | BMW M4 DTM | DNS 0L gap DNS | Joel Eriksson
