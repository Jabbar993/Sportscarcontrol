# dtm-misanoworldcircuit-2019-r3-race1

Event: DTM Misano World Circuit Race 1 | Circuit: Misano | Date: 2019-06-08
Scheduled: 00:55:00 | Official duration: 1:00:42.631 | Laps (winner): 39

## Qualifying (archive order)
Q1 #33 [Class1] 1:25.294 Audi Sport Team Rosberg | René Rast
Q2 #27 [Class1] 1:25.362 WRT Team Audi Sport | Jonathan Aberdein
Q3 #28 [Class1] 1:25.543 Audi Sport Team Phoenix | Loïc Duval
Q4 #4 [Class1] 1:25.680 Audi Sport Team Abt Sportsline | Robin Frijns
Q5 #31 [Class1] 1:25.840 BMW Team RBM | Sheldon van der Linde
Q6 #7 [Class1] 1:25.900 BMW Team RMG | Bruno Spengler
Q7 #25 [Class1] 1:25.943 BMW Team RMR | Philipp Eng
Q8 #51 [Class1] 1:25.978 Audi Sport Team Abt Sportsline | Nico Müller
Q9 #99 [Class1] 1:26.032 Audi Sport Team Phoenix | Mike Rockenfeller
Q10 #16 [Class1] 1:26.153 BMW Team RMR | Timo Glock
Q11 #21 [Class1] 1:26.583 WRT Team Audi Sport | Pietro Fittipaldi
Q12 #47 [Class1] 1:26.832 BMW Team RBM | Joel Eriksson
Q13 #76 [Class1] 1:26.841 R-Motorsport | Jake Dennis
Q14 #23 [Class1] 1:26.887 R-Motorsport | Daniel Juncadella
Q15 #34 [Class1] 1:27.037 WRT Team Audi Sport | Andrea Dovizioso
Q16 #62 [Class1] 1:27.191 R-Motorsport | Ferdinand Habsburg
Q17 #3 [Class1] 1:27.772 R-Motorsport | Paul di Resta

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #33 René Rast 1:25.294 Audi Sport Team Rosberg
Class1: #33 René Rast 1:25.294 Audi Sport Team Rosberg

## Fastest laps (archive)
Overall: #25 Philipp Eng 1:27.991 lap 13
Class1: #25 Philipp Eng 1:27.991 lap 13

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== Class1
 1 g18 #11 BMW Team RMG | BMW M4 DTM | Classified 39L gap — | Marco Wittmann
 2 g1 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 39L gap 8.238 | René Rast
 3 g3 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 39L gap 17.686 | Loïc Duval
 4 g6 #7 BMW Team RMG | BMW M4 DTM | Classified 39L gap 22.853 | Bruno Spengler
 5 g8 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 39L gap 28.503 | Nico Müller
 6 g9 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 39L gap 32.467 | Mike Rockenfeller
 7 g7 #25 BMW Team RMR | BMW M4 DTM | Classified 39L gap 44.922 | Philipp Eng
 8 g2 #27 WRT Team Audi Sport | Audi RS 5 DTM | Classified 39L gap 47.238 | Jonathan Aberdein
 9 g5 #31 BMW Team RBM | BMW M4 DTM | Classified 39L gap 48.347 | Sheldon van der Linde
 10 g10 #16 BMW Team RMR | BMW M4 DTM | Classified 39L gap 48.429 | Timo Glock
 11 g11 #21 WRT Team Audi Sport | Audi RS 5 DTM | Classified 39L gap 50.043 | Pietro Fittipaldi
 12 g15 #34 WRT Team Audi Sport | Audi RS 5 DTM | Classified 39L gap 57.138 | Andrea Dovizioso
 13 g14 #23 R-Motorsport | Aston Martin Vantage DTM | Classified 39L gap 58.948 | Daniel Juncadella
 14 g16 #62 R-Motorsport | Aston Martin Vantage DTM | Classified 39L gap 1:01.928 | Ferdinand Habsburg
 15 g13 #76 R-Motorsport | Aston Martin Vantage DTM | Classified 39L gap 1:08.229 | Jake Dennis
 16 g17 #3 R-Motorsport | Aston Martin Vantage DTM | Classified 31L gap 8 LAPS | Paul di Resta
 17 g4 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | RET 16L gap RET | Robin Frijns
 18 g12 #47 BMW Team RBM | BMW M4 DTM | RET 2L gap RET | Joel Eriksson
