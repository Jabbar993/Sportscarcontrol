# dtm-misanoworldcircuit-2019-r3-race2

Event: DTM Misano World Circuit Race 2 | Circuit: Misano | Date: 2019-06-09
Scheduled: 00:55:00 | Official duration: 00:57:37.468 | Laps (winner): 38

## Qualifying (archive order)
Q1 #33 [Class1] 1:25.384 Audi Sport Team Rosberg | René Rast
Q2 #4 [Class1] 1:25.454 Audi Sport Team Abt Sportsline | Robin Frijns
Q3 #27 [Class1] 1:25.584 WRT Team Audi Sport | Jonathan Aberdein
Q4 #51 [Class1] 1:25.632 Audi Sport Team Abt Sportsline | Nico Müller
Q5 #21 [Class1] 1:25.659 WRT Team Audi Sport | Pietro Fittipaldi
Q6 #11 [Class1] 1:25.764 BMW Team RMG | Marco Wittmann
Q7 #28 [Class1] 1:25.767 Audi Sport Team Phoenix | Loïc Duval
Q8 #47 [Class1] 1:25.803 BMW Team RBM | Joel Eriksson
Q9 #25 [Class1] 1:25.805 BMW Team RMR | Philipp Eng
Q10 #16 [Class1] 1:25.814 BMW Team RMR | Timo Glock
Q11 #31 [Class1] 1:25.981 BMW Team RBM | Sheldon van der Linde
Q12 #99 [Class1] 1:26.005 Audi Sport Team Phoenix | Mike Rockenfeller
Q13 #7 [Class1] 1:26.458 BMW Team RMG | Bruno Spengler
Q14 #34 [Class1] 1:26.703 WRT Team Audi Sport | Andrea Dovizioso
Q15 #76 [Class1] 1:26.831 R-Motorsport | Jake Dennis
Q16 #23 [Class1] 1:27.009 R-Motorsport | Daniel Juncadella
Q17 #3 [Class1] 1:27.198 R-Motorsport | Paul di Resta
Q18 #62 [Class1] 1:27.325 R-Motorsport | Ferdinand Habsburg

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #33 René Rast 1:25.384 Audi Sport Team Rosberg
Class1: #33 René Rast 1:25.384 Audi Sport Team Rosberg

## Fastest laps (archive)
Overall: #4 Robin Frijns 1:27.291 lap 2
Class1: #4 Robin Frijns 1:27.291 lap 2

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== Class1
 1 g4 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 38L gap — | Nico Müller
 2 g9 #25 BMW Team RMR | BMW M4 DTM | Classified 38L gap 7.628 | Philipp Eng
 3 g1 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 38L gap 16.804 | René Rast
 4 g2 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 38L gap 20.072 | Robin Frijns
 5 g5 #21 WRT Team Audi Sport | Audi RS 5 DTM | Classified 38L gap 20.430 | Pietro Fittipaldi
 6 g8 #47 BMW Team RBM | BMW M4 DTM | Classified 38L gap 23.645 | Joel Eriksson
 7 g3 #27 WRT Team Audi Sport | Audi RS 5 DTM | Classified 38L gap 24.813 | Jonathan Aberdein
 8 g13 #7 BMW Team RMG | BMW M4 DTM | Classified 38L gap 28.460 | Bruno Spengler
 9 g11 #31 BMW Team RBM | BMW M4 DTM | Classified 38L gap 29.003 | Sheldon van der Linde
 10 g12 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 38L gap 47.798 | Mike Rockenfeller
 11 g7 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 38L gap 47.902 | Loïc Duval
 12 g18 #62 R-Motorsport | Aston Martin Vantage DTM | Classified 38L gap 48.678 | Ferdinand Habsburg
 13 g15 #76 R-Motorsport | Aston Martin Vantage DTM | Classified 38L gap 51.588 | Jake Dennis
 14 g16 #23 R-Motorsport | Aston Martin Vantage DTM | Classified 38L gap 1:14.053 | Daniel Juncadella
 15 g14 #34 WRT Team Audi Sport | Audi RS 5 DTM | Classified 38L gap 1:16.392 | Andrea Dovizioso
 16 g10 #16 BMW Team RMR | BMW M4 DTM | RET 8L gap RET | Timo Glock
 17 g17 #3 R-Motorsport | Aston Martin Vantage DTM | RET 6L gap RET | Paul di Resta
 18 g6 #11 BMW Team RMG | BMW M4 DTM | RET 0L gap RET | Marco Wittmann
