# dtm-circuitzolder-2019-r2-race2

Event: DTM Circuit Zolder Race 2 | Circuit: Zolder | Date: 2019-05-19
Scheduled: 00:55:00 | Official duration: 00:59:24.539 | Laps (winner): 39

## Qualifying (archive order)
Q1 #31 [Class1] 1:21.590 BMW Team RBM | Sheldon van der Linde
Q2 #33 [Class1] 1:21.596 Audi Sport Team Rosberg | René Rast
Q3 #25 [Class1] 1:21.714 BMW Team RMR | Philipp Eng
Q4 #4 [Class1] 1:21.733 Audi Sport Team Abt Sportsline | Robin Frijns
Q5 #16 [Class1] 1:21.803 BMW Team RMR | Timo Glock
Q6 #99 [Class1] 1:22.133 Audi Sport Team Phoenix | Mike Rockenfeller
Q7 #11 [Class1] 1:22.142 BMW Team RMG | Marco Wittmann
Q8 #27 [Class1] 1:22.246 WRT Team Audi Sport | Jonathan Aberdein
Q9 #53 [Class1] 1:22.255 Audi Sport Team Rosberg | Jamie Green
Q10 #47 [Class1] 1:22.291 BMW Team RBM | Joel Eriksson
Q11 #28 [Class1] 1:22.426 Audi Sport Team Phoenix | Loïc Duval
Q12 #51 [Class1] 1:22.433 Audi Sport Team Abt Sportsline | Nico Müller
Q13 #76 [Class1] 1:22.563 R-Motorsport | Jake Dennis
Q14 #21 [Class1] 1:22.582 WRT Team Audi Sport | Pietro Fittipaldi
Q15 #7 [Class1] 1:22.613 BMW Team RMG | Bruno Spengler
Q16 #23 [Class1] 1:23.103 R-Motorsport | Daniel Juncadella
Q17 #62 [Class1] 1:23.703 R-Motorsport | Ferdinand Habsburg
Q18 #3 [Class1] 1:24.088 R-Motorsport | Paul di Resta

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #31 Sheldon van der Linde 1:21.590 BMW Team RBM
Class1: #31 Sheldon van der Linde 1:21.590 BMW Team RBM

## Fastest laps (archive)
Overall: #25 Philipp Eng 1:23.600 lap 10
Class1: #25 Philipp Eng 1:23.600 lap 10

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== Class1
 1 g2 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 39L gap — | René Rast
 2 g3 #25 BMW Team RMR | BMW M4 DTM | Classified 39L gap 9.845 | Philipp Eng
 3 g9 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 39L gap 11.791 | Jamie Green
 4 g6 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 39L gap 12.601 | Mike Rockenfeller
 5 g1 #31 BMW Team RBM | BMW M4 DTM | Classified 39L gap 13.195 | Sheldon van der Linde
 6 g13 #76 R-Motorsport | Aston Martin Vantage DTM | Classified 39L gap 19.825 | Jake Dennis
 7 g15 #7 BMW Team RMG | BMW M4 DTM | Classified 39L gap 20.468 | Bruno Spengler
 8 g12 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 39L gap 21.563 | Nico Müller
 9 g14 #21 WRT Team Audi Sport | Audi RS 5 DTM | Classified 39L gap 22.661 | Pietro Fittipaldi
 10 g10 #47 BMW Team RBM | BMW M4 DTM | Classified 39L gap 23.550 | Joel Eriksson
 11 g11 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 39L gap 23.648 | Loïc Duval
 12 g8 #27 WRT Team Audi Sport | Audi RS 5 DTM | Classified 39L gap 26.793 | Jonathan Aberdein
 13 g7 #11 BMW Team RMG | BMW M4 DTM | Classified 39L gap 39.780 | Marco Wittmann
 14 g5 #16 BMW Team RMR | BMW M4 DTM | Classified 38L gap 1 LAP | Timo Glock
 15 g16 #23 R-Motorsport | Aston Martin Vantage DTM | RET 27L gap RET | Daniel Juncadella
 16 g4 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | RET 21L gap RET | Robin Frijns
 17 g17 #62 R-Motorsport | Aston Martin Vantage DTM | RET 17L gap RET | Ferdinand Habsburg
 18 g18 #3 R-Motorsport | Aston Martin Vantage DTM | DNS 0L gap DNS | Paul di Resta
