# dtm-hockenheimring-2019-r9-race1

Event: DTM Hockenheimring Race 1 | Circuit: Hockenheimring | Date: 2019-10-05
Scheduled: 00:55:00 | Official duration: 1:01:00.948 | Laps (winner): 38

## Qualifying (archive order)
Q1 #33 [Class1] 1:45.552 Audi Sport Team Rosberg | René Rast
Q2 #11 [Class1] 1:45.679 BMW Team RMG | Marco Wittmann
Q3 #99 [Class1] 1:45.783 Audi Sport Team Phoenix | Mike Rockenfeller
Q4 #27 [Class1] 1:45.928 WRT Team Audi Sport | Jonathan Aberdein
Q5 #28 [Class1] 1:45.939 Audi Sport Team Phoenix | Loïc Duval
Q6 #1 [Class1] 1:46.206 Team Kunimitsu | Jenson Button
Q7 #16 [Class1] 1:46.315 BMW Team RMR | Timo Glock
Q8 #4 [Class1] 1:46.351 Audi Sport Team Abt Sportsline | Robin Frijns
Q9 #31 [Class1] 1:46.383 BMW Team RBM | Sheldon van der Linde
Q10 #47 [Class1] 1:46.628 BMW Team RBM | Joel Eriksson
Q11 #51 [Class1] 1:46.789 Audi Sport Team Abt Sportsline | Nico Müller
Q12 #62 [Class1] 1:46.791 R-Motorsport | Ferdinand Habsburg
Q13 #23 [Class1] 1:46.986 R-Motorsport | Daniel Juncadella
Q14 #76 [Class1] 1:46.988 R-Motorsport | Jake Dennis
Q15 #7 [Class1] 1:47.026 BMW Team RMG | Bruno Spengler
Q16 #3 [Class1] 1:47.090 R-Motorsport | Paul di Resta
Q17 #25 [Class1] 1:47.548 BMW Team RMR | Philipp Eng
Q18 #53 [Class1] 1:47.590 Audi Sport Team Rosberg | Jamie Green
Q19 #21 [Class1] 1:47.792 WRT Team Audi Sport | Pietro Fittipaldi
Q20 #37 [Class1] 1:49.181 Lexus Gazoo Racing Team KeePer TOM'S | Nick Cassidy
Q21 #35 [Class1] 1:49.349 Nismo Team Motul Autech GT Sport | Tsugio Matsuda

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #33 René Rast 1:45.552 Audi Sport Team Rosberg
Class1: #33 René Rast 1:45.552 Audi Sport Team Rosberg

## Fastest laps (archive)
Overall: #51 Nico Müller 1:30.927 lap 25
Class1: #51 Nico Müller 1:30.927 lap 25

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== Class1
 1 g1 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 38L gap — | René Rast
 2 g2 #11 BMW Team RMG | BMW M4 DTM | Classified 38L gap 1.693 | Marco Wittmann
 3 g3 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 38L gap 10.697 | Mike Rockenfeller
 4 g8 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 38L gap 17.795 | Robin Frijns
 5 g5 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 38L gap 24.224 | Loïc Duval
 6 g7 #16 BMW Team RMR | BMW M4 DTM | Classified 38L gap 25.760 | Timo Glock
 7 g15 #3 R-Motorsport | Aston Martin Vantage DTM | Classified 38L gap 26.439 | Paul di Resta
 8 g14 #7 BMW Team RMG | BMW M4 DTM | Classified 38L gap 27.270 | Bruno Spengler
 9 g6 #1 Team Kunimitsu | Honda NSX-GT | Classified 38L gap 31.492 | Jenson Button
 10 g10 #47 BMW Team RBM | BMW M4 DTM | Classified 38L gap 31.868 | Joel Eriksson
 11 g13 #76 R-Motorsport | Aston Martin Vantage DTM | Classified 38L gap 37.997 | Jake Dennis
 12 g17 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 38L gap 38.442 | Jamie Green
 13 g19 #37 Lexus Gazoo Racing Team KeePer TOM'S | Lexus LC500 | Classified 38L gap 40.958 | Ryo Hirakawa
 14 g4 #27 WRT Team Audi Sport | Audi RS 5 DTM | Classified 38L gap 46.931 | Jonathan Aberdein
 15 g18 #21 WRT Team Audi Sport | Audi RS 5 DTM | Classified 38L gap 59.196 | Pietro Fittipaldi
 16 g9 #31 BMW Team RBM | BMW M4 DTM | Classified 38L gap 59.602 | Sheldon van der Linde
 17 g11 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 38L gap 1:01.596 | Nico Müller
 18 g20 #35 Nismo Team Motul Autech GT Sport | Nissan GT-R NISMO GT500 | RET 21L gap RET | Tsugio Matsuda
 19 g12 #23 R-Motorsport | Aston Martin Vantage DTM | RET 20L gap RET | Daniel Juncadella
 20 g16 #25 BMW Team RMR | BMW M4 DTM | RET 17L gap RET | Philipp Eng
 21 g? #62 R-Motorsport | Aston Martin Vantage DTM | DNS 0L gap DNS | Ferdinand Habsburg
