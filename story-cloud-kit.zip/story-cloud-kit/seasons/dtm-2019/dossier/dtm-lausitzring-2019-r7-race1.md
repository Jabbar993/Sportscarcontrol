# dtm-lausitzring-2019-r7-race1

Event: DTM Lausitzring Race 1 | Circuit: Lausitzring | Date: 2019-08-24
Scheduled: 00:55:00 | Official duration: 00:56:53.891 | Laps (winner): 34

## Qualifying (archive order)
Q1 #33 [Class1] 1:35.241 Audi Sport Team Rosberg | René Rast
Q2 #53 [Class1] 1:35.286 Audi Sport Team Rosberg | Jamie Green
Q3 #51 [Class1] 1:35.438 Audi Sport Team Abt Sportsline | Nico Müller
Q4 #4 [Class1] 1:35.537 Audi Sport Team Abt Sportsline | Robin Frijns
Q5 #11 [Class1] 1:35.581 BMW Team RMG | Marco Wittmann
Q6 #99 [Class1] 1:35.595 Audi Sport Team Phoenix | Mike Rockenfeller
Q7 #21 [Class1] 1:35.736 WRT Team Audi Sport | Pietro Fittipaldi
Q8 #25 [Class1] 1:35.760 BMW Team RMR | Philipp Eng
Q9 #16 [Class1] 1:35.926 BMW Team RMR | Timo Glock
Q10 #47 [Class1] 1:35.970 BMW Team RBM | Joel Eriksson
Q11 #28 [Class1] 1:36.001 Audi Sport Team Phoenix | Loïc Duval
Q12 #7 [Class1] 1:36.052 BMW Team RMG | Bruno Spengler
Q13 #76 [Class1] 1:36.134 R-Motorsport | Jake Dennis
Q14 #27 [Class1] 1:36.189 WRT Team Audi Sport | Jonathan Aberdein
Q15 #31 [Class1] 1:36.198 BMW Team RBM | Sheldon van der Linde
Q16 #3 [Class1] 1:36.524 R-Motorsport | Paul di Resta
Q17 #23 [Class1] 1:37.012 R-Motorsport | Daniel Juncadella
Q18 #62 [Class1] 1:38.487 R-Motorsport | Ferdinand Habsburg

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #33 René Rast 1:35.241 Audi Sport Team Rosberg
Class1: #33 René Rast 1:35.241 Audi Sport Team Rosberg

## Fastest laps (archive)
Overall: #4 Robin Frijns 1:38.176 lap 16
Class1: #4 Robin Frijns 1:38.176 lap 16

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== Class1
 1 g3 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 34L gap — | Nico Müller
 2 g4 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 34L gap 2.496 | Robin Frijns
 3 g6 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 34L gap 3.206 | Mike Rockenfeller
 4 g5 #11 BMW Team RMG | BMW M4 DTM | Classified 34L gap 5.807 | Marco Wittmann
 5 g8 #25 BMW Team RMR | BMW M4 DTM | Classified 34L gap 13.477 | Philipp Eng
 6 g11 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 34L gap 14.742 | Loïc Duval
 7 g7 #21 WRT Team Audi Sport | Audi RS 5 DTM | Classified 34L gap 16.859 | Pietro Fittipaldi
 8 g10 #47 BMW Team RBM | BMW M4 DTM | Classified 34L gap 17.532 | Joel Eriksson
 9 g12 #7 BMW Team RMG | BMW M4 DTM | Classified 34L gap 21.472 | Bruno Spengler
 10 g2 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 34L gap 24.318 | Jamie Green
 11 g13 #76 R-Motorsport | Aston Martin Vantage DTM | Classified 34L gap 34.098 | Jake Dennis
 12 g16 #23 R-Motorsport | Aston Martin Vantage DTM | Classified 34L gap 34.511 | Daniel Juncadella
 13 g15 #3 R-Motorsport | Aston Martin Vantage DTM | Classified 34L gap 43.357 | Paul di Resta
 14 g17 #27 WRT Team Audi Sport | Audi RS 5 DTM | Classified 34L gap 45.084 | Jonathan Aberdein
 15 g18 #62 R-Motorsport | Aston Martin Vantage DTM | Classified 34L gap 51.948 | Ferdinand Habsburg
 16 g14 #31 BMW Team RBM | BMW M4 DTM | Classified 34L gap 1:01.608 | Sheldon van der Linde
 17 g9 #16 BMW Team RMR | BMW M4 DTM | RET 17L gap RET | Timo Glock
 18 g1 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | RET 8L gap RET | René Rast
