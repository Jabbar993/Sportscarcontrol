# dtm-circuitzolder-2019-r2-race1

Event: DTM Circuit Zolder Race 1 | Circuit: Zolder | Date: 2019-05-18
Scheduled: 00:55:00 | Official duration: 00:59:34.758 | Laps (winner): 39

## Qualifying (archive order)
Q1 #11 [Class1] 1:21.307 BMW Team RMG | Marco Wittmann
Q2 #33 [Class1] 1:21.349 Audi Sport Team Rosberg | René Rast
Q3 #7 [Class1] 1:21.614 BMW Team RMG | Bruno Spengler
Q4 #31 [Class1] 1:21.744 BMW Team RBM | Sheldon van der Linde
Q5 #4 [Class1] 1:21.911 Audi Sport Team Abt Sportsline | Robin Frijns
Q6 #16 [Class1] 1:21.940 BMW Team RMR | Timo Glock
Q7 #25 [Class1] 1:21.995 BMW Team RMR | Philipp Eng
Q8 #51 [Class1] 1:22.079 Audi Sport Team Abt Sportsline | Nico Müller
Q9 #47 [Class1] 1:22.082 BMW Team RBM | Joel Eriksson
Q10 #53 [Class1] 1:22.143 Audi Sport Team Rosberg | Jamie Green
Q11 #21 [Class1] 1:22.154 WRT Team Audi Sport | Pietro Fittipaldi
Q12 #27 [Class1] 1:22.188 WRT Team Audi Sport | Jonathan Aberdein
Q13 #76 [Class1] 1:22.215 R-Motorsport | Jake Dennis
Q14 #28 [Class1] 1:22.519 Audi Sport Team Phoenix | Loïc Duval
Q15 #23 [Class1] 1:22.675 R-Motorsport | Daniel Juncadella
Q16 #99 [Class1] 1:22.684 Audi Sport Team Phoenix | Mike Rockenfeller
Q17 #3 [Class1] 1:22.694 R-Motorsport | Paul di Resta
Q18 #62 [Class1] 1:23.240 R-Motorsport | Ferdinand Habsburg

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #11 Marco Wittmann 1:21.307 BMW Team RMG
Class1: #11 Marco Wittmann 1:21.307 BMW Team RMG

## Fastest laps (archive)
Overall: #4 Robin Frijns 1:23.751 lap 23
Class1: #4 Robin Frijns 1:23.751 lap 23

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== Class1
 1 g7 #25 BMW Team RMR | BMW M4 DTM | Classified 39L gap — | Philipp Eng
 2 g9 #47 BMW Team RBM | BMW M4 DTM | Classified 39L gap 8.645 | Joel Eriksson
 3 g8 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 39L gap 8.829 | Nico Müller
 4 g14 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 39L gap 18.159 | Loïc Duval
 5 g16 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 39L gap 24.502 | Mike Rockenfeller
 6 g10 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 39L gap 32.318 | Jamie Green
 7 g1 #11 BMW Team RMG | BMW M4 DTM | Classified 39L gap 32.746 | Marco Wittmann
 8 g17 #3 R-Motorsport | Aston Martin Vantage DTM | Classified 39L gap 35.875 | Paul di Resta
 9 g18 #62 R-Motorsport | Aston Martin Vantage DTM | Classified 39L gap 38.858 | Ferdinand Habsburg
 10 g3 #7 BMW Team RMG | BMW M4 DTM | Classified 39L gap 39.874 | Bruno Spengler
 11 g4 #31 BMW Team RBM | BMW M4 DTM | Classified 39L gap 40.571 | Sheldon van der Linde
 12 g5 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 39L gap 42.721 | Robin Frijns
 13 g6 #16 BMW Team RMR | BMW M4 DTM | Classified 39L gap 45.672 | Timo Glock
 14 g11 #21 WRT Team Audi Sport | Audi RS 5 DTM | Classified 39L gap 1:09.779 | Pietro Fittipaldi
 15 g12 #27 WRT Team Audi Sport | Audi RS 5 DTM | NC 27L gap 12 LAPS | Jonathan Aberdein
 16 g2 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | NC 27L gap 12 LAPS | René Rast
 17 g15 #23 R-Motorsport | Aston Martin Vantage DTM | RET 12L gap RET | Daniel Juncadella
 18 g13 #76 R-Motorsport | Aston Martin Vantage DTM | RET 12L gap RET | Jake Dennis
