# dtm-brandshatch-2019-r6-race2

Event: DTM Brands Hatch Race 2 | Circuit: Brands Hatch | Date: 2019-08-11
Scheduled: 00:55:00 | Official duration: 00:57:28.564 | Laps (winner): 42

## Qualifying (archive order)
Q1 #33 [Class1] 1:15.134 Audi Sport Team Rosberg | René Rast
Q2 #28 [Class1] 1:15.432 Audi Sport Team Phoenix | Loïc Duval
Q3 #4 [Class1] 1:15.834 Audi Sport Team Abt Sportsline | Robin Frijns
Q4 #53 [Class1] 1:15.919 Audi Sport Team Rosberg | Jamie Green
Q5 #99 [Class1] 1:15.959 Audi Sport Team Phoenix | Mike Rockenfeller
Q6 #51 [Class1] 1:15.968 Audi Sport Team Abt Sportsline | Nico Müller
Q7 #21 [Class1] 1:16.015 WRT Team Audi Sport | Pietro Fittipaldi
Q8 #27 [Class1] 1:16.016 WRT Team Audi Sport | Jonathan Aberdein
Q9 #25 [Class1] 1:16.175 BMW Team RMR | Philipp Eng
Q10 #23 [Class1] 1:16.257 R-Motorsport | Daniel Juncadella
Q11 #16 [Class1] 1:16.274 BMW Team RMR | Timo Glock
Q12 #11 [Class1] 1:16.296 BMW Team RMG | Marco Wittmann
Q13 #31 [Class1] 1:16.396 BMW Team RBM | Sheldon van der Linde
Q14 #47 [Class1] 1:16.425 BMW Team RBM | Joel Eriksson
Q15 #3 [Class1] 1:16.710 R-Motorsport | Paul di Resta
Q16 #7 [Class1] 1:16.715 BMW Team RMG | Bruno Spengler
Q17 #76 [Class1] 1:16.805 R-Motorsport | Jake Dennis
Q18 #62 [Class1] 1:16.997 R-Motorsport | Ferdinand Habsburg

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #33 René Rast 1:15.134 Audi Sport Team Rosberg
Class1: #33 René Rast 1:15.134 Audi Sport Team Rosberg

## Fastest laps (archive)
Overall: #21 Pietro Fittipaldi 1:18.169 lap 27
Class1: #21 Pietro Fittipaldi 1:18.169 lap 27

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== Class1
 1 g1 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 42L gap — | René Rast
 2 g6 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 42L gap 0.240 | Nico Müller
 3 g3 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 42L gap 0.598 | Robin Frijns
 4 g2 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 42L gap 2.362 | Loïc Duval
 5 g9 #25 BMW Team RMR | BMW M4 DTM | Classified 42L gap 2.889 | Philipp Eng
 6 g5 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 42L gap 3.523 | Mike Rockenfeller
 7 g13 #31 BMW Team RBM | BMW M4 DTM | Classified 42L gap 4.789 | Sheldon van der Linde
 8 g10 #23 R-Motorsport | Aston Martin Vantage DTM | Classified 42L gap 5.229 | Daniel Juncadella
 9 g17 #76 R-Motorsport | Aston Martin Vantage DTM | Classified 42L gap 6.193 | Jake Dennis
 10 g12 #11 BMW Team RMG | BMW M4 DTM | Classified 42L gap 7.837 | Marco Wittmann
 11 g18 #62 R-Motorsport | Aston Martin Vantage DTM | Classified 42L gap 12.091 | Ferdinand Habsburg
 12 g11 #16 BMW Team RMR | BMW M4 DTM | Classified 42L gap 20.594 | Timo Glock
 13 g8 #27 WRT Team Audi Sport | Audi RS 5 DTM | Classified 42L gap 27.882 | Jonathan Aberdein
 14 g15 #3 R-Motorsport | Aston Martin Vantage DTM | Classified 42L gap 35.392 | Paul di Resta
 15 g4 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 42L gap 51.851 | Jamie Green
 16 g7 #21 WRT Team Audi Sport | Audi RS 5 DTM | Classified 42L gap 55.065 | Pietro Fittipaldi
 17 g16 #7 BMW Team RMG | BMW M4 DTM | RET 21L gap RET | Bruno Spengler
 18 g14 #47 BMW Team RBM | BMW M4 DTM | RET 20L gap RET | Joel Eriksson
