# dtm-ttcircuitassen-2019-r5-race2

Event: DTM TT Circuit Assen Race 2 | Circuit: TT Circuit Assen | Date: 2019-07-21
Scheduled: 00:55:00 | Official duration: 00:56:44.559 | Laps (winner): 37

## Qualifying (archive order)
Q1 #33 [Class1] 1:24.849 Audi Sport Team Rosberg | René Rast
Q2 #27 [Class1] 1:24.981 WRT Team Audi Sport | Jonathan Aberdein
Q3 #99 [Class1] 1:25.017 Audi Sport Team Phoenix | Mike Rockenfeller
Q4 #51 [Class1] 1:25.018 Audi Sport Team Abt Sportsline | Nico Müller
Q5 #4 [Class1] 1:25.102 Audi Sport Team Abt Sportsline | Robin Frijns
Q6 #31 [Class1] 1:25.147 BMW Team RBM | Sheldon van der Linde
Q7 #28 [Class1] 1:25.388 Audi Sport Team Phoenix | Loïc Duval
Q8 #25 [Class1] 1:25.410 BMW Team RMR | Philipp Eng
Q9 #16 [Class1] 1:25.468 BMW Team RMR | Timo Glock
Q10 #21 [Class1] 1:25.485 WRT Team Audi Sport | Pietro Fittipaldi
Q11 #47 [Class1] 1:25.517 BMW Team RBM | Joel Eriksson
Q12 #7 [Class1] 1:25.750 BMW Team RMG | Bruno Spengler
Q13 #53 [Class1] 1:25.854 Audi Sport Team Rosberg | Jamie Green
Q14 #23 [Class1] 1:26.087 R-Motorsport | Daniel Juncadella
Q15 #3 [Class1] 1:26.370 R-Motorsport | Paul di Resta
Q16 #62 [Class1] 1:26.566 R-Motorsport | Ferdinand Habsburg
Q17 #76 [Class1] 1:27.379 R-Motorsport | Jake Dennis
Q18 #11 [Class1]  BMW Team RMG | Marco Wittmann

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #33 René Rast 1:24.849 Audi Sport Team Rosberg
Class1: #33 René Rast 1:24.849 Audi Sport Team Rosberg

## Fastest laps (archive)
Overall: #25 Philipp Eng 1:27.860 lap 34
Class1: #25 Philipp Eng 1:27.860 lap 34

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== Class1
 1 g3 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 37L gap — | Mike Rockenfeller
 2 g18 #11 BMW Team RMG | BMW M4 DTM | Classified 37L gap 4.518 | Marco Wittmann
 3 g4 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 37L gap 6.398 | Nico Müller
 4 g2 #27 WRT Team Audi Sport | Audi RS 5 DTM | Classified 37L gap 17.000 | Jonathan Aberdein
 5 g1 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 37L gap 19.348 | René Rast
 6 g5 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 37L gap 21.626 | Robin Frijns
 7 g14 #23 R-Motorsport | Aston Martin Vantage DTM | Classified 37L gap 21.967 | Daniel Juncadella
 8 g15 #3 R-Motorsport | Aston Martin Vantage DTM | Classified 37L gap 22.554 | Paul di Resta
 9 g13 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 37L gap 25.946 | Jamie Green
 10 g10 #21 WRT Team Audi Sport | Audi RS 5 DTM | Classified 37L gap 36.096 | Pietro Fittipaldi
 11 g7 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 37L gap 36.492 | Loïc Duval
 12 g16 #62 R-Motorsport | Aston Martin Vantage DTM | Classified 37L gap 41.444 | Ferdinand Habsburg
 13 g8 #25 BMW Team RMR | BMW M4 DTM | Classified 37L gap 47.996 | Philipp Eng
 14 g9 #16 BMW Team RMR | BMW M4 DTM | Classified 37L gap 57.455 | Timo Glock
 15 g6 #31 BMW Team RBM | BMW M4 DTM | Classified 37L gap 58.520 | Sheldon van der Linde
 16 g11 #47 BMW Team RBM | BMW M4 DTM | Classified 29L gap 8 LAPS | Joel Eriksson
 17 g12 #7 BMW Team RMG | BMW M4 DTM | RET 19L gap RET | Bruno Spengler
 18 g17 #76 R-Motorsport | Aston Martin Vantage DTM | RET 19L gap RET | Jake Dennis
