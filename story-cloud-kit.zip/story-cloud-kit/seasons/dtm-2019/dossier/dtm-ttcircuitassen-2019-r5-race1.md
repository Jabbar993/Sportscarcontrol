# dtm-ttcircuitassen-2019-r5-race1

Event: DTM TT Circuit Assen Race 1 | Circuit: TT Circuit Assen | Date: 2019-07-20
Scheduled: 00:55:00 | Official duration: 1:01:15.672 | Laps (winner): 31

## Qualifying (archive order)
Q1 #11 [Class1] 1:25.434 BMW Team RMG | Marco Wittmann
Q2 #33 [Class1] 1:25.592 Audi Sport Team Rosberg | René Rast
Q3 #28 [Class1] 1:25.749 Audi Sport Team Phoenix | Loïc Duval
Q4 #21 [Class1] 1:25.751 WRT Team Audi Sport | Pietro Fittipaldi
Q5 #16 [Class1] 1:25.853 BMW Team RMR | Timo Glock
Q6 #51 [Class1] 1:25.855 Audi Sport Team Abt Sportsline | Nico Müller
Q7 #31 [Class1] 1:25.856 BMW Team RBM | Sheldon van der Linde
Q8 #7 [Class1] 1:26.004 BMW Team RMG | Bruno Spengler
Q9 #25 [Class1] 1:26.056 BMW Team RMR | Philipp Eng
Q10 #47 [Class1] 1:26.210 BMW Team RBM | Joel Eriksson
Q11 #27 [Class1] 1:26.387 WRT Team Audi Sport | Jonathan Aberdein
Q12 #4 [Class1] 1:26.454 Audi Sport Team Abt Sportsline | Robin Frijns
Q13 #53 [Class1] 1:26.479 Audi Sport Team Rosberg | Jamie Green
Q14 #99 [Class1] 1:26.487 Audi Sport Team Phoenix | Mike Rockenfeller
Q15 #23 [Class1] 1:26.657 R-Motorsport | Daniel Juncadella
Q16 #3 [Class1] 1:26.907 R-Motorsport | Paul di Resta
Q17 #62 [Class1] 1:27.218 R-Motorsport | Ferdinand Habsburg
Q18 #76 [Class1] 1:27.241 R-Motorsport | Jake Dennis

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #11 Marco Wittmann 1:25.434 BMW Team RMG
Class1: #11 Marco Wittmann 1:25.434 BMW Team RMG

## Fastest laps (archive)
Overall: #51 Nico Müller 1:44.598 lap 30
Class1: #51 Nico Müller 1:44.598 lap 30

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== Class1
 1 g1 #11 BMW Team RMG | BMW M4 DTM | Classified 31L gap — | Marco Wittmann
 2 g6 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 31L gap 3.137 | Nico Müller
 3 g2 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 31L gap 8.094 | René Rast
 4 g9 #25 BMW Team RMR | BMW M4 DTM | Classified 31L gap 25.313 | Philipp Eng
 5 g5 #16 BMW Team RMR | BMW M4 DTM | Classified 31L gap 25.534 | Timo Glock
 6 g11 #27 WRT Team Audi Sport | Audi RS 5 DTM | Classified 31L gap 27.887 | Jonathan Aberdein
 7 g12 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 31L gap 36.078 | Jamie Green
 8 g3 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 31L gap 42.496 | Loïc Duval
 9 g13 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 31L gap 43.656 | Mike Rockenfeller
 10 g7 #31 BMW Team RBM | BMW M4 DTM | Classified 31L gap 44.184 | Sheldon van der Linde
 11 g4 #21 WRT Team Audi Sport | Audi RS 5 DTM | Classified 31L gap 45.162 | Pietro Fittipaldi
 12 g17 #76 R-Motorsport | Aston Martin Vantage DTM | Classified 31L gap 45.869 | Jake Dennis
 13 g16 #62 R-Motorsport | Aston Martin Vantage DTM | Classified 31L gap 48.094 | Ferdinand Habsburg
 14 g15 #3 R-Motorsport | Aston Martin Vantage DTM | Classified 31L gap 48.917 | Paul di Resta
 15 g8 #7 BMW Team RMG | BMW M4 DTM | Classified 31L gap 53.378 | Bruno Spengler
 16 g10 #47 BMW Team RBM | BMW M4 DTM | Classified 31L gap 1:01.197 | Joel Eriksson
 17 g18 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | RET 21L gap RET | Robin Frijns
 18 g14 #23 R-Motorsport | Aston Martin Vantage DTM | RET 3L gap RET | Daniel Juncadella
