# dtm-lausitzring-2019-r7-race2

Event: DTM Lausitzring Race 2 | Circuit: Lausitzring | Date: 2019-08-25
Scheduled: 00:55:00 | Official duration: 00:56:59.382 | Laps (winner): 34

## Qualifying (archive order)
Q1 #53 [Class1] 1:35.397 Audi Sport Team Rosberg | Jamie Green
Q2 #27 [Class1] 1:35.498 WRT Team Audi Sport | Jonathan Aberdein
Q3 #51 [Class1] 1:35.548 Audi Sport Team Abt Sportsline | Nico Müller
Q4 #33 [Class1] 1:35.609 Audi Sport Team Rosberg | René Rast
Q5 #4 [Class1] 1:35.628 Audi Sport Team Abt Sportsline | Robin Frijns
Q6 #11 [Class1] 1:35.647 BMW Team RMG | Marco Wittmann
Q7 #28 [Class1] 1:35.677 Audi Sport Team Phoenix | Loïc Duval
Q8 #21 [Class1] 1:35.747 WRT Team Audi Sport | Pietro Fittipaldi
Q9 #16 [Class1] 1:35.843 BMW Team RMR | Timo Glock
Q10 #99 [Class1] 1:35.891 Audi Sport Team Phoenix | Mike Rockenfeller
Q11 #31 [Class1] 1:35.907 BMW Team RBM | Sheldon van der Linde
Q12 #47 [Class1] 1:36.035 BMW Team RBM | Joel Eriksson
Q13 #7 [Class1] 1:36.327 BMW Team RMG | Bruno Spengler
Q14 #3 [Class1] 1:36.555 R-Motorsport | Paul di Resta
Q15 #76 [Class1] 1:36.667 R-Motorsport | Jake Dennis
Q16 #62 [Class1] 1:37.112 R-Motorsport | Ferdinand Habsburg
Q17 #23 [Class1] 1:37.130 R-Motorsport | Daniel Juncadella
Q18 #25 [Class1]  BMW Team RMR | Philipp Eng

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #53 Jamie Green 1:35.397 Audi Sport Team Rosberg
Class1: #53 Jamie Green 1:35.397 Audi Sport Team Rosberg

## Fastest laps (archive)
Overall: #25 Philipp Eng 1:37.897 lap 10
Class1: #25 Philipp Eng 1:37.897 lap 10

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== Class1
 1 g4 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 34L gap — | René Rast
 2 g3 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 34L gap 5.187 | Nico Müller
 3 g10 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 34L gap 8.953 | Mike Rockenfeller
 4 g1 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 34L gap 9.618 | Jamie Green
 5 g5 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 34L gap 11.341 | Robin Frijns
 6 g6 #11 BMW Team RMG | BMW M4 DTM | Classified 34L gap 12.982 | Marco Wittmann
 7 g2 #27 WRT Team Audi Sport | Audi RS 5 DTM | Classified 34L gap 13.752 | Jonathan Aberdein
 8 g7 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 34L gap 14.071 | Loïc Duval
 9 g8 #21 WRT Team Audi Sport | Audi RS 5 DTM | Classified 34L gap 21.130 | Pietro Fittipaldi
 10 g18 #25 BMW Team RMR | BMW M4 DTM | Classified 34L gap 23.105 | Philipp Eng
 11 g11 #31 BMW Team RBM | BMW M4 DTM | Classified 34L gap 23.568 | Sheldon van der Linde
 12 g17 #23 R-Motorsport | Aston Martin Vantage DTM | Classified 34L gap 24.077 | Daniel Juncadella
 13 g12 #47 BMW Team RBM | BMW M4 DTM | Classified 34L gap 43.396 | Joel Eriksson
 14 g13 #7 BMW Team RMG | BMW M4 DTM | Classified 34L gap 54.611 | Bruno Spengler
 15 g9 #16 BMW Team RMR | BMW M4 DTM | Classified 25L gap 9 LAPS | Timo Glock
 16 g14 #3 R-Motorsport | Aston Martin Vantage DTM | RET 20L gap RET | Paul di Resta
 17 g16 #62 R-Motorsport | Aston Martin Vantage DTM | RET 8L gap RET | Ferdinand Habsburg
 18 g15 #76 R-Motorsport | Aston Martin Vantage DTM | RET 2L gap RET | Jake Dennis
