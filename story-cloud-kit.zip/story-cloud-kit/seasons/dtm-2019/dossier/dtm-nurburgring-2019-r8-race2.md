# dtm-nurburgring-2019-r8-race2

Event: DTM Nürburgring Race 2 | Circuit: Nürburgring | Date: 2019-09-15
Scheduled: 00:55:00 | Official duration: 00:57:41.767 | Laps (winner): 41

## Qualifying (archive order)
Q1 #53 [Class1] 1:20.032 Audi Sport Team Rosberg | Jamie Green
Q2 #33 [Class1] 1:20.033 Audi Sport Team Rosberg | René Rast
Q3 #99 [Class1] 1:20.107 Audi Sport Team Phoenix | Mike Rockenfeller
Q4 #4 [Class1] 1:20.122 Audi Sport Team Abt Sportsline | Robin Frijns
Q5 #27 [Class1] 1:20.171 WRT Team Audi Sport | Jonathan Aberdein
Q6 #28 [Class1] 1:20.220 Audi Sport Team Phoenix | Loïc Duval
Q7 #16 [Class1] 1:20.270 BMW Team RMR | Timo Glock
Q8 #11 [Class1] 1:20.312 BMW Team RMG | Marco Wittmann
Q9 #7 [Class1] 1:20.317 BMW Team RMG | Bruno Spengler
Q10 #31 [Class1] 1:20.342 BMW Team RBM | Sheldon van der Linde
Q11 #25 [Class1] 1:20.344 BMW Team RMR | Philipp Eng
Q12 #21 [Class1] 1:20.445 WRT Team Audi Sport | Pietro Fittipaldi
Q13 #47 [Class1] 1:20.489 BMW Team RBM | Joel Eriksson
Q14 #51 [Class1] 1:20.495 Audi Sport Team Abt Sportsline | Nico Müller
Q15 #62 [Class1] 1:20.633 R-Motorsport | Ferdinand Habsburg
Q16 #23 [Class1] 1:20.946 R-Motorsport | Daniel Juncadella
Q17 #76 [Class1] 1:21.061 R-Motorsport | Jake Dennis
Q18 #3 [Class1]  R-Motorsport | Paul di Resta

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #53 Jamie Green 1:20.032 Audi Sport Team Rosberg
Class1: #53 Jamie Green 1:20.032 Audi Sport Team Rosberg

## Fastest laps (archive)
Overall: #33 René Rast 1:22.253 lap 4
Class1: #33 René Rast 1:22.253 lap 4

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== Class1
 1 g1 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 41L gap — | Jamie Green
 2 g4 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 41L gap 0.442 | Robin Frijns
 3 g2 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 41L gap 5.827 | René Rast
 4 g6 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 41L gap 10.813 | Loïc Duval
 5 g5 #27 WRT Team Audi Sport | Audi RS 5 DTM | Classified 41L gap 11.121 | Jonathan Aberdein
 6 g14 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 41L gap 12.410 | Nico Müller
 7 g3 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 41L gap 12.753 | Mike Rockenfeller
 8 g11 #25 BMW Team RMR | BMW M4 DTM | Classified 41L gap 19.886 | Philipp Eng
 9 g7 #16 BMW Team RMR | BMW M4 DTM | Classified 41L gap 27.159 | Timo Glock
 10 g9 #7 BMW Team RMG | BMW M4 DTM | Classified 41L gap 27.675 | Bruno Spengler
 11 g13 #47 BMW Team RBM | BMW M4 DTM | Classified 41L gap 29.974 | Joel Eriksson
 12 g16 #23 R-Motorsport | Aston Martin Vantage DTM | Classified 41L gap 30.660 | Daniel Juncadella
 13 g12 #21 WRT Team Audi Sport | Audi RS 5 DTM | Classified 41L gap 31.625 | Pietro Fittipaldi
 14 g17 #76 R-Motorsport | Aston Martin Vantage DTM | Classified 41L gap 32.000 | Jake Dennis
 15 g15 #62 R-Motorsport | Aston Martin Vantage DTM | Classified 41L gap 32.449 | Ferdinand Habsburg
 16 g10 #31 BMW Team RBM | BMW M4 DTM | Classified 41L gap 51.534 | Sheldon van der Linde
 17 g8 #11 BMW Team RMG | BMW M4 DTM | RET 29L gap RET | Marco Wittmann
 18 g? #3 R-Motorsport | Aston Martin Vantage DTM | DNS 0L gap DNS | Paul di Resta
