# dtm-hockenheimring-2019-r9-race2

Event: DTM Hockenheimring Race 2 | Circuit: Hockenheimring | Date: 2019-10-06
Scheduled: 00:55:00 | Official duration: 1:04:45.023 | Laps (winner): 27

## Qualifying (archive order)
Q1 #99 [Class1] 1:50.800 Audi Sport Team Phoenix | Mike Rockenfeller
Q2 #51 [Class1] 1:50.813 Audi Sport Team Abt Sportsline | Nico Müller
Q3 #16 [Class1] 1:51.260 BMW Team RMR | Timo Glock
Q4 #53 [Class1] 1:51.391 Audi Sport Team Rosberg | Jamie Green
Q5 #47 [Class1] 1:51.489 BMW Team RBM | Joel Eriksson
Q6 #11 [Class1] 1:51.788 BMW Team RMG | Marco Wittmann
Q7 #25 [Class1] 1:51.807 BMW Team RMR | Philipp Eng
Q8 #33 [Class1] 1:51.873 Audi Sport Team Rosberg | René Rast
Q9 #4 [Class1] 1:51.990 Audi Sport Team Abt Sportsline | Robin Frijns
Q10 #28 [Class1] 1:51.994 Audi Sport Team Phoenix | Loïc Duval
Q11 #76 [Class1] 1:52.242 R-Motorsport | Jake Dennis
Q12 #62 [Class1] 1:52.374 R-Motorsport | Ferdinand Habsburg
Q13 #27 [Class1] 1:52.483 WRT Team Audi Sport | Jonathan Aberdein
Q14 #7 [Class1] 1:52.491 BMW Team RMG | Bruno Spengler
Q15 #31 [Class1] 1:52.511 BMW Team RBM | Sheldon van der Linde
Q16 #37 [Class1] 1:52.527 Lexus Gazoo Racing Team KeePer TOM'S | Ryo Hirakawa
Q17 #3 [Class1] 1:52.534 R-Motorsport | Paul di Resta
Q18 #23 [Class1] 1:52.652 R-Motorsport | Daniel Juncadella
Q19 #1 [Class1] 1:52.787 Team Kunimitsu | Jenson Button
Q20 #21 [Class1] 1:53.410 WRT Team Audi Sport | Pietro Fittipaldi
Q21 #35 [Class1] 1:53.875 Nismo Team Motul Autech GT Sport | Ronnie Quintarelli

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #99 Mike Rockenfeller 1:50.800 Audi Sport Team Phoenix
Class1: #99 Mike Rockenfeller 1:50.800 Audi Sport Team Phoenix

## Fastest laps (archive)
Overall: #99 Mike Rockenfeller 1:52.014 lap 22
Class1: #99 Mike Rockenfeller 1:52.014 lap 22

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== Class1
 1 g1 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 27L gap — | Nico Müller
 2 g6 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 27L gap 3.835 | Mike Rockenfeller
 3 g8 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 27L gap 8.403 | René Rast
 4 g2 #16 BMW Team RMR | BMW M4 DTM | Classified 27L gap 11.849 | Timo Glock
 5 g3 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 27L gap 13.094 | Jamie Green
 6 g4 #47 BMW Team RBM | BMW M4 DTM | Classified 27L gap 16.248 | Joel Eriksson
 7 g9 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 27L gap 22.172 | Robin Frijns
 8 g11 #76 R-Motorsport | Aston Martin Vantage DTM | Classified 27L gap 36.954 | Jake Dennis
 9 g14 #7 BMW Team RMG | BMW M4 DTM | Classified 27L gap 51.319 | Bruno Spengler
 10 g10 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 27L gap 55.877 | Loïc Duval
 11 g12 #62 R-Motorsport | Aston Martin Vantage DTM | Classified 27L gap 58.838 | Ferdinand Habsburg
 12 g5 #11 BMW Team RMG | BMW M4 DTM | Classified 27L gap 59.767 | Marco Wittmann
 13 g15 #31 BMW Team RBM | BMW M4 DTM | Classified 27L gap 1:00.417 | Sheldon van der Linde
 14 g7 #25 BMW Team RMR | BMW M4 DTM | Classified 27L gap 1:01.873 | Philipp Eng
 15 g21 #21 WRT Team Audi Sport | Audi RS 5 DTM | Classified 27L gap 1:30.051 | Pietro Fittipaldi
 16 g19 #1 Team Kunimitsu | Honda NSX-GT | Classified 27L gap 1:55.243 | Jenson Button
 17 g20 #35 Nismo Team Motul Autech GT Sport | Nissan GT-R NISMO GT500 | Classified 26L gap 1 LAP | Ronnie Quintarelli
 18 g13 #27 WRT Team Audi Sport | Audi RS 5 DTM | RET 14L gap RET | Jonathan Aberdein
 19 g18 #23 R-Motorsport | Aston Martin Vantage DTM | RET 0L gap RET | Daniel Juncadella
 20 g16 #37 Lexus Gazoo Racing Team KeePer TOM'S | Lexus LC500 | RET 0L gap RET | Nick Cassidy
 21 g17 #3 R-Motorsport | Aston Martin Vantage DTM | DNS 0L gap DNS | Paul di Resta
