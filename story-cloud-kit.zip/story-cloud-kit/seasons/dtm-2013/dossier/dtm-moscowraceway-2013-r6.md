# dtm-moscowraceway-2013-r6

Event: DTM Moscow Raceway | Circuit: Moscow Raceway | Date: 2013-08-04
Scheduled: ? | Official duration: 1:14:38.512 | Laps (winner): 74

## Qualifying (archive order)
Q1 #19 [DTMV8] 58.423 Phoenix Racing | Mike Rockenfeller
Q2 #11 [DTMV8] 58.604 Abt Sportsline | Mattias Ekström
Q3 #7 [DTMV8] 58.677 BMW Team RBM | Augusto Farfus
Q4 #1 [DTMV8] 58.698 BMW Team Schnitzer | Bruno Spengler
Q5 #12 [DTMV8] 58.749 Abt Sportsline | Jamie Green
Q6 #2 [DTMV8] 58.779 BMW Team Schnitzer | Dirk Werner
Q7 #3 [DTMV8] 58.831 HWA Team | Gary Paffett
Q8 #18 [DTMV8] 58.843 Mücke Motorsport | Pascal Wehrlein
Q9 #17 [DTMV8] 58.985 Mücke Motorsport | Daniel Juncadella
Q10 #9 [DTMV8] 59.038 HWA Team | Christian Vietoris
Q11 #20 [DTMV8] 58.907 Phoenix Racing | Miguel Molina
Q12 #24 [DTMV8] 58.910 Audi Sport Team Abt | Adrien Tambay
Q13 #6 [DTMV8] 58.914 Team Rosberg | Filipe Albuquerque
Q14 #23 [DTMV8] 58.954 Audi Sport Team Abt | Timo Scheider
Q15 #8 [DTMV8] 59.013 BMW Team RBM | Joey Hand
Q16 #5 [DTMV8] 59.133 Team Rosberg | Edoardo Mortara
Q17 #22 [DTMV8] 59.177 BMW Team MTEK | Timo Glock
Q18 #10 [DTMV8] 59.285 HWA Team | Robert Wickens
Q19 #15 [DTMV8] 59.286 BMW Team RMG | Martin Tomczyk
Q20 #21 [DTMV8] 59.400 BMW Team MTEK | Marco Wittmann
Q21 #16 [DTMV8] 59.442 BMW Team RMG | Andy Priaulx
Q22 #4 [DTMV8] 59.467 HWA Team | Roberto Merhi

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #19 Mike Rockenfeller 58.423 Phoenix Racing
DTMV8: #19 Mike Rockenfeller 58.423 Phoenix Racing

## Fastest laps (archive)
Overall: #24 Adrien Tambay 58.999 lap 70
DTMV8: #24 Adrien Tambay 58.999 lap 70

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #19 Phoenix Racing | Audi RS 5 DTM | Classified 74L gap — | Mike Rockenfeller
 2 g2 #11 Abt Sportsline | Audi RS 5 DTM | Classified 74L gap 1.303 | Mattias Ekström
 3 g3 #7 BMW Team RBM | BMW M3 DTM | Classified 74L gap 11.393 | Augusto Farfus
 4 g12 #24 Audi Sport Team Abt | Audi RS 5 DTM | Classified 74L gap 12.275 | Adrien Tambay
 5 g7 #3 HWA Team | Mercedes AMG C-Coupé | Classified 74L gap 17.495 | Gary Paffett
 6 g5 #12 Abt Sportsline | Audi RS 5 DTM | Classified 74L gap 18.704 | Jamie Green
 7 g15 #8 BMW Team RBM | BMW M3 DTM | Classified 74L gap 19.363 | Joey Hand
 8 g6 #2 BMW Team Schnitzer | BMW M3 DTM | Classified 74L gap 26.117 | Dirk Werner
 9 g14 #23 Audi Sport Team Abt | Audi RS 5 DTM | Classified 74L gap 34.184 | Timo Scheider
 10 g10 #9 HWA Team | Mercedes AMG C-Coupé | Classified 74L gap 41.331 | Christian Vietoris
 11 g8 #18 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 74L gap 42.029 | Pascal Wehrlein
 12 g18 #10 HWA Team | Mercedes AMG C-Coupé | Classified 74L gap 43.782 | Robert Wickens
 13 g13 #6 Team Rosberg | Audi RS 5 DTM | Classified 74L gap 44.443 | Filipe Albuquerque
 14 g22 #4 HWA Team | Mercedes AMG C-Coupé | Classified 74L gap 51.576 | Roberto Merhi
 15 g20 #21 BMW Team MTEK | BMW M3 DTM | Classified 74L gap 52.941 | Marco Wittmann
 16 g17 #22 BMW Team MTEK | BMW M3 DTM | Classified 74L gap 54.421 | Timo Glock
 17 g19 #15 BMW Team RMG | BMW M3 DTM | Classified 74L gap 58.460 | Martin Tomczyk
 18 g9 #17 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 73L gap 1 LAP | Daniel Juncadella
 19 g4 #1 BMW Team Schnitzer | BMW M3 DTM | Classified 73L gap 1 LAP | Bruno Spengler
 20 g21 #16 BMW Team RMG | BMW M3 DTM | Classified 73L gap 1 LAP | Andy Priaulx
 21 g16 #5 Team Rosberg | Audi RS 5 DTM | RET 31L gap RET | Edoardo Mortara
 22 g11 #20 Phoenix Racing | Audi RS 5 DTM | RET 5L gap RET | Miguel Molina
