# dtm-motorsportarenaosche-2013-r8

Event: DTM Motorsport Arena Oschersleben | Circuit: Oschersleben | Date: 2013-09-15
Scheduled: ? | Official duration: 1:11:40.894 | Laps (winner): 51

## Qualifying (archive order)
Q1 #1 [DTMV8] 1:20.140 BMW Team Schnitzer | Bruno Spengler
Q2 #12 [DTMV8] 1:20.263 Abt Sportsline | Jamie Green
Q3 #7 [DTMV8] 1:20.442 BMW Team RBM | Augusto Farfus
Q4 #19 [DTMV8] 1:20.444 Phoenix Racing | Mike Rockenfeller
Q5 #2 [DTMV8] 1:20.229 BMW Team Schnitzer | Dirk Werner
Q6 #6 [DTMV8] 1:20.306 Team Rosberg | Filipe Albuquerque
Q7 #3 [DTMV8] 1:20.333 HWA Team | Gary Paffett
Q8 #20 [DTMV8] 1:20.371 Phoenix Racing | Miguel Molina
Q9 #15 [DTMV8] 1:20.467 BMW Team RMG | Martin Tomczyk
Q10 #23 [DTMV8] 1:20.761 Audi Sport Team Abt | Timo Scheider
Q11 #24 [DTMV8] 1:21.161 Audi Sport Team Abt | Adrien Tambay
Q12 #10 [DTMV8] 1:21.185 HWA Team | Robert Wickens
Q13 #11 [DTMV8] 1:21.277 Abt Sportsline | Mattias Ekström
Q14 #18 [DTMV8] 1:21.351 Mücke Motorsport | Pascal Wehrlein
Q15 #21 [DTMV8] 1:21.489 BMW Team MTEK | Marco Wittmann
Q16 #22 [DTMV8] 1:21.540 BMW Team MTEK | Timo Glock
Q17 #5 [DTMV8] 1:21.077 Team Rosberg | Edoardo Mortara
Q18 #8 [DTMV8] 1:21.173 BMW Team RBM | Joey Hand
Q19 #16 [DTMV8] 1:21.181 BMW Team RMG | Andy Priaulx
Q20 #17 [DTMV8] 1:21.258 Mücke Motorsport | Daniel Juncadella
Q21 #9 [DTMV8] 1:21.400 HWA Team | Christian Vietoris
Q22 #4 [DTMV8] 1:21.517 HWA Team | Roberto Merhi

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #1 Bruno Spengler 1:20.140 BMW Team Schnitzer
DTMV8: #1 Bruno Spengler 1:20.140 BMW Team Schnitzer

## Fastest laps (archive)
Overall: #8 Joey Hand 1:21.255 lap 14
DTMV8: #8 Joey Hand 1:21.255 lap 14

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g2 #7 BMW Team RBM | BMW M3 DTM | Classified 51L gap — | Augusto Farfus
 2 g3 #19 Phoenix Racing | Audi RS 5 DTM | Classified 51L gap 6.298 | Mike Rockenfeller
 3 g1 #12 Abt Sportsline | Audi RS 5 DTM | Classified 51L gap 6.912 | Jamie Green
 4 g5 #6 Team Rosberg | Audi RS 5 DTM | Classified 51L gap 10.837 | Filipe Albuquerque
 5 g9 #23 Audi Sport Team Abt | Audi RS 5 DTM | Classified 51L gap 13.325 | Timo Scheider
 6 g12 #3 HWA Team | Mercedes AMG C-Coupé | Classified 51L gap 14.707 | Gary Paffett
 7 g13 #11 Abt Sportsline | Audi RS 5 DTM | Classified 51L gap 21.980 | Mattias Ekström
 8 g7 #20 Phoenix Racing | Audi RS 5 DTM | Classified 51L gap 22.692 | Miguel Molina
 9 g10 #24 Audi Sport Team Abt | Audi RS 5 DTM | Classified 51L gap 23.109 | Adrien Tambay
 10 g17 #5 Team Rosberg | Audi RS 5 DTM | Classified 51L gap 23.977 | Edoardo Mortara
 11 g14 #18 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 51L gap 24.136 | Pascal Wehrlein
 12 g15 #21 BMW Team MTEK | BMW M3 DTM | Classified 51L gap 29.004 | Marco Wittmann
 13 g4 #2 BMW Team Schnitzer | BMW M3 DTM | Classified 51L gap 36.997 | Dirk Werner
 14 g21 #4 HWA Team | Mercedes AMG C-Coupé | Classified 51L gap 38.620 | Roberto Merhi
 15 g16 #22 BMW Team MTEK | BMW M3 DTM | Classified 51L gap 48.244 | Timo Glock
 16 g18 #8 BMW Team RBM | BMW M3 DTM | Classified 51L gap 48.756 | Joey Hand
 17 g22 #17 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 51L gap 49.751 | Daniel Juncadella
 18 g20 #9 HWA Team | Mercedes AMG C-Coupé | Classified 51L gap 58.626 | Christian Vietoris
 19 g19 #16 BMW Team RMG | BMW M3 DTM | Classified 51L gap 1:10.973 | Andy Priaulx
 20 g8 #15 BMW Team RMG | BMW M3 DTM | Classified 49L gap 2 LAPS | Martin Tomczyk
 21 g6 #1 BMW Team Schnitzer | BMW M3 DTM | RET 40L gap RET | Bruno Spengler
 22 g11 #10 HWA Team | Mercedes AMG C-Coupé | RET 38L gap RET | Robert Wickens
