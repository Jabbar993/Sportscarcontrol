# dtm-nurburgring-2013-r7

Event: DTM Nürburgring | Circuit: Nürburgring | Date: 2013-08-18
Scheduled: ? | Official duration: 1:15:33.710 | Laps (winner): 47

## Qualifying (archive order)
Q1 #7 [DTMV8] 1:23.296 BMW Team RBM | Augusto Farfus
Q2 #21 [DTMV8] 1:23.445 BMW Team MTEK | Marco Wittmann
Q3 #20 [DTMV8] 1:23.451 Phoenix Racing | Miguel Molina
Q4 #5 [DTMV8] 1:23.648 Team Rosberg | Edoardo Mortara
Q5 #3 [DTMV8] 1:23.514 HWA Team | Gary Paffett
Q6 #17 [DTMV8] 1:23.617 Mücke Motorsport | Daniel Juncadella
Q7 #10 [DTMV8] 1:23.688 HWA Team | Robert Wickens
Q8 #9 [DTMV8] 1:23.688 HWA Team | Christian Vietoris
Q9 #11 [DTMV8] 1:23.803 Abt Sportsline | Mattias Ekström
Q10 #1 [DTMV8] 1:23.822 BMW Team Schnitzer | Bruno Spengler
Q11 #19 [DTMV8] 1:23.555 Phoenix Racing | Mike Rockenfeller
Q12 #12 [DTMV8] 1:23.574 Abt Sportsline | Jamie Green
Q13 #22 [DTMV8] 1:23.665 BMW Team MTEK | Timo Glock
Q14 #24 [DTMV8] 1:23.684 Audi Sport Team Abt | Adrien Tambay
Q15 #18 [DTMV8] 1:23.687 Mücke Motorsport | Pascal Wehrlein
Q16 #8 [DTMV8] 1:23.737 BMW Team RBM | Joey Hand
Q17 #6 [DTMV8] 1:23.914 Team Rosberg | Filipe Albuquerque
Q18 #23 [DTMV8] 1:24.091 Audi Sport Team Abt | Timo Scheider
Q19 #2 [DTMV8] 1:24.198 BMW Team Schnitzer | Dirk Werner
Q20 #15 [DTMV8] 1:24.225 BMW Team RMG | Martin Tomczyk
Q21 #4 [DTMV8] 1:24.359 HWA Team | Roberto Merhi
Q22 #16 [DTMV8] 1:24.505 BMW Team RMG | Andy Priaulx

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #7 Augusto Farfus 1:23.296 BMW Team RBM
DTMV8: #7 Augusto Farfus 1:23.296 BMW Team RBM

## Fastest laps (archive)
Overall: #18 Pascal Wehrlein 1:23.835 lap 42
DTMV8: #18 Pascal Wehrlein 1:23.835 lap 42

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g7 #10 HWA Team | Mercedes AMG C-Coupé | Classified 47L gap — | Robert Wickens
 2 g1 #7 BMW Team RBM | BMW M3 DTM | Classified 47L gap 2.158 | Augusto Farfus
 3 g8 #9 HWA Team | Mercedes AMG C-Coupé | Classified 47L gap 9.749 | Christian Vietoris
 4 g11 #19 Phoenix Racing | Audi RS 5 DTM | Classified 47L gap 20.524 | Mike Rockenfeller
 5 g20 #15 BMW Team RMG | BMW M3 DTM | Classified 47L gap 27.104 | Martin Tomczyk
 6 g14 #24 Audi Sport Team Abt | Audi RS 5 DTM | Classified 47L gap 27.523 | Adrien Tambay
 7 g2 #21 BMW Team MTEK | BMW M3 DTM | Classified 47L gap 29.540 | Marco Wittmann
 8 g3 #20 Phoenix Racing | Audi RS 5 DTM | Classified 47L gap 33.037 | Miguel Molina
 9 g12 #12 Abt Sportsline | Audi RS 5 DTM | Classified 47L gap 39.972 | Jamie Green
 10 g15 #18 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 47L gap 40.486 | Pascal Wehrlein
 11 g17 #6 Team Rosberg | Audi RS 5 DTM | Classified 47L gap 40.908 | Filipe Albuquerque
 12 g4 #5 Team Rosberg | Audi RS 5 DTM | Classified 47L gap 42.629 | Edoardo Mortara
 13 g9 #11 Abt Sportsline | Audi RS 5 DTM | Classified 47L gap 46.303 | Mattias Ekström
 14 g10 #1 BMW Team Schnitzer | BMW M3 DTM | Classified 47L gap 51.991 | Bruno Spengler
 15 g19 #2 BMW Team Schnitzer | BMW M3 DTM | Classified 47L gap 57.649 | Dirk Werner
 16 g22 #16 BMW Team RMG | BMW M3 DTM | Classified 47L gap 1:21.517 | Andy Priaulx
 17 g5 #3 HWA Team | Mercedes AMG C-Coupé | Classified 46L gap 1 LAP | Gary Paffett
 18 g13 #22 BMW Team MTEK | BMW M3 DTM | Classified 46L gap 1 LAP | Timo Glock
 19 g21 #4 HWA Team | Mercedes AMG C-Coupé | Classified 46L gap 1 LAP | Roberto Merhi
 20 g6 #17 Mücke Motorsport | Mercedes AMG C-Coupé | RET 29L gap RET | Daniel Juncadella
 21 g18 #23 Audi Sport Team Abt | Audi RS 5 DTM | RET 8L gap RET | Timo Scheider
 22 g16 #8 BMW Team RBM | BMW M3 DTM | RET 0L gap RET | Joey Hand
