# dtm-redbullring-2013-r3

Event: DTM Red Bull Ring | Circuit: Red Bull Ring | Date: 2013-06-02
Scheduled: ? | Official duration: 1:08:35.249 | Laps (winner): 47

## Qualifying (archive order)
Q1 #1 [DTMV8] 1:24.836 BMW Team Schnitzer | Bruno Spengler
Q2 #21 [DTMV8] 1:24.947 BMW Team MTEK | Marco Wittmann
Q3 #5 [DTMV8] 1:25.036 Team Rosberg | Edoardo Mortara
Q4 #7 [DTMV8] 1:25.183 BMW Team RBM | Augusto Farfus
Q5 #23 [DTMV8] 1:24.887 Audi Sport Team Abt | Timo Scheider
Q6 #6 [DTMV8] 1:24.922 Team Rosberg | Filipe Albuquerque
Q7 #10 [DTMV8] 1:24.973 HWA Team | Robert Wickens
Q8 #19 [DTMV8] 1:24.986 Phoenix Racing | Mike Rockenfeller
Q9 #15 [DTMV8] 1:25.245 BMW Team RMG | Martin Tomczyk
Q10 #3 [DTMV8]  HWA Team | Gary Paffett
Q11 #2 [DTMV8] 1:25.130 BMW Team Schnitzer | Dirk Werner
Q12 #18 [DTMV8] 1:25.146 Mücke Motorsport | Pascal Wehrlein
Q13 #22 [DTMV8] 1:25.168 BMW Team MTEK | Timo Glock
Q14 #17 [DTMV8] 1:25.259 Mücke Motorsport | Daniel Juncadella
Q15 #11 [DTMV8] 1:25.497 Abt Sportsline | Mattias Ekström
Q16 #9 [DTMV8] 1:25.518 HWA Team | Christian Vietoris
Q17 #12 [DTMV8] 1:25.351 Abt Sportsline | Jamie Green
Q18 #24 [DTMV8] 1:25.406 Audi Sport Team Abt | Adrien Tambay
Q19 #8 [DTMV8] 1:25.451 BMW Team RBM | Joey Hand
Q20 #20 [DTMV8] 1:25.552 Phoenix Racing | Miguel Molina
Q21 #4 [DTMV8] 1:25.761 HWA Team | Roberto Merhi
Q22 #16 [DTMV8] 1:25.763 BMW Team RMG | Andy Priaulx

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #1 Bruno Spengler 1:24.836 BMW Team Schnitzer
DTMV8: #1 Bruno Spengler 1:24.836 BMW Team Schnitzer

## Fastest laps (archive)
Overall: #21 Marco Wittmann 1:25.505 lap 6
DTMV8: #21 Marco Wittmann 1:25.505 lap 6

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #1 BMW Team Schnitzer | BMW M3 DTM | Classified 47L gap — | Bruno Spengler
 2 g2 #21 BMW Team MTEK | BMW M3 DTM | Classified 47L gap 1.550 | Marco Wittmann
 3 g12 #22 BMW Team MTEK | BMW M3 DTM | Classified 47L gap 6.504 | Timo Glock
 4 g13 #19 Phoenix Racing | Audi RS 5 DTM | Classified 47L gap 9.183 | Mike Rockenfeller
 5 g15 #11 Abt Sportsline | Audi RS 5 DTM | Classified 47L gap 10.260 | Mattias Ekström
 6 g4 #7 BMW Team RBM | BMW M3 DTM | Classified 47L gap 14.299 | Augusto Farfus
 7 g16 #9 HWA Team | Mercedes AMG C-Coupé | Classified 47L gap 14.884 | Christian Vietoris
 8 g10 #2 BMW Team Schnitzer | BMW M3 DTM | Classified 47L gap 15.548 | Dirk Werner
 9 g9 #3 HWA Team | Mercedes AMG C-Coupé | Classified 47L gap 16.207 | Gary Paffett
 10 g11 #18 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 47L gap 17.462 | Pascal Wehrlein
 11 g17 #24 Audi Sport Team Abt | Audi RS 5 DTM | Classified 47L gap 21.550 | Adrien Tambay
 12 g7 #10 HWA Team | Mercedes AMG C-Coupé | Classified 47L gap 26.499 | Robert Wickens
 13 g14 #17 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 47L gap 26.927 | Daniel Juncadella
 14 g19 #20 Phoenix Racing | Audi RS 5 DTM | Classified 47L gap 27.704 | Miguel Molina
 15 g3 #5 Team Rosberg | Audi RS 5 DTM | Classified 47L gap 29.113 | Edoardo Mortara
 16 g5 #23 Audi Sport Team Abt | Audi RS 5 DTM | Classified 47L gap 29.470 | Timo Scheider
 17 g6 #6 Team Rosberg | Audi RS 5 DTM | Classified 47L gap 31.834 | Filipe Albuquerque
 18 g21 #12 Abt Sportsline | Audi RS 5 DTM | Classified 47L gap 32.854 | Jamie Green
 19 g22 #16 BMW Team RMG | BMW M3 DTM | Classified 47L gap 1:10.907 | Andy Priaulx
 20 g20 #4 HWA Team | Mercedes AMG C-Coupé | Classified 47L gap 1:19.828 | Roberto Merhi
 21 g8 #15 BMW Team RMG | BMW M3 DTM | RET 29L gap RET | Martin Tomczyk
 22 g18 #8 BMW Team RBM | BMW M3 DTM | RET 9L gap RET | Joey Hand
