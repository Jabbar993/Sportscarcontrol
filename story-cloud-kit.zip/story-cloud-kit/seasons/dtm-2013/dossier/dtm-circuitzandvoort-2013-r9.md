# dtm-circuitzandvoort-2013-r9

Event: DTM Circuit Zandvoort | Circuit: Zandvoort | Date: 2013-09-29
Scheduled: ? | Official duration: 1:13:26.294 | Laps (winner): 44

## Qualifying (archive order)
Q1 #21 [DTMV8] 1:30.894 BMW Team MTEK | Marco Wittmann
Q2 #7 [DTMV8] 1:30.979 BMW Team RBM | Augusto Farfus
Q3 #19 [DTMV8] 1:31.325 Phoenix Racing | Mike Rockenfeller
Q4 #23 [DTMV8] 1:32.524 Audi Sport Team Abt | Timo Scheider
Q5 #8 [DTMV8] 1:31.439 BMW Team RBM | Joey Hand
Q6 #6 [DTMV8] 1:31.443 Team Rosberg | Filipe Albuquerque
Q7 #5 [DTMV8] 1:31.460 Team Rosberg | Edoardo Mortara
Q8 #22 [DTMV8] 1:31.614 BMW Team MTEK | Timo Glock
Q9 #24 [DTMV8] 1:31.621 Audi Sport Team Abt | Adrien Tambay
Q10 #20 [DTMV8] 1:32.106 Phoenix Racing | Miguel Molina
Q11 #11 [DTMV8] 1:31.382 Abt Sportsline | Mattias Ekström
Q12 #3 [DTMV8] 1:31.414 HWA Team | Gary Paffett
Q13 #2 [DTMV8] 1:31.442 BMW Team Schnitzer | Dirk Werner
Q14 #18 [DTMV8] 1:31.445 Mücke Motorsport | Pascal Wehrlein
Q15 #16 [DTMV8] 1:31.539 BMW Team RMG | Andy Priaulx
Q16 #1 [DTMV8] 1:31.546 BMW Team Schnitzer | Bruno Spengler
Q17 #9 [DTMV8] 1:32.055 HWA Team | Christian Vietoris
Q18 #12 [DTMV8] 1:32.067 Abt Sportsline | Jamie Green
Q19 #15 [DTMV8] 1:32.088 BMW Team RMG | Martin Tomczyk
Q20 #17 [DTMV8] 1:32.145 Mücke Motorsport | Daniel Juncadella
Q21 #10 [DTMV8] 1:32.241 HWA Team | Robert Wickens
Q22 #4 [DTMV8] 1:32.357 HWA Team | Roberto Merhi

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #21 Marco Wittmann 1:30.894 BMW Team MTEK
DTMV8: #21 Marco Wittmann 1:30.894 BMW Team MTEK

## Fastest laps (archive)
Overall: #21 Marco Wittmann 1:32.296 lap 6
DTMV8: #21 Marco Wittmann 1:32.296 lap 6

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g2 #7 BMW Team RBM | BMW M3 DTM | Classified 44L gap — | Augusto Farfus
 2 g3 #19 Phoenix Racing | Audi RS 5 DTM | Classified 44L gap 1.603 | Mike Rockenfeller
 3 g4 #23 Audi Sport Team Abt | Audi RS 5 DTM | Classified 44L gap 2.149 | Timo Scheider
 4 g11 #11 Abt Sportsline | Audi RS 5 DTM | Classified 44L gap 3.383 | Mattias Ekström
 5 g1 #21 BMW Team MTEK | BMW M3 DTM | Classified 44L gap 3.652 | Marco Wittmann
 6 g9 #24 Audi Sport Team Abt | Audi RS 5 DTM | Classified 44L gap 3.834 | Adrien Tambay
 7 g5 #8 BMW Team RBM | BMW M3 DTM | Classified 44L gap 4.444 | Joey Hand
 8 g6 #6 Team Rosberg | Audi RS 5 DTM | Classified 44L gap 5.060 | Filipe Albuquerque
 9 g12 #3 HWA Team | Mercedes AMG C-Coupé | Classified 44L gap 6.795 | Gary Paffett
 10 g10 #20 Phoenix Racing | Audi RS 5 DTM | Classified 44L gap 7.023 | Miguel Molina
 11 g19 #15 BMW Team RMG | BMW M3 DTM | Classified 44L gap 7.397 | Martin Tomczyk
 12 g14 #18 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 44L gap 7.415 | Pascal Wehrlein
 13 g17 #12 Abt Sportsline | Audi RS 5 DTM | Classified 44L gap 8.068 | Jamie Green
 14 g7 #5 Team Rosberg | Audi RS 5 DTM | Classified 44L gap 9.992 | Edoardo Mortara
 15 g16 #9 HWA Team | Mercedes AMG C-Coupé | Classified 44L gap 10.596 | Christian Vietoris
 16 g21 #10 HWA Team | Mercedes AMG C-Coupé | Classified 44L gap 11.117 | Robert Wickens
 17 g20 #17 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 44L gap 11.558 | Daniel Juncadella
 18 g8 #22 BMW Team MTEK | BMW M3 DTM | Classified 44L gap 12.043 | Timo Glock
 19 g15 #16 BMW Team RMG | BMW M3 DTM | Classified 44L gap 12.890 | Andy Priaulx
 20 g18 #1 BMW Team Schnitzer | BMW M3 DTM | Classified 44L gap 21.301 | Bruno Spengler
 21 g13 #2 BMW Team Schnitzer | BMW M3 DTM | Classified 37L gap 7 LAPS | Dirk Werner
 22 g22 #4 HWA Team | Mercedes AMG C-Coupé | RET 1L gap RET | Roberto Merhi
