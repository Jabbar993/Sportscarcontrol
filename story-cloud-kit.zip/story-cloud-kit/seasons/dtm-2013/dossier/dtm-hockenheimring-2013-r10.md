# dtm-hockenheimring-2013-r10

Event: DTM Hockenheimring | Circuit: Hockenheimring | Date: 2013-10-20
Scheduled: ? | Official duration: 1:16:44.053 | Laps (winner): 41

## Qualifying (archive order)
Q1 #1 [DTMV8] 1:33.443 BMW Team Schnitzer | Bruno Spengler
Q2 #2 [DTMV8] 1:33.746 BMW Team Schnitzer | Dirk Werner
Q3 #16 [DTMV8] 1:34.081 BMW Team RMG | Andy Priaulx
Q4 #22 [DTMV8]  BMW Team MTEK | Timo Glock
Q5 #20 [DTMV8] 1:33.572 Phoenix Racing | Miguel Molina
Q6 #21 [DTMV8] 1:33.575 BMW Team MTEK | Marco Wittmann
Q7 #11 [DTMV8] 1:33.706 Abt Sportsline | Mattias Ekström
Q8 #24 [DTMV8] 1:33.717 Audi Sport Team Abt | Adrien Tambay
Q9 #19 [DTMV8] 1:33.748 Phoenix Racing | Mike Rockenfeller
Q10 #7 [DTMV8] 1:34.247 BMW Team RBM | Augusto Farfus
Q11 #15 [DTMV8] 1:33.594 BMW Team RMG | Martin Tomczyk
Q12 #23 [DTMV8] 1:33.600 Audi Sport Team Abt | Timo Scheider
Q13 #10 [DTMV8] 1:33.719 HWA Team | Robert Wickens
Q14 #6 [DTMV8] 1:33.784 Team Rosberg | Filipe Albuquerque
Q15 #18 [DTMV8] 1:33.839 Mücke Motorsport | Pascal Wehrlein
Q16 #3 [DTMV8] 1:33.899 HWA Team | Gary Paffett
Q17 #17 [DTMV8] 1:33.963 Mücke Motorsport | Daniel Juncadella
Q18 #5 [DTMV8] 1:34.097 Team Rosberg | Edoardo Mortara
Q19 #12 [DTMV8] 1:34.162 Abt Sportsline | Jamie Green
Q20 #9 [DTMV8] 1:34.170 HWA Team | Christian Vietoris
Q21 #4 [DTMV8] 1:34.308 HWA Team | Roberto Merhi
Q22 #8 [DTMV8] 1:34.389 BMW Team RBM | Joey Hand

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #1 Bruno Spengler 1:33.443 BMW Team Schnitzer
DTMV8: #1 Bruno Spengler 1:33.443 BMW Team Schnitzer

## Fastest laps (archive)
Overall: #9 Christian Vietoris 1:46.908 lap 39
DTMV8: #9 Christian Vietoris 1:46.908 lap 39

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g4 #22 BMW Team MTEK | BMW M3 DTM | Classified 41L gap — | Timo Glock
 2 g21 #4 HWA Team | Mercedes AMG C-Coupé | Classified 41L gap 2.787 | Roberto Merhi
 3 g1 #1 BMW Team Schnitzer | BMW M3 DTM | Classified 41L gap 10.120 | Bruno Spengler
 4 g7 #11 Abt Sportsline | Audi RS 5 DTM | Classified 41L gap 11.365 | Mattias Ekström
 5 g5 #20 Phoenix Racing | Audi RS 5 DTM | Classified 41L gap 15.619 | Miguel Molina
 6 g3 #16 BMW Team RMG | BMW M3 DTM | Classified 41L gap 20.922 | Andy Priaulx
 7 g20 #9 HWA Team | Mercedes AMG C-Coupé | Classified 41L gap 30.466 | Christian Vietoris
 8 g2 #2 BMW Team Schnitzer | BMW M3 DTM | Classified 41L gap 31.276 | Dirk Werner
 9 g16 #3 HWA Team | Mercedes AMG C-Coupé | Classified 41L gap 37.027 | Gary Paffett
 10 g17 #17 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 41L gap 37.246 | Daniel Juncadella
 11 g10 #7 BMW Team RBM | BMW M3 DTM | Classified 41L gap 44.516 | Augusto Farfus
 12 g19 #12 Abt Sportsline | Audi RS 5 DTM | Classified 41L gap 44.811 | Jamie Green
 13 g12 #23 Audi Sport Team Abt | Audi RS 5 DTM | Classified 41L gap 45.503 | Timo Scheider
 14 g8 #24 Audi Sport Team Abt | Audi RS 5 DTM | Classified 41L gap 48.966 | Adrien Tambay
 15 g18 #5 Team Rosberg | Audi RS 5 DTM | Classified 41L gap 1:06.528 | Edoardo Mortara
 16 g9 #19 Phoenix Racing | Audi RS 5 DTM | Classified 41L gap 1:14.060 | Mike Rockenfeller
 17 g15 #18 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 41L gap 1:19.961 | Pascal Wehrlein
 18 g13 #10 HWA Team | Mercedes AMG C-Coupé | Classified 41L gap 1:34.478 | Robert Wickens
 19 g11 #15 BMW Team RMG | BMW M3 DTM | Classified 41L gap 1:59.697 | Martin Tomczyk
 20 g22 #8 BMW Team RBM | BMW M3 DTM | Classified 40L gap 1 LAP | Joey Hand
 21 g6 #21 BMW Team MTEK | BMW M3 DTM | DSQ 37L gap DSQ | Marco Wittmann
 22 g14 #6 Team Rosberg | Audi RS 5 DTM | RET 1L gap RET | Filipe Albuquerque
