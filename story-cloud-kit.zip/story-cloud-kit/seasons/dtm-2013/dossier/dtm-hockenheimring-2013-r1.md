# dtm-hockenheimring-2013-r1

Event: DTM Hockenheimring | Circuit: Hockenheimring | Date: 2013-05-05
Scheduled: ? | Official duration: 1:10:11.583 | Laps (winner): 42

## Qualifying (archive order)
Q1 #23 [DTMV8] 1:35.918 Audi Sport Team Abt | Timo Scheider
Q2 #7 [DTMV8] 1:36.034 BMW Team RBM | Augusto Farfus
Q3 #9 [DTMV8] 1:36.194 HWA Team | Christian Vietoris
Q4 #10 [DTMV8]  HWA Team | Robert Wickens
Q5 #11 [DTMV8] 1:40.005 Abt Sportsline | Mattias Ekström
Q6 #3 [DTMV8] 1:40.496 HWA Team | Gary Paffett
Q7 #1 [DTMV8] 1:41.184 BMW Team Schnitzer | Bruno Spengler
Q8 #18 [DTMV8] 1:41.337 Mücke Motorsport | Pascal Wehrlein
Q9 #8 [DTMV8] 1:41.637 BMW Team RBM | Joey Hand
Q10 #17 [DTMV8] 1:43.775 Mücke Motorsport | Daniel Juncadella
Q11 #15 [DTMV8] 1:48.947 BMW Team RMG | Martin Tomczyk
Q12 #12 [DTMV8] 1:49.129 Abt Sportsline | Jamie Green
Q13 #24 [DTMV8] 1:49.136 Audi Sport Team Abt | Adrien Tambay
Q14 #19 [DTMV8] 1:49.366 Phoenix Racing | Mike Rockenfeller
Q15 #22 [DTMV8] 1:49.842 BMW Team MTEK | Timo Glock
Q16 #6 [DTMV8] 1:50.296 Team Rosberg | Filipe Albuquerque
Q17 #16 [DTMV8] 1:50.190 BMW Team RMG | Andy Priaulx
Q18 #20 [DTMV8] 1:50.399 Phoenix Racing | Miguel Molina
Q19 #5 [DTMV8] 1:50.416 Team Rosberg | Edoardo Mortara
Q20 #4 [DTMV8] 1:50.810 HWA Team | Roberto Merhi
Q21 #21 [DTMV8] 1:50.871 BMW Team MTEK | Marco Wittmann
Q22 #2 [DTMV8] 1:50.926 BMW Team Schnitzer | Dirk Werner

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #23 Timo Scheider 1:35.918 Audi Sport Team Abt
DTMV8: #23 Timo Scheider 1:35.918 Audi Sport Team Abt

## Fastest laps (archive)
Overall: #7 Augusto Farfus 1:34.504 lap 5
DTMV8: #7 Augusto Farfus 1:34.504 lap 5

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g2 #7 BMW Team RBM | BMW M3 DTM | Classified 42L gap — | Augusto Farfus
 2 g20 #2 BMW Team Schnitzer | BMW M3 DTM | Classified 42L gap 3.692 | Dirk Werner
 3 g3 #9 HWA Team | Mercedes AMG C-Coupé | Classified 42L gap 9.675 | Christian Vietoris
 4 g6 #3 HWA Team | Mercedes AMG C-Coupé | Classified 42L gap 12.613 | Gary Paffett
 5 g7 #1 BMW Team Schnitzer | BMW M3 DTM | Classified 42L gap 13.212 | Bruno Spengler
 6 g1 #23 Audi Sport Team Abt | Audi RS 5 DTM | Classified 42L gap 13.753 | Timo Scheider
 7 g9 #8 BMW Team RBM | BMW M3 DTM | Classified 42L gap 14.100 | Joey Hand
 8 g14 #19 Phoenix Racing | Audi RS 5 DTM | Classified 42L gap 14.477 | Mike Rockenfeller
 9 g22 #21 BMW Team MTEK | BMW M3 DTM | Classified 42L gap 17.894 | Marco Wittmann
 10 g21 #4 HWA Team | Mercedes AMG C-Coupé | Classified 42L gap 19.537 | Roberto Merhi
 11 g8 #18 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 42L gap 20.902 | Pascal Wehrlein
 12 g10 #17 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 42L gap 26.169 | Daniel Juncadella
 13 g11 #15 BMW Team RMG | BMW M3 DTM | Classified 42L gap 30.904 | Martin Tomczyk
 14 g12 #12 Abt Sportsline | Audi RS 5 DTM | Classified 42L gap 41.166 | Jamie Green
 15 g18 #20 Phoenix Racing | Audi RS 5 DTM | Classified 42L gap 43.535 | Miguel Molina
 16 g16 #6 Team Rosberg | Audi RS 5 DTM | Classified 42L gap 54.077 | Filipe Albuquerque
 17 g17 #16 BMW Team RMG | BMW M3 DTM | Classified 40L gap 2 LAPS | Andy Priaulx
 18 g5 #11 Abt Sportsline | Audi RS 5 DTM | RET 28L gap RET | Mattias Ekström
 19 g19 #5 Team Rosberg | Audi RS 5 DTM | RET 21L gap RET | Edoardo Mortara
 20 g15 #22 BMW Team MTEK | BMW M3 DTM | RET 17L gap RET | Timo Glock
 21 g4 #10 HWA Team | Mercedes AMG C-Coupé | RET 5L gap RET | Robert Wickens
 22 g13 #24 Audi Sport Team Abt | Audi RS 5 DTM | RET 4L gap RET | Adrien Tambay
