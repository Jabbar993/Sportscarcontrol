# dtm-norisring-2013-r5

Event: DTM Norisring | Circuit: Norisring | Date: 2013-07-14
Scheduled: ? | Official duration: 1:12:17.344 | Laps (winner): 83

## Qualifying (archive order)
Q1 #10 [DTMV8] 48.384 HWA Team | Robert Wickens
Q2 #1 [DTMV8] 48.443 BMW Team Schnitzer | Bruno Spengler
Q3 #3 [DTMV8] 48.460 HWA Team | Gary Paffett
Q4 #5 [DTMV8] 48.490 Team Rosberg | Edoardo Mortara
Q5 #18 [DTMV8] 48.356 Mücke Motorsport | Pascal Wehrlein
Q6 #16 [DTMV8] 48.406 BMW Team RMG | Andy Priaulx
Q7 #17 [DTMV8] 48.410 Mücke Motorsport | Daniel Juncadella
Q8 #6 [DTMV8] 48.454 Team Rosberg | Filipe Albuquerque
Q9 #11 [DTMV8] 48.456 Abt Sportsline | Mattias Ekström
Q10 #9 [DTMV8] 48.485 HWA Team | Christian Vietoris
Q11 #24 [DTMV8] 48.443 Audi Sport Team Abt | Adrien Tambay
Q12 #21 [DTMV8] 48.446 BMW Team MTEK | Marco Wittmann
Q13 #23 [DTMV8] 48.459 Audi Sport Team Abt | Timo Scheider
Q14 #12 [DTMV8] 48.465 Abt Sportsline | Jamie Green
Q15 #7 [DTMV8] 48.628 BMW Team RBM | Augusto Farfus
Q16 #22 [DTMV8] 48.724 BMW Team MTEK | Timo Glock
Q17 #15 [DTMV8] 48.632 BMW Team RMG | Martin Tomczyk
Q18 #8 [DTMV8] 48.636 BMW Team RBM | Joey Hand
Q19 #19 [DTMV8] 48.644 Phoenix Racing | Mike Rockenfeller
Q20 #2 [DTMV8] 48.656 BMW Team Schnitzer | Dirk Werner
Q21 #4 [DTMV8] 48.848 HWA Team | Roberto Merhi
Q22 #20 [DTMV8] 48.874 Phoenix Racing | Miguel Molina

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #10 Robert Wickens 48.384 HWA Team
DTMV8: #10 Robert Wickens 48.384 HWA Team

## Fastest laps (archive)
Overall: #9 Christian Vietoris 48.572 lap 9
DTMV8: #9 Christian Vietoris 48.572 lap 9

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 2 g1 #10 HWA Team | Mercedes AMG C-Coupé | Classified 83L gap — | Robert Wickens
 3 g10 #9 HWA Team | Mercedes AMG C-Coupé | Classified 83L gap 3.636 | Christian Vietoris
 4 g7 #17 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 83L gap 4.393 | Daniel Juncadella
 5 g21 #19 Phoenix Racing | Audi RS 5 DTM | Classified 83L gap 5.765 | Mike Rockenfeller
 6 g2 #1 BMW Team Schnitzer | BMW M3 DTM | Classified 83L gap 14.437 | Bruno Spengler
 7 g20 #4 HWA Team | Mercedes AMG C-Coupé | Classified 83L gap 15.948 | Roberto Merhi
 8 g18 #8 BMW Team RBM | BMW M3 DTM | Classified 83L gap 28.552 | Joey Hand
 9 g6 #16 BMW Team RMG | BMW M3 DTM | Classified 83L gap 32.263 | Andy Priaulx
 10 g12 #21 BMW Team MTEK | BMW M3 DTM | Classified 83L gap 32.949 | Marco Wittmann
 11 g19 #2 BMW Team Schnitzer | BMW M3 DTM | Classified 83L gap 37.780 | Dirk Werner
 12 g8 #6 Team Rosberg | Audi RS 5 DTM | Classified 83L gap 40.029 | Filipe Albuquerque
 13 g16 #22 BMW Team MTEK | BMW M3 DTM | Classified 83L gap 40.221 | Timo Glock
 14 g22 #20 Phoenix Racing | Audi RS 5 DTM | Classified 83L gap 41.922 | Miguel Molina
 15 g11 #24 Audi Sport Team Abt | Audi RS 5 DTM | Classified 83L gap 51.445 | Adrien Tambay
 16 g15 #7 BMW Team RBM | BMW M3 DTM | Classified 82L gap 1 LAP | Augusto Farfus
 17 g4 #5 Team Rosberg | Audi RS 5 DTM | Classified 81L gap 2 LAPS | Edoardo Mortara
 18 g3 #3 HWA Team | Mercedes AMG C-Coupé | Classified 81L gap 2 LAPS | Gary Paffett
 19 g14 #12 Abt Sportsline | Audi RS 5 DTM | Classified 65L gap 18 LAPS | Jamie Green
 20 g5 #18 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 65L gap 18 LAPS | Pascal Wehrlein
 21 g9 #11 Abt Sportsline | Audi RS 5 DTM | DSQ 83L gap DSQ | Mattias Ekström
 22 g17 #15 BMW Team RMG | BMW M3 DTM | RET 11L gap RET | Martin Tomczyk
 23 g13 #23 Audi Sport Team Abt | Audi RS 5 DTM | RET 0L gap RET | Timo Scheider
