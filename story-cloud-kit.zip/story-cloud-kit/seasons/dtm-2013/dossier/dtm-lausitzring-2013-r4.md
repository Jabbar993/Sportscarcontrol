# dtm-lausitzring-2013-r4

Event: DTM Lausitzring | Circuit: Lausitzring | Date: 2013-06-16
Scheduled: ? | Official duration: 1:09:58.562 | Laps (winner): 52

## Qualifying (archive order)
Q1 #9 [DTMV8] 1:17.715 HWA Team | Christian Vietoris
Q2 #3 [DTMV8] 1:17.940 HWA Team | Gary Paffett
Q3 #12 [DTMV8] 1:18.028 Abt Sportsline | Jamie Green
Q4 #10 [DTMV8] 1:18.133 HWA Team | Robert Wickens
Q5 #1 [DTMV8] 1:17.967 BMW Team Schnitzer | Bruno Spengler
Q6 #19 [DTMV8] 1:18.134 Phoenix Racing | Mike Rockenfeller
Q7 #24 [DTMV8] 1:18.161 Audi Sport Team Abt | Adrien Tambay
Q8 #5 [DTMV8] 1:18.205 Team Rosberg | Edoardo Mortara
Q9 #4 [DTMV8] 1:18.335 HWA Team | Roberto Merhi
Q10 #7 [DTMV8] 1:18.383 BMW Team RBM | Augusto Farfus
Q11 #18 [DTMV8] 1:18.225 Mücke Motorsport | Pascal Wehrlein
Q12 #2 [DTMV8] 1:18.361 BMW Team Schnitzer | Dirk Werner
Q13 #6 [DTMV8] 1:18.421 Team Rosberg | Filipe Albuquerque
Q14 #22 [DTMV8] 1:18.485 BMW Team MTEK | Timo Glock
Q15 #17 [DTMV8] 1:18.502 Mücke Motorsport | Daniel Juncadella
Q16 #20 [DTMV8] 1:18.229 Phoenix Racing | Miguel Molina
Q17 #23 [DTMV8] 1:18.596 Audi Sport Team Abt | Timo Scheider
Q18 #11 [DTMV8] 1:18.742 Abt Sportsline | Mattias Ekström
Q19 #21 [DTMV8] 1:18.777 BMW Team MTEK | Marco Wittmann
Q20 #8 [DTMV8] 1:18.909 BMW Team RBM | Joey Hand
Q21 #16 [DTMV8] 1:19.065 BMW Team RMG | Andy Priaulx
Q22 #15 [DTMV8] 1:19.137 BMW Team RMG | Martin Tomczyk

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #9 Christian Vietoris 1:17.715 HWA Team
DTMV8: #9 Christian Vietoris 1:17.715 HWA Team

## Fastest laps (archive)
Overall: #19 Mike Rockenfeller 1:18.268 lap 7
DTMV8: #19 Mike Rockenfeller 1:18.268 lap 7

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g2 #3 HWA Team | Mercedes AMG C-Coupé | Classified 52L gap — | Gary Paffett
 2 g6 #19 Phoenix Racing | Audi RS 5 DTM | Classified 52L gap 6.800 | Mike Rockenfeller
 3 g1 #9 HWA Team | Mercedes AMG C-Coupé | Classified 52L gap 11.510 | Christian Vietoris
 4 g4 #10 HWA Team | Mercedes AMG C-Coupé | Classified 52L gap 12.790 | Robert Wickens
 5 g3 #12 Abt Sportsline | Audi RS 5 DTM | Classified 52L gap 14.138 | Jamie Green
 6 g13 #17 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 52L gap 19.462 | Daniel Juncadella
 7 g5 #1 BMW Team Schnitzer | BMW M3 DTM | Classified 52L gap 21.592 | Bruno Spengler
 8 g18 #11 Abt Sportsline | Audi RS 5 DTM | Classified 52L gap 21.621 | Mattias Ekström
 9 g8 #5 Team Rosberg | Audi RS 5 DTM | Classified 52L gap 24.715 | Edoardo Mortara
 10 g9 #4 HWA Team | Mercedes AMG C-Coupé | Classified 52L gap 25.643 | Roberto Merhi
 11 g7 #24 Audi Sport Team Abt | Audi RS 5 DTM | Classified 52L gap 27.968 | Adrien Tambay
 12 g15 #7 BMW Team RBM | BMW M3 DTM | Classified 52L gap 34.178 | Augusto Farfus
 13 g11 #2 BMW Team Schnitzer | BMW M3 DTM | Classified 52L gap 38.000 | Dirk Werner
 14 g17 #22 BMW Team MTEK | BMW M3 DTM | Classified 52L gap 49.305 | Timo Glock
 15 g20 #8 BMW Team RBM | BMW M3 DTM | Classified 52L gap 53.321 | Joey Hand
 16 g14 #20 Phoenix Racing | Audi RS 5 DTM | Classified 52L gap 58.882 | Miguel Molina
 17 g10 #18 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 52L gap 59.948 | Pascal Wehrlein
 18 g12 #6 Team Rosberg | Audi RS 5 DTM | Classified 52L gap 1:03.083 | Filipe Albuquerque
 19 g22 #15 BMW Team RMG | BMW M3 DTM | Classified 52L gap 1:03.107 | Martin Tomczyk
 20 g16 #23 Audi Sport Team Abt | Audi RS 5 DTM | Classified 52L gap 1:08.006 | Timo Scheider
 21 g19 #21 BMW Team MTEK | BMW M3 DTM | Classified 51L gap 1 LAP | Marco Wittmann
 22 g21 #16 BMW Team RMG | BMW M3 DTM | Classified 51L gap 1 LAP | Andy Priaulx
