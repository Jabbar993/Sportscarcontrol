# dtm-brandshatch-2013-r2

Event: DTM Brands Hatch | Circuit: Brands Hatch | Date: 2013-05-19
Scheduled: ? | Official duration: 1:11:28.719 | Laps (winner): 98

## Qualifying (archive order)
Q1 #15 [DTMV8] 41.158 BMW Team RMG | Martin Tomczyk
Q2 #19 [DTMV8] 41.193 Phoenix Racing | Mike Rockenfeller
Q3 #7 [DTMV8] 41.197 BMW Team RBM | Augusto Farfus
Q4 #8 [DTMV8] 41.460 BMW Team RBM | Joey Hand
Q5 #1 [DTMV8] 41.274 BMW Team Schnitzer | Bruno Spengler
Q6 #23 [DTMV8] 41.282 Audi Sport Team Abt | Timo Scheider
Q7 #21 [DTMV8] 41.293 BMW Team MTEK | Marco Wittmann
Q8 #16 [DTMV8] 41.358 BMW Team RMG | Andy Priaulx
Q9 #5 [DTMV8] 41.394 Team Rosberg | Edoardo Mortara
Q10 #20 [DTMV8] 41.472 Phoenix Racing | Miguel Molina
Q11 #22 [DTMV8] 41.353 BMW Team MTEK | Timo Glock
Q12 #3 [DTMV8] 41.363 HWA Team | Gary Paffett
Q13 #11 [DTMV8] 41.401 Abt Sportsline | Mattias Ekström
Q14 #10 [DTMV8] 41.440 HWA Team | Robert Wickens
Q15 #2 [DTMV8] 41.480 BMW Team Schnitzer | Dirk Werner
Q16 #24 [DTMV8] 41.539 Audi Sport Team Abt | Adrien Tambay
Q17 #9 [DTMV8] 41.709 HWA Team | Christian Vietoris
Q18 #12 [DTMV8] 41.727 Abt Sportsline | Jamie Green
Q19 #6 [DTMV8] 41.745 Team Rosberg | Filipe Albuquerque
Q20 #4 [DTMV8] 41.748 HWA Team | Roberto Merhi
Q21 #18 [DTMV8] 41.783 Mücke Motorsport | Pascal Wehrlein
Q22 #17 [DTMV8] 41.787 Mücke Motorsport | Daniel Juncadella

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #15 Martin Tomczyk 41.158 BMW Team RMG
DTMV8: #15 Martin Tomczyk 41.158 BMW Team RMG

## Fastest laps (archive)
Overall: #3 Gary Paffett 42.124 lap 6
DTMV8: #3 Gary Paffett 42.124 lap 6

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #19 Phoenix Racing | Audi RS 5 DTM | Classified 98L gap — | Mike Rockenfeller
 2 g4 #1 BMW Team Schnitzer | BMW M3 DTM | Classified 98L gap 7.641 | Bruno Spengler
 3 g13 #10 HWA Team | Mercedes AMG C-Coupé | Classified 98L gap 24.368 | Robert Wickens
 4 g6 #21 BMW Team MTEK | BMW M3 DTM | Classified 98L gap 24.964 | Marco Wittmann
 5 g3 #8 BMW Team RBM | BMW M3 DTM | Classified 98L gap 26.076 | Joey Hand
 6 g11 #3 HWA Team | Mercedes AMG C-Coupé | Classified 98L gap 27.071 | Gary Paffett
 7 g12 #11 Abt Sportsline | Audi RS 5 DTM | Classified 98L gap 36.523 | Mattias Ekström
 8 g16 #9 HWA Team | Mercedes AMG C-Coupé | Classified 98L gap 38.940 | Christian Vietoris
 9 g5 #23 Audi Sport Team Abt | Audi RS 5 DTM | Classified 98L gap 39.519 | Timo Scheider
 10 g20 #18 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 98L gap 40.290 | Pascal Wehrlein
 11 g9 #20 Phoenix Racing | Audi RS 5 DTM | Classified 98L gap 40.853 | Miguel Molina
 12 g14 #2 BMW Team Schnitzer | BMW M3 DTM | Classified 97L gap 1 LAP | Dirk Werner
 13 g22 #15 BMW Team RMG | BMW M3 DTM | Classified 97L gap 1 LAP | Martin Tomczyk
 14 g10 #22 BMW Team MTEK | BMW M3 DTM | Classified 97L gap 1 LAP | Timo Glock
 15 g17 #12 Abt Sportsline | Audi RS 5 DTM | Classified 97L gap 1 LAP | Jamie Green
 16 g19 #4 HWA Team | Mercedes AMG C-Coupé | Classified 97L gap 1 LAP | Roberto Merhi
 17 g18 #6 Team Rosberg | Audi RS 5 DTM | Classified 97L gap 1 LAP | Filipe Albuquerque
 18 g15 #24 Audi Sport Team Abt | Audi RS 5 DTM | Classified 97L gap 1 LAP | Adrien Tambay
 19 g7 #16 BMW Team RMG | BMW M3 DTM | Classified 96L gap 2 LAPS | Andy Priaulx
 20 g21 #17 Mücke Motorsport | Mercedes AMG C-Coupé | Classified 96L gap 2 LAPS | Daniel Juncadella
 21 g8 #5 Team Rosberg | Audi RS 5 DTM | Classified 87L gap 11 LAPS | Edoardo Mortara
 22 g2 #7 BMW Team RBM | BMW M3 DTM | RET 65L gap RET | Augusto Farfus
