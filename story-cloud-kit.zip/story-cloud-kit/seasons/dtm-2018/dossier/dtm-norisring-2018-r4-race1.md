# dtm-norisring-2018-r4-race1

Event: DTM Norisring Race 1 | Circuit: Norisring | Date: 2018-06-23
Scheduled: 00:55:00 | Official duration: 00:56:12.918 | Laps (winner): 68

## Qualifying (archive order)
Q1 #48 [DTMV8] 47.843 Silberpfeil Energy Mercedes-AMG Motorsport | Edoardo Mortara
Q2 #25 [DTMV8] 47.844 BMW Team RMR | Philipp Eng
Q3 #11 [DTMV8] 47.866 BMW Team RMG | Marco Wittmann
Q4 #2 [DTMV8] 47.872 Mercedes-AMG Motorsport Petronas | Gary Paffett
Q5 #3 [DTMV8] 47.899 Mercedes-AMG Motorsport Remus | Paul di Resta
Q6 #23 [DTMV8] 47.919 Mercedes-AMG Motorsport Remus | Daniel Juncadella
Q7 #22 [DTMV8] 47.934 Silberpfeil Energy Mercedes-AMG Motorsport | Lucas Auer
Q8 #16 [DTMV8] 47.950 BMW Team RMR | Timo Glock
Q9 #7 [DTMV8] 47.973 BMW Team RBM | Bruno Spengler
Q10 #51 [DTMV8] 48.067 Audi Sport Team Abt Sportsline | Nico Müller
Q11 #47 [DTMV8] 48.091 BMW Team RBM | Joel Eriksson
Q12 #15 [DTMV8] 48.098 BMW Team RMG | Augusto Farfus
Q13 #53 [DTMV8] 48.221 Audi Sport Team Rosberg | Jamie Green
Q14 #94 [DTMV8] 48.253 Mercedes-AMG Motorsport Petronas | Pascal Wehrlein
Q15 #28 [DTMV8] 48.301 Audi Sport Team Phoenix | Loïc Duval
Q16 #4 [DTMV8] 48.312 Audi Sport Team Abt Sportsline | Robin Frijns
Q17 #99 [DTMV8] 48.360 Audi Sport Team Phoenix | Mike Rockenfeller
Q18 #33 [DTMV8] 48.444 Audi Sport Team Rosberg | René Rast

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #48 Edoardo Mortara 47.843 Silberpfeil Energy Mercedes-AMG Motorsport
DTMV8: #48 Edoardo Mortara 47.843 Silberpfeil Energy Mercedes-AMG Motorsport

## Fastest laps (archive)
Overall: #23 Daniel Juncadella 48.307 lap 7
DTMV8: #23 Daniel Juncadella 48.307 lap 7

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #48 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 68L gap — | Edoardo Mortara
 2 g4 #2 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 68L gap 0.681 | Gary Paffett
 3 g3 #11 BMW Team RMG | BMW M4 DTM | Classified 68L gap 1.286 | Marco Wittmann
 4 g5 #3 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 68L gap 8.550 | Paul di Resta
 5 g2 #25 BMW Team RMR | BMW M4 DTM | Classified 68L gap 13.773 | Philipp Eng
 6 g9 #7 BMW Team RBM | BMW M4 DTM | Classified 68L gap 14.169 | Bruno Spengler
 7 g7 #22 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 68L gap 14.874 | Lucas Auer
 8 g6 #23 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 68L gap 15.205 | Daniel Juncadella
 9 g11 #47 BMW Team RBM | BMW M4 DTM | Classified 68L gap 15.813 | Joel Eriksson
 10 g8 #16 BMW Team RMR | BMW M4 DTM | Classified 68L gap 16.681 | Timo Glock
 11 g13 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 68L gap 23.330 | Jamie Green
 12 g16 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 68L gap 24.505 | Robin Frijns
 13 g14 #94 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 68L gap 28.033 | Pascal Wehrlein
 14 g12 #15 BMW Team RMG | BMW M4 DTM | Classified 68L gap 30.382 | Augusto Farfus
 15 g17 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 68L gap 30.803 | Mike Rockenfeller
 16 g18 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 68L gap 31.632 | René Rast
 17 g15 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 68L gap 42.539 | Loïc Duval
 18 g10 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 67L gap 1 LAP | Nico Müller
