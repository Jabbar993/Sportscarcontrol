# dtm-nurburgring-2018-r8-race2

Event: DTM Nürburgring Race 2 | Circuit: Nürburgring | Date: 2018-09-09
Scheduled: 00:55:00 | Official duration: 00:57:17.440 | Laps (winner): 40

## Qualifying (archive order)
Q1 #33 [DTMV8] 1:22.140 Audi Sport Team Rosberg | René Rast
Q2 #2 [DTMV8] 1:22.146 Mercedes-AMG Motorsport Petronas | Gary Paffett
Q3 #25 [DTMV8] 1:22.159 BMW Team RMR | Philipp Eng
Q4 #16 [DTMV8] 1:22.203 BMW Team RMR | Timo Glock
Q5 #22 [DTMV8] 1:22.331 Silberpfeil Energy Mercedes-AMG Motorsport | Lucas Auer
Q6 #94 [DTMV8] 1:22.331 Mercedes-AMG Motorsport Petronas | Pascal Wehrlein
Q7 #99 [DTMV8] 1:22.468 Audi Sport Team Phoenix | Mike Rockenfeller
Q8 #7 [DTMV8] 1:22.502 BMW Team RBM | Bruno Spengler
Q9 #11 [DTMV8] 1:22.505 BMW Team RMG | Marco Wittmann
Q10 #47 [DTMV8] 1:22.540 BMW Team RBM | Joel Eriksson
Q11 #3 [DTMV8] 1:22.566 Mercedes-AMG Motorsport Remus | Paul di Resta
Q12 #51 [DTMV8] 1:22.568 Audi Sport Team Abt Sportsline | Nico Müller
Q13 #15 [DTMV8] 1:22.586 BMW Team RMG | Augusto Farfus
Q14 #23 [DTMV8] 1:22.624 Mercedes-AMG Motorsport Remus | Daniel Juncadella
Q15 #53 [DTMV8] 1:22.711 Audi Sport Team Rosberg | Jamie Green
Q16 #28 [DTMV8] 1:22.887 Audi Sport Team Phoenix | Loïc Duval
Q17 #4 [DTMV8] 1:22.921 Audi Sport Team Abt Sportsline | Robin Frijns
Q18 #48 [DTMV8] 1:22.925 Silberpfeil Energy Mercedes-AMG Motorsport | Edoardo Mortara

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #33 René Rast 1:22.140 Audi Sport Team Rosberg
DTMV8: #33 René Rast 1:22.140 Audi Sport Team Rosberg

## Fastest laps (archive)
Overall: #2 Gary Paffett 1:23.875 lap 23
DTMV8: #2 Gary Paffett 1:23.875 lap 23

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 40L gap — | René Rast
 2 g11 #3 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 40L gap 2.739 | Paul di Resta
 3 g9 #11 BMW Team RMG | BMW M4 DTM | Classified 40L gap 3.439 | Marco Wittmann
 4 g8 #7 BMW Team RBM | BMW M4 DTM | Classified 40L gap 5.643 | Bruno Spengler
 5 g2 #2 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 40L gap 7.177 | Gary Paffett
 6 g10 #47 BMW Team RBM | BMW M4 DTM | Classified 40L gap 7.862 | Joel Eriksson
 7 g13 #15 BMW Team RMG | BMW M4 DTM | Classified 40L gap 14.802 | Augusto Farfus
 8 g3 #25 BMW Team RMR | BMW M4 DTM | Classified 40L gap 16.174 | Philipp Eng
 9 g6 #94 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 40L gap 30.606 | Pascal Wehrlein
 10 g17 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 40L gap 30.903 | Robin Frijns
 11 g18 #48 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 40L gap 32.439 | Edoardo Mortara
 12 g16 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 40L gap 34.347 | Loïc Duval
 13 g7 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 40L gap 36.185 | Mike Rockenfeller
 14 g12 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 40L gap 36.445 | Nico Müller
 15 g15 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 40L gap 1:03.843 | Jamie Green
 16 g4 #16 BMW Team RMR | BMW M4 DTM | Classified 40L gap 1:16.234 | Timo Glock
 17 g14 #23 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | NC 38L gap 2 LAPS | Daniel Juncadella
 18 g5 #22 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | NC 33L gap 7 LAPS | Lucas Auer
