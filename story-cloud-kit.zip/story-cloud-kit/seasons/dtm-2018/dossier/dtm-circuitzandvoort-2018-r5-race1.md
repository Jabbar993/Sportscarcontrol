# dtm-circuitzandvoort-2018-r5-race1

Event: DTM Circuit Zandvoort Race 1 | Circuit: Zandvoort | Date: 2018-07-14
Scheduled: 00:55:00 | Official duration: 00:57:29.724 | Laps (winner): 34

## Qualifying (archive order)
Q1 #2 [DTMV8] 1:30.778 Mercedes-AMG Motorsport Petronas | Gary Paffett
Q2 #94 [DTMV8] 1:30.838 Mercedes-AMG Motorsport Petronas | Pascal Wehrlein
Q3 #3 [DTMV8] 1:30.980 Mercedes-AMG Motorsport Remus | Paul di Resta
Q4 #22 [DTMV8] 1:31.063 Silberpfeil Energy Mercedes-AMG Motorsport | Lucas Auer
Q5 #16 [DTMV8] 1:31.217 BMW Team RMR | Timo Glock
Q6 #11 [DTMV8] 1:31.337 BMW Team RMG | Marco Wittmann
Q7 #4 [DTMV8] 1:31.375 Audi Sport Team Abt Sportsline | Robin Frijns
Q8 #51 [DTMV8] 1:31.424 Audi Sport Team Abt Sportsline | Nico Müller
Q9 #33 [DTMV8] 1:31.461 Audi Sport Team Rosberg | René Rast
Q10 #15 [DTMV8] 1:31.469 BMW Team RMG | Augusto Farfus
Q11 #99 [DTMV8] 1:31.477 Audi Sport Team Phoenix | Mike Rockenfeller
Q12 #7 [DTMV8] 1:31.477 BMW Team RBM | Bruno Spengler
Q13 #25 [DTMV8] 1:31.482 BMW Team RMR | Philipp Eng
Q14 #23 [DTMV8] 1:31.507 Mercedes-AMG Motorsport Remus | Daniel Juncadella
Q15 #47 [DTMV8] 1:31.526 BMW Team RBM | Joel Eriksson
Q16 #28 [DTMV8] 1:31.623 Audi Sport Team Phoenix | Loïc Duval
Q17 #53 [DTMV8] 1:31.761 Audi Sport Team Rosberg | Jamie Green
Q18 #48 [DTMV8] 1:31.967 Silberpfeil Energy Mercedes-AMG Motorsport | Edoardo Mortara

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #2 Gary Paffett 1:30.778 Mercedes-AMG Motorsport Petronas
DTMV8: #2 Gary Paffett 1:30.778 Mercedes-AMG Motorsport Petronas

## Fastest laps (archive)
Overall: #2 Gary Paffett 1:32.317 lap 4
DTMV8: #2 Gary Paffett 1:32.317 lap 4

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #2 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 34L gap — | Gary Paffett
 2 g3 #3 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 34L gap 1.422 | Paul di Resta
 3 g4 #22 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 34L gap 1.865 | Lucas Auer
 4 g2 #94 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 34L gap 2.290 | Pascal Wehrlein
 5 g7 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 34L gap 2.697 | Robin Frijns
 6 g5 #16 BMW Team RMR | BMW M4 DTM | Classified 34L gap 4.122 | Timo Glock
 7 g6 #11 BMW Team RMG | BMW M4 DTM | Classified 34L gap 6.863 | Marco Wittmann
 8 g10 #15 BMW Team RMG | BMW M4 DTM | Classified 34L gap 7.201 | Augusto Farfus
 9 g15 #47 BMW Team RBM | BMW M4 DTM | Classified 34L gap 7.867 | Joel Eriksson
 10 g17 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 34L gap 8.548 | Jamie Green
 11 g16 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 34L gap 8.885 | Loïc Duval
 12 g12 #7 BMW Team RBM | BMW M4 DTM | Classified 34L gap 10.099 | Bruno Spengler
 13 g18 #48 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 34L gap 10.458 | Edoardo Mortara
 14 g13 #25 BMW Team RMR | BMW M4 DTM | Classified 34L gap 10.787 | Philipp Eng
 15 g11 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 34L gap 11.444 | Mike Rockenfeller
 16 g14 #23 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 34L gap 11.918 | Daniel Juncadella
 17 g9 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 34L gap 39.538 | René Rast
 18 g8 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | NC 18L gap 16 LAPS | Nico Müller
