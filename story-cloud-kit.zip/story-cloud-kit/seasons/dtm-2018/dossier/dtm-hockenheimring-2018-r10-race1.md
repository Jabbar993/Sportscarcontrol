# dtm-hockenheimring-2018-r10-race1

Event: DTM Hockenheimring Race 1 | Circuit: Hockenheimring | Date: 2018-10-13
Scheduled: 00:55:00 | Official duration: 00:56:59.934 | Laps (winner): 34

## Qualifying (archive order)
Q1 #22 [DTMV8] 1:32.635 Silberpfeil Energy Mercedes-AMG Motorsport | Lucas Auer
Q2 #2 [DTMV8] 1:32.737 Mercedes-AMG Motorsport Petronas | Gary Paffett
Q3 #16 [DTMV8] 1:32.751 BMW Team RMR | Timo Glock
Q4 #33 [DTMV8] 1:32.847 Audi Sport Team Rosberg | René Rast
Q5 #15 [DTMV8] 1:32.880 BMW Team RMG | Augusto Farfus
Q6 #51 [DTMV8] 1:32.887 Audi Sport Team Abt Sportsline | Nico Müller
Q7 #25 [DTMV8] 1:32.902 BMW Team RMR | Philipp Eng
Q8 #3 [DTMV8] 1:32.925 Mercedes-AMG Motorsport Remus | Paul di Resta
Q9 #4 [DTMV8] 1:32.946 Audi Sport Team Abt Sportsline | Robin Frijns
Q10 #48 [DTMV8] 1:32.949 Silberpfeil Energy Mercedes-AMG Motorsport | Edoardo Mortara
Q11 #47 [DTMV8] 1:33.042 BMW Team RBM | Joel Eriksson
Q12 #7 [DTMV8] 1:33.070 BMW Team RBM | Bruno Spengler
Q13 #23 [DTMV8] 1:33.098 Mercedes-AMG Motorsport Remus | Daniel Juncadella
Q14 #94 [DTMV8] 1:33.124 Mercedes-AMG Motorsport Petronas | Pascal Wehrlein
Q15 #99 [DTMV8] 1:33.168 Audi Sport Team Phoenix | Mike Rockenfeller
Q16 #28 [DTMV8] 1:33.275 Audi Sport Team Phoenix | Loïc Duval
Q17 #53 [DTMV8] 1:33.372 Audi Sport Team Rosberg | Jamie Green

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #22 Lucas Auer 1:32.635 Silberpfeil Energy Mercedes-AMG Motorsport
DTMV8: #22 Lucas Auer 1:32.635 Silberpfeil Energy Mercedes-AMG Motorsport

## Fastest laps (archive)
Overall: #16 Timo Glock 1:34.743 lap 19
DTMV8: #16 Timo Glock 1:34.743 lap 19

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g3 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 34L gap — | René Rast
 2 g7 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 34L gap 0.354 | Robin Frijns
 3 g8 #16 BMW Team RMR | BMW M4 DTM | Classified 34L gap 1.856 | Timo Glock
 4 g2 #2 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 34L gap 2.641 | Gary Paffett
 5 g16 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 34L gap 5.136 | Loïc Duval
 6 g15 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 34L gap 6.066 | Mike Rockenfeller
 7 g5 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 34L gap 6.982 | Nico Müller
 8 g6 #3 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 34L gap 7.952 | Paul di Resta
 9 g11 #7 BMW Team RBM | BMW M4 DTM | Classified 34L gap 8.709 | Bruno Spengler
 10 g9 #48 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 34L gap 10.023 | Edoardo Mortara
 11 g14 #94 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 34L gap 11.001 | Pascal Wehrlein
 12 g12 #25 BMW Team RMR | BMW M4 DTM | Classified 34L gap 11.653 | Philipp Eng
 13 g17 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 34L gap 12.299 | Jamie Green
 14 g13 #23 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 34L gap 13.030 | Daniel Juncadella
 15 g10 #47 BMW Team RBM | BMW M4 DTM | Classified 34L gap 13.400 | Joel Eriksson
 16 g18 #11 BMW Team RMG | BMW M4 DTM | Classified 27L gap 7 LAPS | Marco Wittmann
 17 g4 #15 BMW Team RMG | BMW M4 DTM | Classified 25L gap 9 LAPS | Augusto Farfus
 18 g1 #22 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | RET 6L gap RET | Lucas Auer
