# dtm-misanoworldcircuit-2018-r7-race1

Event: DTM Misano World Circuit Race 1 | Circuit: Misano | Date: 2018-08-25
Scheduled: 00:55:00 | Official duration: 00:56:55.841 | Laps (winner): 32

## Qualifying (archive order)
Q1 #3 [DTMV8] 1:46.826 Mercedes-AMG Motorsport Remus | Paul di Resta
Q2 #48 [DTMV8] 1:47.295 Silberpfeil Energy Mercedes-AMG Motorsport | Edoardo Mortara
Q3 #33 [DTMV8] 1:47.401 Audi Sport Team Rosberg | René Rast
Q4 #2 [DTMV8] 1:47.434 Mercedes-AMG Motorsport Petronas | Gary Paffett
Q5 #16 [DTMV8] 1:47.569 BMW Team RMR | Timo Glock
Q6 #22 [DTMV8] 1:47.597 Silberpfeil Energy Mercedes-AMG Motorsport | Lucas Auer
Q7 #99 [DTMV8] 1:47.603 Audi Sport Team Phoenix | Mike Rockenfeller
Q8 #94 [DTMV8] 1:47.645 Mercedes-AMG Motorsport Petronas | Pascal Wehrlein
Q9 #15 [DTMV8] 1:47.654 BMW Team RMG | Augusto Farfus
Q10 #23 [DTMV8] 1:47.769 Mercedes-AMG Motorsport Remus | Daniel Juncadella
Q11 #51 [DTMV8] 1:47.850 Audi Sport Team Abt Sportsline | Nico Müller
Q12 #4 [DTMV8] 1:48.115 Audi Sport Team Abt Sportsline | Robin Frijns
Q13 #7 [DTMV8] 1:48.303 BMW Team RBM | Bruno Spengler
Q14 #28 [DTMV8] 1:48.505 Audi Sport Team Phoenix | Loïc Duval
Q15 #11 [DTMV8] 1:48.550 BMW Team RMG | Marco Wittmann
Q16 #47 [DTMV8] 1:48.674 BMW Team RBM | Joel Eriksson
Q17 #53 [DTMV8] 1:49.383 Audi Sport Team Rosberg | Jamie Green
Q18 #25 [DTMV8] 1:49.631 BMW Team RMR | Philipp Eng
Q19 #12 [DTMV8] 1:50.571 BMW Team RMR | Alex Zanardi

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #3 Paul di Resta 1:46.826 Mercedes-AMG Motorsport Remus
DTMV8: #3 Paul di Resta 1:46.826 Mercedes-AMG Motorsport Remus

## Fastest laps (archive)
Overall: #15 Augusto Farfus 1:30.288 lap 24
DTMV8: #15 Augusto Farfus 1:30.288 lap 24

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #3 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 32L gap — | Paul di Resta
 2 g12 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 32L gap 1.973 | Robin Frijns
 3 g2 #48 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 32L gap 2.144 | Edoardo Mortara
 4 g14 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 32L gap 2.931 | Loïc Duval
 5 g11 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 32L gap 3.663 | Nico Müller
 6 g8 #94 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 32L gap 8.826 | Pascal Wehrlein
 7 g5 #16 BMW Team RMR | BMW M4 DTM | Classified 32L gap 13.624 | Timo Glock
 8 g18 #25 BMW Team RMR | BMW M4 DTM | Classified 32L gap 14.390 | Philipp Eng
 9 g15 #11 BMW Team RMG | BMW M4 DTM | Classified 32L gap 17.398 | Marco Wittmann
 10 g7 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 32L gap 21.447 | Mike Rockenfeller
 11 g9 #15 BMW Team RMG | BMW M4 DTM | Classified 32L gap 31.483 | Augusto Farfus
 12 g16 #47 BMW Team RBM | BMW M4 DTM | Classified 32L gap 44.200 | Joel Eriksson
 13 g19 #12 BMW Team RMR | BMW M4 DTM | Classified 32L gap 1:14.633 | Alex Zanardi
 14 g10 #23 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | RET 27L gap RET | Daniel Juncadella
 15 g3 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | RET 14L gap RET | René Rast
 16 g13 #7 BMW Team RBM | BMW M4 DTM | RET 12L gap RET | Bruno Spengler
 17 g17 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | RET 12L gap RET | Jamie Green
 18 g6 #22 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | RET 12L gap RET | Lucas Auer
 19 g4 #2 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | RET 7L gap RET | Gary Paffett
