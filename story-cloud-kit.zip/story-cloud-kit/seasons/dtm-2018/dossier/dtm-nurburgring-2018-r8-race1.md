# dtm-nurburgring-2018-r8-race1

Event: DTM Nürburgring Race 1 | Circuit: Nürburgring | Date: 2018-09-08
Scheduled: 00:55:00 | Official duration: 00:57:14.769 | Laps (winner): 40

## Qualifying (archive order)
Q1 #33 [DTMV8] 1:22.203 Audi Sport Team Rosberg | René Rast
Q2 #2 [DTMV8] 1:22.231 Mercedes-AMG Motorsport Petronas | Gary Paffett
Q3 #7 [DTMV8] 1:22.281 BMW Team RBM | Bruno Spengler
Q4 #22 [DTMV8] 1:22.337 Silberpfeil Energy Mercedes-AMG Motorsport | Lucas Auer
Q5 #11 [DTMV8] 1:22.350 BMW Team RMG | Marco Wittmann
Q6 #25 [DTMV8] 1:22.390 BMW Team RMR | Philipp Eng
Q7 #23 [DTMV8] 1:22.448 Mercedes-AMG Motorsport Remus | Daniel Juncadella
Q8 #3 [DTMV8] 1:22.530 Mercedes-AMG Motorsport Remus | Paul di Resta
Q9 #94 [DTMV8] 1:22.557 Mercedes-AMG Motorsport Petronas | Pascal Wehrlein
Q10 #15 [DTMV8] 1:22.570 BMW Team RMG | Augusto Farfus
Q11 #99 [DTMV8] 1:22.585 Audi Sport Team Phoenix | Mike Rockenfeller
Q12 #16 [DTMV8] 1:22.604 BMW Team RMR | Timo Glock
Q13 #47 [DTMV8] 1:22.639 BMW Team RBM | Joel Eriksson
Q14 #53 [DTMV8] 1:22.677 Audi Sport Team Rosberg | Jamie Green
Q15 #48 [DTMV8] 1:22.913 Silberpfeil Energy Mercedes-AMG Motorsport | Edoardo Mortara
Q16 #51 [DTMV8] 1:22.918 Audi Sport Team Abt Sportsline | Nico Müller
Q17 #4 [DTMV8] 1:23.025 Audi Sport Team Abt Sportsline | Robin Frijns
Q18 #28 [DTMV8] 1:23.180 Audi Sport Team Phoenix | Loïc Duval

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #33 René Rast 1:22.203 Audi Sport Team Rosberg
DTMV8: #33 René Rast 1:22.203 Audi Sport Team Rosberg

## Fastest laps (archive)
Overall: #33 René Rast 1:23.768 lap 3
DTMV8: #33 René Rast 1:23.768 lap 3

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 40L gap — | René Rast
 2 g3 #7 BMW Team RBM | BMW M4 DTM | Classified 40L gap 0.862 | Bruno Spengler
 3 g2 #2 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 40L gap 6.862 | Gary Paffett
 4 g12 #16 BMW Team RMR | BMW M4 DTM | Classified 40L gap 7.277 | Timo Glock
 5 g5 #11 BMW Team RMG | BMW M4 DTM | Classified 40L gap 10.048 | Marco Wittmann
 6 g11 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 40L gap 23.208 | Mike Rockenfeller
 7 g9 #94 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 40L gap 26.827 | Pascal Wehrlein
 8 g17 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 40L gap 27.401 | Loïc Duval
 9 g10 #15 BMW Team RMG | BMW M4 DTM | Classified 40L gap 35.685 | Augusto Farfus
 10 g16 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 40L gap 36.243 | Nico Müller
 11 g4 #22 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 40L gap 40.143 | Lucas Auer
 12 g13 #47 BMW Team RBM | BMW M4 DTM | Classified 40L gap 43.488 | Joel Eriksson
 13 g15 #48 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 40L gap 43.664 | Edoardo Mortara
 14 g14 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 40L gap 45.384 | Jamie Green
 15 g7 #23 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 40L gap 47.909 | Daniel Juncadella
 16 g6 #25 BMW Team RMR | BMW M4 DTM | Classified 40L gap 54.210 | Philipp Eng
 17 g18 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 40L gap 56.215 | Robin Frijns
 18 g8 #3 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 40L gap 1:04.040 | Paul di Resta
