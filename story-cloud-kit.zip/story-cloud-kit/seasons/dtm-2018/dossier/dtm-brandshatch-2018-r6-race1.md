# dtm-brandshatch-2018-r6-race1

Event: DTM Brands Hatch Race 1 | Circuit: Brands Hatch | Date: 2018-08-11
Scheduled: 00:55:00 | Official duration: 00:57:15.601 | Laps (winner): 41

## Qualifying (archive order)
Q1 #23 [DTMV8] 1:18.069 Mercedes-AMG Motorsport Remus | Daniel Juncadella
Q2 #22 [DTMV8] 1:18.161 Silberpfeil Energy Mercedes-AMG Motorsport | Lucas Auer
Q3 #33 [DTMV8] 1:18.255 Audi Sport Team Rosberg | René Rast
Q4 #25 [DTMV8] 1:18.257 BMW Team RMR | Philipp Eng
Q5 #15 [DTMV8] 1:18.365 BMW Team RMG | Augusto Farfus
Q6 #2 [DTMV8] 1:18.398 Mercedes-AMG Motorsport Petronas | Gary Paffett
Q7 #16 [DTMV8] 1:18.407 BMW Team RMR | Timo Glock
Q8 #48 [DTMV8] 1:18.422 Silberpfeil Energy Mercedes-AMG Motorsport | Edoardo Mortara
Q9 #11 [DTMV8] 1:18.443 BMW Team RMG | Marco Wittmann
Q10 #94 [DTMV8] 1:18.444 Mercedes-AMG Motorsport Petronas | Pascal Wehrlein
Q11 #4 [DTMV8] 1:18.530 Audi Sport Team Abt Sportsline | Robin Frijns
Q12 #3 [DTMV8] 1:18.625 Mercedes-AMG Motorsport Remus | Paul di Resta
Q13 #51 [DTMV8] 1:18.644 Audi Sport Team Abt Sportsline | Nico Müller
Q14 #28 [DTMV8] 1:18.695 Audi Sport Team Phoenix | Loïc Duval
Q15 #99 [DTMV8] 1:18.746 Audi Sport Team Phoenix | Mike Rockenfeller
Q16 #47 [DTMV8] 1:18.755 BMW Team RBM | Joel Eriksson
Q17 #53 [DTMV8] 1:18.799 Audi Sport Team Rosberg | Jamie Green
Q18 #7 [DTMV8] 1:19.385 BMW Team RBM | Bruno Spengler

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #23 Daniel Juncadella 1:18.069 Mercedes-AMG Motorsport Remus
DTMV8: #23 Daniel Juncadella 1:18.069 Mercedes-AMG Motorsport Remus

## Fastest laps (archive)
Overall: #11 Marco Wittmann 1:20.195 lap 7
DTMV8: #11 Marco Wittmann 1:20.195 lap 7

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #23 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 41L gap — | Daniel Juncadella
 2 g5 #15 BMW Team RMG | BMW M4 DTM | Classified 41L gap 7.896 | Augusto Farfus
 3 g2 #22 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 41L gap 10.040 | Lucas Auer
 4 g3 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 41L gap 14.723 | René Rast
 5 g4 #25 BMW Team RMR | BMW M4 DTM | Classified 41L gap 23.546 | Philipp Eng
 6 g6 #2 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 41L gap 23.933 | Gary Paffett
 7 g10 #94 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 41L gap 25.226 | Pascal Wehrlein
 8 g8 #48 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 41L gap 27.528 | Edoardo Mortara
 9 g9 #11 BMW Team RMG | BMW M4 DTM | Classified 41L gap 31.639 | Marco Wittmann
 10 g15 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 41L gap 33.405 | Mike Rockenfeller
 11 g17 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 41L gap 35.822 | Jamie Green
 12 g11 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 41L gap 37.423 | Robin Frijns
 13 g7 #16 BMW Team RMR | BMW M4 DTM | Classified 41L gap 41.607 | Timo Glock
 14 g16 #47 BMW Team RBM | BMW M4 DTM | Classified 41L gap 42.738 | Joel Eriksson
 15 g13 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 41L gap 43.476 | Nico Müller
 16 g12 #3 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 41L gap 46.349 | Paul di Resta
 17 g18 #7 BMW Team RBM | BMW M4 DTM | Classified 41L gap 55.188 | Bruno Spengler
 18 g14 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | RET 1L gap RET | Loïc Duval
