# dtm-hockenheimring-2018-r1-race1

Event: DTM Hockenheimring Race 1 | Circuit: Hockenheimring | Date: 2018-05-05
Scheduled: 00:55:00 | Official duration: 00:58:03.639 | Laps (winner): 36

## Qualifying (archive order)
Q1 #2 [DTMV8] 1:32.264 Mercedes-AMG Motorsport Petronas | Gary Paffett
Q2 #11 [DTMV8] 1:32.463 BMW Team RMG | Marco Wittmann
Q3 #16 [DTMV8] 1:32.468 BMW Team RMR | Timo Glock
Q4 #22 [DTMV8] 1:32.484 Silberpfeil Energy Mercedes-AMG Motorsport | Lucas Auer
Q5 #94 [DTMV8] 1:32.486 Mercedes-AMG Motorsport Petronas | Pascal Wehrlein
Q6 #15 [DTMV8] 1:32.683 BMW Team RMG | Augusto Farfus
Q7 #48 [DTMV8] 1:32.719 Silberpfeil Energy Mercedes-AMG Motorsport | Edoardo Mortara
Q8 #7 [DTMV8] 1:32.776 BMW Team RBM | Bruno Spengler
Q9 #33 [DTMV8] 1:32.780 Audi Sport Team Rosberg | René Rast
Q10 #47 [DTMV8] 1:32.794 BMW Team RBM | Joel Eriksson
Q11 #99 [DTMV8] 1:32.811 Audi Sport Team Phoenix | Mike Rockenfeller
Q12 #3 [DTMV8] 1:32.841 Mercedes-AMG Motorsport Remus | Paul di Resta
Q13 #23 [DTMV8] 1:32.889 Mercedes-AMG Motorsport Remus | Daniel Juncadella
Q14 #51 [DTMV8] 1:32.986 Audi Sport Team Abt Sportsline | Nico Müller
Q15 #25 [DTMV8] 1:32.990 BMW Team RMR | Philipp Eng
Q16 #28 [DTMV8] 1:33.036 Audi Sport Team Phoenix | Loïc Duval
Q17 #4 [DTMV8] 1:33.094 Audi Sport Team Abt Sportsline | Robin Frijns
Q18 #5 [DTMV8] 1:33.174 Audi Sport Team Abt Sportsline | Mattias Ekström
Q19 #53 [DTMV8] 1:33.250 Audi Sport Team Rosberg | Jamie Green

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #2 Gary Paffett 1:32.264 Mercedes-AMG Motorsport Petronas
DTMV8: #2 Gary Paffett 1:32.264 Mercedes-AMG Motorsport Petronas

## Fastest laps (archive)
Overall: #23 Daniel Juncadella 1:34.181 lap 25
DTMV8: #23 Daniel Juncadella 1:34.181 lap 25

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #2 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 36L gap — | Gary Paffett
 2 g4 #22 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 36L gap 1.449 | Lucas Auer
 3 g3 #16 BMW Team RMR | BMW M4 DTM | Classified 36L gap 6.514 | Timo Glock
 4 g7 #48 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 36L gap 8.198 | Edoardo Mortara
 5 g5 #94 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 36L gap 11.391 | Pascal Wehrlein
 6 g8 #7 BMW Team RBM | BMW M4 DTM | Classified 36L gap 15.758 | Bruno Spengler
 7 g12 #3 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 36L gap 16.600 | Paul di Resta
 8 g13 #23 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 36L gap 16.969 | Daniel Juncadella
 9 g9 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 36L gap 18.268 | René Rast
 10 g16 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 36L gap 19.646 | Loïc Duval
 11 g2 #11 BMW Team RMG | BMW M4 DTM | Classified 36L gap 20.740 | Marco Wittmann
 12 g10 #47 BMW Team RBM | BMW M4 DTM | Classified 36L gap 21.294 | Joel Eriksson
 13 g14 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 36L gap 22.421 | Nico Müller
 14 g11 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 36L gap 23.987 | Mike Rockenfeller
 15 g6 #15 BMW Team RMG | BMW M4 DTM | Classified 36L gap 28.724 | Augusto Farfus
 16 g15 #25 BMW Team RMR | BMW M4 DTM | Classified 36L gap 29.486 | Philipp Eng
 17 g18 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 36L gap 30.649 | Mattias Ekström
 18 g17 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 36L gap 31.660 | Robin Frijns
 19 g19 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 36L gap 44.973 | Jamie Green
