# dtm-redbullring-2018-r9-race1

Event: DTM Red Bull Ring Race 1 | Circuit: Red Bull Ring | Date: 2018-09-22
Scheduled: 00:55:00 | Official duration: 00:56:53.591 | Laps (winner): 37

## Qualifying (archive order)
Q1 #23 [DTMV8] 1:36.071 Mercedes-AMG Motorsport Remus | Daniel Juncadella
Q2 #16 [DTMV8] 1:36.142 BMW Team RMR | Timo Glock
Q3 #99 [DTMV8] 1:36.300 Audi Sport Team Phoenix | Mike Rockenfeller
Q4 #3 [DTMV8] 1:36.534 Mercedes-AMG Motorsport Remus | Paul di Resta
Q5 #11 [DTMV8] 1:36.636 BMW Team RMG | Marco Wittmann
Q6 #22 [DTMV8] 1:36.841 Silberpfeil Energy Mercedes-AMG Motorsport | Lucas Auer
Q7 #15 [DTMV8] 1:36.881 BMW Team RMG | Augusto Farfus
Q8 #4 [DTMV8] 1:36.947 Audi Sport Team Abt Sportsline | Robin Frijns
Q9 #33 [DTMV8] 1:37.077 Audi Sport Team Rosberg | René Rast
Q10 #2 [DTMV8] 1:37.123 Mercedes-AMG Motorsport Petronas | Gary Paffett
Q11 #28 [DTMV8] 1:37.234 Audi Sport Team Phoenix | Loïc Duval
Q12 #51 [DTMV8] 1:37.243 Audi Sport Team Abt Sportsline | Nico Müller
Q13 #94 [DTMV8] 1:37.249 Mercedes-AMG Motorsport Petronas | Pascal Wehrlein
Q14 #25 [DTMV8] 1:37.259 BMW Team RMR | Philipp Eng
Q15 #53 [DTMV8] 1:37.581 Audi Sport Team Rosberg | Jamie Green
Q16 #7 [DTMV8] 1:37.589 BMW Team RBM | Bruno Spengler
Q17 #47 [DTMV8] 1:37.924 BMW Team RBM | Joel Eriksson
Q18 #48 [DTMV8] 1:38.355 Silberpfeil Energy Mercedes-AMG Motorsport | Edoardo Mortara
Q19 #17 [DTMV8] 1:38.960 Mercedes-AMG Motorsport Remus | Sébastien Ogier

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #23 Daniel Juncadella 1:36.071 Mercedes-AMG Motorsport Remus
DTMV8: #23 Daniel Juncadella 1:36.071 Mercedes-AMG Motorsport Remus

## Fastest laps (archive)
Overall: #22 Lucas Auer 1:24.493 lap 28
DTMV8: #22 Lucas Auer 1:24.493 lap 28

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g9 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 37L gap — | René Rast
 2 g3 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 37L gap 0.705 | Mike Rockenfeller
 3 g12 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 37L gap 0.887 | Nico Müller
 4 g4 #3 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 37L gap 1.153 | Paul di Resta
 5 g14 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 37L gap 1.444 | Jamie Green
 6 g6 #22 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 37L gap 1.553 | Lucas Auer
 7 g5 #11 BMW Team RMG | BMW M4 DTM | Classified 37L gap 6.730 | Marco Wittmann
 8 g13 #25 BMW Team RMR | BMW M4 DTM | Classified 37L gap 6.752 | Philipp Eng
 9 g7 #15 BMW Team RMG | BMW M4 DTM | Classified 37L gap 7.307 | Augusto Farfus
 10 g10 #2 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 37L gap 7.598 | Gary Paffett
 11 g8 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 37L gap 8.406 | Robin Frijns
 12 g19 #17 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 37L gap 8.650 | Sébastien Ogier
 13 g18 #94 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 37L gap 9.315 | Pascal Wehrlein
 14 g1 #23 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 37L gap 27.238 | Daniel Juncadella
 15 g16 #47 BMW Team RBM | BMW M4 DTM | Classified 37L gap 27.621 | Joel Eriksson
 16 g17 #48 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 37L gap 6.870 | Edoardo Mortara
 17 g2 #16 BMW Team RMR | BMW M4 DTM | Classified 31L gap 6 LAPS | Timo Glock
 18 g15 #7 BMW Team RBM | BMW M4 DTM | Classified 30L gap 7 LAPS | Bruno Spengler
 19 g11 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | RET 1L gap RET | Loïc Duval
