# dtm-redbullring-2018-r9-race2

Event: DTM Red Bull Ring Race 2 | Circuit: Red Bull Ring | Date: 2018-09-23
Scheduled: 00:55:00 | Official duration: 00:57:45.704 | Laps (winner): 40

## Qualifying (archive order)
Q1 #2 [DTMV8] 1:23.404 Mercedes-AMG Motorsport Petronas | Gary Paffett
Q2 #51 [DTMV8] 1:23.432 Audi Sport Team Abt Sportsline | Nico Müller
Q3 #3 [DTMV8] 1:23.632 Mercedes-AMG Motorsport Remus | Paul di Resta
Q4 #48 [DTMV8] 1:23.712 Silberpfeil Energy Mercedes-AMG Motorsport | Edoardo Mortara
Q5 #94 [DTMV8] 1:23.748 Mercedes-AMG Motorsport Petronas | Pascal Wehrlein
Q6 #47 [DTMV8] 1:23.773 BMW Team RBM | Joel Eriksson
Q7 #16 [DTMV8] 1:23.853 BMW Team RMR | Timo Glock
Q8 #33 [DTMV8] 1:23.866 Audi Sport Team Rosberg | René Rast
Q9 #23 [DTMV8] 1:23.885 Mercedes-AMG Motorsport Remus | Daniel Juncadella
Q10 #25 [DTMV8] 1:23.969 BMW Team RMR | Philipp Eng
Q11 #4 [DTMV8] 1:24.014 Audi Sport Team Abt Sportsline | Robin Frijns
Q12 #53 [DTMV8] 1:24.040 Audi Sport Team Rosberg | Jamie Green
Q13 #99 [DTMV8] 1:24.070 Audi Sport Team Phoenix | Mike Rockenfeller
Q14 #22 [DTMV8] 1:24.133 Silberpfeil Energy Mercedes-AMG Motorsport | Lucas Auer
Q15 #7 [DTMV8] 1:24.185 BMW Team RBM | Bruno Spengler
Q16 #15 [DTMV8] 1:24.250 BMW Team RMG | Augusto Farfus
Q17 #11 [DTMV8] 1:24.422 BMW Team RMG | Marco Wittmann
Q18 #28 [DTMV8] 1:24.452 Audi Sport Team Phoenix | Loïc Duval
Q19 #17 [DTMV8] 1:24.700 Mercedes-AMG Motorsport Remus | Sébastien Ogier

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #2 Gary Paffett 1:23.404 Mercedes-AMG Motorsport Petronas
DTMV8: #2 Gary Paffett 1:23.404 Mercedes-AMG Motorsport Petronas

## Fastest laps (archive)
Overall: #2 Gary Paffett 1:24.907 lap 4
DTMV8: #2 Gary Paffett 1:24.907 lap 4

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g7 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 40L gap — | René Rast
 2 g2 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 40L gap 0.421 | Nico Müller
 3 g1 #2 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 40L gap 4.700 | Gary Paffett
 4 g3 #3 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 40L gap 6.963 | Paul di Resta
 5 g5 #47 BMW Team RBM | BMW M4 DTM | Classified 40L gap 10.889 | Joel Eriksson
 6 g4 #94 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 40L gap 14.709 | Pascal Wehrlein
 7 g6 #16 BMW Team RMR | BMW M4 DTM | Classified 40L gap 15.692 | Timo Glock
 8 g13 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 40L gap 20.193 | Mike Rockenfeller
 9 g10 #25 BMW Team RMR | BMW M4 DTM | Classified 40L gap 24.830 | Philipp Eng
 10 g9 #48 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 40L gap 25.685 | Edoardo Mortara
 11 g8 #23 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 40L gap 26.314 | Daniel Juncadella
 12 g12 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 40L gap 26.647 | Jamie Green
 13 g11 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 40L gap 36.841 | Robin Frijns
 14 g17 #11 BMW Team RMG | BMW M4 DTM | Classified 40L gap 37.659 | Marco Wittmann
 15 g15 #7 BMW Team RBM | BMW M4 DTM | Classified 40L gap 38.013 | Bruno Spengler
 16 g18 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 40L gap 38.336 | Loïc Duval
 17 g19 #17 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 39L gap 1 LAP | Sébastien Ogier
 18 g14 #22 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | RET 27L gap RET | Lucas Auer
 19 g16 #15 BMW Team RMG | BMW M4 DTM | RET 15L gap RET | Augusto Farfus
