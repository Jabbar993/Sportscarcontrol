# dtm-hungaroring-2018-r3-race1

Event: DTM Hungaroring Race 1 | Circuit: Hungaroring | Date: 2018-06-02
Scheduled: 00:55:00 | Official duration: 00:57:13.199 | Laps (winner): 34

## Qualifying (archive order)
Q1 #3 [DTMV8] 1:37.349 Mercedes-AMG Motorsport Remus | Paul di Resta
Q2 #51 [DTMV8] 1:37.484 Audi Sport Team Abt Sportsline | Nico Müller
Q3 #22 [DTMV8] 1:37.564 Silberpfeil Energy Mercedes-AMG Motorsport | Lucas Auer
Q4 #33 [DTMV8] 1:37.598 Audi Sport Team Rosberg | René Rast
Q5 #48 [DTMV8] 1:37.727 Silberpfeil Energy Mercedes-AMG Motorsport | Edoardo Mortara
Q6 #23 [DTMV8] 1:37.729 Mercedes-AMG Motorsport Remus | Daniel Juncadella
Q7 #53 [DTMV8] 1:37.904 Audi Sport Team Rosberg | Jamie Green
Q8 #15 [DTMV8] 1:37.917 BMW Team RMG | Augusto Farfus
Q9 #2 [DTMV8] 1:37.994 Mercedes-AMG Motorsport Petronas | Gary Paffett
Q10 #7 [DTMV8] 1:38.050 BMW Team RBM | Bruno Spengler
Q11 #28 [DTMV8] 1:38.065 Audi Sport Team Phoenix | Loïc Duval
Q12 #94 [DTMV8] 1:38.080 Mercedes-AMG Motorsport Petronas | Pascal Wehrlein
Q13 #11 [DTMV8] 1:38.127 BMW Team RMG | Marco Wittmann
Q14 #4 [DTMV8] 1:38.138 Audi Sport Team Abt Sportsline | Robin Frijns
Q15 #47 [DTMV8] 1:38.138 BMW Team RBM | Joel Eriksson
Q16 #16 [DTMV8] 1:38.261 BMW Team RMR | Timo Glock
Q17 #25 [DTMV8] 1:38.268 BMW Team RMR | Philipp Eng
Q18 #99 [DTMV8] 1:38.274 Audi Sport Team Phoenix | Mike Rockenfeller

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #3 Paul di Resta 1:37.349 Mercedes-AMG Motorsport Remus
DTMV8: #3 Paul di Resta 1:37.349 Mercedes-AMG Motorsport Remus

## Fastest laps (archive)
Overall: #22 Lucas Auer 1:38.812 lap 10
DTMV8: #22 Lucas Auer 1:38.812 lap 10

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #3 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 34L gap — | Paul di Resta
 2 g3 #22 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 34L gap 0.587 | Lucas Auer
 3 g2 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 34L gap 2.236 | Nico Müller
 4 g4 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 34L gap 2.898 | René Rast
 5 g5 #48 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 34L gap 6.695 | Edoardo Mortara
 6 g9 #2 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 34L gap 12.166 | Gary Paffett
 7 g14 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 34L gap 15.009 | Robin Frijns
 8 g11 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 34L gap 22.754 | Loïc Duval
 9 g7 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 34L gap 25.829 | Jamie Green
 10 g6 #23 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 34L gap 26.844 | Daniel Juncadella
 11 g18 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 34L gap 27.249 | Mike Rockenfeller
 12 g10 #7 BMW Team RBM | BMW M4 DTM | Classified 34L gap 34.140 | Bruno Spengler
 13 g12 #94 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 34L gap 37.007 | Pascal Wehrlein
 14 g16 #16 BMW Team RMR | BMW M4 DTM | Classified 34L gap 38.689 | Timo Glock
 15 g8 #15 BMW Team RMG | BMW M4 DTM | Classified 34L gap 39.001 | Augusto Farfus
 16 g13 #11 BMW Team RMG | BMW M4 DTM | Classified 34L gap 39.510 | Marco Wittmann
 17 g15 #47 BMW Team RBM | BMW M4 DTM | Classified 34L gap 40.534 | Joel Eriksson
 18 g17 #25 BMW Team RMR | BMW M4 DTM | Classified 34L gap 46.994 | Philipp Eng
