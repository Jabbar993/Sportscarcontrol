# dtm-hungaroring-2018-r3-race2

Event: DTM Hungaroring Race 2 | Circuit: Hungaroring | Date: 2018-06-03
Scheduled: 00:55:00 | Official duration: 1:17:50.129 | Laps (winner): 26

## Qualifying (archive order)
Q1 #22 [DTMV8] 1:36.717 Silberpfeil Energy Mercedes-AMG Motorsport | Lucas Auer
Q2 #94 [DTMV8] 1:36.780 Mercedes-AMG Motorsport Petronas | Pascal Wehrlein
Q3 #3 [DTMV8] 1:36.977 Mercedes-AMG Motorsport Remus | Paul di Resta
Q4 #48 [DTMV8] 1:37.016 Silberpfeil Energy Mercedes-AMG Motorsport | Edoardo Mortara
Q5 #2 [DTMV8] 1:37.025 Mercedes-AMG Motorsport Petronas | Gary Paffett
Q6 #33 [DTMV8] 1:37.046 Audi Sport Team Rosberg | René Rast
Q7 #23 [DTMV8] 1:37.058 Mercedes-AMG Motorsport Remus | Daniel Juncadella
Q8 #16 [DTMV8] 1:37.105 BMW Team RMR | Timo Glock
Q9 #51 [DTMV8] 1:37.219 Audi Sport Team Abt Sportsline | Nico Müller
Q10 #53 [DTMV8] 1:37.259 Audi Sport Team Rosberg | Jamie Green
Q11 #4 [DTMV8] 1:37.265 Audi Sport Team Abt Sportsline | Robin Frijns
Q12 #15 [DTMV8] 1:37.332 BMW Team RMG | Augusto Farfus
Q13 #28 [DTMV8] 1:37.430 Audi Sport Team Phoenix | Loïc Duval
Q14 #11 [DTMV8] 1:37.453 BMW Team RMG | Marco Wittmann
Q15 #25 [DTMV8] 1:37.505 BMW Team RMR | Philipp Eng
Q16 #99 [DTMV8] 1:37.510 Audi Sport Team Phoenix | Mike Rockenfeller
Q17 #47 [DTMV8] 1:37.530 BMW Team RBM | Joel Eriksson
Q18 #7 [DTMV8] 1:37.750 BMW Team RBM | Bruno Spengler

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #22 Lucas Auer 1:36.717 Silberpfeil Energy Mercedes-AMG Motorsport
DTMV8: #22 Lucas Auer 1:36.717 Silberpfeil Energy Mercedes-AMG Motorsport

## Fastest laps (archive)
Overall: #23 Daniel Juncadella 1:38.417 lap 13
DTMV8: #23 Daniel Juncadella 1:38.417 lap 13

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g14 #11 BMW Team RMG | BMW M4 DTM | Classified 26L gap — | Marco Wittmann
 2 g8 #16 BMW Team RMR | BMW M4 DTM | Classified 26L gap 5.870 | Timo Glock
 3 g15 #25 BMW Team RMR | BMW M4 DTM | Classified 26L gap 13.457 | Philipp Eng
 4 g16 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 26L gap 13.937 | Mike Rockenfeller
 5 g3 #3 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 26L gap 16.276 | Paul di Resta
 6 g17 #47 BMW Team RBM | BMW M4 DTM | Classified 26L gap 20.446 | Joel Eriksson
 8 g12 #15 BMW Team RMG | BMW M4 DTM | Classified 26L gap 21.464 | Augusto Farfus
 11 g11 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 26L gap 23.350 | Robin Frijns
 12 g13 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 26L gap 23.772 | Loïc Duval
 13 g6 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 26L gap 24.263 | René Rast
 14 g7 #23 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 26L gap 24.580 | Daniel Juncadella
 15 g2 #94 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 26L gap 25.185 | Pascal Wehrlein
 16 g10 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 26L gap 27.098 | Jamie Green
 17 g9 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 26L gap 24.865 | Nico Müller
 18 g5 #2 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 26L gap 1:15.907 | Gary Paffett
 19 g18 #7 BMW Team RBM | BMW M4 DTM | DSQ 26L gap DSQ | Bruno Spengler
 20 g1 #22 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | DSQ 26L gap DSQ | Lucas Auer
 21 g4 #48 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | DSQ 26L gap DSQ | Edoardo Mortara
