# dtm-circuitzandvoort-2018-r5-race2

Event: DTM Circuit Zandvoort Race 2 | Circuit: Zandvoort | Date: 2018-07-15
Scheduled: 00:55:00 | Official duration: 00:56:44.864 | Laps (winner): 35

## Qualifying (archive order)
Q1 #2 [DTMV8] 1:30.225 Mercedes-AMG Motorsport Petronas | Gary Paffett
Q2 #25 [DTMV8] 1:30.671 BMW Team RMR | Philipp Eng
Q3 #33 [DTMV8] 1:30.716 Audi Sport Team Rosberg | René Rast
Q4 #94 [DTMV8] 1:30.774 Mercedes-AMG Motorsport Petronas | Pascal Wehrlein
Q5 #3 [DTMV8] 1:30.810 Mercedes-AMG Motorsport Remus | Paul di Resta
Q6 #99 [DTMV8] 1:30.876 Audi Sport Team Phoenix | Mike Rockenfeller
Q7 #7 [DTMV8] 1:30.908 BMW Team RBM | Bruno Spengler
Q8 #15 [DTMV8] 1:30.942 BMW Team RMG | Augusto Farfus
Q9 #48 [DTMV8] 1:30.944 Silberpfeil Energy Mercedes-AMG Motorsport | Edoardo Mortara
Q10 #22 [DTMV8] 1:30.948 Silberpfeil Energy Mercedes-AMG Motorsport | Lucas Auer
Q11 #23 [DTMV8] 1:30.954 Mercedes-AMG Motorsport Remus | Daniel Juncadella
Q12 #11 [DTMV8] 1:30.955 BMW Team RMG | Marco Wittmann
Q13 #28 [DTMV8] 1:30.992 Audi Sport Team Phoenix | Loïc Duval
Q14 #47 [DTMV8] 1:31.069 BMW Team RBM | Joel Eriksson
Q15 #53 [DTMV8] 1:31.095 Audi Sport Team Rosberg | Jamie Green
Q16 #51 [DTMV8] 1:31.105 Audi Sport Team Abt Sportsline | Nico Müller
Q17 #16 [DTMV8] 1:31.233 BMW Team RMR | Timo Glock
Q18 #4 [DTMV8] 1:31.528 Audi Sport Team Abt Sportsline | Robin Frijns

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #2 Gary Paffett 1:30.225 Mercedes-AMG Motorsport Petronas
DTMV8: #2 Gary Paffett 1:30.225 Mercedes-AMG Motorsport Petronas

## Fastest laps (archive)
Overall: #99 Mike Rockenfeller 1:31.805 lap 32
DTMV8: #99 Mike Rockenfeller 1:31.805 lap 32

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g3 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 35L gap — | René Rast
 2 g1 #2 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 35L gap 0.824 | Gary Paffett
 3 g5 #3 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 35L gap 1.349 | Paul di Resta
 4 g2 #25 BMW Team RMR | BMW M4 DTM | Classified 35L gap 1.825 | Philipp Eng
 5 g8 #15 BMW Team RMG | BMW M4 DTM | Classified 35L gap 2.123 | Augusto Farfus
 6 g4 #94 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 35L gap 3.200 | Pascal Wehrlein
 7 g16 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 35L gap 4.883 | Nico Müller
 8 g9 #48 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 35L gap 6.302 | Edoardo Mortara
 9 g10 #22 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 35L gap 8.864 | Lucas Auer
 10 g17 #16 BMW Team RMR | BMW M4 DTM | Classified 35L gap 9.177 | Timo Glock
 11 g14 #47 BMW Team RBM | BMW M4 DTM | Classified 35L gap 9.818 | Joel Eriksson
 12 g11 #23 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 35L gap 10.404 | Daniel Juncadella
 13 g7 #7 BMW Team RBM | BMW M4 DTM | Classified 35L gap 13.709 | Bruno Spengler
 14 g15 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 35L gap 26.500 | Jamie Green
 15 g13 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 35L gap 40.438 | Loïc Duval
 16 g6 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 35L gap 43.370 | Mike Rockenfeller
 17 g12 #11 BMW Team RMG | BMW M4 DTM | Classified 35L gap 1:10.745 | Marco Wittmann
 18 g18 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | RET 10L gap RET | Robin Frijns
