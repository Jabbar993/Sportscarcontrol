# dtm-hockenheimring-2018-r1-race2

Event: DTM Hockenheimring Race 2 | Circuit: Hockenheimring | Date: 2018-05-06
Scheduled: 00:55:00 | Official duration: 00:58:04.067 | Laps (winner): 36

## Qualifying (archive order)
Q1 #16 [DTMV8] 1:32.379 BMW Team RMR | Timo Glock
Q2 #33 [DTMV8] 1:32.587 Audi Sport Team Rosberg | René Rast
Q3 #47 [DTMV8] 1:32.613 BMW Team RBM | Joel Eriksson
Q4 #48 [DTMV8] 1:32.623 Silberpfeil Energy Mercedes-AMG Motorsport | Edoardo Mortara
Q5 #22 [DTMV8] 1:32.632 Silberpfeil Energy Mercedes-AMG Motorsport | Lucas Auer
Q6 #3 [DTMV8] 1:32.657 Mercedes-AMG Motorsport Remus | Paul di Resta
Q7 #23 [DTMV8] 1:32.717 Mercedes-AMG Motorsport Remus | Daniel Juncadella
Q8 #11 [DTMV8] 1:32.756 BMW Team RMG | Marco Wittmann
Q9 #99 [DTMV8] 1:32.762 Audi Sport Team Phoenix | Mike Rockenfeller
Q10 #2 [DTMV8] 1:32.881 Mercedes-AMG Motorsport Petronas | Gary Paffett
Q11 #94 [DTMV8] 1:32.885 Mercedes-AMG Motorsport Petronas | Pascal Wehrlein
Q12 #28 [DTMV8] 1:32.887 Audi Sport Team Phoenix | Loïc Duval
Q13 #15 [DTMV8] 1:32.973 BMW Team RMG | Augusto Farfus
Q14 #7 [DTMV8] 1:33.003 BMW Team RBM | Bruno Spengler
Q15 #4 [DTMV8] 1:33.045 Audi Sport Team Abt Sportsline | Robin Frijns
Q16 #51 [DTMV8] 1:33.061 Audi Sport Team Abt Sportsline | Nico Müller
Q17 #53 [DTMV8] 1:33.109 Audi Sport Team Rosberg | Jamie Green
Q18 #25 [DTMV8] 1:33.116 BMW Team RMR | Philipp Eng
Q19 #5 [DTMV8] 1:34.043 Audi Sport Team Abt Sportsline | Mattias Ekström

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #16 Timo Glock 1:32.379 BMW Team RMR
DTMV8: #16 Timo Glock 1:32.379 BMW Team RMR

## Fastest laps (archive)
Overall: #2 Gary Paffett 1:34.069 lap 19
DTMV8: #2 Gary Paffett 1:34.069 lap 19

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g1 #16 BMW Team RMR | BMW M4 DTM | Classified 36L gap — | Timo Glock
 2 g9 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 36L gap 2.078 | Mike Rockenfeller
 3 g10 #2 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 36L gap 3.099 | Gary Paffett
 4 g3 #47 BMW Team RBM | BMW M4 DTM | Classified 36L gap 3.481 | Joel Eriksson
 5 g12 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 36L gap 3.854 | Loïc Duval
 6 g11 #94 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 36L gap 4.129 | Pascal Wehrlein
 7 g2 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 36L gap 4.849 | René Rast
 8 g19 #7 BMW Team RBM | BMW M4 DTM | Classified 36L gap 8.862 | Bruno Spengler
 9 g6 #3 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 36L gap 11.082 | Paul di Resta
 10 g13 #15 BMW Team RMG | BMW M4 DTM | Classified 36L gap 11.265 | Augusto Farfus
 11 g8 #11 BMW Team RMG | BMW M4 DTM | Classified 36L gap 14.590 | Marco Wittmann
 12 g14 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 36L gap 15.093 | Robin Frijns
 13 g15 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 36L gap 17.858 | Nico Müller
 14 g17 #25 BMW Team RMR | BMW M4 DTM | Classified 36L gap 18.303 | Philipp Eng
 15 g5 #22 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 36L gap 22.103 | Lucas Auer
 16 g18 #5 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 36L gap 23.148 | Mattias Ekström
 17 g16 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 36L gap 23.853 | Jamie Green
 18 g7 #23 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 36L gap 32.993 | Daniel Juncadella
 19 g4 #48 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | RET 2L gap RET | Edoardo Mortara
