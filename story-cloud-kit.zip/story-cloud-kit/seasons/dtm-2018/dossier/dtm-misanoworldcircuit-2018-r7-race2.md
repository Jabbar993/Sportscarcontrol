# dtm-misanoworldcircuit-2018-r7-race2

Event: DTM Misano World Circuit Race 2 | Circuit: Misano | Date: 2018-08-26
Scheduled: 00:55:00 | Official duration: 00:57:19.154 | Laps (winner): 31

## Qualifying (archive order)
Q1 #28 [DTMV8] 1:45.766 Audi Sport Team Phoenix | Loïc Duval
Q2 #48 [DTMV8] 1:46.086 Silberpfeil Energy Mercedes-AMG Motorsport | Edoardo Mortara
Q3 #23 [DTMV8] 1:46.496 Mercedes-AMG Motorsport Remus | Daniel Juncadella
Q4 #99 [DTMV8] 1:46.545 Audi Sport Team Phoenix | Mike Rockenfeller
Q5 #33 [DTMV8] 1:46.635 Audi Sport Team Rosberg | René Rast
Q6 #11 [DTMV8] 1:46.688 BMW Team RMG | Marco Wittmann
Q7 #51 [DTMV8] 1:46.762 Audi Sport Team Abt Sportsline | Nico Müller
Q8 #2 [DTMV8] 1:46.774 Mercedes-AMG Motorsport Petronas | Gary Paffett
Q9 #16 [DTMV8] 1:46.801 BMW Team RMR | Timo Glock
Q10 #3 [DTMV8] 1:46.926 Mercedes-AMG Motorsport Remus | Paul di Resta
Q11 #94 [DTMV8] 1:47.103 Mercedes-AMG Motorsport Petronas | Pascal Wehrlein
Q12 #47 [DTMV8] 1:47.302 BMW Team RBM | Joel Eriksson
Q13 #22 [DTMV8] 1:47.313 Silberpfeil Energy Mercedes-AMG Motorsport | Lucas Auer
Q14 #15 [DTMV8] 1:47.442 BMW Team RMG | Augusto Farfus
Q15 #4 [DTMV8] 1:47.802 Audi Sport Team Abt Sportsline | Robin Frijns
Q16 #25 [DTMV8] 1:47.886 BMW Team RMR | Philipp Eng
Q17 #53 [DTMV8] 1:48.266 Audi Sport Team Rosberg | Jamie Green
Q18 #7 [DTMV8] 1:48.315 BMW Team RBM | Bruno Spengler
Q19 #12 [DTMV8] 1:50.207 BMW Team RMR | Alex Zanardi

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #28 Loïc Duval 1:45.766 Audi Sport Team Phoenix
DTMV8: #28 Loïc Duval 1:45.766 Audi Sport Team Phoenix

## Fastest laps (archive)
Overall: #48 Edoardo Mortara 1:42.023 lap 5
DTMV8: #48 Edoardo Mortara 1:42.023 lap 5

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g12 #47 BMW Team RBM | BMW M4 DTM | Classified 31L gap — | Joel Eriksson
 2 g2 #48 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 31L gap 1.817 | Edoardo Mortara
 3 g5 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 31L gap 6.493 | René Rast
 4 g15 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 31L gap 16.879 | Robin Frijns
 5 g19 #12 BMW Team RMR | BMW M4 DTM | Classified 31L gap 47.316 | Alex Zanardi
 6 g10 #3 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 31L gap 59.802 | Paul di Resta
 7 g1 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 31L gap 1:10.232 | Loïc Duval
 8 g17 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 31L gap 1:12.162 | Jamie Green
 9 g4 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 31L gap 1:21.814 | Mike Rockenfeller
 10 g7 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 31L gap 1:25.646 | Nico Müller
 11 g18 #7 BMW Team RBM | BMW M4 DTM | Classified 31L gap 1:26.598 | Bruno Spengler
 12 g11 #94 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 31L gap 1:27.097 | Pascal Wehrlein
 13 g6 #11 BMW Team RMG | BMW M4 DTM | Classified 31L gap 1:34.540 | Marco Wittmann
 14 g8 #2 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 31L gap 1:39.009 | Gary Paffett
 15 g9 #16 BMW Team RMR | BMW M4 DTM | Classified 31L gap 1:42.331 | Timo Glock
 16 g16 #25 BMW Team RMR | BMW M4 DTM | Classified 31L gap 1:42.600 | Philipp Eng
 17 g3 #23 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 30L gap 1 LAP | Daniel Juncadella
 18 g14 #15 BMW Team RMG | BMW M4 DTM | RET 14L gap RET | Augusto Farfus
 19 g13 #22 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | RET 10L gap RET | Lucas Auer
