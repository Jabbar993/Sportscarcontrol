# dtm-norisring-2018-r4-race2

Event: DTM Norisring Race 2 | Circuit: Norisring | Date: 2018-06-24
Scheduled: 00:55:00 | Official duration: 00:56:13.000 | Laps (winner): 68

## Qualifying (archive order)
Q1 #23 [DTMV8] 47.705 Mercedes-AMG Motorsport Remus | Daniel Juncadella
Q2 #2 [DTMV8] 47.739 Mercedes-AMG Motorsport Petronas | Gary Paffett
Q3 #22 [DTMV8] 47.834 Silberpfeil Energy Mercedes-AMG Motorsport | Lucas Auer
Q4 #3 [DTMV8] 47.882 Mercedes-AMG Motorsport Remus | Paul di Resta
Q5 #48 [DTMV8] 47.886 Silberpfeil Energy Mercedes-AMG Motorsport | Edoardo Mortara
Q6 #7 [DTMV8] 47.926 BMW Team RBM | Bruno Spengler
Q7 #11 [DTMV8] 47.932 BMW Team RMG | Marco Wittmann
Q8 #47 [DTMV8] 47.939 BMW Team RBM | Joel Eriksson
Q9 #16 [DTMV8] 47.963 BMW Team RMR | Timo Glock
Q10 #25 [DTMV8] 47.997 BMW Team RMR | Philipp Eng
Q11 #51 [DTMV8] 48.023 Audi Sport Team Abt Sportsline | Nico Müller
Q12 #53 [DTMV8] 48.123 Audi Sport Team Rosberg | Jamie Green
Q13 #33 [DTMV8] 48.235 Audi Sport Team Rosberg | René Rast
Q14 #15 [DTMV8] 48.239 BMW Team RMG | Augusto Farfus
Q15 #99 [DTMV8] 48.264 Audi Sport Team Phoenix | Mike Rockenfeller
Q16 #4 [DTMV8] 48.291 Audi Sport Team Abt Sportsline | Robin Frijns
Q17 #28 [DTMV8] 48.357 Audi Sport Team Phoenix | Loïc Duval
Q18 #94 [DTMV8] 48.477 Mercedes-AMG Motorsport Petronas | Pascal Wehrlein

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #23 Daniel Juncadella 47.705 Mercedes-AMG Motorsport Remus
DTMV8: #23 Daniel Juncadella 47.705 Mercedes-AMG Motorsport Remus

## Fastest laps (archive)
Overall: #53 Jamie Green 48.311 lap 10
DTMV8: #53 Jamie Green 48.311 lap 10

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g7 #11 BMW Team RMG | BMW M4 DTM | Classified 68L gap — | Marco Wittmann
 2 g5 #48 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 68L gap 0.450 | Edoardo Mortara
 3 g1 #23 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 68L gap 0.860 | Daniel Juncadella
 4 g6 #7 BMW Team RBM | BMW M4 DTM | Classified 68L gap 5.497 | Bruno Spengler
 5 g3 #22 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 68L gap 6.062 | Lucas Auer
 6 g4 #3 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 68L gap 11.707 | Paul di Resta
 7 g11 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 68L gap 12.724 | Nico Müller
 8 g16 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 68L gap 13.748 | Robin Frijns
 9 g18 #94 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 68L gap 17.917 | Pascal Wehrlein
 10 g9 #16 BMW Team RMR | BMW M4 DTM | Classified 68L gap 29.239 | Timo Glock
 11 g10 #25 BMW Team RMR | BMW M4 DTM | Classified 68L gap 29.559 | Philipp Eng
 12 g8 #47 BMW Team RBM | BMW M4 DTM | Classified 68L gap 31.139 | Joel Eriksson
 13 g2 #2 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 68L gap 32.071 | Gary Paffett
 14 g13 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 68L gap 33.201 | René Rast
 15 g12 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 68L gap 35.547 | Jamie Green
 16 g15 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 68L gap 37.893 | Mike Rockenfeller
 17 g14 #15 BMW Team RMG | BMW M4 DTM | Classified 68L gap 47.521 | Augusto Farfus
 18 g17 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 67L gap 1 LAP | Loïc Duval
