# dtm-lausitzring-2018-r2-race1

Event: DTM Lausitzring Race 1 | Circuit: Lausitzring | Date: 2018-05-19
Scheduled: 00:55:00 | Official duration: 00:57:54.520 | Laps (winner): 21

## Qualifying (archive order)
Q1 #22 [DTMV8] 1:37.343 Silberpfeil Energy Mercedes-AMG Motorsport | Lucas Auer
Q2 #25 [DTMV8] 1:37.350 BMW Team RMR | Philipp Eng
Q3 #7 [DTMV8] 1:37.513 BMW Team RBM | Bruno Spengler
Q4 #94 [DTMV8] 1:37.518 Mercedes-AMG Motorsport Petronas | Pascal Wehrlein
Q5 #16 [DTMV8] 1:37.534 BMW Team RMR | Timo Glock
Q6 #11 [DTMV8] 1:37.544 BMW Team RMG | Marco Wittmann
Q7 #48 [DTMV8] 1:37.580 Silberpfeil Energy Mercedes-AMG Motorsport | Edoardo Mortara
Q8 #3 [DTMV8] 1:37.825 Mercedes-AMG Motorsport Remus | Paul di Resta
Q9 #51 [DTMV8] 1:37.860 Audi Sport Team Abt Sportsline | Nico Müller
Q10 #99 [DTMV8] 1:37.965 Audi Sport Team Phoenix | Mike Rockenfeller
Q11 #47 [DTMV8] 1:37.966 BMW Team RBM | Joel Eriksson
Q12 #4 [DTMV8] 1:37.986 Audi Sport Team Abt Sportsline | Robin Frijns
Q13 #28 [DTMV8] 1:38.113 Audi Sport Team Phoenix | Loïc Duval
Q14 #2 [DTMV8] 1:38.135 Mercedes-AMG Motorsport Petronas | Gary Paffett
Q15 #33 [DTMV8] 1:38.161 Audi Sport Team Rosberg | René Rast
Q16 #15 [DTMV8] 1:38.210 BMW Team RMG | Augusto Farfus
Q17 #53 [DTMV8] 1:38.326 Audi Sport Team Rosberg | Jamie Green
Q18 #23 [DTMV8] 1:38.520 Mercedes-AMG Motorsport Remus | Daniel Juncadella

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #22 Lucas Auer 1:37.343 Silberpfeil Energy Mercedes-AMG Motorsport
DTMV8: #22 Lucas Auer 1:37.343 Silberpfeil Energy Mercedes-AMG Motorsport

## Fastest laps (archive)
Overall: #23 Daniel Juncadella 1:39.699 lap 19
DTMV8: #23 Daniel Juncadella 1:39.699 lap 19

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g7 #48 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 21L gap — | Edoardo Mortara
 2 g5 #16 BMW Team RMR | BMW M4 DTM | Classified 21L gap 0.920 | Timo Glock
 3 g2 #25 BMW Team RMR | BMW M4 DTM | Classified 21L gap 2.887 | Philipp Eng
 4 g1 #22 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 21L gap 3.185 | Lucas Auer
 5 g3 #7 BMW Team RBM | BMW M4 DTM | Classified 21L gap 5.094 | Bruno Spengler
 6 g8 #3 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 21L gap 5.761 | Paul di Resta
 7 g6 #11 BMW Team RMG | BMW M4 DTM | Classified 21L gap 6.403 | Marco Wittmann
 8 g4 #94 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 21L gap 7.281 | Pascal Wehrlein
 9 g14 #2 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 21L gap 7.607 | Gary Paffett
 10 g16 #15 BMW Team RMG | BMW M4 DTM | Classified 21L gap 8.369 | Augusto Farfus
 11 g10 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 21L gap 8.758 | Mike Rockenfeller
 12 g11 #47 BMW Team RBM | BMW M4 DTM | Classified 21L gap 9.522 | Joel Eriksson
 13 g12 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 21L gap 12.941 | Robin Frijns
 14 g18 #23 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 21L gap 13.867 | Daniel Juncadella
 15 g13 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | RET 7L gap RET | Loïc Duval
 16 g15 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | RET 6L gap RET | René Rast
 17 g9 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | RET 0L gap RET | Nico Müller
 18 g17 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | RET 0L gap RET | Jamie Green
