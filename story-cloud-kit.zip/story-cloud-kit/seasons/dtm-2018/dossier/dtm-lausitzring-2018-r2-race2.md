# dtm-lausitzring-2018-r2-race2

Event: DTM Lausitzring Race 2 | Circuit: Lausitzring | Date: 2018-05-20
Scheduled: 00:55:00 | Official duration: 00:57:27.909 | Laps (winner): 34

## Qualifying (archive order)
Q1 #25 [DTMV8] 1:38.150 BMW Team RMR | Philipp Eng
Q2 #94 [DTMV8] 1:38.176 Mercedes-AMG Motorsport Petronas | Pascal Wehrlein
Q3 #2 [DTMV8] 1:38.218 Mercedes-AMG Motorsport Petronas | Gary Paffett
Q4 #11 [DTMV8] 1:38.283 BMW Team RMG | Marco Wittmann
Q5 #99 [DTMV8] 1:38.376 Audi Sport Team Phoenix | Mike Rockenfeller
Q6 #48 [DTMV8] 1:38.538 Silberpfeil Energy Mercedes-AMG Motorsport | Edoardo Mortara
Q7 #47 [DTMV8] 1:38.556 BMW Team RBM | Joel Eriksson
Q8 #22 [DTMV8] 1:38.566 Silberpfeil Energy Mercedes-AMG Motorsport | Lucas Auer
Q9 #23 [DTMV8] 1:38.658 Mercedes-AMG Motorsport Remus | Daniel Juncadella
Q10 #16 [DTMV8] 1:38.673 BMW Team RMR | Timo Glock
Q11 #7 [DTMV8] 1:38.675 BMW Team RBM | Bruno Spengler
Q12 #15 [DTMV8] 1:38.710 BMW Team RMG | Augusto Farfus
Q13 #51 [DTMV8] 1:38.743 Audi Sport Team Abt Sportsline | Nico Müller
Q14 #4 [DTMV8] 1:38.756 Audi Sport Team Abt Sportsline | Robin Frijns
Q15 #3 [DTMV8] 1:38.853 Mercedes-AMG Motorsport Remus | Paul di Resta
Q16 #53 [DTMV8] 1:38.874 Audi Sport Team Rosberg | Jamie Green
Q17 #28 [DTMV8] 1:38.884 Audi Sport Team Phoenix | Loïc Duval

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #25 Philipp Eng 1:38.150 BMW Team RMR
DTMV8: #25 Philipp Eng 1:38.150 BMW Team RMR

## Fastest laps (archive)
Overall: #11 Marco Wittmann 1:39.395 lap 17
DTMV8: #11 Marco Wittmann 1:39.395 lap 17

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g3 #2 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 34L gap — | Gary Paffett
 2 g4 #11 BMW Team RMG | BMW M4 DTM | Classified 34L gap 1.427 | Marco Wittmann
 3 g2 #94 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 34L gap 8.602 | Pascal Wehrlein
 4 g15 #3 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 34L gap 17.891 | Paul di Resta
 5 g10 #16 BMW Team RMR | BMW M4 DTM | Classified 34L gap 19.061 | Timo Glock
 6 g16 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 34L gap 23.243 | Jamie Green
 7 g1 #25 BMW Team RMR | BMW M4 DTM | Classified 34L gap 24.292 | Philipp Eng
 8 g5 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 34L gap 24.631 | Mike Rockenfeller
 9 g7 #47 BMW Team RBM | BMW M4 DTM | Classified 34L gap 27.050 | Joel Eriksson
 10 g14 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 34L gap 30.992 | Robin Frijns
 11 g6 #48 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 34L gap 32.458 | Edoardo Mortara
 12 g9 #23 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 34L gap 32.803 | Daniel Juncadella
 13 g17 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 34L gap 33.304 | Loïc Duval
 14 g8 #22 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 34L gap 38.266 | Lucas Auer
 15 g11 #7 BMW Team RBM | BMW M4 DTM | Classified 34L gap 38.526 | Bruno Spengler
 16 g12 #15 BMW Team RMG | BMW M4 DTM | Classified 34L gap 40.550 | Augusto Farfus
 17 g13 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 34L gap 41.673 | Nico Müller
