# dtm-brandshatch-2018-r6-race2

Event: DTM Brands Hatch Race 2 | Circuit: Brands Hatch | Date: 2018-08-12
Scheduled: 00:55:00 | Official duration: 00:56:23.282 | Laps (winner): 40

## Qualifying (archive order)
Q1 #2 [DTMV8] 1:17.948 Mercedes-AMG Motorsport Petronas | Gary Paffett
Q2 #3 [DTMV8] 1:18.021 Mercedes-AMG Motorsport Remus | Paul di Resta
Q3 #94 [DTMV8] 1:18.034 Mercedes-AMG Motorsport Petronas | Pascal Wehrlein
Q4 #33 [DTMV8] 1:18.052 Audi Sport Team Rosberg | René Rast
Q5 #22 [DTMV8] 1:18.135 Silberpfeil Energy Mercedes-AMG Motorsport | Lucas Auer
Q6 #4 [DTMV8] 1:18.140 Audi Sport Team Abt Sportsline | Robin Frijns
Q7 #15 [DTMV8] 1:18.182 BMW Team RMG | Augusto Farfus
Q8 #28 [DTMV8] 1:18.205 Audi Sport Team Phoenix | Loïc Duval
Q9 #11 [DTMV8] 1:18.244 BMW Team RMG | Marco Wittmann
Q10 #25 [DTMV8] 1:18.304 BMW Team RMR | Philipp Eng
Q11 #53 [DTMV8] 1:18.315 Audi Sport Team Rosberg | Jamie Green
Q12 #99 [DTMV8] 1:18.330 Audi Sport Team Phoenix | Mike Rockenfeller
Q13 #16 [DTMV8] 1:18.508 BMW Team RMR | Timo Glock
Q14 #23 [DTMV8] 1:18.517 Mercedes-AMG Motorsport Remus | Daniel Juncadella
Q15 #51 [DTMV8] 1:18.607 Audi Sport Team Abt Sportsline | Nico Müller
Q16 #47 [DTMV8] 1:18.654 BMW Team RBM | Joel Eriksson
Q17 #48 [DTMV8] 1:18.670 Silberpfeil Energy Mercedes-AMG Motorsport | Edoardo Mortara
Q18 #7 [DTMV8] 1:19.115 BMW Team RBM | Bruno Spengler

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #2 Gary Paffett 1:17.948 Mercedes-AMG Motorsport Petronas
DTMV8: #2 Gary Paffett 1:17.948 Mercedes-AMG Motorsport Petronas

## Fastest laps (archive)
Overall: #3 Paul di Resta 1:19.943 lap 5
DTMV8: #3 Paul di Resta 1:19.943 lap 5

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g2 #3 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 40L gap — | Paul di Resta
 2 g1 #2 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 40L gap 1.019 | Gary Paffett
 3 g4 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 40L gap 1.376 | René Rast
 4 g3 #94 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 40L gap 11.484 | Pascal Wehrlein
 5 g9 #11 BMW Team RMG | BMW M4 DTM | Classified 40L gap 14.312 | Marco Wittmann
 6 g12 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 40L gap 14.841 | Mike Rockenfeller
 7 g10 #25 BMW Team RMR | BMW M4 DTM | Classified 40L gap 17.239 | Philipp Eng
 8 g5 #22 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 40L gap 17.972 | Lucas Auer
 9 g14 #23 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 40L gap 18.505 | Daniel Juncadella
 10 g15 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 40L gap 20.798 | Nico Müller
 11 g13 #16 BMW Team RMR | BMW M4 DTM | Classified 40L gap 21.764 | Timo Glock
 12 g6 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 40L gap 22.007 | Robin Frijns
 13 g16 #47 BMW Team RBM | BMW M4 DTM | Classified 40L gap 23.197 | Joel Eriksson
 14 g18 #7 BMW Team RBM | BMW M4 DTM | Classified 40L gap 31.998 | Bruno Spengler
 15 g11 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 40L gap 33.359 | Jamie Green
 16 g8 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 38L gap 2 LAPS | Loïc Duval
 17 g17 #48 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 37L gap 3 LAPS | Edoardo Mortara
 18 g7 #15 BMW Team RMG | BMW M4 DTM | RET 20L gap RET | Augusto Farfus
