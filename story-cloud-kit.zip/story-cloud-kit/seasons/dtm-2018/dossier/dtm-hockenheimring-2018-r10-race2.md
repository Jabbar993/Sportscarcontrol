# dtm-hockenheimring-2018-r10-race2

Event: DTM Hockenheimring Race 2 | Circuit: Hockenheimring | Date: 2018-10-14
Scheduled: 00:55:00 | Official duration: 00:58:03.981 | Laps (winner): 36

## Qualifying (archive order)
Q1 #11 [DTMV8] 1:32.683 BMW Team RMG | Marco Wittmann
Q2 #33 [DTMV8] 1:32.737 Audi Sport Team Rosberg | René Rast
Q3 #2 [DTMV8] 1:32.846 Mercedes-AMG Motorsport Petronas | Gary Paffett
Q4 #7 [DTMV8] 1:32.901 BMW Team RBM | Bruno Spengler
Q5 #15 [DTMV8] 1:32.911 BMW Team RMG | Augusto Farfus
Q6 #48 [DTMV8] 1:32.916 Silberpfeil Energy Mercedes-AMG Motorsport | Edoardo Mortara
Q7 #47 [DTMV8] 1:32.947 BMW Team RBM | Joel Eriksson
Q8 #25 [DTMV8] 1:32.960 BMW Team RMR | Philipp Eng
Q9 #51 [DTMV8] 1:32.972 Audi Sport Team Abt Sportsline | Nico Müller
Q10 #16 [DTMV8] 1:33.112 BMW Team RMR | Timo Glock
Q11 #3 [DTMV8] 1:33.114 Mercedes-AMG Motorsport Remus | Paul di Resta
Q12 #22 [DTMV8] 1:33.126 Silberpfeil Energy Mercedes-AMG Motorsport | Lucas Auer
Q13 #23 [DTMV8] 1:33.287 Mercedes-AMG Motorsport Remus | Daniel Juncadella
Q14 #53 [DTMV8] 1:33.324 Audi Sport Team Rosberg | Jamie Green
Q15 #94 [DTMV8] 1:33.427 Mercedes-AMG Motorsport Petronas | Pascal Wehrlein
Q16 #99 [DTMV8] 1:33.468 Audi Sport Team Phoenix | Mike Rockenfeller
Q17 #28 [DTMV8] 1:33.477 Audi Sport Team Phoenix | Loïc Duval
Q18 #4 [DTMV8] 1:34.695 Audi Sport Team Abt Sportsline | Robin Frijns

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #11 Marco Wittmann 1:32.683 BMW Team RMG
DTMV8: #11 Marco Wittmann 1:32.683 BMW Team RMG

## Fastest laps (archive)
Overall: #4 Robin Frijns 1:34.512 lap 27
DTMV8: #4 Robin Frijns 1:34.512 lap 27

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== DTMV8
 1 g2 #33 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 36L gap — | René Rast
 2 g1 #11 BMW Team RMG | BMW M4 DTM | Classified 36L gap 3.786 | Marco Wittmann
 3 g3 #2 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 36L gap 15.838 | Gary Paffett
 4 g9 #51 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 36L gap 17.241 | Nico Müller
 5 g18 #4 Audi Sport Team Abt Sportsline | Audi RS 5 DTM | Classified 36L gap 18.942 | Robin Frijns
 6 g4 #7 BMW Team RBM | BMW M4 DTM | Classified 36L gap 21.004 | Bruno Spengler
 7 g5 #15 BMW Team RMG | BMW M4 DTM | Classified 36L gap 21.460 | Augusto Farfus
 8 g8 #25 BMW Team RMR | BMW M4 DTM | Classified 36L gap 24.458 | Philipp Eng
 9 g7 #47 BMW Team RBM | BMW M4 DTM | Classified 36L gap 28.683 | Joel Eriksson
 10 g10 #16 BMW Team RMR | BMW M4 DTM | Classified 36L gap 30.003 | Timo Glock
 11 g16 #99 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 36L gap 33.406 | Mike Rockenfeller
 12 g17 #28 Audi Sport Team Phoenix | Audi RS 5 DTM | Classified 36L gap 33.587 | Loïc Duval
 13 g6 #48 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 36L gap 34.985 | Edoardo Mortara
 14 g11 #3 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 36L gap 38.204 | Paul di Resta
 15 g13 #23 Mercedes-AMG Motorsport Remus | Mercedes-AMG C 63 DTM | Classified 36L gap 38.869 | Daniel Juncadella
 16 g12 #22 Silberpfeil Energy Mercedes-AMG Motorsport | Mercedes-AMG C 63 DTM | Classified 36L gap 39.611 | Lucas Auer
 17 g14 #53 Audi Sport Team Rosberg | Audi RS 5 DTM | Classified 36L gap 40.132 | Jamie Green
 18 g15 #94 Mercedes-AMG Motorsport Petronas | Mercedes-AMG C 63 DTM | Classified 36L gap 44.638 | Pascal Wehrlein
