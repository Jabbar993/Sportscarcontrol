# elms-spa-2016

Event: 4 Hours of Spa-Francorchamps | Circuit: Spa-Francorchamps | Date: 2016-09-25
Scheduled: 04:00:00 | Official duration: 4:01:13.639 | Laps (winner): 96

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q29 #56 [LMGTE] 2:17.038 AT Racing | Alessandro Pier Guidi
Q30 #88 [LMGTE] 2:17.376 Proton Competition | Matteo Cairoli
Q31 #55 [LMGTE] 2:17.707 AF Corse | Matt Griffin
Q32 #66 [LMGTE] 2:18.071 JMW Motorsport | Andrea Bertolini
Q33 #99 [LMGTE] 2:18.290 Aston Martin Racing | Darren Turner
Q34 #77 [LMGTE] 2:18.365 Proton Competition | Wolf Henzler
Q35 #51 [LMGTE] 2:18.508 AF Corse | Marco Cioci
Q37 #60 [LMGTE] 2:19.198 Formula Racing | Mikkel Mac
Q1 #21 [LMP2] 2:06.603 DragonSpeed | Nicolas Lapierre
Q2 #46 [LMP2] 2:07.048 Thiriet by TDS Racing | Mathias Beche
Q3 #38 [LMP2] 2:07.214 G-Drive Racing | Harry Tincknell
Q4 #33 [LMP2] 2:07.332 Eurasia Motorsport | Tristan Gommendy
Q5 #25 [LMP2] 2:07.613 Algarve Pro Racing | Andrea Pizzitola
Q6 #41 [LMP2] 2:07.624 Greaves Motorsport | Nathanaël Berthon
Q7 #32 [LMP2] 2:07.778 SMP Racing | Stefano Coletti
Q8 #47 [LMP2] 2:08.253 Team WRT | Laurens Vanthoor
Q9 #23 [LMP2] 2:08.384 Panis Barthez Competition | Paul Loup Chatin
Q10 #48 [LMP2] 2:09.698 Murphy Prototypes | Garry Findlay
Q11 #29 [LMP2] 2:10.647 Pegasus Racing | Léo Roussel
Q12 #40 [LMP2] 2:14.291 Krohn Racing | Tracy Krohn
Q38 #28 [LMP2] 2:19.616 Idec Sport Racing | Dimitri Enjalbert
Q13 #9 [LMP3] 2:14.392 Graff | Enzo Guibbert
Q14 #3 [LMP3] 2:14.456 United Autosports | Matthew Bell
Q15 #26 [LMP3] 2:14.529 Tockwith Motorsports | Nigel Moore
Q16 #16 [LMP3] 2:14.714 Panis Barthez Competition | Simon Gachet
Q17 #2 [LMP3] 2:14.825 United Autosports | Alex Brundle
Q18 #18 [LMP3] 2:15.146 M.Racing - YMR | Yann Ehrlacher
Q19 #19 [LMP3] 2:15.448 Duqueine Engineering | Dino Lunardi
Q20 #6 [LMP3] 2:15.497 360 Racing | Ross Kaiser
Q21 #7 [LMP3] 2:15.573 Villorba Corse | Giorgio Sernagiotto
Q22 #24 [LMP3] 2:15.682 Oak Racing | Jacques Nicolet
Q23 #17 [LMP3] 2:15.722 Ultimate | Jean Baptiste Lahaye
Q24 #8 [LMP3] 2:15.815 RACE Performance | Giorgio Maggi
Q25 #20 [LMP3] 2:16.039 Duqueine Engineering | Antonin Borga
Q26 #15 [LMP3] 2:16.101 RLR MSport | Morten Dons
Q27 #10 [LMP3] 2:16.600 Graff | Vicente Potolicchio
Q28 #13 [LMP3] 2:16.932 Inter Europol Competition | Jakub Smiechowski
Q36 #4 [LMP3] 2:18.602 Oak Racing | Erik Maris

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #21 Nicolas Lapierre 2:06.603 DragonSpeed
LMGTE: #56 Alessandro Pier Guidi 2:17.038 AT Racing
LMP2: #21 Nicolas Lapierre 2:06.603 DragonSpeed
LMP3: #9 Enzo Guibbert 2:14.392 Graff

## Fastest laps (archive)
Overall: #46 Mathias Beche 2:08.796
LMGTE: #66 Rory Butcher 2:20.298
LMP2: #46 Mathias Beche 2:08.796
LMP3: #9 Enzo Guibbert 2:16.524

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g1 #21 DragonSpeed | Oreca 05 - Nissan | Classified 96L gap — | Henrik Hedman / Nicolas Lapierre / Ben Hanley
 2 g8 #47 Team WRT | Ligier JSP2 | Classified 96L gap — | Laurens Vanthoor / Will Stevens / Dries Vanthoor
 3 g2 #46 Thiriet by TDS Racing | Oreca 05 - Nissan | Classified 96L gap 39.967 | Pierre Thiriet / Mathias Beche / Ryo Hirakawa
 4 g6 #41 Greaves Motorsport | Ligier JS P2 - Nissan | Classified 96L gap 46.342 | Memo Rojas / Julien Canal / Nathanaël Berthon
 5 g3 #38 G-Drive Racing | Gibson 015S - Nissan | Classified 96L gap — | Simon Dolan / Harry Tincknell / Giedo van der Garde
 6 g7 #32 SMP Racing | BR 01- Nissan | Classified 95L gap 1 Laps | Stefano Coletti / Andreas Wirth / Vitaly Petrov
 7 g9 #23 Panis Barthez Competition | Ligier JS P2 - Nissan | Classified 95L gap 1 Laps | Fabien Barthez / Timothé Buret / Paul Loup Chatin
 8 g13 #28 Idec Sport Racing | Ligier JS P2 - Judd | Classified 95L gap 1 Laps | Patrice Lafargue / Paul Lafargue / Dimitri Enjalbert
 9 g5 #25 Algarve Pro Racing | Ligier JS P2 - Nissan | Classified 94L gap 2 Laps | Michael Munemann / Jonathan Hirschi / Andrea Pizzitola
 30 g12 #40 Krohn Racing | Ligier JS P2 - Nissan | Classified 87L gap 9 Laps | Tracy Krohn / Niclas Jönsson / Olivier Pla
 33 g11 #29 Pegasus Racing | Morgan - Nissan | NC 45L gap NC | Inès Taittinger / Rémy Striebig / Léo Roussel
 34 g10 #48 Murphy Prototypes | Oreca 03R - Nissan | NC 36L gap NC | Garry Findlay / Bruno Bonifacio / Sean Doyle
 39 g4 #33 Eurasia Motorsport | Oreca 05 - Nissan | NC 0L gap NC | Junjin Pu / Nico Pieter de Bruijn / Tristan Gommendy
== LMP3
 10 g14 #9 Graff | Ligier JS P3 - Nissan | Classified 92L gap 4 Laps | Eric Trouillet / Paul Petit / Enzo Guibbert
 11 g18 #2 United Autosports | Ligier JS P3 - Nissan | Classified 92L gap 4 Laps | Alex Brundle / Michael Guasch / Christian England
 12 g15 #3 United Autosports | Ligier JS P3 - Nissan | Classified 92L gap 4 Laps | Mark Patterson / Matthew Bell / Wayne Boyd
 13 g24 #17 Ultimate | Ligier JS P3 - Nissan | Classified 92L gap 4 Laps | Jean Baptiste Lahaye / François Heriau / Matthieu Lahaye
 14 g21 #6 360 Racing | Ligier JS P3 - Nissan | Classified 92L gap 4 Laps | Terrence Woodward / Ross Kaiser / James Swift
 15 g29 #13 Inter Europol Competition | Ligier JS P3 - Nissan | Classified 92L gap 4 Laps | Jakub Smiechowski / Jens Petersen
 16 g28 #10 Graff | Ligier JS P3 - Nissan | Classified 92L gap 4 Laps | John Falb / Sean Rayhall / Vicente Potolicchio
 17 g27 #15 RLR MSport | Ligier JS P3 - Nissan | Classified 91L gap 5 Laps | Morten Dons / Anthony Wells / Alasdair Mccaig
 18 g22 #7 Villorba Corse | Ligier JS P3 - Nissan | Classified 91L gap 5 Laps | Roberto Lacorte / Giorgio Sernagiotto
 19 g26 #20 Duqueine Engineering | Ligier JS P3 - Nissan | Classified 91L gap 5 Laps | Maxime Pialat / Eric Clement / Antonin Borga
 20 g17 #16 Panis Barthez Competition | Ligier JS P3 - Nissan | Classified 91L gap 5 Laps | Eric Debard / Valentin Moineault / Simon Gachet
 25 g16 #26 Tockwith Motorsports | Ligier JSP3 | Classified 90L gap 6 Laps | Nigel Moore / Phil Hanson
 26 g23 #24 Oak Racing | Ligier JS P3 - Nissan | Classified 90L gap 6 Laps | Jacques Nicolet / Pierre Nicolet
 31 g37 #4 Oak Racing | Ligier JS P3 - Nissan | Classified 87L gap 9 Laps | Carlos Tavares / Erik Maris
 32 g19 #18 M.Racing - YMR | Ligier JS P3 - Nissan | NC 69L gap NC | Thomas Laurent / Yann Ehrlacher / Alexandre Cougnaud
 35 g20 #19 Duqueine Engineering | Ligier JS P3 - Nissan | NC 25L gap NC | David Hallyday / Dino Lunardi / David Droux
 37 g25 #8 RACE Performance | Ligier JS P3 - Nissan | NC 0L gap NC | Marcello Marateotto / Giorgio Maggi / Bert Longin
 38 g39 #5 By Speed Factory | Ligier JS P3 - Nissan | NC 0L gap NC | Daniel Polley / Kevin O Hara / Kim Rodkjaer
== LMGTE
 21 g33 #66 JMW Motorsport | Ferrari F458 Italia | Classified 91L gap 5 Laps | Robert Smith / Rory Butcher / Andrea Bertolini
 22 g31 #88 Proton Competition | Porsche 911 RSR 991 | Classified 91L gap 5 Laps | Gianluca Roda / Christian Ried / Matteo Cairoli
 23 g32 #55 AF Corse | Ferrari F458 Italia | Classified 90L gap 6 Laps | Duncan Cameron / Matt Griffin / Aaron Scott
 24 g35 #77 Proton Competition | Porsche 911 RSR 991 | Classified 90L gap 6 Laps | Michael Hedlund / Wolf Henzler / Marco Seefried
 27 g34 #99 Aston Martin Racing | Aston Martin V8 Vantage | Classified 89L gap 7 Laps | Andrew Howard / Darren Turner / Alex Macdowall
 28 g36 #51 AF Corse | Ferrari F458 Italia | Classified 89L gap 7 Laps | Piergiuseppe Perazzini / Marco Cioci / Rui Aguas
 29 g38 #60 Formula Racing | Ferrari F458 Italia | Classified 88L gap 8 Laps | Johnny Laursen / Mikkel Mac / Christina Nielsen
 36 g30 #56 AT Racing | Ferrari F458 Italia | NC 0L gap NC | Alexander Talkanitsa / Alexander Talka Jr / Alessandro Pier Guidi
