# elms-silverstone-2016

Event: 4 Hours of Silverstone | Circuit: Silverstone | Date: 2016-04-16
Scheduled: 04:00:00 | Official duration: 4:01:45.391 | Laps (winner): 118

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q1 #46 [LMP2] 2:06.471 Thiriet By Tds Racing | Mathias Beche
Q2 #32 [LMP2] 2:07.576 SMP Racing | Stefano Coletti
Q3 #29 [LMP2] 2:07.624 Pegasus Racing | Leo Roussel
Q4 #38 [LMP2] 2:07.855 G-Drive Racing | Harry Tincknell
Q5 #21 [LMP2] 2:08.194 DragonSpeed | Nicolas Lapierre
Q6 #44 [LMP2] 2:08.247 SMP Racing | Sean Gelael
Q7 #41 [LMP2] 2:08.592 Greaves Motorsport | Jakub Giermaziak
Q8 #23 [LMP2] 2:08.895 Panis Barthez Competition | Paul-Loup Chatin
Q9 #40 [LMP2] 2:09.518 Krohn Racing | Bjorn Wirdheim
Q10 #28 [LMP2] 2:09.943 IDEC SPORT RACING | Dimitri Enjalbert
Q11 #34 [LMP2] 2:10.511 RACE PERFORMANCE | Franck Mailleux
Q12 #33 [LMP2] 2:10.785 EURASIA MOTORSPORT | Tristan Gommendy
Q13 #84 [LMP2] 2:11.079 SRT41 By OAK Racing | Christophe Tinseau
Q14 #22 [LMP2] 2:12.642 SO24 ! BY LOMBARD RACING | Vincent Capillaire
Q15 #6 [LMP3] 2:13.264 360 Racing | Ross Kaiser
Q16 #19 [LMP3] 2:13.315 DUQUEINE ENGINEERING | Dino Lunardi
Q17 #9 [LMP3] 2:13.914 GRAFF | Enzo Guibbert
Q18 #2 [LMP3] 2:14.411 UNITED AUTOSPORTS | Alex Brundle
Q19 #3 [LMP3] 2:14.415 UNITED AUTOSPORTS | Matthew Bell
Q20 #17 [LMP3] 2:14.839 ULTIMATE | Matthieu Lahaye
Q21 #5 [LMP3] 2:15.385 BY SPEED FACTORY | Tom Jackson
Q22 #10 [LMP3] 2:15.681 GRAFF | Sean Rayhall
Q23 #16 [LMP3] 2:16.007 Panis Barthez Competition | Simon Gachet
Q24 #18 [LMP3] 2:16.194 M.RACING - YMR | Alexandre Cougnaud
Q25 #7 [LMP3] 2:16.949 Villorba Corse | Giorgio Sernagiotto
Q26 #25 [LMP2] 2:16.972 Algarve Pro Racing | Parth Ghorpade
Q27 #15 [LMP3] 2:17.481 RLR MSPORT | Morten Dons
Q28 #11 [LMP3] 2:17.808 EUROINTERNATIONAL | Giorgio Mondini
Q29 #13 [LMP3] 2:17.899 Inter Europol Competition | Jakub Smiechowski
Q30 #8 [LMP3] 2:18.183 RACE PERFORMANCE | Bert Longin
Q31 #96 [LMGTE] 2:19.348 Aston Martin Racing | Richie Stanaway
Q32 #24 [LMP3] 2:19.803 Oak Racing | Jacques Nicolet
Q33 #88 [LMGTE] 2:20.286 Proton Competition | Richard Lietz
Q34 #66 [LMGTE] 2:20.378 JMW Motorsport | Andrea Bertolini
Q35 #20 [LMP3] 2:20.497 DUQUEINE ENGINEERING | Maxime Pialat
Q36 #55 [LMGTE] 2:21.309 AF Corse | Matt Griffin
Q37 #56 [LMGTE] 2:21.360 AT Racing | Alessandro Pier Guidi
Q38 #77 [LMGTE] 2:21.419 Proton Competition | Wolf Henzler
Q39 #4 [LMP3] 2:21.624 Oak Racing | Erik Maris
Q40 #99 [LMGTE] 2:21.986 Aston Martin Racing | Alex MacDowall
Q41 #60 [LMGTE] 2:22.388 Formula Racing | Mikkel Mac
Q42 #51 [LMGTE] 2:22.545 AF Corse | Marco Cioci
Q43 #14 [LMP3] 2:23.140 MurphyP3-3Dimensional.com | Michael Cullen

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #46 Mathias Beche 2:06.471 Thiriet By Tds Racing
LMP2: #46 Mathias Beche 2:06.471 Thiriet By Tds Racing
LMP3: #6 Ross Kaiser 2:13.264 360 Racing
LMGTE: #96 Richie Stanaway 2:19.348 Aston Martin Racing

## Fastest laps (archive)
LMGTE: #88 Richard Lietz 2:01.241
Overall: #23 Paul-Loup Chatin 1:50.426
LMP2: #23 Paul-Loup Chatin 1:50.426
LMP3: #2 Alex Brundle 1:55.817

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g4 #38 G-Drive Racing | Gibson 015S - Nissan | Classified 118L gap — | Simon Dolan / Harry Tincknell / Giedo van der Garde
 2 g2 #32 SMP Racing | BR 01- Nissan | Classified 118L gap — | Stefano Coletti / Julian Leal / Andreas Wirth
 3 g12 #22 SO24 ! BY LOMBARD RACING | LIGIER JS P2 - Judd | Classified 117L gap 1 Laps | Vincent Capillaire / Olivier Lombard / Jonathan Coleman
 4 g11 #40 Krohn Racing | LIGIER JS P2 - Nissan | Classified 117L gap 1 Laps | Tracy Krohn / Niclas Jönsson / Bjorn Wirdheim
 5 g6 #44 SMP Racing | BR 01- Nissan | Classified 117L gap 1 Laps | Sean Gelael / Mitch Evans / Antonio Giovinazzi
 6 g9 #34 RACE PERFORMANCE | Oreca 03R - Judd | Classified 116L gap 2 Laps | Nicolas Leutwiler / James Winslow / Franck Mailleux
 7 g16 #28 IDEC SPORT RACING | LIGIER JS P2 - Judd | Classified 116L gap 2 Laps | Paul Lafargue / Patrice Lafargue / Dimitri Enjalbert
 8 g7 #41 Greaves Motorsport | LIGIER JS P2 - Nissan | Classified 115L gap 3 Laps | Memo Rojas / Julien Canal / Jakub Giermaziak
 9 g8 #23 Panis Barthez Competition | LIGIER JS P2 - Nissan | Classified 114L gap 4 Laps | Fabien Barthez / Timothe Buret / Paul-Loup Chatin
 10 g26 #25 Algarve Pro Racing | LIGIER JS P2 - Nissan | Classified 114L gap 4 Laps | Michael Munemann / Chris Hoy / Parth Ghorpade
 15 g44 #48 Murphy Prototypes | Oreca 03R - Nissan | Classified 112L gap 6 Laps | Damien Faulkner / Shaun Balfe / Sean Doyle
 31 g13 #84 SRT41 By OAK Racing | ONROAK AUTOMOTIVE MORGAN LMP2 | Classified 106L gap 12 Laps | Frédéric Sausset / Christophe Tinseau / Jean-Bernard Bouvet
 36 g3 #29 Pegasus Racing | Morgan - Nissan | NC 90L gap NC | Inès Taittinger / Rémy Striebig / Leo Roussel
 37 g5 #21 DragonSpeed | Oreca 05 - Nissan | NC 63L gap NC | Henrik Hedman / Nicolas Lapierre / Ben Hanley
 42 g10 #33 EURASIA MOTORSPORT | Oreca 05 - Nissan | NC 0L gap NC | Pu Junjin / Nico Pieter de Bruijn / Tristan Gommendy
 43 g1 #46 Thiriet By Tds Racing | Oreca 05 - Nissan | NC 0L gap NC | Pierre Thiriet / Mathias Beche / Ryo Hirakawa
== LMP3
 11 g18 #2 UNITED AUTOSPORTS | LIGIER JS P3 - Nissan | Classified 113L gap 5 Laps | Alex Brundle / Michael Guasch / Christian England
 12 g19 #3 UNITED AUTOSPORTS | LIGIER JS P3 - Nissan | Classified 112L gap 6 Laps | Mark Patterson / Matthew Bell / Wayne Boyd
 13 g17 #9 GRAFF | LIGIER JS P3 - Nissan | Classified 112L gap 6 Laps | Eric Trouillet / Paul Petit / Enzo Guibbert
 14 g15 #19 DUQUEINE ENGINEERING | LIGIER JS P3 - Nissan | Classified 112L gap 6 Laps | David Hallyday / Dino Lunardi
 16 g14 #6 360 Racing | LIGIER JS P3 - Nissan | Classified 111L gap 7 Laps | Terrence Woodward / Ross Kaiser / James Swift
 17 g30 #8 RACE PERFORMANCE | LIGIER JS P3 - Nissan | Classified 110L gap 8 Laps | Marcello Marateotto / Giorgio Maggi / Bert Longin
 18 g23 #16 Panis Barthez Competition | LIGIER JS P3 - Nissan | Classified 110L gap 8 Laps | Eric Debard / Valentin Moineault / Simon Gachet
 19 g27 #15 RLR MSPORT | LIGIER JS P3 - Nissan | Classified 109L gap 9 Laps | Morten Dons / Ossy Yusuf
 23 g32 #24 Oak Racing | LIGIER JS P3 - Nissan | Classified 108L gap 10 Laps | Jacques Nicolet / Pierre Nicolet
 25 g35 #20 DUQUEINE ENGINEERING | LIGIER JS P3 - Nissan | Classified 108L gap 10 Laps | Romain Iannetta / Maxime Pialat / Eric Clément
 29 g20 #17 ULTIMATE | LIGIER JS P3 - Nissan | Classified 107L gap 11 Laps | Matthieu Lahaye / François Heriau / Jean-Baptiste Lahaye
 32 g39 #4 Oak Racing | LIGIER JS P3 - Nissan | Classified 105L gap 13 Laps | Jean-Marc Merlin / Erik Maris
 33 g22 #10 GRAFF | LIGIER JS P3 - Nissan | Classified 100L gap 18 Laps | John Falb / Sean Rayhall / Enzo Potolicchio
 34 g29 #13 Inter Europol Competition | LIGIER JS P3 - Nissan | NC 107L gap NC | Jakub Smiechowski / Jens Petersen
 35 g28 #11 EUROINTERNATIONAL | LIGIER JS P3 - Nissan | NC 97L gap NC | Giorgio Mondini / Andrea Roda / Marco Jacoboni
 38 g43 #14 MurphyP3-3Dimensional.com | Ginetta - Nissan | NC 29L gap NC | Michael Cullen / Tony Ave / Doug Peterson
 39 g24 #18 M.RACING - YMR | LIGIER JS P3 - Nissan | NC 0L gap NC | Thomas Laurent / Yann Ehrlacher / Alexandre Cougnaud
 40 g21 #5 BY SPEED FACTORY | LIGIER JS P3 - Nissan | NC 0L gap NC | Tom Jackson / Alvaro Fontes / Jesus Fuster
 41 g25 #7 Villorba Corse | LIGIER JS P3 - Nissan | NC 0L gap NC | Roberto Lacorte / Giorgio Sernagiotto / Nicollo Schiro
== LMGTE
 20 g40 #99 Aston Martin Racing | Aston Martin V8 Vantage | Classified 109L gap 9 Laps | Andrew Howard / Darren Turner / Alex MacDowall
 21 g37 #56 AT Racing | Ferrari F458 Italia | Classified 109L gap 9 Laps | Alexander Sr Talkanitsa / Alexander Talka Jr / Alessandro Pier Guidi
 22 g31 #96 Aston Martin Racing | Aston Martin V8 Vantage | Classified 109L gap 9 Laps | Roald Goethe / Stuart Hall / Richie Stanaway
 24 g36 #55 AF Corse | Ferrari F458 Italia | Classified 108L gap 10 Laps | Duncan Cameron / Matt Griffin / Aaron Scott
 26 g41 #60 Formula Racing | Ferrari F458 Italia | Classified 108L gap 10 Laps | Johnny Laursen / Mikkel Mac / Christina Nielsen
 27 g33 #88 Proton Competition | Porsche 911 RSR 991 | Classified 108L gap 10 Laps | Gianluca Roda / Richard Lietz / Christian Ried
 28 g42 #51 AF Corse | Ferrari F458 Italia | Classified 108L gap 10 Laps | Piergiuseppe Perazzini / Marco Cioci / Rui Aguas
 30 g38 #77 Proton Competition | Porsche 911 RSR 991 | Classified 107L gap 11 Laps | Michael Hedlund / Wolf Henzler / Marco Seefried
 44 g34 #66 JMW Motorsport | Ferrari F458 Italia | DSQ 110L gap DSQ | Rob Smith / Rory Butcher / Andrea Bertolini
