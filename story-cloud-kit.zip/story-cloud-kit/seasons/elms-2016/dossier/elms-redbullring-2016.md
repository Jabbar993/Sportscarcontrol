# elms-redbullring-2016

Event: 4 Hours of Red Bull Ring | Circuit: Red Bull Ring | Date: 2016-07-17
Scheduled: 04:00:00 | Official duration: 4:00:04.366 | Laps (winner): 160

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q26 #88 [LMGTE] 1:27.652 Proton Competition | Matteo Cairoli
Q27 #66 [LMGTE] 1:27.773 JMW Motorsport | Andrea Bertolini
Q28 #56 [LMGTE] 1:27.819 AT Racing | Alessandro Pier Guidi
Q33 #51 [LMGTE] 1:28.100 AF Corse | Marco Cioci
Q34 #55 [LMGTE] 1:28.239 AF Corse | Matt Griffin
Q35 #99 [LMGTE] 1:28.240 Aston Martin Racing | Darren Turner
Q37 #77 [LMGTE] 1:28.705 Proton Competition | Wolf Henzler
Q38 #60 [LMGTE] 1:28.738 Formula Racing | Mikkel Mac
Q1 #23 [LMP2] 1:20.700 Panis Barthez Competition | Paul Loup Chatin
Q2 #46 [LMP2] 1:20.753 Thiriet by TDS Racing | Mathias Beche
Q3 #38 [LMP2] 1:20.826 G-Drive Racing | Harry Tincknell
Q4 #33 [LMP2] 1:20.927 Eurasia Motorsport | Tristan Gommendy
Q5 #21 [LMP2] 1:20.956 DragonSpeed | Nicolas Lapierre
Q6 #40 [LMP2] 1:21.297 Krohn Racing | Olivier Pla
Q7 #25 [LMP2] 1:21.325 Algarve Pro Racing | Andrea Pizzitola
Q8 #32 [LMP2] 1:21.750 SMP Racing | Julian Leal
Q9 #41 [LMP2] 1:22.026 Greaves Motorsport | Nathanaël Berthon
Q10 #48 [LMP2] 1:22.359 Murphy Prototypes | Sean Doyle
Q11 #29 [LMP2] 1:22.872 Pegasus Racing | Léo Roussel
Q12 #16 [LMP3] 1:26.126 Panis Barthez Competition | Simon Gachet
Q13 #3 [LMP3] 1:26.283 United Autosports | Wayne Boyd
Q14 #19 [LMP3] 1:26.394 Duqueine Engineering | David Droux
Q15 #17 [LMP3] 1:26.545 Ultimate | Matthieu Lahaye
Q16 #11 [LMP3] 1:26.580 Eurointernational | Giorgio Mondini
Q17 #9 [LMP3] 1:26.630 Graff | James Winslow
Q18 #18 [LMP3] 1:26.671 M. Racing - YMR | Yann Ehrlacher
Q19 #2 [LMP3] 1:26.760 United Autosports | Alex Brundle
Q20 #10 [LMP3] 1:26.980 Graff | Sean Rayhall
Q21 #5 [LMP3] 1:27.008 By Speed Factory | Tom Jackson
Q22 #12 [LMP3] 1:27.018 Eurointernational | Roman Rusinov
Q23 #6 [LMP3] 1:27.076 360 Racing | Ross Kaiser
Q24 #13 [LMP3] 1:27.502 Inter Europol Competition | Jakub Smiechowski
Q25 #7 [LMP3] 1:27.526 Villorba Corse | Giorgio Sernagiotto
Q29 #15 [LMP3] 1:27.901 RLR MSport | Morten Dons
Q30 #24 [LMP3] 1:27.924 Oak Racing | Jacques Nicolet
Q31 #20 [LMP3] 1:27.927 Duqueine Engineering | Maxime Pialat
Q32 #4 [LMP3] 1:27.954 Oak Racing | Erik Maris
Q36 #8 [LMP3] 1:28.642 RACE Performance | Giorgio Maggi

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #23 Paul Loup Chatin 1:20.700 Panis Barthez Competition
LMGTE: #88 Matteo Cairoli 1:27.652 Proton Competition
LMP2: #23 Paul Loup Chatin 1:20.700 Panis Barthez Competition
LMP3: #16 Simon Gachet 1:26.126 Panis Barthez Competition

## Fastest laps (archive)
Overall: #38 Giedo van der Garde 1:22.392
LMGTE: #88 Matteo Cairoli 1:29.166
LMP2: #38 Giedo van der Garde 1:22.392
LMP3: #11 Giorgio Mondini 1:26.829

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g2 #46 Thiriet by TDS Racing | Oreca 05 - Nissan | Classified 160L gap — | Pierre Thiriet / Mathias Beche / Ryo Hirakawa
 2 g4 #33 Eurasia Motorsport | Oreca 05 - Nissan | Classified 160L gap 51.622 | Junjin Pu / Nico Pieter de Bruijn / Tristan Gommendy
 3 g3 #38 G-Drive Racing | Gibson 015S - Nissan | Classified 160L gap 59.108 | Simon Dolan / Harry Tincknell / Giedo van der Garde
 4 g8 #32 SMP Racing | BR 01- Nissan | Classified 159L gap 1 Laps | Stefano Coletti / Julian Leal / Andreas Wirth
 5 g7 #25 Algarve Pro Racing | LIGIER JS P2 - Nissan | Classified 159L gap 1 Laps | Michael Munemann / Andrea Pizzitola / Jonathan Hirschi
 6 g9 #41 Greaves Motorsport | LIGIER JS P2 - Nissan | Classified 159L gap 1 Laps | Memo Rojas / Julien Canal / Nathanaël Berthon
 7 g1 #23 Panis Barthez Competition | LIGIER JS P2 - Nissan | Classified 159L gap 1 Laps | Fabien Barthez / Timothé Buret / Paul Loup Chatin
 8 g10 #48 Murphy Prototypes | Oreca 03R - Nissan | Classified 156L gap 4 Laps | Guglielmo Belotti / Sean Doyle / Karun Chandhok
 32 g6 #40 Krohn Racing | LIGIER JS P2 - Nissan | Classified 145L gap 15 Laps | Tracy Krohn / Niclas Jönsson / Olivier Pla
 34 g11 #29 Pegasus Racing | Morgan - Nissan | NC 123L gap NC | Inès Taittinger / Rémy Striebig / Léo Roussel
 36 g5 #21 DragonSpeed | Oreca 05 - Nissan | NC 103L gap NC | Henrik Hedman / Nicolas Lapierre / Ben Hanley
== LMP3
 9 g19 #2 United Autosports | LIGIER JS P3 - Nissan | Classified 151L gap 9 Laps | Alex Brundle / Michael Guasch / Christian England
 10 g14 #19 Duqueine Engineering | LIGIER JS P3 - Nissan | Classified 151L gap 9 Laps | David Hallyday / Dino Lunardi / David Droux
 11 g23 #6 360 Racing | LIGIER JS P3 - Nissan | Classified 151L gap 9 Laps | Terrence Woodward / Ross Kaiser / James Swift
 12 g17 #9 Graff | LIGIER JS P3 - Nissan | Classified 151L gap 9 Laps | Eric Trouillet / Paul Petit / James Winslow
 14 g30 #24 Oak Racing | LIGIER JS P3 - Nissan | Classified 150L gap 10 Laps | Jacques Nicolet / Pierre Nicolet
 15 g36 #8 RACE Performance | LIGIER JS P3 - Nissan | Classified 150L gap 10 Laps | Marcello Marateotto / Giorgio Maggi / Bert Longin
 16 g20 #10 Graff | LIGIER JS P3 - Nissan | Classified 150L gap 10 Laps | John Falb / Sean Rayhall / Vicente Potolicchio
 19 g12 #16 Panis Barthez Competition | LIGIER JS P3 - Nissan | Classified 150L gap 10 Laps | Eric Debard / Valentin Moineault / Simon Gachet
 20 g22 #12 Eurointernational | LIGIER JS P3 - Nissan | Classified 150L gap 10 Laps | Andrea Dromedari / Fabio Mancini / Roman Rusinov
 26 g18 #18 M. Racing - YMR | LIGIER JS P3 - Nissan | Classified 149L gap 11 Laps | Thomas Laurent / Yann Ehrlacher / Alexandre Cougnaud
 27 g31 #20 Duqueine Engineering | LIGIER JS P3 - Nissan | Classified 148L gap 12 Laps | Maxime Pialat / Eric Clement / Antonin Borga
 28 g25 #7 Villorba Corse | LIGIER JS P3 - Nissan | Classified 148L gap 12 Laps | Roberto Lacorte / Giorgio Sernagiotto / Nicollo Schiro
 29 g21 #5 By Speed Factory | LIGIER JS P3 - Nissan | Classified 147L gap 13 Laps | Tom Jackson / Alain Costa
 30 g13 #3 United Autosports | LIGIER JS P3 - Nissan | Classified 146L gap 14 Laps | Mark Patterson / Matthew Bell / Wayne Boyd
 31 g29 #15 RLR MSport | LIGIER JS P3 - Nissan | Classified 146L gap 14 Laps | Morten Dons / Ross Warburton / John Hartshorne
 33 g32 #4 Oak Racing | LIGIER JS P3 - Nissan | Classified 140L gap 20 Laps | Jean-Marc Merlin / Erik Maris
 35 g16 #11 Eurointernational | LIGIER JS P3 - Nissan | NC 105L gap NC | Giorgio Mondini / Marco Jacoboni
 37 g15 #17 Ultimate | LIGIER JS P3 - Nissan | NC 87L gap NC | Matthieu Lahaye / François Heriau / Jean Baptiste Lahaye
 38 g24 #13 Inter Europol Competition | LIGIER JS P3 - Nissan | NC 42L gap NC | Jakub Smiechowski / Jens Petersen
== LMGTE
 13 g27 #66 JMW Motorsport | Ferrari F458 Italia | Classified 151L gap 9 Laps | Robert Smith / Rory Butcher / Andrea Bertolini
 17 g33 #51 AF Corse | Ferrari F458 Italia | Classified 150L gap 10 Laps | Piergiuseppe Perazzini / Marco Cioci / Rui Aguas
 18 g28 #56 AT Racing | Ferrari F458 Italia | Classified 150L gap 10 Laps | Alexander Talkanitsa / Alexander Talka Jr / Alessandro Pier Guidi
 21 g35 #99 Aston Martin Racing | Aston Martin V8 Vantage | Classified 150L gap 10 Laps | Andrew Howard / Darren Turner / Alex Macdowall
 22 g26 #88 Proton Competition | Porsche 911 RSR 991 | Classified 150L gap 10 Laps | Gianluca Roda / Christian Ried / Matteo Cairoli
 23 g37 #77 Proton Competition | Porsche 911 RSR 991 | Classified 149L gap 11 Laps | Michael Hedlund / Wolf Henzler / Marco Seefried
 24 g38 #60 Formula Racing | Ferrari F458 Italia | Classified 149L gap 11 Laps | Johnny Laursen / Mikkel Mac / Christina Nielsen
 25 g34 #55 AF Corse | Ferrari F458 Italia | Classified 149L gap 11 Laps | Duncan Cameron / Matt Griffin / Aaron Scott
