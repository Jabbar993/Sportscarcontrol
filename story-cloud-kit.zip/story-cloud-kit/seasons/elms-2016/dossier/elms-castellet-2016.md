# elms-castellet-2016

Event: 4 Hours of Le Castellet | Circuit: Paul Ricard | Date: 2016-08-28
Scheduled: 04:00:00 | Official duration: 4:00:58.207 | Laps (winner): 124

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q28 #99 [LMGTE] 1:56.285 Aston Martin Racing | Darren Turner
Q30 #56 [LMGTE] 1:56.483 AT Racing | Alessandro Pier Guidi
Q31 #55 [LMGTE] 1:56.545 AF Corse | Matt Griffin
Q32 #66 [LMGTE] 1:56.630 JMW Motorsport | Andrea Bertolini
Q34 #51 [LMGTE] 1:57.285 AF Corse | Marco Cioci
Q35 #60 [LMGTE] 1:57.290 Formula Racing | Mikkel Mac
Q36 #77 [LMGTE] 1:57.325 Proton Competition | Wolf Henzler
Q1 #46 [LMP2] 1:47.033 Thiriet by TDS Racing | Mathias Beche
Q2 #21 [LMP2] 1:47.514 DragonSpeed | Nicolas Lapierre
Q3 #41 [LMP2] 1:48.420 Greaves Motorsport | Nathanaël Berthon
Q4 #32 [LMP2] 1:48.596 SMP Racing | Stefano Coletti
Q5 #25 [LMP2] 1:48.684 Algarve Pro Racing | Andrea Pizzitola
Q6 #48 [LMP2] 1:48.956 Murphy Prototypes | Kevin Ceccon
Q7 #28 [LMP2] 1:48.961 Idec Sport Racing | Dimitri Enjalbert
Q8 #33 [LMP2] 1:49.044 Eurasia Motorsport | Tristan Gommendy
Q9 #38 [LMP2] 1:49.207 G-Drive Racing | Giedo van der Garde
Q10 #23 [LMP2] 1:49.492 Panis Barthez Competition | Paul Loup Chatin
Q11 #29 [LMP2] 1:51.164 Pegasus Racing | Léo Roussel
Q12 #40 [LMP2] 1:52.690 Krohn Racing | Tracy Krohn
Q13 #26 [LMP3] 1:54.006 Tockwith Motorsports | Nigel Moore
Q14 #9 [LMP3] 1:54.796 Graff | Enzo Guibbert
Q15 #16 [LMP3] 1:54.817 Panis Barthez Competition | Simon Gachet
Q16 #2 [LMP3] 1:55.238 United Autosports | Alex Brundle
Q17 #6 [LMP3] 1:55.322 360 Racing | Ross Kaiser
Q18 #18 [LMP3] 1:55.395 M.Racing - YMR | Alexandre Cougnaud
Q19 #10 [LMP3] 1:55.425 Graff | Sean Rayhall
Q20 #19 [LMP3] 1:55.431 Duqueine Engineering | Dino Lunardi
Q21 #11 [LMP3] 1:55.510 Eurointernational | Giorgio Mondini
Q22 #17 [LMP3] 1:55.514 Ultimate | Jean Baptiste Lahaye
Q23 #15 [LMP3] 1:55.574 RLR MSport | Morten Dons
Q24 #12 [LMP3] 1:55.662 Eurointernational | Rik Breukers
Q25 #7 [LMP3] 1:56.042 Villorba Corse | Giorgio Sernagiotto
Q26 #5 [LMP3] 1:56.119 By Speed Factory | Tom Jackson
Q27 #20 [LMP3] 1:56.122 Duqueine Engineering | Antonin Borga
Q29 #24 [LMP3] 1:56.312 Oak Racing | Jacques Nicolet
Q33 #13 [LMP3] 1:57.247 Inter Europol Competition | Jakub Smiechowski
Q37 #8 [LMP3] 1:57.726 RACE Performance | Marcello Marateotto
Q38 #4 [LMP3] 1:58.419 Oak Racing | Jean-Marc Merlin

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #46 Mathias Beche 1:47.033 Thiriet by TDS Racing
LMGTE: #99 Darren Turner 1:56.285 Aston Martin Racing
LMP2: #46 Mathias Beche 1:47.033 Thiriet by TDS Racing
LMP3: #26 Nigel Moore 1:54.006 Tockwith Motorsports

## Fastest laps (archive)
Overall: #46 Mike Conway 1:49.548
LMGTE: #56 Alessandro Pier Guidi 1:58.676
LMP2: #46 Mike Conway 1:49.548
LMP3: #26 Nigel Moore 1:55.151

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g1 #46 Thiriet by TDS Racing | Oreca 05 - Nissan | Classified 124L gap — | Pierre Thiriet / Mathias Beche / Mike Conway
 2 g4 #32 SMP Racing | BR 01- Nissan | Classified 123L gap 1 Laps | Stefano Coletti / Julian Leal / Andreas Wirth
 3 g2 #21 DragonSpeed | Oreca 05 - Nissan | Classified 123L gap 1 Laps | Henrik Hedman / Nicolas Lapierre / Ben Hanley
 4 g8 #33 Eurasia Motorsport | Oreca 05 - Nissan | Classified 123L gap 1 Laps | Nico Pieter de Bruijn / Tristan Gommendy
 5 g9 #38 G-Drive Racing | Gibson 015S - Nissan | Classified 123L gap 1 Laps | Simon Dolan / Harry Tincknell / Giedo van der Garde
 6 g3 #41 Greaves Motorsport | LIGIER JS P2 - Nissan | Classified 123L gap 1 Laps | Memo Rojas / Julien Canal / Nathanaël Berthon
 7 g5 #25 Algarve Pro Racing | LIGIER JS P2 - Nissan | Classified 121L gap 3 Laps | Andrea Roda / Jonathan Hirschi / Andrea Pizzitola
 8 g12 #40 Krohn Racing | LIGIER JS P2 - Nissan | Classified 121L gap 3 Laps | Tracy Krohn / Niclas Jönsson / Olivier Pla
 9 g6 #48 Murphy Prototypes | Oreca 03R - Nissan | Classified 121L gap 3 Laps | Sean Doyle / Jonathan Coleman / Kevin Ceccon
 10 g7 #28 Idec Sport Racing | LIGIER JS P2 - Judd | Classified 121L gap 3 Laps | Paul Lafargue / Patrice Lafargue / Dimitri Enjalbert
 11 g10 #23 Panis Barthez Competition | LIGIER JS P2 - Nissan | Classified 120L gap 4 Laps | Fabien Barthez / Timothe Buret / Paul Loup Chatin
 17 g11 #29 Pegasus Racing | Morgan - Nissan | Classified 116L gap 8 Laps | Inès Taittinger / Rémy Striebig / Léo Roussel
== LMP3
 12 g14 #9 Graff | LIGIER JS P3 - Nissan | Classified 117L gap 7 Laps | Eric Trouillet / Paul Petit / Enzo Guibbert
 13 g20 #19 Duqueine Engineering | LIGIER JS P3 - Nissan | Classified 117L gap 7 Laps | David Hallyday / Dino Lunardi / David Droux
 14 g16 #2 United Autosports | LIGIER JS P3 - Nissan | Classified 117L gap 7 Laps | Alex Brundle / Michael Guasch / Christian England
 15 g22 #17 Ultimate | LIGIER JS P3 - Nissan | Classified 116L gap 8 Laps | Jean Baptiste Lahaye / François Heriau / Matthieu Lahaye
 16 g17 #6 360 Racing | LIGIER JS P3 - Nissan | Classified 116L gap 8 Laps | Terrence Woodward / Ross Kaiser / James Swift
 18 g13 #26 Tockwith Motorsports | LIGIER JS P3 - Nissan | Classified 116L gap 8 Laps | Nigel Moore / Phil Hanson
 19 g33 #13 Inter Europol Competition | LIGIER JS P3 - Nissan | Classified 116L gap 8 Laps | Jakub Smiechowski / Jens Petersen
 24 g15 #16 Panis Barthez Competition | LIGIER JS P3 - Nissan | Classified 115L gap 9 Laps | Eric Debard / Valentin Moineault / Simon Gachet
 25 g24 #12 Eurointernational | LIGIER JS P3 - Nissan | Classified 115L gap 9 Laps | Andrea Dromedari / Rik Breukers
 26 g25 #7 Villorba Corse | LIGIER JS P3 - Nissan | Classified 115L gap 9 Laps | Roberto Lacorte / Giorgio Sernagiotto
 29 g39 #3 United Autosports | LIGIER JS P3 - Nissan | Classified 114L gap 10 Laps | Mark Patterson / Matthew Bell / Wayne Boyd
 30 g38 #4 Oak Racing | LIGIER JS P3 - Nissan | Classified 113L gap 11 Laps | Jean-Marc Merlin / Erik Maris
 31 g27 #20 Duqueine Engineering | LIGIER JS P3 - Nissan | Classified 112L gap 12 Laps | Maxime Pialat / Eric Clement / Antonin Borga
 32 g26 #5 By Speed Factory | LIGIER JS P3 - Nissan | Classified 111L gap 13 Laps | Tom Jackson / Alain Costa / John Hartshorne
 33 g29 #24 Oak Racing | LIGIER JS P3 - Nissan | Classified 105L gap 19 Laps | Jacques Nicolet / Pierre Nicolet
 34 g19 #10 Graff | LIGIER JS P3 - Nissan | NC 115L gap NC | John Falb / Sean Rayhall / Vicente Potolicchio
 36 g21 #11 Eurointernational | LIGIER JS P3 - Nissan | NC 66L gap NC | Giorgio Mondini / Marco Jacoboni
 37 g37 #8 RACE Performance | LIGIER JS P3 - Nissan | NC 50L gap NC | Marcello Marateotto / Giorgio Maggi / Bert Longin
 38 g23 #15 RLR MSport | LIGIER JS P3 - Nissan | NC 46L gap NC | Morten Dons / Ross Warburton / Anthony Wells
 39 g18 #18 M.Racing - YMR | LIGIER JS P3 - Nissan | NC 36L gap NC | Thomas Laurent / Yann Ehrlacher / Alexandre Cougnaud
== LMGTE
 20 g32 #66 JMW Motorsport | Ferrari F458 Italia | Classified 115L gap 9 Laps | Robert Smith / Rory Butcher / Andrea Bertolini
 21 g35 #60 Formula Racing | Ferrari F458 Italia | Classified 115L gap 9 Laps | Johnny Laursen / Mikkel Mac / Mikkel Jensen
 22 g28 #99 Aston Martin Racing | Aston Martin V8 Vantage | Classified 115L gap 9 Laps | Andrew Howard / Darren Turner / Alex Macdowall
 23 g30 #56 AT Racing | Ferrari F458 Italia | Classified 115L gap 9 Laps | Alexander Talkanitsa / Alexander Talka Jr / Alessandro Pier Guidi
 27 g31 #55 AF Corse | Ferrari F458 Italia | Classified 115L gap 9 Laps | Duncan Cameron / Matt Griffin / Aaron Scott
 28 g36 #77 Proton Competition | Porsche 911 RSR 991 | Classified 115L gap 9 Laps | Michael Hedlund / Wolf Henzler / Marco Seefried
 35 g34 #51 AF Corse | Ferrari F458 Italia | NC 74L gap NC | Piergiuseppe Perazzini / Marco Cioci / Rui Aguas
 40 g40 #88 Proton Competition | Porsche 911 RSR 991 | NC 0L gap NC | Gianluca Roda / Christian Ried / David Jahn
