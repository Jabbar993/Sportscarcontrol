# elms-imola-2016

Event: 4 Hours of Imola | Circuit: Imola | Date: 2016-05-15
Scheduled: 04:00:00 | Official duration: 4:01:13.223 | Laps (winner): 121

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q30 #77 [LMGTE] 1:41.269 Proton Competition | Wolf Henzler
Q31 #66 [LMGTE] 1:41.310 JMW Motorsport | Andrea Bertolini
Q32 #88 [LMGTE] 1:41.397 Proton Competition | Klaus Bachler
Q33 #56 [LMGTE] 1:41.517 AT Racing | Davide Rigon
Q36 #55 [LMGTE] 1:41.736 AF Corse | Matt Griffin
Q37 #51 [LMGTE] 1:41.776 AF Corse | Marco Cioci
Q41 #99 [LMGTE] 1:44.944 Aston Martin Racing | Andrew Howard
Q1 #21 [LMP2] 1:33.780 DragonSpeed | Nicolas Lapierre
Q2 #46 [LMP2] 1:33.815 Thiriet by TDS Racing | Mathias Beche
Q3 #23 [LMP2] 1:33.815 Panis Barthez Competition | Paul Loup Chatin
Q4 #40 [LMP2] 1:33.824 Krohn Racing | Olivier Pla
Q5 #38 [LMP2] 1:34.024 G-Drive Racing | Giedo van der Garde
Q6 #33 [LMP2] 1:34.070 Eurasia Motorsport | Tristan Gommendy
Q7 #41 [LMP2] 1:34.136 Greaves Motorsport | Jakub Giermaziak
Q8 #22 [LMP2] 1:34.682 SO24 ! BY LOMBARD RACING | Olivier Lombard
Q9 #29 [LMP2] 1:35.014 Pegasus Racing | Léo Roussel
Q10 #25 [LMP2] 1:35.068 Algarve Pro Racing | Parth Ghorpade
Q11 #48 [LMP2] 1:35.151 Murphy Prototypes | Garry Findlay
Q12 #32 [LMP2] 1:35.492 SMP Racing | Stefano Coletti
Q13 #28 [LMP2] 1:35.854 Idec Sport Racing | Dimitri Enjalbert
Q14 #34 [LMP2] 1:35.954 RACE Performance | James Winslow
Q15 #3 [LMP3] 1:39.256 United Autosports | Wayne Boyd
Q16 #11 [LMP3] 1:39.401 Eurointernational | Giorgio Mondini
Q17 #2 [LMP3] 1:39.623 United Autosports | Alex Brundle
Q18 #10 [LMP3] 1:39.934 Graff | Sean Rayhall
Q19 #19 [LMP3] 1:40.049 Duqueine Engineering | Dino Lunardi
Q20 #17 [LMP3] 1:40.303 Ultimate | Matthieu Lahaye
Q21 #16 [LMP3] 1:40.333 Panis Barthez Competition | Simon Gachet
Q22 #12 [LMP3] 1:40.444 Eurointernational | Roman Rusinov
Q23 #7 [LMP3] 1:40.484 Villorba Corse | Nicollo Schiro
Q24 #9 [LMP3] 1:40.594 Graff | Enzo Guibbert
Q25 #6 [LMP3] 1:40.643 360 Racing | Ross Kaiser
Q26 #5 [LMP3] 1:40.821 By Speed Factory | Tom Jackson
Q27 #18 [LMP3] 1:40.895 M.Racing - YMR | Yann Ehrlacher
Q28 #24 [LMP3] 1:41.062 Oak Racing | Jacques Nicolet
Q29 #8 [LMP3] 1:41.229 RACE Performance | Giorgio Maggi
Q34 #20 [LMP3] 1:41.522 Duqueine Engineering | Maxime Pialat
Q35 #13 [LMP3] 1:41.653 Inter Europol Competition | Jakub Smiechowski
Q38 #15 [LMP3] 1:42.158 RLR MSport | Morten Dons
Q39 #4 [LMP3] 1:43.178 Oak Racing | Jean-Marc Merlin
Q40 #14 [LMP3] 1:44.534 MurphyP3-3Dimensional.com | Alex Kapadia

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #21 Nicolas Lapierre 1:33.780 DragonSpeed
LMGTE: #77 Wolf Henzler 1:41.269 Proton Competition
LMP2: #21 Nicolas Lapierre 1:33.780 DragonSpeed
LMP3: #3 Wayne Boyd 1:39.256 United Autosports

## Fastest laps (archive)
Overall: #21 Nicolas Lapierre 1:34.799
LMGTE: #99 Darren Turner 1:41.876
LMP2: #21 Nicolas Lapierre 1:34.799
LMP3: #19 Dino Lunardi 1:40.019

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g2 #46 Thiriet by TDS Racing | Oreca 05 - Nissan | Classified 121L gap — | Pierre Thiriet / Mathias Beche / Ryo Hirakawa
 2 g5 #38 G-Drive Racing | Gibson 015S - Nissan | Classified 121L gap 19.257 | Simon Dolan / Harry Tincknell / Giedo van der Garde
 3 g1 #21 DragonSpeed | Oreca 05 - Nissan | Classified 121L gap 30.810 | Henrik Hedman / Nicolas Lapierre / Ben Hanley
 4 g12 #32 SMP Racing | BR 01- Nissan | Classified 121L gap 33.991 | Stefano Coletti / Julian Leal / Andreas Wirth
 5 g6 #33 Eurasia Motorsport | Oreca 05 - Nissan | Classified 121L gap 45.472 | Pu Junjin / Nico Pieter de Bruijn / Tristan Gommendy
 6 g4 #40 Krohn Racing | LIGIER JS P2 - Nissan | Classified 120L gap 1 Laps | Bjorn Wirdheim / Niclas Jönsson / Olivier Pla
 7 g3 #23 Panis Barthez Competition | LIGIER JS P2 - Nissan | Classified 120L gap 1 Laps | Fabien Barthez / Timothe Buret / Paul Loup Chatin
 8 g7 #41 Greaves Motorsport | LIGIER JS P2 - Nissan | Classified 118L gap 3 Laps | Memo Rojas / Julien Canal / Jakub Giermaziak
 9 g14 #34 RACE Performance | Oreca 03R - Judd | Classified 118L gap 3 Laps | Nicolas Leutwiler / James Winslow / Shinji Nakano
 10 g11 #48 Murphy Prototypes | Oreca 03R - Nissan | Classified 118L gap 3 Laps | Sean Doyle / Patrick Mcclughan / Garry Findlay
 11 g8 #22 SO24 ! BY LOMBARD RACING | LIGIER JS P2 - Judd | Classified 117L gap 4 Laps | Vincent Capillaire / Olivier Lombard / Jonathan Coleman
 12 g9 #29 Pegasus Racing | Morgan - Nissan | Classified 116L gap 5 Laps | Inès Taittinger / Rémy Striebig / Léo Roussel
 38 g10 #25 Algarve Pro Racing | LIGIER JS P2 - Nissan | NC 90L gap NC | Michael Munemann / Chris Hoy / Parth Ghorpade
 39 g13 #28 Idec Sport Racing | LIGIER JS P2 - Judd | NC 80L gap NC | Paul Lafargue / Patrice Lafargue / Dimitri Enjalbert
== LMGTE
 13 g30 #77 Proton Competition | Porsche 911 RSR 991 | Classified 116L gap 5 Laps | Michael Hedlund / Wolf Henzler / Robert Renauer
 16 g31 #66 JMW Motorsport | Ferrari F458 Italia | Classified 115L gap 6 Laps | Robert Smith / Rory Butcher / Andrea Bertolini
 22 g33 #56 AT Racing | Ferrari F458 Italia | Classified 114L gap 7 Laps | Alexander Talkanitsa / Alexander Talka Jr / Davide Rigon
 23 g32 #88 Proton Competition | Porsche 911 RSR 991 | Classified 114L gap 7 Laps | Gianluca Roda / Klaus Bachler / Christian Ried
 24 g? #99 Aston Martin Racing | Aston Martin V8 Vantage | Classified 114L gap 7 Laps | Andrew Howard / Darren Turner / Alex Macdowall
 26 g36 #55 AF Corse | Ferrari F458 Italia | Classified 114L gap 7 Laps | Duncan Cameron / Matt Griffin / Aaron Scott
 28 g37 #51 AF Corse | Ferrari F458 Italia | Classified 113L gap 8 Laps | Piergiuseppe Perazzini / Marco Cioci / Rui Aguas
== LMP3
 14 g17 #2 United Autosports | LIGIER JS P3 - Nissan | Classified 115L gap 6 Laps | Alex Brundle / Michael Guasch / Christian England
 15 g16 #11 Eurointernational | LIGIER JS P3 - Nissan | Classified 115L gap 6 Laps | Giorgio Mondini / Andrea Roda / Marco Jacoboni
 17 g21 #16 Panis Barthez Competition | LIGIER JS P3 - Nissan | Classified 115L gap 6 Laps | Eric Debard / Valentin Moineault / Simon Gachet
 18 g19 #19 Duqueine Engineering | LIGIER JS P3 - Nissan | Classified 115L gap 6 Laps | David Hallyday / Dino Lunardi / David Droux
 19 g27 #18 M.Racing - YMR | LIGIER JS P3 - Nissan | Classified 115L gap 6 Laps | Thomas Laurent / Yann Ehrlacher / Alexandre Cougnaud
 20 g38 #15 RLR MSport | LIGIER JS P3 - Nissan | Classified 114L gap 7 Laps | Morten Dons / Ossy Yusuf
 21 g15 #3 United Autosports | LIGIER JS P3 - Nissan | Classified 114L gap 7 Laps | Mark Patterson / Matthew Bell / Wayne Boyd
 25 g22 #12 Eurointernational | LIGIER JS P3 - Nissan | Classified 114L gap 7 Laps | Andrea Dromedari / Fabio Mancini / Roman Rusinov
 27 g25 #6 360 Racing | LIGIER JS P3 - Nissan | Classified 114L gap 7 Laps | Terrence Woodward / Ross Kaiser / James Swift
 29 g20 #17 Ultimate | LIGIER JS P3 - Nissan | Classified 113L gap 8 Laps | Matthieu Lahaye / François Heriau / Jean Baptiste Lahaye
 30 g34 #20 Duqueine Engineering | LIGIER JS P3 - Nissan | Classified 113L gap 8 Laps | Romain Iannetta / Maxime Pialat / Eric Clement
 31 g40 #14 MurphyP3-3Dimensional.com | LIGIER JS P3 - Nissan | Classified 112L gap 9 Laps | Barrie Baxter / Alex Kapadia / Rob Garofall
 32 g29 #8 RACE Performance | LIGIER JS P3 - Nissan | Classified 110L gap 11 Laps | Marcello Marateotto / Giorgio Maggi / Bert Longin
 33 g39 #4 Oak Racing | LIGIER JS P3 - Nissan | Classified 109L gap 12 Laps | Jean-Marc Merlin / Erik Maris
 34 g35 #13 Inter Europol Competition | LIGIER JS P3 - Nissan | Classified 105L gap 16 Laps | Jakub Smiechowski / Jens Petersen
 35 g23 #7 Villorba Corse | LIGIER JS P3 - Nissan | Classified 103L gap 18 Laps | Roberto Lacorte / Giorgio Sernagiotto / Nicollo Schiro
 36 g28 #24 Oak Racing | LIGIER JS P3 - Nissan | Classified 94L gap 27 Laps | Jacques Nicolet / Pierre Nicolet
 37 g18 #10 Graff | LIGIER JS P3 - Nissan | NC 93L gap NC | John Falb / Sean Rayhall / Vicente Potolicchio
 40 g26 #5 By Speed Factory | LIGIER JS P3 - Nissan | NC 67L gap NC | Tom Jackson / Alvaro Fontes / Jesus Fuster
 41 g24 #9 Graff | LIGIER JS P3 - Nissan | DSQ 111L gap DSQ | Eric Trouillet / Paul Petit / Enzo Guibbert
