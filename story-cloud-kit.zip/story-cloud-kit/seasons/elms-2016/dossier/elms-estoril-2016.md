# elms-estoril-2016

Event: 4 Hours of Estoril | Circuit: Estoril | Date: 2016-10-23
Scheduled: 04:00:00 | Official duration: 4:01:32.368 | Laps (winner): 145

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q27 #88 [LMGTE] 1:54.754 Proton Competition | Benjamin Barker
Q28 #56 [LMGTE] 1:55.091 AT Racing | Alessandro Pier Guidi
Q31 #51 [LMGTE] 1:55.809 AF Corse | Marco Cioci
Q32 #55 [LMGTE] 1:55.975 AF Corse | Matt Griffin
Q33 #66 [LMGTE] 1:56.409 JMW Motorsport | Andrea Bertolini
Q34 #60 [LMGTE] 1:56.964 Formula Racing | Mikkel Mac
Q35 #77 [LMGTE] 1:57.130 Proton Competition | Wolf Henzler
Q36 #99 [LMGTE] 1:57.213 Aston Martin Racing | Darren Turner
Q1 #21 [LMP2] 1:44.146 DragonSpeed | Nicolas Lapierre
Q2 #23 [LMP2] 1:44.553 Panis Barthez Competition | Paul Loup Chatin
Q3 #38 [LMP2] 1:44.758 G-Drive Racing | Giedo van der Garde
Q4 #40 [LMP2] 1:45.237 Krohn Racing | Olivier Pla
Q5 #32 [LMP2] 1:45.857 SMP Racing | Vitaly Petrov
Q6 #28 [LMP2] 1:46.352 Idec Sport Racing | Dimitri Enjalbert
Q7 #46 [LMP2] 1:47.125 Thiriet by TDS Racing | Mathias Beche
Q8 #29 [LMP2] 1:47.382 Pegasus Racing | Léo Roussel
Q9 #41 [LMP2] 1:50.056 Greaves Motorsport | Julien Canal
Q20 #33 [LMP2] 1:53.138 Eurasia Motorsport | Tristan Gommendy
Q10 #2 [LMP3] 1:50.355 United Autosports | Alex Brundle
Q11 #3 [LMP3] 1:50.541 United Autosports | Wayne Boyd
Q12 #19 [LMP3] 1:51.045 Duqueine Engineering | Dino Lunardi
Q13 #20 [LMP3] 1:51.112 Duqueine Engineering | Antonin Borga
Q14 #16 [LMP3] 1:51.318 Panis Barthez Competition | Simon Gachet
Q15 #7 [LMP3] 1:51.487 Villorba Corse | Giorgio Sernagiotto
Q16 #15 [LMP3] 1:51.982 RLR MSport | Morten Dons
Q17 #9 [LMP3] 1:52.309 Graff | Enzo Guibbert
Q18 #18 [LMP3] 1:52.664 M.Racing - YMR | Alexandre Cougnaud
Q19 #6 [LMP3] 1:52.778 360 Racing | Ross Kaiser
Q21 #8 [LMP3] 1:53.179 RACE Performance | Bert Longin
Q22 #17 [LMP3] 1:53.205 Ultimate | Jean Baptiste Lahaye
Q23 #12 [LMP3] 1:53.313 Eurointernational | Rik Breukers
Q24 #10 [LMP3] 1:53.507 Graff | Vicente Potolicchio
Q25 #13 [LMP3] 1:53.692 Inter Europol Competition | Jakub Smiechowski
Q26 #24 [LMP3] 1:53.829 Oak Racing | Jacques Nicolet
Q29 #4 [LMP3] 1:55.103 Oak Racing | Erik Maris
Q30 #11 [LMP3] 1:55.747 Eurointernational | Giorgio Mondini

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #21 Nicolas Lapierre 1:44.146 DragonSpeed
LMGTE: #88 Benjamin Barker 1:54.754 Proton Competition
LMP2: #21 Nicolas Lapierre 1:44.146 DragonSpeed
LMP3: #2 Alex Brundle 1:50.355 United Autosports

## Fastest laps (archive)
Overall: #21 Nicolas Lapierre 1:32.898
LMGTE: #56 Alessandro Pier Guidi 1:40.476
LMP2: #21 Nicolas Lapierre 1:32.898
LMP3: #2 Alex Brundle 1:37.519

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g3 #38 G-Drive Racing | Gibson 015S - Nissan | Classified 145L gap — | Simon Dolan / Harry Tincknell / Giedo van der Garde
 2 g1 #21 DragonSpeed | Oreca 05 - Nissan | Classified 145L gap 51.157 | Henrik Hedman / Nicolas Lapierre / Ben Hanley
 3 g5 #32 SMP Racing | BR 01- Nissan | Classified 145L gap 29.746 | Stefano Coletti / Andreas Wirth / Vitaly Petrov
 4 g4 #40 Krohn Racing | LIGIER JS P2 - Nissan | Classified 145L gap 8.058 | Niclas Jönsson / Olivier Pla
 5 g20 #33 Eurasia Motorsport | Oreca 05 - Nissan | Classified 143L gap 2 Laps | Tristan Gommendy / Frédéric Vervisch / Michael Lyons
 6 g6 #28 Idec Sport Racing | LIGIER JS P2 - Judd | Classified 141L gap 4 Laps | Paul Lafargue / Patrice Lafargue / Dimitri Enjalbert
 8 g2 #23 Panis Barthez Competition | LIGIER JS P2 - Nissan | Classified 139L gap 6 Laps | Fabien Barthez / Timothé Buret / Paul Loup Chatin
 28 g7 #46 Thiriet by TDS Racing | Oreca 05 - Nissan | Classified 121L gap 24 Laps | Pierre Thiriet / Mathias Beche / Ryo Hirakawa
 31 g9 #41 Greaves Motorsport | LIGIER JS P2 - Nissan | NC 87L gap NC | Memo Rojas / Julien Canal / Nathanaël Berthon
 36 g8 #29 Pegasus Racing | Morgan - Nissan | DSQ 139L gap DSQ | Inès Taittinger / Léo Roussel / Julien Schell
== LMP3
 7 g18 #18 M.Racing - YMR | LIGIER JS P3 - Nissan | Classified 140L gap 5 Laps | Thomas Laurent / Yann Ehrlacher / Alexandre Cougnaud
 9 g11 #3 United Autosports | LIGIER JS P3 - Nissan | Classified 138L gap 7 Laps | Mark Patterson / Matthew Bell / Wayne Boyd
 10 g17 #9 Graff | LIGIER JS P3 - Nissan | Classified 138L gap 7 Laps | Eric Trouillet / Paul Petit / Enzo Guibbert
 11 g24 #10 Graff | LIGIER JS P3 - Nissan | Classified 137L gap 8 Laps | John Falb / Sean Rayhall / Vicente Potolicchio
 12 g25 #13 Inter Europol Competition | LIGIER JS P3 - Nissan | Classified 137L gap 8 Laps | Jakub Smiechowski / Jens Petersen
 13 g23 #12 Eurointernational | LIGIER JS P3 - Nissan | Classified 137L gap 8 Laps | Rik Breukers / Andrea Dromedari / Miguel Faisca
 14 g21 #8 RACE Performance | LIGIER JS P3 - Nissan | Classified 137L gap 8 Laps | Nicolas Leutwiler / Giorgio Maggi / Bert Longin
 15 g15 #7 Villorba Corse | LIGIER JS P3 - Nissan | Classified 137L gap 8 Laps | Roberto Lacorte / Giorgio Sernagiotto
 16 g12 #19 Duqueine Engineering | LIGIER JS P3 - Nissan | Classified 136L gap 9 Laps | David Hallyday / Dino Lunardi / David Droux
 17 g16 #15 RLR MSport | LIGIER JS P3 - Nissan | Classified 136L gap 9 Laps | Morten Dons / Anthony Wells / Alisdair Mccaig
 20 g10 #2 United Autosports | LIGIER JS P3 - Nissan | Classified 135L gap 10 Laps | Alex Brundle / Michael Guasch / Christian England
 23 g29 #4 Oak Racing | LIGIER JS P3 - Nissan | Classified 132L gap 13 Laps | Jean-Marc Merlin / Erik Maris
 24 g26 #24 Oak Racing | LIGIER JS P3 - Nissan | Classified 131L gap 14 Laps | Jacques Nicolet / Pierre Nicolet
 26 g22 #17 Ultimate | LIGIER JS P3 - Nissan | Classified 129L gap 16 Laps | Jean Baptiste Lahaye / François Heriau / Matthieu Lahaye
 29 g13 #20 Duqueine Engineering | LIGIER JS P3 - Nissan | NC 130L gap NC | Maxime Pialat / Eric Clement / Antonin Borga
 30 g14 #16 Panis Barthez Competition | LIGIER JS P3 - Nissan | NC 106L gap NC | Eric Debard / Valentin Moineault / Simon Gachet
 32 g30 #11 Eurointernational | LIGIER JS P3 - Nissan | NC 84L gap NC | Giorgio Mondini / Jay Palmer
 33 g19 #6 360 Racing | LIGIER JS P3 - Nissan | NC 82L gap NC | Terrence Woodward / Ross Kaiser / James Swift
== LMGTE
 18 g36 #99 Aston Martin Racing | Aston Martin V8 Vantage | Classified 136L gap 9 Laps | Andrew Howard / Darren Turner / Alex Macdowall
 19 g28 #56 AT Racing | Ferrari F458 Italia | Classified 135L gap 10 Laps | Alexander Talkanitsa / Alexander Talka Jr / Alessandro Pier Guidi
 21 g32 #55 AF Corse | Ferrari F458 Italia | Classified 135L gap 10 Laps | Duncan Cameron / Matt Griffin / Aaron Scott
 22 g31 #51 AF Corse | Ferrari F458 Italia | Classified 135L gap 10 Laps | Piergiuseppe Perazzini / Marco Cioci / Rui Aguas
 25 g27 #88 Proton Competition | Porsche 911 RSR 991 | Classified 131L gap 14 Laps | Gianluca Roda / Christian Ried / Benjamin Barker
 27 g35 #77 Proton Competition | Porsche 911 RSR 991 | Classified 125L gap 20 Laps | Michael Hedlund / Wolf Henzler / Marco Seefried
 34 g33 #66 JMW Motorsport | Ferrari F458 Italia | NC 45L gap NC | Robert Smith / Rory Butcher / Andrea Bertolini
 35 g34 #60 Formula Racing | Ferrari F458 Italia | NC 0L gap NC | Johnny Laursen / Mikkel Mac / Christina Nielsen
