# elms-estoril-2014

Event: 4 Hours of Estoril | Circuit: Estoril | Date: 2014-10-19
Scheduled: 04:00:00 | Official duration: 4:00:27.461 | Laps (winner): 146

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q19 #71 [GTC] 1:38.783 SMP Racing | Luca Persiani
Q20 #98 [GTC] 1:38.874 ART Grand Prix | Kevin Korjus
Q21 #75 [GTC] 1:38.996 Prospeed Competition | Maxime Soulet
Q24 #87 [GTC] 1:39.134 BMW Sport Trophy Marc VDS | Bas Leinders
Q25 #60 [GTC] 1:39.198 Formula Racing | Mikkel Mac
Q26 #99 [GTC] 1:39.245 ART Grand Prix | Alex Brundle
Q27 #92 [GTC] 1:39.266 Ombra Racing | Andrea Montermini
Q28 #73 [GTC] 1:39.495 SMP Racing | Olivier Beretta
Q29 #78 [GTC] 1:39.520 Team Russia by Barwell | Jonathan Cocker
Q30 #59 [GTC] 1:39.919 Team Sofrev-ASP | Jean-Philippe Belloc
Q31 #95 [GTC] 1:40.775 AF Corse | Adrien de Leener
Q32 #63 [GTC] 1:42.119 AF Corse | Filipe Barreiros
Q34 #57 [GTC] 1:49.414 SMP Racing | Boris Rotenberg
Q11 #85 [LMGTE] 1:37.269 Gulf Racing UK | Stuart Hall
Q12 #66 [LMGTE] 1:37.365 JMW Motorsport | Daniel Zampieri
Q13 #55 [LMGTE] 1:37.416 AF Corse | Matt Griffin
Q14 #72 [LMGTE] 1:37.511 SMP Racing | Andrea Bertolini
Q15 #86 [LMGTE] 1:37.988 Gulf Racing UK | Adam Carroll
Q16 #56 [LMGTE] 1:38.080 AT Racing | Pierre Kaffer
Q17 #58 [LMGTE] 1:38.352 Team Sofrev-ASP | Soheil Ayari
Q18 #54 [LMGTE] 1:38.604 AF Corse | Marco Cioci
Q22 #80 [LMGTE] 1:39.031 Kessel Racing | Giacomo Piccini
Q23 #76 [LMGTE] 1:39.069 IMSA Performance Matmut | Nicolas Armindo
Q33 #67 [LMGTE] 1:46.635 IMSA Performance Matmut | Erik Maris
Q1 #38 [LMP2] 1:29.497 Jota Sport | Harry Tincknell
Q2 #46 [LMP2] 1:30.210 Thiriet by TDS Racing | Tristan Gommendy
Q3 #36 [LMP2] 1:30.808 Signatech Alpine | Nelson Panciatici
Q4 #48 [LMP2] 1:31.054 Murphy Prototypes | Pipo Derani
Q5 #43 [LMP2] 1:31.215 Newblood By Morand Racing | Christian Klien
Q6 #24 [LMP2] 1:31.222 Sebastien Loeb Racing | Jimmy Eriksson
Q7 #28 [LMP2] 1:31.235 Greaves Motorsport | Mark Shulzhitskiy
Q8 #34 [LMP2] 1:31.780 RACE Performance | Franck Mailleux
Q9 #29 [LMP2] 1:32.247 Pegasus Racing | Julien Schell
Q10 #41 [LMP2] 1:32.635 Greaves Motorsport | Matthew Mcmurry

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #38 Harry Tincknell 1:29.497 Jota Sport
GTC: #71 Luca Persiani 1:38.783 SMP Racing
LMGTE: #85 Stuart Hall 1:37.269 Gulf Racing UK
LMP2: #38 Harry Tincknell 1:29.497 Jota Sport

## Fastest laps (archive)
Overall: #48 Pipo Derani 1:32.854
GTC: #71 Luca Persiani 1:40.145
LMGTE: #86 Benjamin Barker 1:39.370
LMP2: #48 Pipo Derani 1:32.854

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g? #24 Sebastien Loeb Racing | Oreca 03R - Nissan | Classified 146L gap — | Vincent Capillaire / Jimmy Eriksson
 2 g? #43 Newblood By Morand Racing | Morgan - Judd | Classified 146L gap 35.399 | Christian Klien / Gary Hirsch / Pierre Ragues
 3 g? #38 Jota Sport | Zytek Z11SN - Nissan | Classified 146L gap 43.713 | Simon Dolan / Harry Tincknell / Filipe Albuquerque
 4 g? #34 RACE Performance | Oreca 03 - Judd | Classified 145L gap 1 Laps | Michel Frey / Franck Mailleux / Patric Niederhauser
 5 g? #36 Signatech Alpine | Alpine A450b - Nissan | Classified 145L gap 1 Laps | Paul-Loup Chatin / Nelson Panciatici / Oliver Webb
 6 g? #48 Murphy Prototypes | Oreca 03R - Nissan | Classified 144L gap 2 Laps | Pipo Derani / James Littlejohn / Anthony Wells
 7 g? #41 Greaves Motorsport | Zytek Z11SN - Nissan | Classified 144L gap 2 Laps | Matthew Mcmurry / Miguel Faisca / James Fletcher
 8 g? #29 Pegasus Racing | Morgan - Nissan | Classified 141L gap 5 Laps | Julien Schell / Nicolas Leutwiler / Jonathan Coleman
 31 g? #28 Greaves Motorsport | Zytek Z11SN - Nissan | NC 135L gap NC | Luciano Bacheta / Mark Shulzhitskiy
 34 g? #46 Thiriet by TDS Racing | Ligier JS P2 - Nissan | NC 62L gap NC | Pierre Thiriet / Ludovic Badey / Tristan Gommendy
== LMGTE
 9 g? #72 SMP Racing | Ferrari F458 Italia | Classified 139L gap 7 Laps | Andrea Bertolini / Viktor Shaitar / Sergey Zlobin
 10 g? #54 AF Corse | Ferrari F458 Italia | Classified 138L gap 8 Laps | Piergiuseppe Perazzini / Marco Cioci / Michael Lyons
 11 g? #66 JMW Motorsport | Ferrari F458 Italia | Classified 138L gap 8 Laps | Daniel Mckenzie / George Richardson / Daniel Zampieri
 12 g? #86 Gulf Racing UK | Porsche 911 RSR | Classified 138L gap 8 Laps | Michael Wainwright / Adam Carroll / Benjamin Barker
 13 g? #85 Gulf Racing UK | Aston Martin Vantage V8 | Classified 138L gap 8 Laps | Roald Goethe / Stuart Hall / Daniel Brown
 14 g? #56 AT Racing | Ferrari F458 Italia | Classified 138L gap 8 Laps | Alexander Talkanitsa / Alexander Talkanitsa Jr / Pierre Kaffer
 17 g? #80 Kessel Racing | Ferrari F458 Italia | Classified 136L gap 10 Laps | Michael Broniszewski / Giacomo Piccini
 20 g? #70 AF Corse | Ferrari F458 Italia | Classified 136L gap 10 Laps | François Perrodo / Emmanuel Collard / Yannick Mallegol
 21 g? #76 IMSA Performance Matmut | Porsche 911 GT3 RSR | Classified 135L gap 11 Laps | Raymond Narac / Nicolas Armindo / Christina Nielsen
 25 g? #67 IMSA Performance Matmut | Porsche 911 GT3 RSR | Classified 133L gap 13 Laps | Erik Maris / Jean-Marc Merlin / Eric Helary
 30 g? #55 AF Corse | Ferrari F458 Italia | Classified 116L gap 30 Laps | Duncan Cameron / Matt Griffin / Michele Rugolo
 32 g? #58 Team Sofrev-ASP | Ferrari F458 Italia | NC 116L gap NC | Fabien Barthez / Anthony Pons / Soheil Ayari
== GTC
 15 g? #87 BMW Sport Trophy Marc VDS | BMW Z4 GT3 | Classified 137L gap 9 Laps | Bas Leinders / Markus Paltalla / Henry Hassid
 16 g? #60 Formula Racing | Ferrari F458 Italia GT3 | Classified 136L gap 10 Laps | Johnny Laursen / Mikkel Mac / Jan Magnussen
 18 g? #73 SMP Racing | Ferrari F458 Italia GT3 | Classified 136L gap 10 Laps | Olivier Beretta / David Markozov / Anton Ladygin
 19 g? #71 SMP Racing | Ferrari F458 Italia GT3 | Classified 136L gap 10 Laps | Kirill Ladygin / Aleksey Basov / Luca Persiani
 22 g? #98 ART Grand Prix | McLaren MP4 12C GT3 | Classified 134L gap 12 Laps | Kevin Korjus / Grégoire Demoustier / Yann Goudy
 23 g? #78 Team Russia by Barwell | BMW Z4 GT3 | Classified 134L gap 12 Laps | Leonid Machitski / Timur Sardarov / Jonathan Cocker
 24 g? #95 AF Corse | Ferrari F458 Italia GT3 | Classified 133L gap 13 Laps | Adrien de Leener / Cedric Sbirrazzuoli
 26 g? #63 AF Corse | Ferrari F458 Italia GT3 | Classified 132L gap 14 Laps | Mads Rasmussen / Filipe Barreiros / Francisco Guedes
 27 g? #92 Ombra Racing | Ferrari F458 Italia GT3 | Classified 131L gap 15 Laps | Mario Cordoni / Marco Zanuttini / Andrea Montermini
 28 g? #59 Team Sofrev-ASP | Ferrari F458 Italia GT3 | Classified 131L gap 15 Laps | Christophe Bourret / Pascal Gibon / Jean-Philippe Belloc
 29 g? #57 SMP Racing | Ferrari F458 Italia GT3 | Classified 127L gap 19 Laps | Boris Rotenberg / Mika Salo / Maurizio Mediani
 33 g? #75 Prospeed Competition | Porsche GT3 R | NC 91L gap NC | Max van Splunteren / Gilles Vannelet / Maxime Soulet
 35 g? #99 ART Grand Prix | McLaren MP4 12C GT3 | NC 23L gap NC | Ricardo Gonzalez / Karim Ajlani / Alex Brundle
