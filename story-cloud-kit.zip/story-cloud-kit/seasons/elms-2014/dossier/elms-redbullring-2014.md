# elms-redbullring-2014

Event: 4 Hours of Red Bull Ring | Circuit: Red Bull Ring | Date: 2014-07-20
Scheduled: 04:00:00 | Official duration: 4:00:16.248 | Laps (winner): 160

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q21 #60 [GTC] 1:30.647 Formula Racing | Jan Magnussen
Q23 #98 [GTC] 1:30.816 ART Grand Prix | Kevin Korjus
Q24 #95 [GTC] 1:30.963 AF Corse | Cedric Sbirrazzuoli
Q25 #73 [GTC] 1:30.965 SMP Racing | Olivier Beretta
Q26 #71 [GTC] 1:30.977 SMP Racing | Kirill Ladygin
Q27 #99 [GTC] 1:31.126 ART Grand Prix | Alex Brundle
Q28 #93 [GTC] 1:31.128 Pro GT by Almeras | Franck Perera
Q29 #75 [GTC] 1:31.717 Prospeed Competition | Mike Parisy
Q30 #78 [GTC] 1:32.050 Team Russia by Barwell | Jonathan Cocker
Q31 #63 [GTC] 1:32.456 AF Corse | Mads Rasmussen
Q32 #59 [GTC] 1:33.083 Team Sofrev-ASP | Jean Beaubelique
Q33 #57 [GTC] 1:35.952 SMP Racing | Boris Rotenberg
Q9 #72 [LMGTE] 1:29.286 SMP Racing | Andrea Bertolini
Q10 #77 [LMGTE] 1:29.499 Proton Competition | Richard Lietz
Q11 #85 [LMGTE] 1:29.887 Gulf Racing UK | Stuart Hall
Q12 #66 [LMGTE] 1:29.973 JMW Motorsport | Rob Bell
Q13 #56 [LMGTE] 1:29.991 AT Racing | Pierre Kaffer
Q14 #58 [LMGTE] 1:30.133 Team Sofrev-ASP | Soheil Ayari
Q15 #81 [LMGTE] 1:30.137 Kessel Racing | Matteo Cressoni
Q16 #67 [LMGTE] 1:30.154 IMSA Performance Matmut | Eric Helary
Q17 #54 [LMGTE] 1:30.342 AF Corse | Marco Cioci
Q18 #76 [LMGTE] 1:30.428 IMSA Performance Matmut | Nicolas Armindo
Q19 #70 [LMGTE] 1:30.499 AF Corse | Emmanuel Collard
Q20 #55 [LMGTE] 1:30.567 AF Corse | Matt Griffin
Q22 #86 [LMGTE] 1:30.685 Gulf Racing UK | Adam Carroll
Q1 #38 [LMP2] 1:23.078 Jota Sport | Harry Tincknell
Q2 #34 [LMP2] 1:23.561 RACE Performance | Franck Mailleux
Q3 #46 [LMP2] 1:23.613 Thiriet by TDS Racing | Tristan Gommendy
Q4 #43 [LMP2] 1:23.763 Newblood By Morand Racing | Christian Klien
Q5 #36 [LMP2] 1:23.785 Signatech Alpine | Nelson Panciatici
Q6 #41 [LMP2] 1:23.995 Greaves Motorsport | Tom Kimber-Smith
Q7 #28 [LMP2] 1:23.997 Greaves Motorsport | Luciano Bacheta
Q8 #29 [LMP2] 1:25.449 Pegasus Racing | Julien Schell

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #38 Harry Tincknell 1:23.078 Jota Sport
GTC: #60 Jan Magnussen 1:30.647 Formula Racing
LMGTE: #72 Andrea Bertolini 1:29.286 SMP Racing
LMP2: #38 Harry Tincknell 1:23.078 Jota Sport

## Fastest laps (archive)
Overall: #34 Franck Mailleux 1:24.969
GTC: #98 Kevin Korjus 1:31.775
LMGTE: #55 Michele Rugolo 1:30.260
LMP2: #34 Franck Mailleux 1:24.969

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g? #36 Signatech Alpine | Alpine A450b - Nissan | Classified 160L gap — | Paul-Loup Chatin / Nelson Panciatici / Oliver Webb
 2 g? #38 Jota Sport | Zytek Z11SN - Nissan | Classified 160L gap 12.385 | Simon Dolan / Harry Tincknell / Filipe Albuquerque
 3 g? #34 RACE Performance | Oreca 03 - Judd | Classified 160L gap 18.772 | Michel Frey / Franck Mailleux
 4 g? #28 Greaves Motorsport | Zytek Z11SN - Nissan | Classified 160L gap 51.412 | Luciano Bacheta / Mark Shulzhitskiy
 5 g? #43 Newblood By Morand Racing | Morgan - Judd | Classified 158L gap 2 Laps | Christian Klien / Gary Hirsch / Pierre Ragues
 6 g? #41 Greaves Motorsport | Zytek Z11SN - Nissan | Classified 158L gap 2 Laps | Tom Kimber-Smith / Matthew Mcmurry / Mark Patterson
 29 g? #29 Pegasus Racing | Morgan - Nissan | Classified 142L gap 18 Laps | Julien Schell / Nicolas Leutwiler / Jonathan Coleman
 32 g? #46 Thiriet by TDS Racing | Ligier JS P2 - Nissan | NC 40L gap NC | Pierre Thiriet / Ludovic Badey / Tristan Gommendy
== LMGTE
 7 g? #55 AF Corse | Ferrari F458 Italia | Classified 153L gap 7 Laps | Duncan Cameron / Matt Griffin / Michele Rugolo
 8 g? #81 Kessel Racing | Ferrari F458 Italia | Classified 153L gap 7 Laps | Thomas Kemenater / Matteo Cressoni
 9 g? #66 JMW Motorsport | Ferrari F458 Italia | Classified 153L gap 7 Laps | Daniel Mckenzie / George Richardson / Rob Bell
 10 g? #56 AT Racing | Ferrari F458 Italia | Classified 153L gap 7 Laps | Alexander Talkanitsa Jr / Alexander Talkanitsa / Pierre Kaffer
 11 g? #54 AF Corse | Ferrari F458 Italia | Classified 153L gap 7 Laps | Piergiuseppe Perazzini / Marco Cioci / Michael Lyons
 12 g? #72 SMP Racing | Ferrari F458 Italia | Classified 153L gap 7 Laps | Andrea Bertolini / Viktor Shaitar / Sergey Zlobin
 13 g? #85 Gulf Racing UK | Aston Martin Vantage V8 | Classified 152L gap 8 Laps | Roald Goethe / Stuart Hall / Daniel Brown
 14 g? #70 AF Corse | Ferrari F458 Italia | Classified 151L gap 9 Laps | Yannick Mallegol / François Perrodo / Emmanuel Collard
 18 g? #86 Gulf Racing UK | Porsche 911 GT3 RSR | Classified 149L gap 11 Laps | Michael Wainwright / Adam Carroll / Michael Meadows
 20 g? #58 Team Sofrev-ASP | Ferrari F458 Italia | Classified 149L gap 11 Laps | Fabien Barthez / Anthony Pons / Soheil Ayari
 21 g? #77 Proton Competition | Porsche 911 GT3 RSR | Classified 149L gap 11 Laps | Horst Felbermayr Sr / Horst Felbermayr Jr / Richard Lietz
 27 g? #67 IMSA Performance Matmut | Porsche 911 GT3 RSR | Classified 147L gap 13 Laps | Erik Maris / Jean-Marc Merlin / Eric Helary
 31 g? #76 IMSA Performance Matmut | Porsche 911 GT3 RSR | NC 107L gap NC | Raymond Narac / Nicolas Armindo / Christina Nielsen
== GTC
 15 g? #71 SMP Racing | Ferrari F458 Italia GT3 | Classified 151L gap 9 Laps | Kirill Ladygin / Aleksey Basov / Luca Persiani
 16 g? #73 SMP Racing | Ferrari F458 Italia GT3 | Classified 150L gap 10 Laps | Olivier Beretta / David Markozov / Anton Ladygin
 17 g? #95 AF Corse | Ferrari F458 Italia GT3 | Classified 150L gap 10 Laps | Adrien de Leener / Cedric Sbirrazzuoli
 19 g? #99 ART Grand Prix | McLaren MP4 12C GT3 | Classified 149L gap 11 Laps | Ricardo Gonzalez / Karim Ajlani / Alex Brundle
 22 g? #98 ART Grand Prix | McLaren MP4 12C GT3 | Classified 148L gap 12 Laps | Kevin Korjus / Grégoire Demoustier / Yann Goudy
 23 g? #93 Pro GT by Almeras | Porsche 997 GT3R | Classified 148L gap 12 Laps | Franck Perera / Matthieu Vaxivière / Henry Hassid
 24 g? #63 AF Corse | Ferrari F458 Italia GT3 | Classified 148L gap 12 Laps | Mads Rasmussen / Ilya Melnikov
 25 g? #75 Prospeed Competition | Porsche GT3 R | Classified 148L gap 12 Laps | Max van Splunteren / Gilles Vannelet / Mike Parisy
 26 g? #57 SMP Racing | Ferrari F458 Italia GT3 | Classified 147L gap 13 Laps | Boris Rotenberg / Mika Salo / Maurizio Mediani
 28 g? #59 Team Sofrev-ASP | Ferrari F458 Italia GT3 | Classified 146L gap 14 Laps | Christophe Bourret / Jean Beaubelique / Jean-Philippe Belloc
 30 g? #60 Formula Racing | Ferrari F458 Italia GT3 | Classified 125L gap 35 Laps | Johnny Laursen / Mikkel Mac / Jan Magnussen
 33 g? #78 Team Russia by Barwell | BMW Z4 GT3 | NC 0L gap NC | Leonid Machitski / Timur Sardarov / Jonathan Cocker
