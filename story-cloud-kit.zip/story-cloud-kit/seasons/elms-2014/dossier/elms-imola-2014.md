# elms-imola-2014

Event: 4 Hours of Imola | Circuit: Imola | Date: 2014-05-18
Scheduled: 04:00:00 | Official duration: 4:00:04.690 | Laps (winner): 139

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q19 #60 [GTC] 1:42.082 Formula Racing | Mikkel Mac
Q23 #95 [GTC] 1:42.379 AF Corse | Cedric Sbirrazzuoli
Q25 #71 [GTC] 1:42.691 SMP Racing | Luca Persiani
Q26 #98 [GTC] 1:42.696 ART Grand Prix | Kevin Korjus
Q27 #73 [GTC] 1:42.750 SMP Racing | Olivier Beretta
Q28 #93 [GTC] 1:42.808 Pro GT by Almeras | Franck Perera
Q29 #94 [GTC] 1:42.926 AF Corse | Francesco Castellacci
Q30 #99 [GTC] 1:42.994 ART Grand Prix | Alex Brundle
Q31 #57 [GTC] 1:43.028 SMP Racing | Mika Salo
Q33 #75 [GTC] 1:43.488 Prospeed Competition | Maxime Soulet
Q34 #78 [GTC] 1:43.642 Team Russia by Barwell | Jonathan Cocker
Q35 #63 [GTC] 1:46.202 AF Corse | Mads Rasmussen
Q36 #59 [GTC] 1:46.950 Team Sofrev-ASP | Pascal Gibon
Q10 #81 [LMGTE] 1:39.920 Kessel Racing | Matteo Cressoni
Q11 #72 [LMGTE] 1:40.221 SMP Racing | Andrea Bertolini
Q12 #54 [LMGTE] 1:40.550 AF Corse | Marco Cioci
Q13 #80 [LMGTE] 1:40.750 Kessel Racing | Giacomo Piccini
Q14 #55 [LMGTE] 1:40.852 AF Corse | Matt Griffin
Q15 #56 [LMGTE] 1:41.026 AT Racing | Pierre Kaffer
Q16 #65 [LMGTE] 1:41.202 AF Corse | Raffaele Giammaria
Q17 #66 [LMGTE] 1:41.319 JMW Motorsport | Daniel Zampieri
Q18 #58 [LMGTE] 1:41.592 Team Sofrev-ASP | Soheil Ayari
Q20 #86 [LMGTE] 1:42.145 Gulf Racing UK | Adam Carroll
Q21 #76 [LMGTE] 1:42.207 IMSA Performance Matmut | Nicolas Armindo
Q22 #85 [LMGTE] 1:42.377 Gulf Racing UK | Stuart Hall
Q24 #82 [LMGTE] 1:42.670 Crubile Sport | Emmanuel Collard
Q32 #67 [LMGTE] 1:43.099 IMSA Performance Matmut | Eric Helary
Q1 #38 [LMP2] 1:33.974 Jota Sport | Filipe Albuquerque
Q2 #46 [LMP2] 1:34.658 Thiriet by TDS Racing | Tristan Gommendy
Q3 #36 [LMP2] 1:34.861 Signatech Alpine | Nelson Panciatici
Q4 #48 [LMP2] 1:34.882 Murphy Prototypes | Nathanael Berthon
Q5 #43 [LMP2] 1:35.593 Newblood By Morand Racing | Christian Klien
Q6 #34 [LMP2] 1:35.649 RACE Performance | Franck Mailleux
Q7 #41 [LMP2] 1:35.798 Greaves Motorsport | Tom Kimber-Smith
Q8 #29 [LMP2] 1:36.330 Pegasus Racing | Julien Schell
Q9 #24 [LMP2] 1:36.447 Sebastien Loeb Racing | Vincent Capillaire

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #38 Filipe Albuquerque 1:33.974 Jota Sport
GTC: #60 Mikkel Mac 1:42.082 Formula Racing
LMGTE: #81 Matteo Cressoni 1:39.920 Kessel Racing
LMP2: #38 Filipe Albuquerque 1:33.974 Jota Sport

## Fastest laps (archive)
Overall: #38 Filipe Albuquerque 1:36.144
GTC: #94 Francesco Castellacci 1:43.035
LMGTE: #55 Matt Griffin 1:41.024
LMP2: #38 Filipe Albuquerque 1:36.144

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g? #38 Jota Sport | Zytek Z11SN - Nissan | Classified 139L gap — | Simon Dolan / Harry Tincknell / Filipe Albuquerque
 2 g? #24 Sebastien Loeb Racing | Oreca 03 - Nissan | Classified 139L gap 28.869 | Vincent Capillaire / Jan Charouz
 3 g? #36 Signatech Alpine | Alpine A450 - Nissan | Classified 139L gap 42.679 | Paul-Loup Chatin / Nelson Panciatici / Oliver Webb
 4 g? #41 Greaves Motorsport | Zytek Z11SN - Nissan | Classified 138L gap 1 Laps | Tom Kimber-Smith / Matthew Mcmurry
 5 g? #46 Thiriet by TDS Racing | Morgan - Nissan | Classified 137L gap 2 Laps | Pierre Thiriet / Ludovic Badey / Tristan Gommendy
 6 g? #29 Pegasus Racing | Morgan - Nissan | Classified 137L gap 2 Laps | Julien Schell / Nicolas Leutwiler / Jonathan Coleman
 18 g? #34 RACE Performance | Oreca 03 - Judd | Classified 132L gap 7 Laps | Michel Frey / Franck Mailleux
 33 g? #43 Newblood By Morand Racing | Morgan - Judd | NC 136L gap NC | Christian Klien / Gary Hirsch / Romain Brandela
 36 g? #48 Murphy Prototypes | Oreca 03 - Nissan | NC 80L gap NC | Rodolfo Gonzalez / Karun Chandhok / Nathanael Berthon
== LMGTE
 7 g? #72 SMP Racing | Ferrari F458 Italia | Classified 134L gap 5 Laps | Andrea Bertolini / Viktor Shaitar / Sergey Zlobin
 8 g? #81 Kessel Racing | Ferrari F458 Italia | Classified 134L gap 5 Laps | Thomas Kemenater / Matteo Cressoni
 9 g? #66 JMW Motorsport | Ferrari F458 Italia | Classified 134L gap 5 Laps | Daniel Mckenzie / George Richardson / Daniel Zampieri
 10 g? #56 AT Racing | Ferrari F458 Italia | Classified 133L gap 6 Laps | Alexander Talkanitsa Jr / Alexander Talkanitsa / Pierre Kaffer
 11 g? #58 Team Sofrev-ASP | Ferrari F458 Italia | Classified 133L gap 6 Laps | Fabien Barthez / Anthony Pons / Soheil Ayari
 12 g? #76 IMSA Performance Matmut | Porsche 911 GT3 RSR | Classified 132L gap 7 Laps | Raymond Narac / Nicolas Armindo / David Hallyday
 16 g? #55 AF Corse | Ferrari F458 Italia | Classified 132L gap 7 Laps | Duncan Cameron / Matt Griffin / Mirko Venturi
 17 g? #86 Gulf Racing UK | Porsche 911 GT3 RSR | Classified 132L gap 7 Laps | Michael Wainwright / Adam Carroll / Benjamin Barker
 19 g? #85 Gulf Racing UK | Aston Martin Vantage V8 | Classified 131L gap 8 Laps | Roald Goethe / Stuart Hall / Daniel Brown
 20 g? #82 Crubile Sport | Porsche 997 GT3 RSR | Classified 130L gap 9 Laps | François Perrodo / Sébastien Crubilé / Emmanuel Collard
 22 g? #67 IMSA Performance Matmut | Porsche 911 GT3 RSR | Classified 129L gap 10 Laps | Erik Maris / Jean-Marc Merlin / Eric Helary
 32 g? #65 AF Corse | Ferrari F458 Italia | Classified 124L gap 15 Laps | Peter Mann / Lorenzo Casé / Raffaele Giammaria
 35 g? #80 Kessel Racing | Ferrari F458 Italia | NC 99L gap NC | Michael Broniszewski / Giacomo Piccini
 37 g? #54 AF Corse | Ferrari F458 Italia | NC 66L gap NC | Piergiuseppe Perazzini / Marco Cioci / Michael Lyons
== GTC
 13 g? #60 Formula Racing | Ferrari F458 Italia GT3 | Classified 132L gap 7 Laps | Johnny Laursen / Mikkel Mac / Andrea Piccini
 14 g? #73 SMP Racing | Ferrari F458 Italia GT3 | Classified 132L gap 7 Laps | Olivier Beretta / David Markozov / Anton Ladygin
 15 g? #71 SMP Racing | Ferrari F458 Italia GT3 | Classified 132L gap 7 Laps | Kirill Ladygin / Aleksey Basov / Luca Persiani
 21 g? #99 ART Grand Prix | McLaren MP4 12C GT3 | Classified 129L gap 10 Laps | Ricardo Gonzalez / Karim Ajlani / Alex Brundle
 23 g? #59 Team Sofrev-ASP | Ferrari F458 Italia GT3 | Classified 129L gap 10 Laps | Christophe Bourret / Pascal Gibon / Jean-Philippe Belloc
 24 g? #63 AF Corse | Ferrari F458 Italia GT3 | Classified 129L gap 10 Laps | Mads Rasmussen / Ilya Melnikov
 25 g? #94 AF Corse | Ferrari F458 Italia GT3 | Classified 129L gap 10 Laps | Thomas Flohr / Francesco Castellacci
 26 g? #98 ART Grand Prix | McLaren MP4 12C GT3 | Classified 128L gap 11 Laps | Kevin Korjus / Grégoire Demoustier / Yann Goudy
 27 g? #78 Team Russia by Barwell | BMW Z4 GT3 | Classified 128L gap 11 Laps | Leonid Machitski / Timur Sardarov / Jonathan Cocker
 28 g? #57 SMP Racing | Ferrari F458 Italia GT3 | Classified 127L gap 12 Laps | Boris Rotenberg / Mika Salo / Maurizio Mediani
 29 g? #93 Pro GT by Almeras | Porsche 997 GT3R | Classified 127L gap 12 Laps | Franck Perera / Lucas Laserre / Eric Dermont
 30 g? #95 AF Corse | Ferrari F458 Italia GT3 | Classified 126L gap 13 Laps | Adrien de Leener / Cedric Sbirrazzuoli
 31 g? #62 AF Corse | Ferrari F458 Italia GT3 | Classified 126L gap 13 Laps | Yannick Mallegol / Howard Blank / Jean-Marc Bachelier
 34 g? #75 Prospeed Competition | Porsche GT3 R | NC 118L gap NC | Paul van Splunteren / Gilles Vannelet / Maxime Soulet
