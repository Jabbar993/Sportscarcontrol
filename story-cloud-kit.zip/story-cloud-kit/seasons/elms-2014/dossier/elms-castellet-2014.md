# elms-castellet-2014

Event: 4 Hours of Le Castellet | Circuit: Paul Ricard | Date: 2014-09-14
Scheduled: 04:00:00 | Official duration: 4:00:33.427 | Laps (winner): 125

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q21 #71 [GTC] 1:57.336 SMP Racing | Luca Persiani
Q22 #98 [GTC] 1:57.513 ART Grand Prix | Kevin Korjus
Q23 #95 [GTC] 1:57.745 AF Corse | Cedric Sbirrazzuoli
Q25 #78 [GTC] 1:57.891 Team Russia by Barwell | Jonathan Cocker
Q26 #57 [GTC] 1:57.931 SMP Racing | Mika Salo
Q27 #94 [GTC] 1:57.955 AF Corse | Francesco Castellacci
Q28 #93 [GTC] 1:58.057 Pro GT by Almeras | Franck Perera
Q29 #75 [GTC] 1:58.134 Prospeed Competition | Mike Parisy
Q31 #60 [GTC] 1:58.454 Formula Racing | Jan Magnussen
Q32 #99 [GTC] 1:58.554 ART Grand Prix | Alex Brundle
Q33 #73 [GTC] 1:58.652 SMP Racing | David Markozov
Q34 #63 [GTC] 2:00.914 AF Corse | Mads Rasmussen
Q35 #92 [GTC] 2:01.209 Ombra Racing | Mario Cordoni
Q36 #59 [GTC] 2:01.582 Team Sofrev-ASP | Pascal Gibon
Q11 #72 [LMGTE] 1:55.691 SMP Racing | Andrea Bertolini
Q12 #80 [LMGTE] 1:55.887 Kessel Racing | Giacomo Piccini
Q13 #55 [LMGTE] 1:55.911 AF Corse | Matt Griffin
Q14 #86 [LMGTE] 1:56.010 Gulf Racing UK | Adam Carroll
Q15 #54 [LMGTE] 1:56.140 AF Corse | Marco Cioci
Q16 #66 [LMGTE] 1:56.338 JMW Motorsport | James Walker
Q17 #70 [LMGTE] 1:56.816 AF Corse | Emmanuel Collard
Q18 #81 [LMGTE] 1:56.852 Kessel Racing | Matteo Cressoni
Q19 #58 [LMGTE] 1:56.988 Team Sofrev-ASP | Soheil Ayari
Q20 #56 [LMGTE] 1:57.078 AT Racing | Mirko Venturi
Q24 #76 [LMGTE] 1:57.781 IMSA Performance Matmut | Nicolas Armindo
Q30 #67 [LMGTE] 1:58.279 IMSA Performance Matmut | Eric Helary
Q37 #85 [LMGTE] 2:04.550 Gulf Racing UK | Daniel Brown
Q1 #48 [LMP2] 1:47.837 Murphy Prototypes | Nathanael Berthon
Q2 #38 [LMP2] 1:48.126 Jota Sport | Harry Tincknell
Q3 #43 [LMP2] 1:48.420 Newblood By Morand Racing | Christian Klien
Q4 #34 [LMP2] 1:48.594 RACE Performance | Franck Mailleux
Q5 #36 [LMP2] 1:48.956 Signatech Alpine | Nelson Panciatici
Q6 #24 [LMP2] 1:48.958 Sebastien Loeb Racing | Arthur Pic
Q7 #46 [LMP2] 1:49.055 Thiriet by TDS Racing | Tristan Gommendy
Q8 #28 [LMP2] 1:49.413 Greaves Motorsport | Luciano Bacheta
Q9 #29 [LMP2] 1:50.868 Pegasus Racing | Julien Schell
Q10 #41 [LMP2] 1:51.502 Greaves Motorsport | Matthew Mcmurry

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #48 Nathanael Berthon 1:47.837 Murphy Prototypes
GTC: #71 Luca Persiani 1:57.336 SMP Racing
LMGTE: #72 Andrea Bertolini 1:55.691 SMP Racing
LMP2: #48 Nathanael Berthon 1:47.837 Murphy Prototypes

## Fastest laps (archive)
Overall: #36 Paul-Loup Chatin 1:49.887
GTC: #57 Maurizio Mediani 1:58.805
LMGTE: #72 Andrea Bertolini 1:56.735
LMP2: #36 Paul-Loup Chatin 1:49.887

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g? #43 Newblood By Morand Racing | Morgan - Judd | Classified 125L gap — | Christian Klien / Gary Hirsch / Pierre Ragues
 2 g? #36 Signatech Alpine | Alpine A450b - Nissan | Classified 125L gap 5.518 | Paul-Loup Chatin / Nelson Panciatici / Oliver Webb
 3 g? #48 Murphy Prototypes | Oreca 03R - Nissan | Classified 125L gap 18.856 | Pipo Derani / Nathanael Berthon / Rodolfo Gonzalez
 4 g? #38 Jota Sport | Zytek Z11SN - Nissan | Classified 125L gap — | Simon Dolan / Harry Tincknell / Filipe Albuquerque
 5 g? #28 Greaves Motorsport | Zytek Z11SN - Nissan | Classified 125L gap 37.358 | Luciano Bacheta / Mark Shulzhitskiy
 6 g? #24 Sebastien Loeb Racing | Oreca 03R - Nissan | Classified 123L gap 2 Laps | Vincent Capillaire / Andrea Roda / Arthur Pic
 7 g? #34 RACE Performance | Oreca 03 - Judd | Classified 122L gap 3 Laps | Michel Frey / Franck Mailleux
 33 g? #46 Thiriet by TDS Racing | Ligier JS P2 - Nissan | NC 89L gap NC | Pierre Thiriet / Ludovic Badey / Tristan Gommendy
 35 g? #29 Pegasus Racing | Morgan - Nissan | NC 50L gap NC | Julien Schell / Nicolas Leutwiler / Jonathan Coleman
 37 g? #41 Greaves Motorsport | Zytek Z11SN - Nissan | NC 0L gap NC | Matthew Mcmurry / Johnny Mowlem
== LMGTE
 8 g? #55 AF Corse | Ferrari F458 Italia | Classified 119L gap 6 Laps | Duncan Cameron / Matt Griffin / Michele Rugolo
 9 g? #56 AT Racing | Ferrari F458 Italia | Classified 119L gap 6 Laps | Alexander Talkanitsa / Pierre Kaffer / Mirko Venturi
 10 g? #66 JMW Motorsport | Ferrari F458 Italia | Classified 119L gap 6 Laps | Daniel Mckenzie / George Richardson / James Walker
 11 g? #54 AF Corse | Ferrari F458 Italia | Classified 119L gap 6 Laps | Piergiuseppe Perazzini / Marco Cioci / Michael Lyons
 12 g? #80 Kessel Racing | Ferrari F458 Italia | Classified 119L gap 6 Laps | Michael Broniszewski / Giacomo Piccini
 13 g? #86 Gulf Racing UK | Porsche 911 RSR | Classified 118L gap 7 Laps | Michael Wainwright / Adam Carroll / Benjamin Barker
 14 g? #72 SMP Racing | Ferrari F458 Italia | Classified 118L gap 7 Laps | Andrea Bertolini / Viktor Shaitar / Sergey Zlobin
 15 g? #76 IMSA Performance Matmut | Porsche 911 GT3 RSR | Classified 118L gap 7 Laps | Raymond Narac / Nicolas Armindo / Christina Nielsen
 16 g? #81 Kessel Racing | Ferrari F458 Italia | Classified 117L gap 8 Laps | Thomas Kemenater / Matteo Cressoni
 27 g? #85 Gulf Racing UK | Aston Martin Vantage V8 | Classified 114L gap 11 Laps | Roald Goethe / Stuart Hall / Daniel Brown
 31 g? #67 IMSA Performance Matmut | Porsche 911 GT3 RSR | Classified 112L gap 13 Laps | Erik Maris / Jean-Marc Merlin / Eric Helary
 34 g? #70 AF Corse | Ferrari F458 Italia | NC 68L gap NC | François Perrodo / Emmanuel Collard / Yannick Mallegol
 36 g? #58 Team Sofrev-ASP | Ferrari F458 Italia | NC 0L gap NC | Fabien Barthez / Anthony Pons / Soheil Ayari
== GTC
 17 g? #73 SMP Racing | Ferrari F458 Italia GT3 | Classified 117L gap 8 Laps | Olivier Beretta / David Markozov / Anton Ladygin
 18 g? #60 Formula Racing | Ferrari F458 Italia GT3 | Classified 117L gap 8 Laps | Johnny Laursen / Mikkel Mac / Jan Magnussen
 19 g? #98 ART Grand Prix | McLaren MP4 12C GT3 | Classified 116L gap 9 Laps | Kevin Korjus / Grégoire Demoustier / Yann Goudy
 20 g? #71 SMP Racing | Ferrari F458 Italia GT3 | Classified 116L gap 9 Laps | Kirill Ladygin / Aleksey Basov / Luca Persiani
 21 g? #95 AF Corse | Ferrari F458 Italia GT3 | Classified 116L gap 9 Laps | Adrien de Leener / Cedric Sbirrazzuoli
 22 g? #94 AF Corse | Ferrari F458 Italia GT3 | Classified 116L gap 9 Laps | Thomas Flohr / Francesco Castellacci / Andrea Rizzoli
 23 g? #93 Pro GT by Almeras | Porsche 997 GT3R | Classified 116L gap 9 Laps | Franck Perera / Lucas Lasserre / Eric Dermont
 24 g? #99 ART Grand Prix | McLaren MP4 12C GT3 | Classified 115L gap 10 Laps | Ricardo Gonzalez / Karim Ajlani / Alex Brundle
 25 g? #75 Prospeed Competition | Porsche GT3 R | Classified 115L gap 10 Laps | Max van Splunteren / Gilles Vannelet / Mike Parisy
 26 g? #78 Team Russia by Barwell | BMW Z4 GT3 | Classified 114L gap 11 Laps | Leonid Machitski / Timur Sardarov / Jonathan Cocker
 28 g? #57 SMP Racing | Ferrari F458 Italia GT3 | Classified 114L gap 11 Laps | Boris Rotenberg / Mika Salo / Maurizio Mediani
 29 g? #63 AF Corse | Ferrari F458 Italia GT3 | Classified 114L gap 11 Laps | Mads Rasmussen / Filipe Barreiros
 30 g? #59 Team Sofrev-ASP | Ferrari F458 Italia GT3 | Classified 114L gap 11 Laps | Christophe Bourret / Pascal Gibon / Jean-Philippe Belloc
 32 g? #92 Ombra Racing | Ferrari F458 Italia GT3 | Classified 112L gap 13 Laps | Mario Cordoni / Marco Zanuttini
