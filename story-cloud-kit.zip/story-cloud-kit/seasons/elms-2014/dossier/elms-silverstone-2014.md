# elms-silverstone-2014

Event: 4 Hours of Silverstone | Circuit: Silverstone | Date: 2014-04-19
Scheduled: 04:00:00 | Official duration: 4:00:29.711 | Laps (winner): 118

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q1 #38 [LMP2] 1:47.702 Jota Sport | Harry Tincknell
Q2 #34 [LMP2] 1:48.854 Race Performance | Franck Mailleux
Q3 #48 [LMP2] 1:48.912 Murphy Prototypes | Karun Chandhok
Q4 #41 [LMP2] 1:48.950 Greaves Motorsport | Tom Kimber-Smith
Q5 #46 [LMP2] 1:49.057 Thiriet By TDS Racing | Tristan Gommendy
Q6 #43 [LMP2] 1:49.715 Newblood By Morand Racing | Christian Klien
Q7 #36 [LMP2] 1:49.762 Signatech Alpine | Nelson Panciatici
Q8 #28 [LMP2] 1:50.236 Greaves Motorsport | James Littlejohn
Q9 #24 [LMP2] 1:51.822 Sebastien Loeb Racing | Jan Charouz
Q10 #29 [LMP2] 1:51.997 Pegasus Racing | Jonathan Coleman
Q11 #50 [LMP2] 1:52.846 Larbre Competition | Gustavo Yacaman
Q12 #72 [LMGTE] 1:57.970 SMP Racing | Andrea Bertolini
Q13 #66 [LMGTE] 1:58.590 JMW Motorsport | Daniel Zampieri
Q14 #55 [LMGTE] 1:58.835 AF Corse | Matt Griffin
Q15 #58 [LMGTE] 1:59.166 Team Sofrev-ASP | Soheil Ayari
Q16 #81 [LMGTE] 1:59.471 Kessel Racing | Matteo Cressoni
Q17 #54 [LMGTE] 1:59.687 AF Corse | Michael Lyons
Q18 #76 [LMGTE] 1:59.755 IMSA Performance Matmut | Nicolas Armindo
Q19 #80 [LMGTE] 1:59.775 Kessel Racing | Giacomo Piccini
Q20 #56 [LMGTE] 1:59.803 AT Racing | Pierre Kaffer
Q21 #71 [GTC] 2:00.032 SMP Racing | Luca Persiani
Q22 #96 [GTC] 2:00.209 Team Ukraine | Alessandro Pier Guidi
Q23 #63 [GTC] 2:00.676 AF Corse | Dennis Lind
Q24 #82 [LMGTE] 2:00.717 Crubile Sport | Emmanuel Collard
Q25 #78 [GTC] 2:00.956 Team Russia By Barwell | Jonathan Cocker
Q26 #98 [GTC] 2:01.091 ART Grand Prix | Kevin Korjus
Q27 #86 [LMGTE] 2:01.222 Gulf Racing UK | Adam Carroll
Q28 #60 [GTC] 2:01.434 Formula Racing | Jan Magnussen
Q29 #51 [GTC] 2:01.589 Sebastien Loeb Racing | Mike Parisy
Q30 #99 [GTC] 2:01.669 ART Grand Prix | Alex Brundle
Q31 #93 [GTC] 2:01.906 Pro GT By Almeras | Franck Perera
Q32 #59 [GTC] 2:02.020 Team Sofrev-ASP | Jean-Philippe Belloc
Q33 #75 [GTC] 2:02.048 Prospeed Competition | Maxime Soulet
Q34 #67 [LMGTE] 2:02.335 IMSA Performance Matmut | Eric Helary
Q35 #73 [GTC] 2:04.384 SMP Racing | Olivier Beretta
Q36 #95 [GTC] 2:04.555 AF Corse | Adrien de Leener
Q37 #85 [LMGTE] 2:04.701 Gulf Racing UK | Roald Goethe
Q38 #62 [GTC] 2:04.716 AF Corse | Yannick Mallegol

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #38 Harry Tincknell 1:47.702 Jota Sport
LMP2: #38 Harry Tincknell 1:47.702 Jota Sport
LMGTE: #72 Andrea Bertolini 1:57.970 SMP Racing
GTC: #71 Luca Persiani 2:00.032 SMP Racing

## Fastest laps (archive)
Overall: #48 Karun Chandhok 1:50.757
LMP2: #48 Karun Chandhok 1:50.757
LMGTE: #55 Michele Rugolo 2:00.077
GTC: #63 Dennis Lind 2:02.044

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g5 #46 Thiriet By TDS Racing | Morgan - Nissan | Classified 118L | Pierre Thiriet / Ludovic Badey / Tristan Gommendy
 2 g2 #34 Race Performance | Oreca 03 - Judd | Classified 118L gap 3.828 | Michel Frey / Franck Mailleux
 3 g6 #43 Newblood By Morand Racing | Morgan - Judd | Classified 118L gap 4.731 | Christian Klien / Gary Hirsch / Romain Brandela
 4 g4 #41 Greaves Motorsport | Zytek Z11SN - Nissan | Classified 118L gap 14.388 | Tom Kimber-Smith / Chris Dyson / Matthew McMurry
 5 g7 #36 Signatech Alpine | Alpine A450 - Nissan | Classified 118L gap 55.068 | Paul-Loup Chatin / Nelson Panciatici / Oliver Webb
 6 g8 #28 Greaves Motorsport | Zytek Z11SN - Nissan | Classified 118L gap 1'00.569 | James Littlejohn / Anthony Wells / James Walker
 7 g9 #24 Sebastien Loeb Racing | Oreca 03 - Nissan | Classified 116L gap 2 Laps | Vincent Capillaire / Jan Charouz
 8 g3 #48 Murphy Prototypes | Oreca 03 - Nissan | Classified 112L gap 6 Laps | Rodolfo Gonzalez / Alex Kapadia / Karun Chandhok
 12 g11 #50 Larbre Competition | Morgan - Judd | Classified 111L gap 7 Laps | Gustavo Yacaman / Keiko Ihara
 36 g1 #38 Jota Sport | Zytek Z11SN - Nissan | RET 97L gap RET | Simon Dolan / Harry Tincknell / Filipe Albuquerque
 37 g10 #29 Pegasus Racing | Morgan - Nissan | RET 74L gap RET | Julien Schell / Nicolas Leutwiler / Jonathan Coleman
== LMGTE
 9 g14 #55 AF Corse | Ferrari F458 Italia | Classified 112L gap 6 Laps | Duncan Cameron / Matt Griffin / Michele Rugolo
 10 g12 #72 SMP Racing | Ferrari F458 Italia | Classified 112L gap 6 Laps | Andrea Bertolini / Viktor Shaitar / Sergey Zlobin
 11 g18 #76 IMSA Performance Matmut | Porsche 911 GT3 RSR | Classified 111L gap 7 Laps | Raymond Narac / Nicolas Armindo / David Hallyday
 13 g20 #56 AT Racing | Ferrari F458 Italia | Classified 111L gap 7 Laps | Alexander Talkanitsa Jr / Alexander Talkanitsa / Pierre Kaffer
 14 g13 #66 JMW Motorsport | Ferrari F458 Italia | Classified 111L gap 7 Laps | Daniel McKenzie / George Richardson / Daniel Zampieri
 15 g17 #54 AF Corse | Ferrari F458 Italia | Classified 110L gap 8 Laps | Piergiuseppe Perazzini / Marco Cioci / Michael Lyons
 16 g15 #58 Team Sofrev-ASP | Ferrari F458 Italia | Classified 110L gap 8 Laps | Fabien Barthez / Anthony Pons / Soheil Ayari
 20 g24 #82 Crubile Sport | Porsche 997 GT3 RSR | Classified 109L gap 9 Laps | François Perrodo / Sebastien Crubilé / Emmanuel Collard
 21 g27 #86 Gulf Racing UK | Porsche 911 GT3 RSR | Classified 109L gap 9 Laps | Michael Wainwright / Adam Carroll / Ben Barker
 22 g19 #80 Kessel Racing | Ferrari F458 Italia | Classified 108L gap 10 Laps | Michael Broniszewski / Giacomo Piccini
 24 g37 #85 Gulf Racing UK | Aston Martin Vantage V8 | Classified 108L gap 10 Laps | Roald Goethe / Stuart Hall / Daniel Brown
 31 g34 #67 IMSA Performance Matmut | Porsche 911 GT3 RSR | Classified 106L gap 12 Laps | Erik Maris / Jean-Marc Merlin / Eric Helary
 33 g16 #81 Kessel Racing | Ferrari F458 Italia | Classified 104L gap 14 Laps | Thomas Kemenater / Matteo Cressoni
== GTC
 17 g22 #96 Team Ukraine | Ferrari F458 Italia GT3 | Classified 109L gap 9 Laps | Andriy Kruglyk / Sergii Chukanov / Alessandro Pier Guidi
 18 g35 #73 SMP Racing | Ferrari F458 Italia GT3 | Classified 109L gap 9 Laps | Olivier Beretta / David Markozov / Anton Ladygin
 19 g28 #60 Formula Racing | Ferrari F458 Italia GT3 | Classified 109L gap 9 Laps | Jan Magnussen / Johnny Laursen / Mikkel Mac
 23 g25 #78 Team Russia By Barwell | BMW Z4 GT3 | Classified 108L gap 10 Laps | Leonid Machitski / Timur Sardarov / Jonathan Cocker
 25 g30 #99 ART Grand Prix | McLaren MP4 12C GT3 | Classified 107L gap 11 Laps | Ricardo Gonzalez / Karim Ajlani / Alex Brundle
 26 g29 #51 Sebastien Loeb Racing | Audi R8 LMS ultra | Classified 107L gap 11 Laps | Henri Hassid / Mike Parisy / Olivier Lombard
 27 g26 #98 ART Grand Prix | McLaren MP4 12C GT3 | Classified 107L gap 11 Laps | Kevin Korjus / Grégoire Demoustier / Yann Goudy
 28 g31 #93 Pro GT By Almeras | Porsche 997 GT3R | Classified 107L gap 11 Laps | Franck Perera / Lucas Lasserre / Eric Dermont
 29 g33 #75 Prospeed Competition | Porsche GT3 R | Classified 107L gap 11 Laps | Paul van Splunteren / Gilles Vannelet / Maxime Soulet
 30 g23 #63 AF Corse | Ferrari F458 Italia GT3 | Classified 106L gap 12 Laps | Mads Rasmussen / Dennis Lind
 32 g32 #59 Team Sofrev-ASP | Ferrari F458 Italia GT3 | Classified 106L gap 12 Laps | Christophe Bourret / Pascal Gibon / Jean-Philippe Belloc
 34 g36 #95 AF Corse | Ferrari F458 Italia GT3 | Classified 102L gap 16 Laps | Adrien de Leener / Cedric Sbirrazzuoli
 35 g38 #62 AF Corse | Ferrari F458 Italia GT3 | Classified 102L gap 16 Laps | Yannick Mallegol / Howard Blank / Jean-Marc Bachelier
 38 g21 #71 SMP Racing | Ferrari F458 Italia GT3 | RET 0L gap RET | Kirill Ladygin / Aleksey Basov / Luca Persiani
