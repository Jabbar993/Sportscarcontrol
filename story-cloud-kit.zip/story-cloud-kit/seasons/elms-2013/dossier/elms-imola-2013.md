# elms-imola-2013

Event: 3 Hours of Imola | Circuit: Imola | Date: 2013-05-18
Scheduled: 03:00:00 | Official duration: 3:00:13.017 | Laps (winner): 108

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q19 #60 [GTC] 1:43.752 Kox Racing | Peter Kox
Q20 #62 [GTC] 1:44.235 AF Corse | Stefano Gai
Q23 #65 [GTC] 1:45.786 Momo Megatron DF1 | Kuba Giermaziak
Q24 #79 [GTC] 1:45.831 Ecurie Ecosse | Andrew Smith
Q25 #69 [GTC] 1:46.149 SMP Racing | Viktor Shaitar
Q27 #68 [GTC] 1:49.733 SMP Racing | Yury Evstigneev
Q13 #52 [LMGTE] 1:41.994 RAM Racing | Matt Griffin
Q14 #67 [LMGTE] 1:42.055 IMSA Performance Matmut | Patrick Long
Q16 #53 [LMGTE] 1:42.669 RAM Racing | Gunnar Jeannette
Q17 #66 [LMGTE] 1:42.911 JMW Motorsport | Joël Camathias
Q18 #54 [LMGTE] 1:43.551 AF Corse | Yannick Mallegol
Q21 #55 [LMGTE] 1:44.478 AF Corse | Piergiuseppe Perazzini
Q22 #77 [LMGTE] 1:45.173 Proton Competition | Christian Ried
Q26 #75 [LMGTE] 1:46.358 Prospeed Competition | Sebastien Crubilé
Q1 #38 [LMP2] 1:34.343 Jota Sport | Oliver Turvey
Q2 #1 [LMP2] 1:34.914 Thiriet by TDS Racing | Mathias Beche
Q3 #18 [LMP2] 1:34.951 Murphy Prototypes | Brendon Hartley
Q4 #36 [LMP2] 1:35.538 Signatech Alpine | Nelson Panciatici
Q5 #3 [LMP2] 1:35.606 Greaves Motorsport | Tom Kimber-Smith
Q6 #43 [LMP2] 1:36.320 Morand Racing | Frank Mailleux
Q7 #34 [LMP2] 1:36.444 RACE Performance | Patric Niederhauser
Q8 #30 [LMP2] 1:37.309 HVM Status GP | Jonathan Hirschi
Q9 #4 [LMP2] 1:38.128 Boutsen Ginion Racing | Bastien Brière
Q11 #39 [LMP2] 1:41.445 DKR Engineering | Olivier Porta
Q10 #49 [LMPC] 1:39.222 Team Endurance Challenge | Gary Hirsch
Q12 #47 [LMPC] 1:41.708 Team Endurance Challenge | Matthieu Lecuyer
Q15 #48 [LMPC] 1:42.093 Team Endurance Challenge | Anthony Pons

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #38 Oliver Turvey 1:34.343 Jota Sport
GTC: #60 Peter Kox 1:43.752 Kox Racing
LMGTE: #52 Matt Griffin 1:41.994 RAM Racing
LMP2: #38 Oliver Turvey 1:34.343 Jota Sport
LMPC: #49 Gary Hirsch 1:39.222 Team Endurance Challenge

## Fastest laps (archive)
Overall: #38 Oliver Turvey 1:34.992
GTC: #60 Peter Kox 1:43.886
LMGTE: #67 Patrick Long 1:42.236
LMP2: #38 Oliver Turvey 1:34.992
LMPC: #49 Paul Loup Chatin 1:40.250

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g? #1 Thiriet by TDS Racing | Oreca 03 - Nissan | Classified 108L gap — | Pierre Thiriet / Mathias Beche
 2 g? #36 Signatech Alpine | Alpine - Nissan | Classified 108L gap 46.236 | Pierre Ragues / Nelson Panciatici
 3 g? #43 Morand Racing | Morgan - Judd | Classified 107L gap 1 Laps | Natacha Gachnang / Frank Mailleux
 4 g? #34 RACE Performance | Oreca 03 - Judd | Classified 107L gap 1 Laps | Michel Frey / Patric Niederhauser
 5 g? #3 Greaves Motorsport | Zytek Z11SN - Nissan | Classified 107L gap 1 Laps | David Heinemeier Hansson / Tom Kimber-Smith
 6 g? #18 Murphy Prototypes | Oreca 03 - Nissan | Classified 105L gap 3 Laps | Brendon Hartley / Mark Patterson
 14 g? #4 Boutsen Ginion Racing | Oreca 03 - Nissan | Classified 101L gap 7 Laps | Bastien Brière / Thomas Dagoneau / John Hartshorne
 23 g? #30 HVM Status GP | Lola B12/80 Coupé - Judd | Classified 89L gap 19 Laps | Tony Burgess / Jonathan Hirschi
 24 g? #38 Jota Sport | Zytek Z11SN - Nissan | NC 101L gap NC | Simon Dolan / Oliver Turvey
 26 g? #39 DKR Engineering | Lola B11/40 - Judd | NC 89L gap NC | Olivier Porta / Romain Brandela / Bernard Delhez
== LMPC
 7 g? #49 Team Endurance Challenge | Formula Le Mans Oreca 09 | Classified 103L gap 5 Laps | Paul Loup Chatin / Gary Hirsch
 9 g? #48 Team Endurance Challenge | Formula Le Mans Oreca 09 | Classified 102L gap 6 Laps | Anthony Pons / Soheil Ayari
 10 g? #47 Team Endurance Challenge | Formula Le Mans Oreca 09 | Classified 102L gap 6 Laps | Alex Loan / Matthieu Lecuyer
== LMGTE
 8 g? #52 RAM Racing | Ferrari F458 Italia | Classified 102L gap 6 Laps | Johnny Mowlem / Matt Griffin
 11 g? #55 AF Corse | Ferrari F458 Italia | Classified 101L gap 7 Laps | Piergiuseppe Perazzini / Marco Cioci / Federico Leo
 12 g? #53 RAM Racing | Ferrari F458 Italia | Classified 101L gap 7 Laps | Gunnar Jeannette / Frank Montecalvo
 13 g? #66 JMW Motorsport | Ferrari F458 Italia | Classified 101L gap 7 Laps | Andrea Bertolini / Joël Camathias
 15 g? #77 Proton Competition | Porsche 911 GT3 RSR | Classified 101L gap 7 Laps | Christian Ried / Gianluca Roda / Paolo Ruberti
 16 g? #67 IMSA Performance Matmut | Porsche 911 GT3 RSR | Classified 100L gap 8 Laps | Patrice Milesi / Patrick Long
 20 g? #54 AF Corse | Ferrari F458 Italia | Classified 97L gap 11 Laps | Yannick Mallegol / Jean-Marc Bachelier / Howard Blank
 28 g? #75 Prospeed Competition | Porsche 911 GT3 RSR | NC 43L gap NC | François Perrodo / Sebastien Crubilé
== GTC
 17 g? #69 SMP Racing | Ferrari F458 Italia GT3 | Classified 100L gap 8 Laps | Fabio Babini / Viktor Shaitar / Kirill Ladygin
 18 g? #62 AF Corse | Ferrari F458 Italia GT3 | Classified 99L gap 9 Laps | Andrea Rizzoli / Stefano Gai / Lorenzo Casé
 19 g? #79 Ecurie Ecosse | BMW Z4 | Classified 97L gap 11 Laps | Ollie Millroy / Andrew Smith / Joe Twyman
 21 g? #72 SMP Racing | Ferrari F458 Italia GT3 | Classified 97L gap 11 Laps | Maurizio Mediani / Serguey Zlobin / Boris Rotenberg
 22 g? #68 SMP Racing | Ferrari F458 Italia GT3 | Classified 96L gap 12 Laps | Devi Markozov / Yury Evstigneev / Alexander Frolov
 25 g? #60 Kox Racing | Lamborghini Gallardo LP600 GT3 | NC 97L gap NC | Peter Kox / Nico Pronk
 27 g? #65 Momo Megatron DF1 | Audi R8 LMS | NC 60L gap NC | Raffi Bader / Dylan Derdaele / Kuba Giermaziak
