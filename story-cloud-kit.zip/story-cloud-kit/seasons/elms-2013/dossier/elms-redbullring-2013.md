# elms-redbullring-2013

Event: 3 Hours of Red Bull Ring | Circuit: Red Bull Ring | Date: 2013-07-20
Scheduled: 03:00:00 | Official duration: 3:00:09.351 | Laps (winner): 122

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q19 #72 [GTC] 1:30.705 SMP Racing | Luca Persiani
Q20 #69 [GTC] 1:30.741 SMP Racing | Kirill Ladygin
Q21 #62 [GTC] 1:30.836 AF Corse | Andrea Rizzoli
Q24 #79 [GTC] 1:31.765 Ecurie Ecosse | Ollie Millroy
Q25 #60 [GTC] 1:31.797 Kox Racing | Peter Kox
Q12 #77 [LMGTE] 1:29.391 Proton Competition | Nicholas Tandy
Q13 #66 [LMGTE] 1:29.513 JMW Motorsport | Andrea Bertolini
Q14 #52 [LMGTE] 1:29.629 RAM Racing | Johnny Mowlem
Q15 #67 [LMGTE] 1:29.800 IMSA Performance Matmut | Jean Vernay
Q16 #75 [LMGTE] 1:30.068 Prospeed Competition | Emmanuel Collard
Q17 #53 [LMGTE] 1:30.103 RAM Racing | Gunnar Jeannette
Q18 #55 [LMGTE] 1:30.187 AF Corse | Marco Cioci
Q22 #54 [LMGTE] 1:30.865 AF Corse | Yannick Mallegol
Q23 #88 [LMGTE] 1:31.466 Proton Competition | Klaus Bachler
Q1 #38 [LMP2] 1:23.871 Jota Sport | Oliver Turvey
Q2 #18 [LMP2] 1:24.010 Murphy Prototypes | Brendon Hartley
Q3 #1 [LMP2] 1:24.054 Thiriet by TDS Racing | Mathias Beche
Q4 #43 [LMP2] 1:24.318 Morand Racing | Franck Mailleux
Q5 #34 [LMP2] 1:24.407 RACE Performance | Patric Niederhauser
Q6 #4 [LMP2] 1:24.794 Boutsen Ginion Racing | Dominik Kraihamer
Q7 #37 [LMP2] 1:25.865 SMP Racing | Maurizio Mediani
Q8 #46 [LMPC] 1:28.234 Algarve Pro Racing Team | Nicky Catsburg
Q9 #47 [LMPC] 1:28.394 Team Endurance Challenge | Nicolas Verdonck
Q10 #49 [LMPC] 1:28.635 Team Endurance Challenge | Paul Chatin
Q11 #48 [LMPC] 1:28.770 Team Endurance Challenge | Soheil Ayari

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #38 Oliver Turvey 1:23.871 Jota Sport
GTC: #72 Luca Persiani 1:30.705 SMP Racing
LMGTE: #77 Nicholas Tandy 1:29.391 Proton Competition
LMP2: #38 Oliver Turvey 1:23.871 Jota Sport
LMPC: #46 Nicky Catsburg 1:28.234 Algarve Pro Racing Team

## Fastest laps (archive)
Overall: #38 Oliver Turvey 1:25.152
GTC: #69 Viktor Shaitar 1:32.188
LMGTE: #55 Federico Leo 1:30.993
LMP2: #38 Oliver Turvey 1:25.152
LMPC: #46 Nicky Catsburg 1:29.080

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g? #1 Thiriet by TDS Racing | Oreca 03 - Nissan | Classified 122L gap — | Pierre Thiriet / Mathias Beche
 2 g? #36 Signatech Alpine | Alpine - Nissan | Classified 122L gap 21.143 | Pierre Ragues / Nelson Panciatici
 3 g? #43 Morand Racing | Morgan - Judd | Classified 122L gap 49.915 | Natacha Gachnang / Franck Mailleux
 4 g? #38 Jota Sport | Zytek Z11SN - Nissan | Classified 121L gap 1 Laps | Simon Dolan / Oliver Turvey
 5 g? #34 RACE Performance | Oreca 03 - Judd | Classified 121L gap 1 Laps | Michel Frey / Patric Niederhauser
 6 g? #37 SMP Racing | Oreca 03 - Nissan | Classified 119L gap 3 Laps | Maurizio Mediani / Serguey Zlobin
 25 g? #18 Murphy Prototypes | Oreca 03 - Nissan | Classified 102L gap 20 Laps | Brendon Hartley / Jonathan Hirschi
 26 g? #4 Boutsen Ginion Racing | Oreca 03 - Nissan | NC 69L gap NC | Dominik Kraihamer / Thomas Holzer
== LMPC
 7 g? #49 Team Endurance Challenge | Formula Le Mans Oreca 09 | Classified 118L gap 4 Laps | Paul Chatin / Gary Hirsch
 8 g? #47 Team Endurance Challenge | Formula Le Mans Oreca 09 | Classified 118L gap 4 Laps | Alex Loan / Nicolas Verdonck
 9 g? #46 Algarve Pro Racing Team | Formula Le Mans Oreca 09 | Classified 116L gap 6 Laps | Cornelius Jones / Nicky Catsburg
 14 g? #48 Team Endurance Challenge | Formula Le Mans Oreca 09 | Classified 115L gap 7 Laps | Anthony Pons / Soheil Ayari
== LMGTE
 10 g? #52 RAM Racing | Ferrari F458 Italia | Classified 116L gap 6 Laps | Johnny Mowlem / Matt Griffin
 11 g? #66 JMW Motorsport | Ferrari F458 Italia | Classified 116L gap 6 Laps | Andrea Bertolini / Joël Camathias
 12 g? #53 RAM Racing | Ferrari F458 Italia | Classified 115L gap 7 Laps | Gunnar Jeannette / Frank Montecalvo
 13 g? #55 AF Corse | Ferrari F458 Italia | Classified 115L gap 7 Laps | Piergiuseppe Perazzini / Marco Cioci / Federico Leo
 15 g? #75 Prospeed Competition | Porsche 911 GT3 RSR | Classified 115L gap 7 Laps | François Perrodo / Emmanuel Collard
 16 g? #88 Proton Competition | Porsche 911 GT3 RSR | Classified 114L gap 8 Laps | Horst Felbermayr / Horst Felbermayr Sr. / Klaus Bachler
 17 g? #67 IMSA Performance Matmut | Porsche 911 GT3 RSR | Classified 114L gap 8 Laps | Patrice Milesi / Jean Vernay
 19 g? #77 Proton Competition | Porsche 911 GT3 RSR | Classified 114L gap 8 Laps | Christian Ried / Gianluca Roda / Nicholas Tandy
 22 g? #54 AF Corse | Ferrari F458 Italia | Classified 112L gap 10 Laps | Yannick Mallegol / Jean-Marc Bachelier / Howard Blank
== GTC
 18 g? #69 SMP Racing | Ferrari F458 Italia GT3 | Classified 114L gap 8 Laps | Fabio Babini / Viktor Shaitar / Kirill Ladygin
 20 g? #62 AF Corse | Ferrari F458 Italia GT3 | Classified 113L gap 9 Laps | Andrea Rizzoli / Stefano Gai / Lorenzo Casé
 21 g? #79 Ecurie Ecosse | BMW Z4 | Classified 112L gap 10 Laps | Ollie Millroy / Andrew Smith / Alasdair Mccaig
 23 g? #60 Kox Racing | Lamborghini Gallardo LP600 GT3 | Classified 112L gap 10 Laps | Peter Kox / Nico Pronk
 24 g? #72 SMP Racing | Ferrari F458 Italia GT3 | Classified 112L gap 10 Laps | Devi Markozov / Alexander Frolov / Luca Persiani
