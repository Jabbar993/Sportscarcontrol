# elms-silverstone-2013

Event: 3 Hours of Silverstone | Circuit: Silverstone | Date: 2013-04-13
Scheduled: 03:00:00 | Official duration: 2:15:22.561 | Laps (winner): 48

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q1 #38 [LMP2] 1:48.032 Jota Sport | Oliver Turvey
Q2 #18 [LMP2] 1:48.863 Murphy Prototypes | Brendon Hartley
Q3 #36 [LMP2] 1:49.063 Signatech Alpine | Nelson Panciatici
Q4 #34 [LMP2] 1:50.010 Race Performance | Patric Niederhauser
Q5 #43 [LMP2] 1:50.139 Morand Racing | Frank Mailleux
Q6 #1 [LMP2] 1:50.157 Thiriet By TDS Racing | Jonathan Hirschi
Q7 #4 [LMP2] 1:52.072 Boutsen Ginion Racing | Bastien Brière
Q8 #3 [LMP2] 1:52.529 Greaves Motorsport | Chris Dyson
Q9 #49 [LMP2] 1:54.102 Team Endurance Challenge | Paul-Loup Chatin
Q10 #48 [LMP2] 1:54.721 Team Endurance Challenge | Soheil Ayari
Q11 #39 [LMP2] 1:55.634 DKR Engineering | Olivier Porta
Q12 #47 [LMP2] 1:58.310 Team Endurance Challenge | Alex Loan
Q13 #52 [LMGTE] 2:02.358 RAM Racing | Johnny Mowlem
Q14 #77 [LMGTE] 2:02.653 Proton Competition | Nicholas Tandy
Q15 #75 [LMGTE] 2:02.685 Prospeed Competition | Emanuel Collard
Q16 #55 [LMGTE] 2:02.731 AF Corse | Federico Leo
Q17 #66 [LMGTE] 2:03.015 JMW Motorsport | Joël Camathias
Q18 #65 [LMP2] 2:03.484 Momo Megatron DF1 | Kuba Giermaziak
Q19 #79 [LMP2] 2:03.737 Ecurie Ecosse | Andrew Smith
Q20 #62 [GTC] 2:04.233 AF Corse | Lorenzo Casè
Q21 #53 [LMGTE] 2:04.412 RAM Racing | Franck Montecalvo
Q22 #54 [LMGTE] 2:05.198 AF Corse | Yannick Mallegol
Q23 #67 [LMGTE] 2:08.745 IMSA Performance Matmut | Patrice Milesi

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #38 Oliver Turvey 1:48.032 Jota Sport
LMP2: #38 Oliver Turvey 1:48.032 Jota Sport
LMGTE: #52 Johnny Mowlem 2:02.358 RAM Racing
GTC: #62 Lorenzo Casè 2:04.233 AF Corse

## Fastest laps (archive)
LMGTE: #77 Nicholas Tandy 2:17.006
GTC: #62 Lorenzo Casè 2:23.579 lap 15
Overall: #18 Brendon Hartley 2:08.869
LMP2: #18 Brendon Hartley 2:08.869

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g? #38 Jota Sport | Zytek Z11SN - Nissan | Classified 48L gap — | Simon Dolan / Oliver Turvey
 2 g? #34 Race Performance | Oreca 03 - Judd | Classified 48L gap 4.619 | Michel Frey / Patric Niederhauser
 3 g? #1 Thiriet By TDS Racing | Oreca 03 - Nissan | Classified 48L gap 5.485 | Pierre Thiriet / Jonathan Hirschi
 4 g? #36 Signatech Alpine | Alpine - Nissan | Classified 48L gap — | Pierre Ragues / Nelson Panciatici
 11 g? #4 Boutsen Ginion Racing | Oreca 03 - Nissan | Classified 46L gap 2 Laps | Bastien Brière / Thomas Dagoneau / John Hatshorne
 15 g? #39 DKR Engineering | Lola B11/40 - Judd | Classified 43L gap 5 Laps | Olivier Porta / Romain Brandela / Stephane Raffin
 17 g? #3 Greaves Motorsport | Zytek Z11SN - Nissan | NC 23L gap NC | Chris Dyson / Michael Marsal
 18 g? #18 Murphy Prototypes | Oreca 03 - Nissan | Classified 41L gap 7 Laps | Brendon Hartley / Mark Patterson
 18 g? #43 Morand Racing | Morgan - Judd | NC 0L gap NC | Natacha Gachnang / Frank Mailleux
== LMGTE
 5 g? #77 Proton Competition | Porsche 911 GT3 RSR | Classified 48L gap 6.699 | Christian Ried / Gianluca Roda / Nicholas Tandy
 6 g? #52 RAM Racing | Ferrari F458 Italia | Classified 47L gap 1 Laps | Johnny Mowlem / Matt Griffin
 7 g? #53 RAM Racing | Ferrari F458 Italia | Classified 47L gap 1 Laps | Gunnar Jeanette / Franck Montecalvo
 8 g? #66 JMW Motorsport | Ferrari F458 Italia | Classified 47L gap 1 Laps | Andrea Bertolini / Joël Camathias
 12 g? #75 Prospeed Competition | Porsche 911 GT3 RSR | Classified 46L gap 2 Laps | François Perrodo / Emanuel Collard / Sebastien Crubilé
 14 g? #67 IMSA Performance Matmut | Porsche 911 GT3 RSR | Classified 44L gap 4 Laps | Patrice Milesi / Wolf Henzler
 16 g? #55 AF Corse | Ferrari F458 Italia | Classified 43L gap 5 Laps | Piergiuseppe Perazzini / Marco Cioci / Federico Leo
 17 g? #54 AF Corse | Ferrari F458 Italia | Classified 42L gap 6 Laps | Yannick Mallegol / Jean-Marc Bachelier / Howard Blank
== GTC
 13 g? #62 AF Corse | Ferrari F458 Italia GT3 | Classified 46L gap 2 Laps | Andrea Rizzoli / Stefano Gai / Lorenzo Casè
