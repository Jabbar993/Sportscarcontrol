# elms-hungaroring-2013

Event: 3 Hours of Hungaroring | Circuit: Hungaroring | Date: 2013-09-14
Scheduled: 03:00:00 | Official duration: 3:01:18.622 | Laps (winner): 99

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q10 #62 [GTC] 2:17.878 AF Corse | Lorenzo Casé
Q12 #69 [GTC] 2:19.524 SMP Racing | Viktor Shaitar
Q13 #83 [GTC] 2:20.996 Easyrace | Fabio Mancini
Q14 #60 [GTC] 2:22.799 Kox Racing | Peter Kox
Q20 #79 [GTC] 2:43.465 Ecurie Ecosse | Ollie Millroy
Q11 #66 [LMGTE] 2:19.363 JMW Motorsport | Andrea Bertolini
Q16 #77 [LMGTE] 2:24.568 Proton Competition | Nicholas Tandy
Q17 #67 [LMGTE] 2:30.589 IMSA Performance Matmut | Jean-Karl Vernay
Q18 #75 [LMGTE] 2:31.706 Prospeed Competition | Emmanuel Collard
Q19 #52 [LMGTE] 2:34.872 RAM Racing | Johnny Mowlem
Q21 #53 [LMGTE] 2:47.476 RAM Racing | Gunnar Jeannette
Q22 #55 [LMGTE] 2:51.096 AF Corse | Federico Leo
Q1 #18 [LMP2] 2:09.301 Murphy Prototypes | Brendon Hartley
Q2 #34 [LMP2] 2:11.394 RACE Performance | Patric Niederhauser
Q3 #36 [LMP2] 2:12.251 Signatech Alpine | Nelson Panciatici
Q4 #37 [LMP2] 2:12.763 SMP Racing | Maurizio Mediani
Q5 #38 [LMP2] 2:13.350 Jota Sport | Oliver Turvey
Q7 #1 [LMP2] 2:16.784 Thiriet by TDS Racing | Mathias Beche
Q8 #43 [LMP2] 2:16.904 Morand Racing | Christian Klien
Q15 #4 [LMP2] 2:23.507 Boutsen Ginion Racing | Alex Kapadia
Q6 #49 [LMPC] 2:13.959 Team Endurance Challenge | Paul Loup Chatin
Q9 #48 [LMPC] 2:16.927 Team Endurance Challenge | Soheil Ayari

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #18 Brendon Hartley 2:09.301 Murphy Prototypes
GTC: #62 Lorenzo Casé 2:17.878 AF Corse
LMGTE: #66 Andrea Bertolini 2:19.363 JMW Motorsport
LMP2: #18 Brendon Hartley 2:09.301 Murphy Prototypes
LMPC: #49 Paul Loup Chatin 2:13.959 Team Endurance Challenge

## Fastest laps (archive)
Overall: #36 Nelson Panciatici 1:37.529
GTC: #72 Luca Persiani 1:47.684
LMGTE: #66 Andrea Bertolini 1:45.343
LMP2: #36 Nelson Panciatici 1:37.529
LMPC: #46 Nicky Catsburg 1:41.351

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g? #36 Signatech Alpine | Alpine - Nissan | Classified 99L gap — | Pierre Ragues / Nelson Panciatici
 2 g? #18 Murphy Prototypes | Oreca 03 - Nissan | Classified 99L gap 38.268 | Brendon Hartley / Jonathan Hirschi
 3 g? #38 Jota Sport | Zytek Z11SN - Nissan | Classified 98L gap 1 Laps | Simon Dolan / Oliver Turvey
 4 g? #37 SMP Racing | Oreca 03 - Nissan | Classified 96L gap 3 Laps | Maurizio Mediani / Serguey Zlobin
 5 g? #43 Morand Racing | Morgan - Judd | Classified 95L gap 4 Laps | Natacha Gachnang / Christian Klien
 6 g? #1 Thiriet by TDS Racing | Oreca 03 - Nissan | Classified 94L gap 5 Laps | Pierre Thiriet / Mathias Beche
 16 g? #4 Boutsen Ginion Racing | Oreca 03 - Nissan | Classified 90L gap 9 Laps | Alex Kapadia / Khaled Al Mudhaf / John Hartshorne
 24 g? #34 RACE Performance | Oreca 03 - Judd | RET 0L gap RET | Michel Frey / Patric Niederhauser
== LMGTE
 7 g? #77 Proton Competition | Porsche 911 GT3 RSR | Classified 93L gap 6 Laps | Christian Ried / Klaus Bachler / Nicholas Tandy
 9 g? #52 RAM Racing | Ferrari F458 Italia | Classified 92L gap 7 Laps | Johnny Mowlem / Matt Griffin
 10 g? #55 AF Corse | Ferrari F458 Italia | Classified 92L gap 7 Laps | Piergiuseppe Perazzini / Marco Cioci / Federico Leo
 11 g? #75 Prospeed Competition | Porsche 911 GT3 RSR | Classified 91L gap 8 Laps | François Perrodo / Emmanuel Collard
 12 g? #67 IMSA Performance Matmut | Porsche 911 GT3 RSR | Classified 91L gap 8 Laps | Patrice Milesi / Jean-Karl Vernay
 13 g? #53 RAM Racing | Ferrari F458 Italia | Classified 91L gap 8 Laps | Gunnar Jeannette / Frank Montecalvo
 21 g? #54 AF Corse | Ferrari F458 Italia | NC 73L gap NC | Yannick Mallegol / Jean-Marc Bachelier / Howard Blank
 22 g? #66 JMW Motorsport | Ferrari F458 Italia | NC 68L gap NC | Andrea Bertolini / Joël Camathias
== LMPC
 8 g? #49 Team Endurance Challenge | Formula Le Mans Oreca 09 | Classified 93L gap 6 Laps | Paul Loup Chatin / Gary Hirsch
 19 g? #48 Team Endurance Challenge | Formula Le Mans Oreca 09 | Classified 79L gap 20 Laps | Anthony Pons / Soheil Ayari
 23 g? #46 Algarve Pro Racing Team | Formula Le Mans Oreca 09 | NC 58L gap NC | Cornelius Jones / Nicky Catsburg
== GTC
 14 g? #69 SMP Racing | Ferrari F458 Italia GT3 | Classified 90L gap 9 Laps | Fabio Babini / Viktor Shaitar / Kirill Ladygin
 15 g? #72 SMP Racing | Ferrari F458 Italia GT3 | Classified 90L gap 9 Laps | Devi Markozov / Alexander Frolov / Luca Persiani
 17 g? #62 AF Corse | Ferrari F458 Italia GT3 | Classified 90L gap 9 Laps | Andrea Rizzoli / Stefano Gai / Lorenzo Casé
 18 g? #83 Easyrace | Ferrari F458 Italia GT3 | Classified 88L gap 11 Laps | Tommaso Rocca / Diego Romanini / Fabio Mancini
 20 g? #79 Ecurie Ecosse | BMW Z4 | NC 77L gap NC | Ollie Millroy / Joe Twyman / Alasdair Mccaig
 25 g? #60 Kox Racing | Lamborghini Gallardo LP600 GT3 | RET 0L gap RET | Peter Kox / Nico Pronk / Dennis Retera
