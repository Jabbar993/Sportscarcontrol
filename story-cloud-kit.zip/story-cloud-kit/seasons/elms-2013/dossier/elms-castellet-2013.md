# elms-castellet-2013

Event: 3 Hours of Le Castellet | Circuit: Paul Ricard | Date: 2013-09-28
Scheduled: 03:00:00 | Official duration: 3:01:04.351 | Laps (winner): 93

## Qualifying (archive order; ELMS lists may be sorted BY CLASS — pos 1 is not necessarily overall pole)
Q16 #68 [GTC] 1:57.012 SMP Racing | Mika Salo
Q17 #69 [GTC] 1:57.038 SMP Racing | Viktor Shaitar
Q20 #86 [GTC] 1:57.866 Scuderia Villorba Corse | Steeve Hiesse
Q21 #72 [GTC] 1:57.952 SMP Racing | Alexander Frolov
Q22 #62 [GTC] 1:58.097 AF Corse | Andrea Rizzoli
Q23 #60 [GTC] 1:58.185 Kox Racing | Peter Kox
Q25 #79 [GTC] 1:58.944 Ecurie Ecosse | Ollie Millroy
Q26 #85 [GTC] 2:00.273 DKR Engineering | Thomas Accary
Q11 #52 [LMGTE] 1:55.374 RAM Racing | Matt Griffin
Q12 #66 [LMGTE] 1:55.427 JMW Motorsport | Andrea Bertolini
Q13 #55 [LMGTE] 1:55.879 AF Corse | Marco Cioci
Q14 #53 [LMGTE] 1:56.132 RAM Racing | Gunnar Jeannette
Q15 #77 [LMGTE] 1:56.390 Proton Competition | Nicholas Tandy
Q18 #67 [LMGTE] 1:57.212 IMSA Performance Matmut | Jean-Karl Vernay
Q19 #75 [LMGTE] 1:57.847 Prospeed Competition | Emmanuel Collard
Q24 #54 [LMGTE] 1:58.381 AF Corse | Yannick Mallegol
Q1 #38 [LMP2] 1:48.043 Jota Sport | Oliver Turvey
Q2 #18 [LMP2] 1:48.140 Murphy Prototypes | Brendon Hartley
Q3 #1 [LMP2] 1:48.974 Thiriet by TDS Racing | Mathias Beche
Q4 #36 [LMP2] 1:49.102 Signatech Alpine | Nelson Panciatici
Q5 #43 [LMP2] 1:49.148 Morand Racing | Christian Klien
Q6 #4 [LMP2] 1:49.360 Boutsen Ginion Racing | Alex Kapadia
Q7 #34 [LMP2] 1:50.918 RACE Performance | Michel Frey
Q8 #37 [LMP2] 1:51.031 SMP Racing | Maurizio Mediani
Q9 #49 [LMPC] 1:52.052 Team Endurance Challenge | Paul Loup Chatin
Q10 #48 [LMPC] 1:54.611 Team Endurance Challenge | Soheil Ayari

## Poles (archive PERF — known to be UNRELIABLE for ELMS; cross-check with grid g1 and sources)
Overall: #38 Oliver Turvey 1:48.043 Jota Sport
GTC: #68 Mika Salo 1:57.012 SMP Racing
LMGTE: #52 Matt Griffin 1:55.374 RAM Racing
LMP2: #38 Oliver Turvey 1:48.043 Jota Sport
LMPC: #49 Paul Loup Chatin 1:52.052 Team Endurance Challenge

## Fastest laps (archive)
Overall: #36 Nelson Panciatici 1:50.242
GTC: #86 Steeve Hiesse 1:58.702
LMGTE: #66 Andrea Bertolini 1:57.854
LMP2: #36 Nelson Panciatici 1:50.242
LMPC: #49 Paul Loup Chatin 1:54.084

## Results by class (pos = OVERALL position; NC = not classified; gN = grid; archive WINS over sources)
== LMP2
 1 g? #18 Murphy Prototypes | Oreca 03 - Nissan | Classified 93L gap — | Brendon Hartley / Jonathan Hirschi
 2 g? #43 Morand Racing | Morgan - Judd | Classified 93L gap 6.255 | Natacha Gachnang / Christian Klien
 3 g? #38 Jota Sport | Zytek Z11SN - Nissan | Classified 93L gap 21.691 | Simon Dolan / Oliver Turvey
 4 g? #36 Signatech Alpine | Alpine - Nissan | Classified 93L gap — | Pierre Ragues / Nelson Panciatici
 5 g? #4 Boutsen Ginion Racing | Oreca 03 - Nissan | Classified 93L gap 14.604 | Alex Kapadia / Renaud Kuppens / James Swift
 6 g? #37 SMP Racing | Oreca 03 - Nissan | Classified 92L gap 1 Laps | Maurizio Mediani / Serguey Zlobin
 7 g? #34 RACE Performance | Oreca 03 - Judd | Classified 91L gap 2 Laps | Michel Frey / Marcello Marateotto
 22 g? #1 Thiriet by TDS Racing | Oreca 03 - Nissan | Classified 86L gap 7 Laps | Pierre Thiriet / Mathias Beche
== LMPC
 8 g? #48 Team Endurance Challenge | Formula Le Mans Oreca 09 | Classified 90L gap 3 Laps | Anthony Pons / Soheil Ayari
 21 g? #49 Team Endurance Challenge | Formula Le Mans Oreca 09 | Classified 86L gap 7 Laps | Paul Loup Chatin / Gary Hirsch
== LMGTE
 9 g? #52 RAM Racing | Ferrari F458 Italia | Classified 90L gap 3 Laps | Johnny Mowlem / Matt Griffin
 10 g? #66 JMW Motorsport | Ferrari F458 Italia | Classified 89L gap 4 Laps | Andrea Bertolini / Joël Camathias
 11 g? #77 Proton Competition | Porsche 911 GT3 RSR | Classified 89L gap 4 Laps | Christian Ried / Klaus Bachler / Nicholas Tandy
 12 g? #55 AF Corse | Ferrari F458 Italia | Classified 89L gap 4 Laps | Piergiuseppe Perazzini / Marco Cioci / Federico Leo
 13 g? #53 RAM Racing | Ferrari F458 Italia | Classified 88L gap 5 Laps | Gunnar Jeannette / Frank Montecalvo
 16 g? #75 Prospeed Competition | Porsche 911 GT3 RSR | Classified 87L gap 6 Laps | François Perrodo / Emmanuel Collard
 17 g? #67 IMSA Performance Matmut | Porsche 911 GT3 RSR | Classified 87L gap 6 Laps | Patrice Milesi / Jean-Karl Vernay
 20 g? #54 AF Corse | Ferrari F458 Italia | Classified 86L gap 7 Laps | Yannick Mallegol / Jean-Marc Bachelier / Howard Blank
== GTC
 14 g? #69 SMP Racing | Ferrari F458 Italia GT3 | Classified 88L gap 5 Laps | Fabio Babini / Viktor Shaitar / Kirill Ladygin
 15 g? #72 SMP Racing | Ferrari F458 Italia GT3 | Classified 87L gap 6 Laps | Devi Markozov / Alexander Frolov / Luca Persiani
 18 g? #86 Scuderia Villorba Corse | Ferrari F458 Italia GT3 | Classified 87L gap 6 Laps | Steeve Hiesse / Cédric Mezard
 19 g? #79 Ecurie Ecosse | BMW Z4 | Classified 86L gap 7 Laps | Ollie Millroy / Andrew Smith / Phil Quaife
 23 g? #68 SMP Racing | Ferrari F458 Italia GT3 | Classified 85L gap 8 Laps | Mika Salo / Boris Rotenberg / Anton Ladygin
 24 g? #85 DKR Engineering | BMW Z4 GT3 Spec 2011 | Classified 85L gap 8 Laps | Matthieu Lecuyer / Thomas Accary / Dimitri Enjalbert
 25 g? #62 AF Corse | Ferrari F458 Italia GT3 | Classified 82L gap 11 Laps | Andrea Rizzoli / Stefano Gai / Lorenzo Casé
 26 g? #60 Kox Racing | Lamborghini Gallardo LP600 GT3 | NC 61L gap NC | Peter Kox / Nico Pronk / Dennis Retera
